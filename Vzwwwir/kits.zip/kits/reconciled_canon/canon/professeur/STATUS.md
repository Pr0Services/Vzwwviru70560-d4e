STATUS: CANON
Source: CHE_NU_Professeur_Kit_v1.zip
Role: Stability, failure marking, anti-drift.
