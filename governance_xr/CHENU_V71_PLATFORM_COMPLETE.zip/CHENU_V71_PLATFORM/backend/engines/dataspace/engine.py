"""
CHE·NU™ V70 — DATASPACE ENGINE
==============================
Main DataSpace engine for intelligent governed storage.

Based on: DATASPACE_ENGINE_CHAPTER.md

Core Principle: A DataSpace = a "self-contained OS micro-environment"
that understands its contents, maintains its history, respects its
governance rules, and serves its designated purpose.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple
from uuid import uuid4
import logging

from .models import (
    # Enums
    DataSpaceType,
    DataSpaceStatus,
    ContentType,
    DocumentType,
    MediaType,
    TaskStatus,
    TaskPriority,
    DiagramType,
    HierarchyLevel,
    # Content Models
    DataSpaceDocument,
    DataSpaceTask,
    DataSpaceMedia,
    DataSpaceDiagram,
    DataSpaceXRScene,
    DataSpaceTimeline,
    AgentMemory,
    DataSpaceDecision,
    DataSpaceRelationship,
    # DataSpace
    DataSpace,
    DataSpaceMetadata,
    # Factories
    create_dataspace,
    create_project_dataspace,
    create_building_dataspace,
    create_meeting_dataspace,
)

logger = logging.getLogger("chenu.dataspace.engine")


# =============================================================================
# DATASPACE ENGINE
# =============================================================================

class DataSpaceEngine:
    """
    CHE·NU DataSpace Engine.
    
    Manages intelligent, governed storage across the entire system.
    
    Features:
    - Hierarchical DataSpace management
    - Multi-content type support
    - Governance enforcement
    - Relationship management
    - Search and discovery
    - Version control
    - Agent memory governance
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        # DataSpace storage
        self._dataspaces: Dict[str, DataSpace] = {}
        
        # Index by type
        self._by_type: Dict[DataSpaceType, Set[str]] = {t: set() for t in DataSpaceType}
        
        # Index by owner
        self._by_owner: Dict[str, Set[str]] = {}
        
        # Index by sphere
        self._by_sphere: Dict[str, Set[str]] = {}
        
        # Index by domain
        self._by_domain: Dict[str, Set[str]] = {}
        
        # Relationship index
        self._relationships: Dict[str, List[DataSpaceRelationship]] = {}
        
        logger.info("DataSpaceEngine initialized")
    
    # =========================================================================
    # DATASPACE CRUD
    # =========================================================================
    
    def create(
        self,
        title: str,
        dataspace_type: DataSpaceType,
        owner_id: str,
        sphere: str = "personal",
        domain: str = "general",
        parent_id: Optional[str] = None,
    ) -> DataSpace:
        """Create a new DataSpace."""
        # Validate parent if specified
        if parent_id and parent_id not in self._dataspaces:
            raise ValueError(f"Parent DataSpace not found: {parent_id}")
        
        # Create DataSpace
        ds = create_dataspace(
            title=title,
            dataspace_type=dataspace_type,
            owner_id=owner_id,
            sphere=sphere,
            domain=domain,
            parent_id=parent_id,
        )
        
        # Store
        self._dataspaces[ds.dataspace_id] = ds
        
        # Update indices
        self._by_type[dataspace_type].add(ds.dataspace_id)
        
        if owner_id not in self._by_owner:
            self._by_owner[owner_id] = set()
        self._by_owner[owner_id].add(ds.dataspace_id)
        
        if sphere not in self._by_sphere:
            self._by_sphere[sphere] = set()
        self._by_sphere[sphere].add(ds.dataspace_id)
        
        if domain not in self._by_domain:
            self._by_domain[domain] = set()
        self._by_domain[domain].add(ds.dataspace_id)
        
        # Update parent
        if parent_id:
            parent = self._dataspaces[parent_id]
            parent.children_ids.append(ds.dataspace_id)
        
        logger.info(f"Created DataSpace: {ds.dataspace_id} ({dataspace_type.value})")
        
        return ds
    
    def get(self, dataspace_id: str) -> Optional[DataSpace]:
        """Get DataSpace by ID."""
        return self._dataspaces.get(dataspace_id)
    
    def update(
        self,
        dataspace_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[DataSpaceStatus] = None,
    ) -> Optional[DataSpace]:
        """Update DataSpace metadata."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        if title:
            ds.title = title
        if description:
            ds.description = description
        if status:
            ds.metadata.status = status
        
        ds.metadata.modified_at = datetime.utcnow()
        ds.metadata.version += 1
        
        logger.info(f"Updated DataSpace: {dataspace_id}")
        
        return ds
    
    def delete(self, dataspace_id: str, soft: bool = True) -> bool:
        """Delete DataSpace (soft delete by default)."""
        ds = self.get(dataspace_id)
        if not ds:
            return False
        
        if soft:
            ds.metadata.status = DataSpaceStatus.DELETED
            ds.metadata.modified_at = datetime.utcnow()
        else:
            # Hard delete - remove from all indices
            self._by_type[ds.metadata.dataspace_type].discard(dataspace_id)
            self._by_owner.get(ds.metadata.owner_id, set()).discard(dataspace_id)
            self._by_sphere.get(ds.metadata.sphere, set()).discard(dataspace_id)
            self._by_domain.get(ds.metadata.domain, set()).discard(dataspace_id)
            del self._dataspaces[dataspace_id]
        
        logger.info(f"Deleted DataSpace: {dataspace_id} (soft={soft})")
        
        return True
    
    def archive(self, dataspace_id: str) -> bool:
        """Archive DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return False
        
        ds.metadata.status = DataSpaceStatus.ARCHIVED
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.info(f"Archived DataSpace: {dataspace_id}")
        
        return True
    
    # =========================================================================
    # HIERARCHY
    # =========================================================================
    
    def get_children(self, dataspace_id: str) -> List[DataSpace]:
        """Get child DataSpaces."""
        ds = self.get(dataspace_id)
        if not ds:
            return []
        
        return [self.get(cid) for cid in ds.children_ids if self.get(cid)]
    
    def get_parent(self, dataspace_id: str) -> Optional[DataSpace]:
        """Get parent DataSpace."""
        ds = self.get(dataspace_id)
        if not ds or not ds.parent_id:
            return None
        
        return self.get(ds.parent_id)
    
    def get_ancestors(self, dataspace_id: str) -> List[DataSpace]:
        """Get all ancestors up to root."""
        ancestors = []
        current = self.get(dataspace_id)
        
        while current and current.parent_id:
            parent = self.get(current.parent_id)
            if parent:
                ancestors.append(parent)
                current = parent
            else:
                break
        
        return ancestors
    
    def get_descendants(self, dataspace_id: str) -> List[DataSpace]:
        """Get all descendants recursively."""
        descendants = []
        ds = self.get(dataspace_id)
        if not ds:
            return descendants
        
        def collect(ds_id: str):
            ds = self.get(ds_id)
            if ds:
                for child_id in ds.children_ids:
                    child = self.get(child_id)
                    if child:
                        descendants.append(child)
                        collect(child_id)
        
        collect(dataspace_id)
        return descendants
    
    # =========================================================================
    # CONTENT MANAGEMENT
    # =========================================================================
    
    def add_document(
        self,
        dataspace_id: str,
        document_type: DocumentType,
        title: str,
        content: str = "",
        author_id: str = "",
        tags: List[str] = None,
    ) -> Optional[DataSpaceDocument]:
        """Add document to DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        doc = DataSpaceDocument(
            document_type=document_type,
            title=title,
            content=content,
            author_id=author_id,
            tags=tags or [],
            synthetic=True,  # GOVERNANCE
        )
        
        ds.documents.append(doc)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added document {doc.document_id} to DataSpace {dataspace_id}")
        
        return doc
    
    def add_task(
        self,
        dataspace_id: str,
        title: str,
        description: str = "",
        priority: TaskPriority = TaskPriority.MEDIUM,
        due_date: Optional[datetime] = None,
        assignee_id: Optional[str] = None,
    ) -> Optional[DataSpaceTask]:
        """Add task to DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        task = DataSpaceTask(
            title=title,
            description=description,
            priority=priority,
            due_date=due_date,
            assignee_id=assignee_id,
            synthetic=True,  # GOVERNANCE
        )
        
        ds.tasks.append(task)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added task {task.task_id} to DataSpace {dataspace_id}")
        
        return task
    
    def add_media(
        self,
        dataspace_id: str,
        media_type: MediaType,
        filename: str,
        file_path: str,
        title: str = "",
    ) -> Optional[DataSpaceMedia]:
        """Add media to DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        media = DataSpaceMedia(
            media_type=media_type,
            filename=filename,
            file_path=file_path,
            title=title or filename,
            synthetic=True,  # GOVERNANCE
        )
        
        ds.media.append(media)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added media {media.media_id} to DataSpace {dataspace_id}")
        
        return media
    
    def add_diagram(
        self,
        dataspace_id: str,
        diagram_type: DiagramType,
        title: str,
        source_code: str,
    ) -> Optional[DataSpaceDiagram]:
        """Add diagram to DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        diagram = DataSpaceDiagram(
            diagram_type=diagram_type,
            title=title,
            source_code=source_code,
            synthetic=True,  # GOVERNANCE
        )
        
        ds.diagrams.append(diagram)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added diagram {diagram.diagram_id} to DataSpace {dataspace_id}")
        
        return diagram
    
    def add_xr_scene(
        self,
        dataspace_id: str,
        scene_type: str,
        title: str,
    ) -> Optional[DataSpaceXRScene]:
        """
        Add XR scene to DataSpace (READ ONLY).
        
        CRITICAL: XR scenes are always read-only.
        """
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        scene = DataSpaceXRScene(
            scene_type=scene_type,
            title=title,
            read_only=True,  # GOVERNANCE: Always read-only
        )
        
        ds.xr_scenes.append(scene)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added XR scene {scene.scene_id} to DataSpace {dataspace_id} (READ ONLY)")
        
        return scene
    
    def add_decision(
        self,
        dataspace_id: str,
        title: str,
        description: str,
        decision_maker: str,
        options: List[Dict[str, Any]] = None,
    ) -> Optional[DataSpaceDecision]:
        """Add decision to DataSpace."""
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        decision = DataSpaceDecision(
            title=title,
            description=description,
            decision_maker=decision_maker,
            options_considered=options or [],
            hitl_approved=False,  # GOVERNANCE: Requires HITL
            synthetic=True,
        )
        
        ds.decisions.append(decision)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added decision {decision.decision_id} to DataSpace {dataspace_id}")
        
        return decision
    
    # =========================================================================
    # AGENT MEMORY (GOVERNED)
    # =========================================================================
    
    def add_agent_memory(
        self,
        dataspace_id: str,
        agent_id: str,
        memory_type: str,
        key: str,
        value: Any,
        admin_approved: bool = False,
    ) -> Optional[AgentMemory]:
        """
        Add agent memory to DataSpace (GOVERNED).
        
        Rules:
        - NO personal data
        - Scoped to DataSpace only
        - User can view/delete
        - Cannot cross identity boundaries
        """
        ds = self.get(dataspace_id)
        if not ds:
            return None
        
        memory = AgentMemory(
            dataspace_id=dataspace_id,
            agent_id=agent_id,
            memory_type=memory_type,
            key=key,
            value=value,
            admin_approved=admin_approved,
            user_deletable=True,  # GOVERNANCE: Always deletable
            synthetic=True,
        )
        
        ds.agent_memories.append(memory)
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.debug(f"Added agent memory {memory.memory_id} to DataSpace {dataspace_id}")
        
        return memory
    
    def delete_agent_memory(
        self,
        dataspace_id: str,
        memory_id: str,
    ) -> bool:
        """Delete agent memory (user right to delete)."""
        ds = self.get(dataspace_id)
        if not ds:
            return False
        
        ds.agent_memories = [m for m in ds.agent_memories if m.memory_id != memory_id]
        ds.metadata.modified_at = datetime.utcnow()
        
        logger.info(f"Deleted agent memory {memory_id} from DataSpace {dataspace_id}")
        
        return True
    
    def get_agent_memories(
        self,
        dataspace_id: str,
        agent_id: Optional[str] = None,
    ) -> List[AgentMemory]:
        """Get agent memories (user can view all)."""
        ds = self.get(dataspace_id)
        if not ds:
            return []
        
        memories = ds.agent_memories
        
        if agent_id:
            memories = [m for m in memories if m.agent_id == agent_id]
        
        return memories
    
    # =========================================================================
    # RELATIONSHIPS
    # =========================================================================
    
    def create_relationship(
        self,
        source_id: str,
        target_id: str,
        relationship_type: str,
        bidirectional: bool = False,
    ) -> Optional[DataSpaceRelationship]:
        """
        Create relationship between DataSpaces.
        
        GOVERNANCE: Must be same identity.
        """
        source = self.get(source_id)
        target = self.get(target_id)
        
        if not source or not target:
            return None
        
        # GOVERNANCE: Check same identity
        if source.metadata.identity_id != target.metadata.identity_id:
            logger.warning(
                f"Cannot create cross-identity relationship: "
                f"{source_id} -> {target_id}"
            )
            return None
        
        rel = DataSpaceRelationship(
            source_dataspace_id=source_id,
            target_dataspace_id=target_id,
            relationship_type=relationship_type,
            bidirectional=bidirectional,
            same_identity=True,
            synthetic=True,
        )
        
        source.relationships.append(rel)
        
        if bidirectional:
            reverse_rel = DataSpaceRelationship(
                source_dataspace_id=target_id,
                target_dataspace_id=source_id,
                relationship_type=relationship_type,
                bidirectional=True,
                same_identity=True,
                synthetic=True,
            )
            target.relationships.append(reverse_rel)
        
        logger.debug(f"Created relationship: {source_id} -> {target_id} ({relationship_type})")
        
        return rel
    
    def get_related(
        self,
        dataspace_id: str,
        relationship_type: Optional[str] = None,
    ) -> List[DataSpace]:
        """Get related DataSpaces."""
        ds = self.get(dataspace_id)
        if not ds:
            return []
        
        rels = ds.relationships
        
        if relationship_type:
            rels = [r for r in rels if r.relationship_type == relationship_type]
        
        related = []
        for rel in rels:
            target = self.get(rel.target_dataspace_id)
            if target:
                related.append(target)
        
        return related
    
    # =========================================================================
    # SEARCH
    # =========================================================================
    
    def list_by_owner(
        self,
        owner_id: str,
        status: Optional[DataSpaceStatus] = None,
    ) -> List[DataSpace]:
        """List DataSpaces by owner."""
        ds_ids = self._by_owner.get(owner_id, set())
        dataspaces = [self.get(ds_id) for ds_id in ds_ids if self.get(ds_id)]
        
        if status:
            dataspaces = [ds for ds in dataspaces if ds.metadata.status == status]
        
        return dataspaces
    
    def list_by_type(
        self,
        dataspace_type: DataSpaceType,
        status: Optional[DataSpaceStatus] = None,
    ) -> List[DataSpace]:
        """List DataSpaces by type."""
        ds_ids = self._by_type.get(dataspace_type, set())
        dataspaces = [self.get(ds_id) for ds_id in ds_ids if self.get(ds_id)]
        
        if status:
            dataspaces = [ds for ds in dataspaces if ds.metadata.status == status]
        
        return dataspaces
    
    def list_by_sphere(
        self,
        sphere: str,
        status: Optional[DataSpaceStatus] = None,
    ) -> List[DataSpace]:
        """List DataSpaces by sphere."""
        ds_ids = self._by_sphere.get(sphere, set())
        dataspaces = [self.get(ds_id) for ds_id in ds_ids if self.get(ds_id)]
        
        if status:
            dataspaces = [ds for ds in dataspaces if ds.metadata.status == status]
        
        return dataspaces
    
    def search(
        self,
        query: str,
        owner_id: Optional[str] = None,
        sphere: Optional[str] = None,
        domain: Optional[str] = None,
        dataspace_type: Optional[DataSpaceType] = None,
    ) -> List[DataSpace]:
        """Search DataSpaces by query."""
        results = []
        query_lower = query.lower()
        
        for ds in self._dataspaces.values():
            # Apply filters
            if owner_id and ds.metadata.owner_id != owner_id:
                continue
            if sphere and ds.metadata.sphere != sphere:
                continue
            if domain and ds.metadata.domain != domain:
                continue
            if dataspace_type and ds.metadata.dataspace_type != dataspace_type:
                continue
            
            # Search in title and description
            if query_lower in ds.title.lower() or query_lower in ds.description.lower():
                results.append(ds)
                continue
            
            # Search in tags
            all_tags = ds.metadata.user_tags + ds.metadata.ai_tags
            if any(query_lower in tag.lower() for tag in all_tags):
                results.append(ds)
                continue
            
            # Search in document titles
            if any(query_lower in doc.title.lower() for doc in ds.documents):
                results.append(ds)
                continue
        
        return results
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        total = len(self._dataspaces)
        active = sum(
            1 for ds in self._dataspaces.values()
            if ds.metadata.status == DataSpaceStatus.ACTIVE
        )
        
        by_type = {
            t.value: len(ids) for t, ids in self._by_type.items()
        }
        
        return {
            "total_dataspaces": total,
            "active_dataspaces": active,
            "by_type": by_type,
            "total_owners": len(self._by_owner),
            "total_spheres": len(self._by_sphere),
            "total_domains": len(self._by_domain),
            "governance": {
                "synthetic_only": True,
                "xr_read_only": True,
                "agent_memory_deletable": True,
                "same_identity_relationships": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_dataspace_engine: Optional[DataSpaceEngine] = None


def get_dataspace_engine() -> DataSpaceEngine:
    """Get the DataSpace engine singleton."""
    global _dataspace_engine
    if _dataspace_engine is None:
        _dataspace_engine = DataSpaceEngine()
    return _dataspace_engine
