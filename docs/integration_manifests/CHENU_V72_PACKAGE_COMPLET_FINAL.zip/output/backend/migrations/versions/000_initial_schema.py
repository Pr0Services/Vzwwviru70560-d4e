"""
CHE·NU™ Initial Migration: Create All Core Tables
=================================================

Revision ID: 000_initial
Revises: None (Initial Migration)
Create Date: 2026-01-07

This migration creates the complete CHE·NU database schema:
- Users & Authentication
- Spheres & Bureau Sections
- Threads & Events (APPEND-ONLY)
- Decisions & Actions
- Snapshots for Memory Compression

R&D COMPLIANCE:
✅ All tables have: id (UUID), created_at
✅ User-owned tables have: created_by (identity boundary)
✅ Event tables are IMMUTABLE (no update triggers)
✅ Proper indexes for performance
✅ Foreign key constraints with appropriate ON DELETE
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# Revision identifiers
revision: str = "000_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Create all CHE·NU core tables."""
    
    # ========================================================================
    # USERS & AUTHENTICATION
    # ========================================================================
    
    # Users table
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("first_name", sa.String(100), nullable=True),
        sa.Column("last_name", sa.String(100), nullable=True),
        sa.Column("display_name", sa.String(200), nullable=True),
        sa.Column("avatar_url", sa.String(500), nullable=True),
        sa.Column("is_active", sa.Boolean, default=True, nullable=False),
        sa.Column("is_verified", sa.Boolean, default=False, nullable=False),
        sa.Column("is_superuser", sa.Boolean, default=False, nullable=False),
        sa.Column("preferences", postgresql.JSONB, default={}, nullable=False),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)
    op.create_index("ix_users_is_active", "users", ["is_active"])
    
    # Refresh tokens table
    op.create_table(
        "refresh_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("device_info", sa.String(500), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("is_revoked", sa.Boolean, default=False, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_refresh_tokens_user_id", "refresh_tokens", ["user_id"])
    op.create_index("ix_refresh_tokens_token_hash", "refresh_tokens", ["token_hash"], unique=True)
    op.create_index("ix_refresh_tokens_expires_at", "refresh_tokens", ["expires_at"])
    
    # Password reset tokens table
    op.create_table(
        "password_reset_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("token_hash", sa.String(255), nullable=False, unique=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("is_used", sa.Boolean, default=False, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_password_reset_tokens_token_hash", "password_reset_tokens", ["token_hash"], unique=True)
    
    # ========================================================================
    # SPHERES & BUREAU SECTIONS
    # ========================================================================
    
    # Spheres table - The 9 life spheres
    op.create_table(
        "spheres",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("identity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sphere_type", sa.String(50), nullable=False),  # personal, business, government, etc.
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("icon", sa.String(50), nullable=True),
        sa.Column("color", sa.String(20), nullable=True),
        sa.Column("display_order", sa.Integer, default=0, nullable=False),
        sa.Column("is_active", sa.Boolean, default=True, nullable=False),
        sa.Column("settings", postgresql.JSONB, default={}, nullable=False),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("thread_count", sa.Integer, default=0, nullable=False),
        sa.Column("active_thread_count", sa.Integer, default=0, nullable=False),
        sa.Column("last_activity_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
    )
    op.create_index("ix_spheres_identity_id", "spheres", ["identity_id"])
    op.create_index("ix_spheres_identity_type", "spheres", ["identity_id", "sphere_type"], unique=True)
    op.create_index("ix_spheres_identity_order", "spheres", ["identity_id", "display_order"])
    
    # Bureau sections table - 6 sections per sphere
    op.create_table(
        "bureau_sections",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("sphere_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("spheres.id", ondelete="CASCADE"), nullable=False),
        sa.Column("section_type", sa.String(50), nullable=False),  # quick_capture, resume_workspace, threads, etc.
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("icon", sa.String(50), nullable=True),
        sa.Column("display_order", sa.Integer, default=0, nullable=False),
        sa.Column("is_visible", sa.Boolean, default=True, nullable=False),
        sa.Column("settings", postgresql.JSONB, default={}, nullable=False),
        sa.Column("item_count", sa.Integer, default=0, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
    )
    op.create_index("ix_bureau_sections_sphere_id", "bureau_sections", ["sphere_id"])
    op.create_index("ix_bureau_sections_sphere_type", "bureau_sections", ["sphere_id", "section_type"], unique=True)
    
    # Quick capture items table - Inbox items
    op.create_table(
        "quick_capture_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("section_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("bureau_sections.id", ondelete="CASCADE"), nullable=False),
        sa.Column("identity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("content_type", sa.String(50), default="text", nullable=False),  # text, voice, image, link
        sa.Column("source", sa.String(100), nullable=True),
        sa.Column("is_processed", sa.Boolean, default=False, nullable=False),
        sa.Column("processed_thread_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    op.create_index("ix_quick_capture_section_id", "quick_capture_items", ["section_id"])
    op.create_index("ix_quick_capture_identity_id", "quick_capture_items", ["identity_id"])
    op.create_index("ix_quick_capture_unprocessed", "quick_capture_items", ["section_id", "is_processed"])
    
    # ========================================================================
    # THREADS - THE CORE APPEND-ONLY ENGINE
    # ========================================================================
    
    # Threads table - The heart of CHE·NU
    op.create_table(
        "threads",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("identity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sphere_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("spheres.id", ondelete="SET NULL"), nullable=True),
        sa.Column("parent_thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="SET NULL"), nullable=True),
        # FOUNDING INTENT IS IMMUTABLE - Never update this field!
        sa.Column("founding_intent", sa.Text, nullable=False),
        sa.Column("title", sa.String(500), nullable=True),
        sa.Column("current_intent", sa.Text, nullable=True),  # Can be refined, founding_intent stays
        sa.Column("thread_type", sa.String(50), default="personal", nullable=False),  # personal, collective, institutional
        sa.Column("status", sa.String(50), default="active", nullable=False),  # active, paused, archived, completed
        sa.Column("visibility", sa.String(50), default="private", nullable=False),  # private, semi_private, public
        sa.Column("tags", postgresql.ARRAY(sa.String(100)), default=[], nullable=False),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        # Counters for quick access
        sa.Column("event_count", sa.Integer, default=0, nullable=False),
        sa.Column("decision_count", sa.Integer, default=0, nullable=False),
        sa.Column("action_count", sa.Integer, default=0, nullable=False),
        sa.Column("pending_action_count", sa.Integer, default=0, nullable=False),
        # Timestamps
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    op.create_index("ix_threads_identity_id", "threads", ["identity_id"])
    op.create_index("ix_threads_identity_sphere", "threads", ["identity_id", "sphere_id"])
    op.create_index("ix_threads_identity_status", "threads", ["identity_id", "status"])
    op.create_index("ix_threads_parent_id", "threads", ["parent_thread_id"])
    op.create_index("ix_threads_sphere_id", "threads", ["sphere_id"])
    
    # Thread events table - IMMUTABLE APPEND-ONLY LOG
    op.create_table(
        "thread_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="CASCADE"), nullable=False),
        sa.Column("sequence_number", sa.Integer, nullable=False),  # Deterministic ordering
        sa.Column("parent_event_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("thread_events.id", ondelete="SET NULL"), nullable=True),  # Causal ordering
        sa.Column("event_type", sa.String(100), nullable=False),  # thread.created, decision.recorded, etc.
        sa.Column("payload", postgresql.JSONB, nullable=False),  # Event-specific data
        sa.Column("summary", sa.Text, nullable=True),  # Human-readable summary
        sa.Column("source", sa.String(100), nullable=True),  # user, agent, system
        sa.Column("agent_id", postgresql.UUID(as_uuid=True), nullable=True),  # If from agent
        # IMMUTABLE - No updated_at, events are never modified
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    # CRITICAL: Unique constraint on thread_id + sequence_number for ordering integrity
    op.create_index("ix_thread_events_thread_seq", "thread_events", ["thread_id", "sequence_number"], unique=True)
    op.create_index("ix_thread_events_thread_id", "thread_events", ["thread_id"])
    op.create_index("ix_thread_events_type", "thread_events", ["event_type"])
    op.create_index("ix_thread_events_created_at", "thread_events", ["created_at"])
    
    # Thread decisions table - Queryable view of decisions
    op.create_table(
        "thread_decisions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("thread_events.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("rationale", sa.Text, nullable=True),
        sa.Column("options_considered", postgresql.JSONB, default=[], nullable=False),  # List of options
        sa.Column("chosen_option", sa.String(500), nullable=True),
        sa.Column("is_active", sa.Boolean, default=True, nullable=False),  # False if superseded
        sa.Column("supersedes_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("thread_decisions.id", ondelete="SET NULL"), nullable=True),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    op.create_index("ix_thread_decisions_thread_id", "thread_decisions", ["thread_id"])
    op.create_index("ix_thread_decisions_active", "thread_decisions", ["thread_id", "is_active"])
    
    # Thread actions table - Action items with status tracking
    op.create_table(
        "thread_actions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("thread_events.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("description", sa.Text, nullable=True),
        sa.Column("status", sa.String(50), default="pending", nullable=False),  # pending, in_progress, completed, cancelled
        sa.Column("priority", sa.String(20), default="medium", nullable=False),  # low, medium, high, urgent
        sa.Column("due_date", sa.DateTime(timezone=True), nullable=True),
        sa.Column("assignee_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), onupdate=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    op.create_index("ix_thread_actions_thread_id", "thread_actions", ["thread_id"])
    op.create_index("ix_thread_actions_status", "thread_actions", ["thread_id", "status"])
    op.create_index("ix_thread_actions_due_date", "thread_actions", ["due_date"])
    
    # Thread snapshots table - Memory compression
    op.create_table(
        "thread_snapshots",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="CASCADE"), nullable=False),
        sa.Column("event_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("thread_events.id", ondelete="CASCADE"), nullable=True),  # Event that triggered snapshot
        sa.Column("sequence_number", sa.Integer, nullable=False),  # Snapshot at this event sequence
        sa.Column("snapshot_type", sa.String(50), default="auto", nullable=False),  # auto, manual, milestone
        sa.Column("summary", sa.Text, nullable=False),
        sa.Column("state", postgresql.JSONB, nullable=False),  # Full state at snapshot time
        sa.Column("key_decisions", postgresql.JSONB, default=[], nullable=False),
        sa.Column("active_actions", postgresql.JSONB, default=[], nullable=False),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("created_by", postgresql.UUID(as_uuid=True), nullable=False),
    )
    op.create_index("ix_thread_snapshots_thread_id", "thread_snapshots", ["thread_id"])
    op.create_index("ix_thread_snapshots_latest", "thread_snapshots", ["thread_id", "sequence_number"])
    
    # ========================================================================
    # GOVERNANCE - Checkpoints & Audit
    # ========================================================================
    
    # Checkpoints table - Human gates
    op.create_table(
        "governance_checkpoints",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("identity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("thread_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("threads.id", ondelete="SET NULL"), nullable=True),
        sa.Column("checkpoint_type", sa.String(50), nullable=False),  # governance, cost, identity, sensitive
        sa.Column("reason", sa.Text, nullable=False),
        sa.Column("action_data", postgresql.JSONB, nullable=False),  # The pending action
        sa.Column("options", postgresql.JSONB, default=["approve", "reject"], nullable=False),
        sa.Column("status", sa.String(50), default="pending", nullable=False),  # pending, approved, rejected, expired
        sa.Column("resolution", sa.String(50), nullable=True),  # Which option was chosen
        sa.Column("resolution_reason", sa.Text, nullable=True),
        sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("resolved_by", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("metadata", postgresql.JSONB, default={}, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_checkpoints_identity_id", "governance_checkpoints", ["identity_id"])
    op.create_index("ix_checkpoints_status", "governance_checkpoints", ["identity_id", "status"])
    op.create_index("ix_checkpoints_thread_id", "governance_checkpoints", ["thread_id"])
    
    # Audit log table - Complete audit trail
    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("identity_id", postgresql.UUID(as_uuid=True), sa.ForeignKey("users.id", ondelete="SET NULL"), nullable=True),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("resource_type", sa.String(100), nullable=False),
        sa.Column("resource_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("details", postgresql.JSONB, default={}, nullable=False),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("user_agent", sa.String(500), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
    )
    op.create_index("ix_audit_logs_identity_id", "audit_logs", ["identity_id"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])
    op.create_index("ix_audit_logs_resource", "audit_logs", ["resource_type", "resource_id"])
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])
    
    print("✅ CHE·NU Initial Migration Complete!")
    print("   - Users & Authentication tables created")
    print("   - Spheres & Bureau Sections tables created")
    print("   - Threads (APPEND-ONLY) tables created")
    print("   - Governance tables created")


def downgrade() -> None:
    """
    Drop all tables in reverse order.
    
    WARNING: This will DELETE ALL DATA!
    Use with extreme caution in production.
    """
    # Governance
    op.drop_table("audit_logs")
    op.drop_table("governance_checkpoints")
    
    # Threads
    op.drop_table("thread_snapshots")
    op.drop_table("thread_actions")
    op.drop_table("thread_decisions")
    op.drop_table("thread_events")
    op.drop_table("threads")
    
    # Spheres
    op.drop_table("quick_capture_items")
    op.drop_table("bureau_sections")
    op.drop_table("spheres")
    
    # Authentication
    op.drop_table("password_reset_tokens")
    op.drop_table("refresh_tokens")
    op.drop_table("users")
    
    print("⚠️ CHE·NU tables dropped!")
