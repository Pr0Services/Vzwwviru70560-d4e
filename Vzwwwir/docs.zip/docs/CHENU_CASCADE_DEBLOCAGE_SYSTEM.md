# 🔗 CHE·NU™ — CASCADES DE DÉBLOCAGE & DÉPENDANCES

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║           🔗 SYSTÈME DE CASCADES — ORDRE COMPLET                            ║
║                                                                              ║
║     "Chaque déblocage ouvre des portes — Dans le bon ordre"                 ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Version**: 1.0
**Date**: 23 Décembre 2025

---

# 1. ARBRE MAÎTRE DES DÉBLOCAGES

## 1.1 Vue Globale — L'Arbre Complet

```
                                    ┌─────────────────────┐
                                    │    INSCRIPTION      │
                                    │      (T=0)          │
                                    └──────────┬──────────┘
                                               │
                    ╔══════════════════════════╧══════════════════════════╗
                    ║              NIVEAU 0: FONDAMENTAUX                 ║
                    ║           (Collecte automatique/obligatoire)        ║
                    ╠═════════════════════════════════════════════════════╣
                    ║  P000: Identité (nom, email)                        ║
                    ║  P001: Langue préférée                               ║
                    ║  P002: Conditions acceptées                          ║
                    ║  P003: Timezone (auto-détecté)                       ║
                    ╚══════════════════════════╤══════════════════════════╝
                                               │
                                               ▼
                                    ┌─────────────────────┐
                                    │   ACCÈS CHE·NU      │
                                    │   TUT-000 Auto      │
                                    │   "Bienvenue"       │
                                    └──────────┬──────────┘
                                               │
                    ╔══════════════════════════╧══════════════════════════╗
                    ║              NIVEAU 1: DÉCOUVERTE                    ║
                    ║              (Jour 1 - Exploration)                  ║
                    ╠═════════════════════════════════════════════════════╣
                    ║                                                     ║
                    ║  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ ║
                    ║  │ 1ère SPHÈRE │  │ 1er THREAD  │  │ 1er UPLOAD  │ ║
                    ║  │   VISITÉE   │  │    CRÉÉ     │  │             │ ║
                    ║  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘ ║
                    ║         │                │                │        ║
                    ║         ▼                ▼                ▼        ║
                    ║  TUT-001 Sphères  TUT-003 Threads  TUT-004 Files   ║
                    ║  P010: Sphère     P011: Thread     P012: Type      ║
                    ║  principale      usage            fichiers         ║
                    ║                                                     ║
                    ╚══════════════════════════╤══════════════════════════╝
                                               │
                                               ▼
                    ╔══════════════════════════════════════════════════════╗
                    ║              NIVEAU 2: CONTEXTUALISATION             ║
                    ║              (Semaine 1 - Patterns détectés)         ║
                    ╠═════════════════════════════════════════════════════╣
                    ║                                                     ║
                    ║  SELON SPHÈRE PRINCIPALE DÉTECTÉE (P010):           ║
                    ║                                                     ║
                    ║  ┌─────────────────────────────────────────────────┐║
                    ║  │ Si P010 = Personal                              │║
                    ║  │ └─▶ Branche PERSONNEL (voir section 2)         │║
                    ║  ├─────────────────────────────────────────────────┤║
                    ║  │ Si P010 = Business                              │║
                    ║  │ └─▶ Branche BUSINESS (voir section 3)          │║
                    ║  ├─────────────────────────────────────────────────┤║
                    ║  │ Si P010 = Creative                              │║
                    ║  │ └─▶ Branche CREATIVE (voir section 4)          │║
                    ║  ├─────────────────────────────────────────────────┤║
                    ║  │ Si P010 = Government                            │║
                    ║  │ └─▶ Branche GOVERNMENT (voir section 5)        │║
                    ║  └─────────────────────────────────────────────────┘║
                    ║                                                     ║
                    ╚══════════════════════════════════════════════════════╝
```

---

# 2. BRANCHE PERSONNEL — Cascade Complète

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    BRANCHE PERSONNEL 🏠 — CASCADE COMPLÈTE                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ENTRÉE: P010 = Personal (sphère principale)                               │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  NIVEAU 2.1: CONTEXTE PERSONNEL                                            │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Détection automatique (observation actions):                               │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │   ACTION DÉTECTÉE              PIÈCE COLLECTÉE        DÉBLOCAGE    │   │
│  │   ─────────────────            ───────────────        ──────────   │   │
│  │                                                                     │   │
│  │   Upload 3+ factures    ──▶    P-PER-001: Budget   ──▶ TUT-P01    │   │
│  │                                actif = true             Budget      │   │
│  │                                                                     │   │
│  │   Upload doc propriété  ──▶    P-PER-002: Proprio  ──▶ TUT-P03    │   │
│  │   (bail, titre, etc.)          = true                   Propriété   │   │
│  │                                                                     │   │
│  │   Rappel santé x2       ──▶    P-PER-003: Santé    ──▶ TUT-P02    │   │
│  │                                tracking = true          Santé       │   │
│  │                                                                     │   │
│  │   Mention famille x3    ──▶    P-PER-004: Famille  ──▶ TUT-P04    │   │
│  │   (tâches, notes)              présente = true          Cercle Fam  │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  NIVEAU 2.2: SOUS-CASCADES (après TUT-P0x complétés)                       │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ TUT-P01 (Budget) COMPLÉTÉ                                           │   │
│  │ │                                                                   │   │
│  │ ├─▶ Si 3+ catégories utilisées:                                    │   │
│  │ │   └─▶ P-PER-001a: Catégories définies                            │   │
│  │ │       └─▶ TUT-P01a: Rapports Financiers                          │   │
│  │ │                                                                   │   │
│  │ └─▶ Si dépenses récurrentes détectées:                             │   │
│  │     └─▶ P-PER-001b: Abonnements actifs                             │   │
│  │         └─▶ TUT-P01b: Suivi Abonnements                            │   │
│  │             └─▶ Feature: Alerte renouvellement                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ TUT-P03 (Propriété) COMPLÉTÉ                                        │   │
│  │ │                                                                   │   │
│  │ ├─▶ Si 2+ propriétés ajoutées:                                     │   │
│  │ │   └─▶ P-PER-002a: Multi-propriétés                               │   │
│  │ │       └─▶ TUT-P03a: Portfolio Immobilier Perso                   │   │
│  │ │           └─▶ CROSS: Module Immobilier débloqué                  │   │
│  │ │                                                                   │   │
│  │ └─▶ Question Nova (après 7j):                                      │   │
│  │     "C'est votre résidence ou un investissement?"                  │   │
│  │     │                                                               │   │
│  │     ├─▶ Si "Investissement":                                       │   │
│  │     │   └─▶ P-PER-002b: Investisseur = true                        │   │
│  │     │       └─▶ TUT-P03b: Rentabilité Locative                     │   │
│  │     │           └─▶ CROSS: Sphère Business suggérée                │   │
│  │     │                                                               │   │
│  │     └─▶ Si "Résidence":                                            │   │
│  │         └─▶ TUT-P03c: Maintenance Maison                           │   │
│  │             └─▶ Feature: Calendrier entretien                      │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ TUT-P04 (Famille) COMPLÉTÉ                                          │   │
│  │ │                                                                   │   │
│  │ ├─▶ Si partage activé:                                             │   │
│  │ │   └─▶ P-PER-004a: Partage famille actif                          │   │
│  │ │       └─▶ TUT-P04a: Calendrier Partagé                           │   │
│  │ │                                                                   │   │
│  │ └─▶ Question Nova (si enfants mentionnés):                         │   │
│  │     "Des enfants dans le foyer?"                                   │   │
│  │     │                                                               │   │
│  │     └─▶ Si Oui:                                                    │   │
│  │         └─▶ P-PER-004b: Enfants = true                             │   │
│  │             └─▶ TUT-P04b: Organisation Familiale                   │   │
│  │                 └─▶ Features: Tâches enfants, Activités            │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  NIVEAU 2.3: CROSS-SPHÈRE (Ponts vers autres sphères)                      │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  TRIGGER                        ACTION NOVA                         │   │
│  │  ───────                        ───────────                         │   │
│  │                                                                     │   │
│  │  P-PER-002b (Investisseur)  ──▶ "Avez-vous pensé à gérer vos      │   │
│  │                                  investissements depuis Business?"  │   │
│  │                                  └─▶ TUT-CROSS-01: Perso→Business  │   │
│  │                                                                     │   │
│  │  Hobby créatif détecté      ──▶ "Votre passion pourrait avoir     │   │
│  │  (photos, musique, etc.)         sa place dans Creative Studio"    │   │
│  │                                  └─▶ TUT-CROSS-02: Perso→Creative  │   │
│  │                                                                     │   │
│  │  Événement famille créé     ──▶ "Pour les événements plus grands, │   │
│  │  (10+ invités)                   voir Community"                   │   │
│  │                                  └─▶ TUT-CROSS-03: Perso→Community │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 3. BRANCHE BUSINESS — Cascade Complète

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    BRANCHE BUSINESS 💼 — CASCADE COMPLÈTE                   │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ENTRÉE: P010 = Business (sphère principale)                               │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  NIVEAU 2.1: QUESTION INITIALE (Obligatoire pour Business)                 │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  Question Nova (1ère visite Business):                              │   │
│  │  "Travaillez-vous seul ou en équipe?"                              │   │
│  │                                                                     │   │
│  │  ┌─────────────┐      ┌─────────────┐      ┌─────────────┐        │   │
│  │  │    SEUL     │      │   ÉQUIPE    │      │ PLUS TARD   │        │   │
│  │  │ (Freelance) │      │ (Entreprise)│      │  (Skip)     │        │   │
│  │  └──────┬──────┘      └──────┬──────┘      └──────┬──────┘        │   │
│  │         │                    │                    │                │   │
│  │         ▼                    ▼                    ▼                │   │
│  │  P-BUS-001a:          P-BUS-001b:          P-BUS-001:             │   │
│  │  solo = true          team = true          unknown                │   │
│  │         │                    │                    │                │   │
│  │         ▼                    ▼                    ▼                │   │
│  │  PATH FREELANCE       PATH ENTREPRISE      PATH GÉNÉRIQUE         │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  PATH FREELANCE (P-BUS-001a = solo)                                        │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  TUT-B00a: Mode Freelance (auto après choix)                       │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: 1ère facture créée                                 │   │
│  │  │   └─▶ P-BUS-002: Facturation active                             │   │
│  │  │       └─▶ TUT-B01: Facturation Pro                              │   │
│  │  │           │                                                      │   │
│  │  │           ├─▶ Si 3+ factures même client:                       │   │
│  │  │           │   └─▶ TUT-B01a: Client Récurrent                    │   │
│  │  │           │       └─▶ Feature: Facturation auto                 │   │
│  │  │           │                                                      │   │
│  │  │           └─▶ Si facture internationale:                        │   │
│  │  │               └─▶ P-BUS-002a: International = true              │   │
│  │  │                   └─▶ TUT-B01b: Facturation Multi-devise        │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: 1er devis créé                                     │   │
│  │  │   └─▶ P-BUS-003: Estimation active                              │   │
│  │  │       └─▶ TUT-B04: Estimation Rapide                            │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: 3+ clients ajoutés                                 │   │
│  │  │   └─▶ P-BUS-004: CRM besoin                                     │   │
│  │  │       └─▶ TUT-B02: Gestion Clients                              │   │
│  │  │           └─▶ Feature: Pipeline ventes                          │   │
│  │  │                                                                  │   │
│  │  └─▶ Question Nova (après 2 semaines):                             │   │
│  │      "Quel est votre domaine d'activité?"                          │   │
│  │      │                                                              │   │
│  │      ├─▶ "Construction"                                            │   │
│  │      │   └─▶ P-BUS-005a: Domaine = construction                    │   │
│  │      │       └─▶ CROSS: Module Construction débloqué               │   │
│  │      │           └─▶ Cascade Construction (Section 6)              │   │
│  │      │                                                              │   │
│  │      ├─▶ "Immobilier"                                              │   │
│  │      │   └─▶ P-BUS-005b: Domaine = immobilier                      │   │
│  │      │       └─▶ CROSS: Module Immobilier Pro débloqué             │   │
│  │      │           └─▶ Cascade Immobilier (Section 7)                │   │
│  │      │                                                              │   │
│  │      ├─▶ "Créatif/Design"                                          │   │
│  │      │   └─▶ P-BUS-005c: Domaine = creative                        │   │
│  │      │       └─▶ CROSS: Sphère Creative Studio suggérée            │   │
│  │      │                                                              │   │
│  │      └─▶ "Autre"                                                   │   │
│  │          └─▶ TUT-B-GEN: Business Générique                         │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  PATH ENTREPRISE (P-BUS-001b = team)                                       │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  TUT-B00b: Mode Équipe (auto après choix)                          │   │
│  │  │                                                                  │   │
│  │  ├─▶ Question Nova immédiate:                                      │   │
│  │  │   "Quelle est la taille de votre équipe?"                       │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "2-5 personnes"                                           │   │
│  │  │   │   └─▶ P-BUS-006a: Petite équipe                             │   │
│  │  │   │       └─▶ TUT-B-TEAM-S: Collaboration Simple                │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "6-20 personnes"                                          │   │
│  │  │   │   └─▶ P-BUS-006b: Moyenne équipe                            │   │
│  │  │   │       └─▶ TUT-B-TEAM-M: Gestion Équipe                      │   │
│  │  │   │           └─▶ Features: Rôles, Permissions                  │   │
│  │  │   │                                                              │   │
│  │  │   └─▶ "20+ personnes"                                           │   │
│  │  │       └─▶ P-BUS-006c: Grande entreprise                         │   │
│  │  │           └─▶ TUT-B-TEAM-L: Gouvernance Entreprise              │   │
│  │  │               └─▶ Features: Départements, Hiérarchie            │   │
│  │  │                                                                  │   │
│  │  ├─▶ Question Nova (suivante):                                     │   │
│  │  │   "Quel est votre rôle?"                                        │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Dirigeant/Fondateur"                                     │   │
│  │  │   │   └─▶ P-BUS-007a: Rôle = leader                             │   │
│  │  │   │       └─▶ TUT-B-ROLE-L: Vue Direction                       │   │
│  │  │   │           └─▶ Features: Dashboards, KPIs                    │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Manager/Responsable"                                     │   │
│  │  │   │   └─▶ P-BUS-007b: Rôle = manager                            │   │
│  │  │   │       └─▶ TUT-B-ROLE-M: Vue Manager                         │   │
│  │  │   │                                                              │   │
│  │  │   └─▶ "Employé/Collaborateur"                                   │   │
│  │  │       └─▶ P-BUS-007c: Rôle = member                             │   │
│  │  │           └─▶ TUT-B-ROLE-E: Vue Collaborateur                   │   │
│  │  │                                                                  │   │
│  │  └─▶ Même cascade domaine que Path Freelance                       │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 4. CASCADES DOMAINES MÉTIER

## 4.1 Cascade Construction

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 CASCADE CONSTRUCTION 🏗️ — SOUS-ARBRE                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ENTRÉE: P-BUS-005a = construction (domaine détecté)                       │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  TUT-CONSTR-INTRO: Introduction Construction (auto)                │   │
│  │  │                                                                  │   │
│  │  ├─▶ Question Nova:                                                │   │
│  │  │   "Quel est votre rôle dans la construction?"                   │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Entrepreneur général"                                    │   │
│  │  │   │   └─▶ P-CON-001a: Role = GC                                 │   │
│  │  │   │       └─▶ TUT-CON-GC: Mode Entrepreneur                     │   │
│  │  │   │           └─▶ Features: Soumissions, Sous-traitants         │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Sous-traitant"                                           │   │
│  │  │   │   └─▶ P-CON-001b: Role = subcontractor                      │   │
│  │  │   │       └─▶ TUT-CON-SUB: Mode Sous-traitant                   │   │
│  │  │   │                                                              │   │
│  │  │   └─▶ "Propriétaire/Client"                                     │   │
│  │  │       └─▶ P-CON-001c: Role = owner                              │   │
│  │  │           └─▶ TUT-CON-OWN: Mode Donneur d'ouvrage               │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: Document RBQ uploadé                               │   │
│  │  │   └─▶ P-CON-002: Licence RBQ = true                             │   │
│  │  │       └─▶ P-CON-002a: Juridiction = Quebec                      │   │
│  │  │           └─▶ TUT-CON-RBQ: Conformité RBQ                       │   │
│  │  │               │                                                  │   │
│  │  │               ├─▶ Feature: Suivi licence                        │   │
│  │  │               ├─▶ Feature: Rappels formation                    │   │
│  │  │               └─▶ TUT-CON-RBQ-ADV: RBQ Avancé (après 30j)      │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: 1er projet construction créé                       │   │
│  │  │   └─▶ P-CON-003: Projet actif = true                            │   │
│  │  │       └─▶ TUT-CON-PROJ: Gestion Chantier                        │   │
│  │  │           │                                                      │   │
│  │  │           ├─▶ Si employés ajoutés:                              │   │
│  │  │           │   └─▶ P-CON-004: Employés = true                    │   │
│  │  │           │       └─▶ TUT-CON-CNESST: Sécurité CNESST           │   │
│  │  │           │                                                      │   │
│  │  │           └─▶ Si sous-traitants ajoutés:                        │   │
│  │  │               └─▶ TUT-CON-SUBS: Gestion Sous-traitants          │   │
│  │  │                                                                  │   │
│  │  └─▶ Détection: 1ère soumission créée                              │   │
│  │      └─▶ P-CON-005: Soumissions = true                             │   │
│  │          └─▶ TUT-CON-BID: Soumissions Pro                          │   │
│  │              │                                                      │   │
│  │              └─▶ Question Nova (si 5+ soumissions):                │   │
│  │                  "Utilisez-vous des bases de prix standardisées?"  │   │
│  │                  │                                                  │   │
│  │                  └─▶ Si Oui:                                       │   │
│  │                      └─▶ TUT-CON-PRICING: Estimation Avancée       │   │
│  │                          └─▶ Feature: 1-Click Estimation           │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4.2 Cascade Immobilier Pro

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                 CASCADE IMMOBILIER PRO 🏢 — SOUS-ARBRE                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ENTRÉE: P-BUS-005b = immobilier (domaine détecté)                         │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                                                                     │   │
│  │  TUT-IMMO-INTRO: Introduction Immobilier Pro (auto)                │   │
│  │  │                                                                  │   │
│  │  ├─▶ Question Nova:                                                │   │
│  │  │   "Quel type d'immobilier gérez-vous?"                          │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Résidentiel locatif"                                     │   │
│  │  │   │   └─▶ P-IMM-001a: Type = residential                        │   │
│  │  │   │       └─▶ TUT-IMM-RES: Gestion Résidentielle                │   │
│  │  │   │           │                                                  │   │
│  │  │   │           ├─▶ Détection: Document TAL                       │   │
│  │  │   │           │   └─▶ P-IMM-002: Juridiction = Quebec           │   │
│  │  │   │           │       └─▶ TUT-IMM-TAL: Conformité TAL           │   │
│  │  │   │           │           └─▶ Features: Formulaires TAL         │   │
│  │  │   │           │                                                  │   │
│  │  │   │           └─▶ Détection: Bail uploadé                       │   │
│  │  │   │               └─▶ TUT-IMM-LEASE: Gestion Baux                │   │
│  │  │   │                                                              │   │
│  │  │   ├─▶ "Commercial"                                              │   │
│  │  │   │   └─▶ P-IMM-001b: Type = commercial                         │   │
│  │  │   │       └─▶ TUT-IMM-COM: Immobilier Commercial                │   │
│  │  │   │           └─▶ Features: Baux commerciaux                    │   │
│  │  │   │                                                              │   │
│  │  │   └─▶ "Mixte"                                                   │   │
│  │  │       └─▶ P-IMM-001c: Type = mixed                              │   │
│  │  │           └─▶ TUT-IMM-MIX: Portfolio Mixte                      │   │
│  │  │                                                                  │   │
│  │  ├─▶ Détection: 5+ propriétés                                      │   │
│  │  │   └─▶ P-IMM-003: Portfolio = large                              │   │
│  │  │       └─▶ TUT-IMM-PORT: Analytics Portfolio                     │   │
│  │  │           └─▶ Features: KPIs, Comparatifs                       │   │
│  │  │                                                                  │   │
│  │  └─▶ Détection: Paiements trackés                                  │   │
│  │      └─▶ P-IMM-004: Paiements = true                               │   │
│  │          └─▶ TUT-IMM-PAY: Suivi Paiements                          │   │
│  │              │                                                      │   │
│  │              └─▶ Si retard détecté:                                │   │
│  │                  └─▶ TUT-IMM-LATE: Gestion Impayés                 │   │
│  │                                                                     │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 5. MATRICE DES DÉPENDANCES

## 5.1 Dépendances entre Pièces

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MATRICE DES DÉPENDANCES — PIÈCES                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  LÉGENDE:                                                                   │
│  ──────────                                                                 │
│  ● = Dépendance obligatoire (doit être collectée avant)                    │
│  ○ = Dépendance optionnelle (enrichit si présente)                         │
│  ✕ = Incompatible (l'une exclut l'autre)                                   │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                P000 P001 P010 P-BUS-001 P-BUS-005 P-CON-001        │    │
│  │  P000 (Identité) ─   ─    ─      ─          ─         ─           │    │
│  │  P001 (Langue)   ●   ─    ─      ─          ─         ─           │    │
│  │  P010 (Sphère)   ●   ●    ─      ─          ─         ─           │    │
│  │  P-BUS-001      ●   ●    ●      ─          ─         ─           │    │
│  │  P-BUS-005      ●   ●    ●      ●          ─         ─           │    │
│  │  P-CON-001      ●   ●    ●      ●          ●         ─           │    │
│  │  P-CON-002      ●   ●    ●      ●          ●         ●           │    │
│  │                                                                    │    │
│  │  LECTURE: P-CON-001 requiert P000, P001, P010, P-BUS-001, P-BUS-005│    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  INCOMPATIBILITÉS:                                                          │
│  ─────────────────                                                          │
│  P-BUS-001a (solo) ✕ P-BUS-001b (team)                                     │
│  P-CON-001a (GC) ✕ P-CON-001c (owner)                                      │
│  P-IMM-001a (résidentiel) partiel ✕ P-IMM-001b (commercial)                │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 5.2 Dépendances entre Tutoriels

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    MATRICE DES DÉPENDANCES — TUTORIELS                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │                                                                    │    │
│  │  TUTORIEL              PRÉREQUIS                 DÉBLOQUE          │    │
│  │  ────────              ─────────                 ────────          │    │
│  │                                                                    │    │
│  │  TUT-000 (Bienvenue)   [Aucun]                   TUT-001, TUT-003 │    │
│  │  TUT-001 (Sphères)     TUT-000                   TUT selon sphère │    │
│  │  TUT-003 (Threads)     TUT-000                   [Usage avancé]   │    │
│  │                                                                    │    │
│  │  TUT-B00a (Freelance)  TUT-001 + P-BUS-001a     TUT-B01 à B04    │    │
│  │  TUT-B00b (Équipe)     TUT-001 + P-BUS-001b     TUT-B-TEAM-*     │    │
│  │                                                                    │    │
│  │  TUT-B01 (Facturation) TUT-B00a ou TUT-B00b     TUT-B01a, B01b   │    │
│  │  TUT-B01a (Récurrent)  TUT-B01 + 3 fact/client  Feature FactAuto │    │
│  │                                                                    │    │
│  │  TUT-CONSTR-INTRO      P-BUS-005a               TUT-CON-*        │    │
│  │  TUT-CON-RBQ           TUT-CONSTR-INTRO + RBQ   TUT-CON-RBQ-ADV  │    │
│  │  TUT-CON-RBQ-ADV       TUT-CON-RBQ + 30 jours   Features avancées│    │
│  │                                                                    │    │
│  │  TUT-IMMO-INTRO        P-BUS-005b               TUT-IMM-*        │    │
│  │  TUT-IMM-TAL           TUT-IMMO-INTRO + TAL doc Feature TAL Forms│    │
│  │                                                                    │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 6. TIMING DES QUESTIONS

## 6.1 Calendrier des Questions Nova

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    CALENDRIER QUESTIONS NOVA                                │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  JOUR 1                                                                     │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  T+0        Inscription                    [Aucune question - config]      │
│  T+2min     Fin TUT-000                    [Aucune question]               │
│  T+5min     1ère sphère visitée            [Observation silencieuse]       │
│  T+10min    1ère action significative      Question contextuelle si besoin │
│                                             (max 1 question jour 1)         │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  JOURS 2-3                                                                  │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Retour     Si pattern détecté (3x)        Question pattern                │
│  Session    Si sphère Business 1ère fois   Q: "Solo ou équipe?"           │
│  End        Fin session                    [Aucune question]               │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  JOURS 4-7                                                                  │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Selon      Pattern domaine détecté        Q: "Quel domaine?"              │
│  usage      Tutoriel complété              Question follow-up possible     │
│             Fin semaine                    Q: "Comment trouvez-vous CHE·NU?"│
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  SEMAINES 2-4                                                               │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Contextuell Questions domaine spécifiques selon usage détecté             │
│  Max 1 question par session                                                 │
│  Toujours skippable                                                         │
│                                                                             │
│  ═══════════════════════════════════════════════════════════════════════   │
│  MOIS 2+                                                                    │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                             │
│  Rare       Questions d'optimisation                                        │
│  usage      Questions sur nouvelles features                                │
│  basé       Jamais de questionnaire                                         │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 6.2 Règles de Non-Intrusion

```typescript
const QUESTION_RULES = {
  // Limites strictes
  maxQuestionsDay1: 1,
  maxQuestionsPerSession: 1,
  maxQuestionsPerWeek: 3,
  
  // Timing
  minTimeBetweenQuestions: '4h',
  cooldownAfterSkip: '7d',
  cooldownAfterAnswer: '24h',
  
  // Contextes interdits
  neverAskDuring: [
    'error_state',
    'upload_in_progress',
    'meeting_active',
    'deep_focus_mode',
    'first_10_minutes',
    'tutorial_in_progress',
  ],
  
  // Moments préférés
  preferredMoments: [
    'after_successful_action',
    'after_tutorial_completion',
    'session_natural_pause',
    'return_after_absence_24h+',
  ],
  
  // Fallback
  ifAllSkipped: {
    stopAskingAfter: 3,  // 3 skips = stop asking
    resumeAfter: '30d',   // Réessayer après 30j
  },
};
```

---

# 7. SCHÉMA DE LA BASE DE DONNÉES

```sql
-- ═══════════════════════════════════════════════════════════════════════════
-- TABLES PUZZLE INFORMATIONNEL
-- ═══════════════════════════════════════════════════════════════════════════

-- Pièces du puzzle collectées par utilisateur
CREATE TABLE user_puzzle_pieces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    -- Pièce
    piece_id VARCHAR(100) NOT NULL,
    piece_value JSONB NOT NULL,
    
    -- Source
    source VARCHAR(50) NOT NULL, -- 'detection', 'question', 'import', 'inference'
    source_action VARCHAR(200),  -- Action qui a déclenché
    
    -- État
    confidence DECIMAL(3,2) DEFAULT 1.0,
    verified BOOLEAN DEFAULT FALSE,
    
    -- Timing
    collected_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    -- Audit
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(user_id, identity_id, piece_id)
);

-- Questions posées à l'utilisateur
CREATE TABLE user_questions_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    
    -- Question
    question_id VARCHAR(100) NOT NULL,
    module_id VARCHAR(100) NOT NULL,
    
    -- Timing
    asked_at TIMESTAMP DEFAULT NOW(),
    responded_at TIMESTAMP,
    
    -- Réponse
    response_value JSONB,
    was_skipped BOOLEAN DEFAULT FALSE,
    response_time_seconds INTEGER,
    
    -- Context
    trigger_context VARCHAR(200),
    sphere_context VARCHAR(50),
    
    -- Tracking
    ask_count INTEGER DEFAULT 1,
    
    created_at TIMESTAMP DEFAULT NOW()
);

-- Index pour skip tracking
CREATE INDEX idx_questions_skipped ON user_questions_history(user_id, question_id, was_skipped);

-- Tutoriels utilisateur
CREATE TABLE user_tutorials (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    
    -- Tutoriel
    tutorial_id VARCHAR(100) NOT NULL,
    module_id VARCHAR(100) NOT NULL,
    
    -- État
    status VARCHAR(20) DEFAULT 'locked', -- locked, unlocked, started, completed, skipped
    
    -- Progression
    current_step INTEGER DEFAULT 0,
    total_steps INTEGER NOT NULL,
    time_spent_seconds INTEGER DEFAULT 0,
    
    -- Timing
    unlocked_at TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    skipped_at TIMESTAMP,
    
    -- Déblocage
    unlock_trigger VARCHAR(200),
    unlock_piece_id VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(user_id, tutorial_id)
);

-- Déblocages planifiés (delayed unlocks)
CREATE TABLE scheduled_unlocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    
    -- Ce qui sera débloqué
    unlock_type VARCHAR(50) NOT NULL, -- 'tutorial', 'feature', 'question'
    unlock_id VARCHAR(100) NOT NULL,
    
    -- Quand
    scheduled_for TIMESTAMP NOT NULL,
    
    -- Source
    triggered_by_tutorial VARCHAR(100),
    triggered_by_piece VARCHAR(100),
    
    -- État
    executed BOOLEAN DEFAULT FALSE,
    executed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT NOW()
);

-- Index pour job de déblocage
CREATE INDEX idx_scheduled_unlocks_pending ON scheduled_unlocks(scheduled_for) 
WHERE executed = FALSE;

-- Features débloquées
CREATE TABLE user_features (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    
    feature_id VARCHAR(100) NOT NULL,
    module_id VARCHAR(100) NOT NULL,
    
    -- État
    unlocked BOOLEAN DEFAULT FALSE,
    unlocked_at TIMESTAMP,
    
    -- Source déblocage
    unlock_source VARCHAR(50), -- 'piece', 'tutorial', 'subscription'
    unlock_piece_id VARCHAR(100),
    unlock_tutorial_id VARCHAR(100),
    
    -- Usage
    first_used_at TIMESTAMP,
    usage_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(user_id, feature_id)
);

-- ═══════════════════════════════════════════════════════════════════════════
-- VUES UTILES
-- ═══════════════════════════════════════════════════════════════════════════

-- Vue profil utilisateur complet
CREATE VIEW user_puzzle_profile AS
SELECT 
    u.id as user_id,
    u.email,
    jsonb_object_agg(p.piece_id, p.piece_value) as puzzle_pieces,
    COUNT(p.id) as pieces_collected,
    (SELECT COUNT(*) FROM user_tutorials t WHERE t.user_id = u.id AND t.status = 'completed') as tutorials_completed,
    (SELECT COUNT(*) FROM user_features f WHERE f.user_id = u.id AND f.unlocked = TRUE) as features_unlocked
FROM users u
LEFT JOIN user_puzzle_pieces p ON u.id = p.user_id
GROUP BY u.id, u.email;

-- Vue questions en attente
CREATE VIEW pending_questions AS
SELECT 
    q.user_id,
    q.question_id,
    q.module_id,
    MAX(q.asked_at) as last_asked,
    SUM(CASE WHEN q.was_skipped THEN 1 ELSE 0 END) as skip_count,
    SUM(CASE WHEN NOT q.was_skipped AND q.response_value IS NOT NULL THEN 1 ELSE 0 END) as answered_count
FROM user_questions_history q
GROUP BY q.user_id, q.question_id, q.module_id
HAVING SUM(CASE WHEN q.was_skipped THEN 1 ELSE 0 END) < 3
   AND SUM(CASE WHEN NOT q.was_skipped AND q.response_value IS NOT NULL THEN 1 ELSE 0 END) = 0;

-- ═══════════════════════════════════════════════════════════════════════════
-- TRIGGERS
-- ═══════════════════════════════════════════════════════════════════════════

-- Trigger pour vérifier déblocages après collecte pièce
CREATE OR REPLACE FUNCTION check_unlocks_after_piece()
RETURNS TRIGGER AS $$
BEGIN
    -- Appeler fonction de vérification des déblocages
    -- (Implémenté dans le backend)
    PERFORM pg_notify('piece_collected', json_build_object(
        'user_id', NEW.user_id,
        'piece_id', NEW.piece_id,
        'piece_value', NEW.piece_value
    )::text);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_check_unlocks
AFTER INSERT ON user_puzzle_pieces
FOR EACH ROW EXECUTE FUNCTION check_unlocks_after_piece();

-- Trigger pour déblocages planifiés
CREATE OR REPLACE FUNCTION process_scheduled_unlocks()
RETURNS void AS $$
DECLARE
    unlock_record RECORD;
BEGIN
    FOR unlock_record IN 
        SELECT * FROM scheduled_unlocks 
        WHERE scheduled_for <= NOW() AND executed = FALSE
    LOOP
        -- Notifier le backend pour traitement
        PERFORM pg_notify('scheduled_unlock', json_build_object(
            'id', unlock_record.id,
            'user_id', unlock_record.user_id,
            'unlock_type', unlock_record.unlock_type,
            'unlock_id', unlock_record.unlock_id
        )::text);
        
        -- Marquer comme exécuté
        UPDATE scheduled_unlocks 
        SET executed = TRUE, executed_at = NOW()
        WHERE id = unlock_record.id;
    END LOOP;
END;
$$ LANGUAGE plpgsql;
```

---

# 8. RÉSUMÉ EXÉCUTIF

## 8.1 Ordre des Opérations

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                    ORDRE DES OPÉRATIONS — RÉSUMÉ                             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  1. EXPLIQUER (Nova présente)                                                ║
║     └─▶ Message première découverte module                                  ║
║         └─▶ Tutoriel introduction si pertinent                              ║
║                                                                              ║
║  2. OBSERVER (Détection silencieuse)                                         ║
║     └─▶ Tracker actions utilisateur                                         ║
║         └─▶ Détecter patterns (3x minimum)                                  ║
║             └─▶ Collecter pièces automatiquement                            ║
║                                                                              ║
║  3. INVITER (Question optionnelle)                                           ║
║     └─▶ SI pattern confirmé ET moment approprié                             ║
║         └─▶ Poser UNE question contextuelle                                 ║
║             └─▶ Accepter skip sans relance immédiate                        ║
║                                                                              ║
║  4. DÉBLOQUER (Cascade)                                                      ║
║     └─▶ Si pièce collectée → Vérifier conditions déblocage                  ║
║         └─▶ Débloquer tutoriels associés                                    ║
║             └─▶ Débloquer features associées                                ║
║                 └─▶ Déclencher sous-cascades                                ║
║                                                                              ║
║  5. RÉPÉTER (Cycle continu)                                                  ║
║     └─▶ Retour à étape 2                                                    ║
║         └─▶ Nouvelles observations → Nouvelles pièces → Nouveaux déblocages ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## 8.2 Checklist Rapide par Module

```
□ Module Manifest créé avec toutes sections Nova
□ Tutoriel intro défini (obligatoire)
□ Pièces du puzzle listées avec ordre
□ Questions définies avec triggers
□ Déblocages conditionnels mappés
□ Tutoriels features créés
□ Tutoriels avancés créés si applicable
□ Tutoriels imbriqués définis si applicable
□ Messages contextuels écrits
□ Hooks Nova implémentés
□ Tests parcours utilisateur passés
```

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    CASCADES DE DÉBLOCAGE COMPLÈTES                           ║
║                                                                              ║
║     "L'ordre crée la clarté — La clarté crée la maîtrise"                   ║
║                                                                              ║
║                          ON CONTINUE! 💪🔥                                   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```
