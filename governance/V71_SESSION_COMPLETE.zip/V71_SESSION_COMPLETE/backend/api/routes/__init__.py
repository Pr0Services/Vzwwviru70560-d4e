"""
CHE·NU™ V71 — API Routes Package
================================
Exports all API routers for V71 platform.
"""

from .synaptic_routes import router as synaptic_router
from .quantum_routes import router as quantum_router
from .multitech_routes import router as multitech_router

__all__ = [
    "synaptic_router",
    "quantum_router", 
    "multitech_router"
]
