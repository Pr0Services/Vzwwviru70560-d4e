# Canon
Single source of truth for active concepts.
