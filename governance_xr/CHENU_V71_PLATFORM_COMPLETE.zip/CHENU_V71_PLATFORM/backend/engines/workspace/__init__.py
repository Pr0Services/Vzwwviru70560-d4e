"""
CHE·NU™ V70 — WORKSPACE ENGINE PACKAGE
======================================
Adaptive, intelligent, multi-modal interaction surface.

Based on: WORKSPACE_ENGINE_CHAPTER.md (Chapters 97-108)

The Workspace Engine is NOT a fixed user interface.
It is an adaptive surface that automatically assumes
the optimal form for any given task.

Modes:
- Document Mode
- Board Mode
- Timeline Mode
- Spreadsheet Mode
- Dashboard Mode
- Diagram Mode
- Whiteboard Mode
- XR Launcher Mode (READ ONLY)
- Hybrid Mode

GOUVERNANCE > EXÉCUTION
"""

from .models import (
    # Enums
    WorkspaceMode,
    SphereContext,
    DomainContext,
    IntentSignal,
    WorkflowStage,
    TransitionType,
    # Models
    WorkspaceState,
    ModeTransition,
    IntentDetection,
    GestureSignal,
    AgentSignal,
    WorkspaceAgent,
    CollaborationSession,
    DataSpaceLink,
    XRLaunchConfig,
    PipelineStep,
    WorkflowPipeline,
    PipelineExecution,
    # Factories
    create_workspace,
    create_pipeline,
    create_xr_launch,
)

from .modes import (
    ModeCapability,
    DocumentMode,
    BoardMode,
    TimelineMode,
    SpreadsheetMode,
    DashboardMode,
    DiagramMode,
    WhiteboardMode,
    XRLauncherMode,
    HybridMode,
    MODE_REGISTRY,
    get_mode_config,
    get_mode_capabilities,
    get_domain_templates,
    suggest_mode_for_intent,
)

from .intent import (
    IntentDetector,
    get_intent_detector,
)

from .pipelines import (
    create_project_pipeline,
    create_meeting_pipeline,
    create_document_pipeline,
    create_xr_pipeline,
    create_immobilier_property_pipeline,
    create_construction_estimation_pipeline,
    create_architecture_review_pipeline,
    get_pipeline_template,
    list_available_pipelines,
)

from .engine import (
    WorkspaceEngine,
    get_workspace_engine,
)

__all__ = [
    # Enums
    "WorkspaceMode",
    "SphereContext",
    "DomainContext",
    "IntentSignal",
    "WorkflowStage",
    "TransitionType",
    "ModeCapability",
    # Models
    "WorkspaceState",
    "ModeTransition",
    "IntentDetection",
    "GestureSignal",
    "AgentSignal",
    "WorkspaceAgent",
    "CollaborationSession",
    "DataSpaceLink",
    "XRLaunchConfig",
    "PipelineStep",
    "WorkflowPipeline",
    "PipelineExecution",
    # Mode definitions
    "DocumentMode",
    "BoardMode",
    "TimelineMode",
    "SpreadsheetMode",
    "DashboardMode",
    "DiagramMode",
    "WhiteboardMode",
    "XRLauncherMode",
    "HybridMode",
    "MODE_REGISTRY",
    # Functions
    "create_workspace",
    "create_pipeline",
    "create_xr_launch",
    "get_mode_config",
    "get_mode_capabilities",
    "get_domain_templates",
    "suggest_mode_for_intent",
    # Intent
    "IntentDetector",
    "get_intent_detector",
    # Pipelines
    "create_project_pipeline",
    "create_meeting_pipeline",
    "create_document_pipeline",
    "create_xr_pipeline",
    "create_immobilier_property_pipeline",
    "create_construction_estimation_pipeline",
    "create_architecture_review_pipeline",
    "get_pipeline_template",
    "list_available_pipelines",
    # Engine
    "WorkspaceEngine",
    "get_workspace_engine",
]

__version__ = "70.0.0"
