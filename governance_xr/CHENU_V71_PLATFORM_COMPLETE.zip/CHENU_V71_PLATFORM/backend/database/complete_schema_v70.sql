-- ============================================================
-- CHE·NU™ DATABASE SCHEMA V70 — COMPLETE ENGINE STACK
-- Based on: CHENU_SQL_SCHEMA_v29.sql
-- Generated: January 2026
-- 
-- GOUVERNANCE > EXÉCUTION
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ============================================================
-- SECTION 1: CORE IDENTITY & USER MANAGEMENT
-- ============================================================

CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    display_name VARCHAR(100),
    avatar_url TEXT,
    preferred_language VARCHAR(10) DEFAULT 'fr',
    timezone VARCHAR(50) DEFAULT 'America/Toronto',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_login_at TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE
);

CREATE TABLE identities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    identity_type VARCHAR(50) NOT NULL, -- 'personal', 'enterprise', 'creative', 'design', 'architecture', 'construction'
    identity_name VARCHAR(100) NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    config JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, identity_type, identity_name)
);

CREATE TABLE identity_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identity_id UUID NOT NULL REFERENCES identities(id) ON DELETE CASCADE,
    permission_key VARCHAR(100) NOT NULL,
    permission_value JSONB DEFAULT '{}',
    granted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    granted_by UUID REFERENCES users(id),
    expires_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(identity_id, permission_key)
);

CREATE INDEX idx_identities_user ON identities(user_id);
CREATE INDEX idx_identities_type ON identities(identity_type);

-- ============================================================
-- SECTION 2: SPHERE & DOMAIN MANAGEMENT
-- ============================================================

CREATE TABLE spheres (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(50) UNIQUE NOT NULL, -- 'personal', 'business', 'creative', 'scholar', 'myteam', etc.
    name_fr VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    color VARCHAR(20),
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    config JSONB DEFAULT '{}'
);

CREATE TABLE domains (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sphere_id UUID NOT NULL REFERENCES spheres(id),
    code VARCHAR(50) NOT NULL, -- 'finance', 'immobilier', 'construction', 'architecture'
    name_fr VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    description TEXT,
    icon VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    config JSONB DEFAULT '{}',
    UNIQUE(sphere_id, code)
);

CREATE TABLE user_sphere_access (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    identity_id UUID NOT NULL REFERENCES identities(id) ON DELETE CASCADE,
    sphere_id UUID NOT NULL REFERENCES spheres(id),
    access_level VARCHAR(20) DEFAULT 'full', -- 'full', 'read', 'limited'
    granted_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(identity_id, sphere_id)
);

-- ============================================================
-- SECTION 3: DATASPACE ENGINE
-- ============================================================

CREATE TABLE dataspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    sphere_id UUID REFERENCES spheres(id),
    domain_id UUID REFERENCES domains(id),
    parent_id UUID REFERENCES dataspaces(id),
    
    name VARCHAR(255) NOT NULL,
    description TEXT,
    dataspace_type VARCHAR(50) NOT NULL, -- 'project', 'property', 'client', 'meeting', 'document', 'custom'
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'archived', 'deleted'
    visibility VARCHAR(20) DEFAULT 'private', -- 'private', 'shared', 'public'
    
    metadata JSONB DEFAULT '{}',
    tags TEXT[],
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    archived_at TIMESTAMP WITH TIME ZONE,
    
    -- Full-text search
    search_vector TSVECTOR
);

CREATE INDEX idx_dataspaces_owner ON dataspaces(owner_id);
CREATE INDEX idx_dataspaces_identity ON dataspaces(identity_id);
CREATE INDEX idx_dataspaces_sphere ON dataspaces(sphere_id);
CREATE INDEX idx_dataspaces_domain ON dataspaces(domain_id);
CREATE INDEX idx_dataspaces_type ON dataspaces(dataspace_type);
CREATE INDEX idx_dataspaces_status ON dataspaces(status);
CREATE INDEX idx_dataspaces_search ON dataspaces USING GIN(search_vector);

CREATE TABLE dataspace_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dataspace_id UUID NOT NULL REFERENCES dataspaces(id) ON DELETE CASCADE,
    item_type VARCHAR(50) NOT NULL, -- 'document', 'note', 'task', 'link', 'file', 'reference'
    title VARCHAR(255),
    content TEXT,
    metadata JSONB DEFAULT '{}',
    position INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE dataspace_links (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_dataspace_id UUID NOT NULL REFERENCES dataspaces(id) ON DELETE CASCADE,
    target_dataspace_id UUID NOT NULL REFERENCES dataspaces(id) ON DELETE CASCADE,
    link_type VARCHAR(50) DEFAULT 'reference', -- 'reference', 'parent', 'related', 'derived'
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(source_dataspace_id, target_dataspace_id, link_type)
);

-- ============================================================
-- SECTION 4: THREAD ENGINE
-- ============================================================

CREATE TABLE threads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dataspace_id UUID REFERENCES dataspaces(id) ON DELETE SET NULL,
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    title VARCHAR(255),
    thread_type VARCHAR(50) DEFAULT 'conversation', -- 'conversation', 'decision', 'task', 'meeting', 'support'
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'resolved', 'archived'
    
    participants UUID[], -- Array of user IDs
    
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE thread_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    thread_id UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES users(id),
    agent_id UUID, -- If sent by an agent
    
    message_type VARCHAR(50) DEFAULT 'text', -- 'text', 'file', 'action', 'decision', 'system'
    content TEXT NOT NULL,
    
    attachments JSONB DEFAULT '[]',
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    edited_at TIMESTAMP WITH TIME ZONE,
    is_edited BOOLEAN DEFAULT FALSE
);

CREATE TABLE thread_decisions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    thread_id UUID NOT NULL REFERENCES threads(id) ON DELETE CASCADE,
    message_id UUID REFERENCES thread_messages(id),
    
    decision_text TEXT NOT NULL,
    decision_type VARCHAR(50), -- 'approval', 'direction', 'assignment', 'policy'
    
    made_by UUID REFERENCES users(id),
    made_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- GOVERNANCE: HITL tracking
    requires_hitl BOOLEAN DEFAULT TRUE,
    hitl_approved BOOLEAN DEFAULT FALSE,
    hitl_approved_by UUID REFERENCES users(id),
    hitl_approved_at TIMESTAMP WITH TIME ZONE,
    
    affected_dataspaces UUID[],
    metadata JSONB DEFAULT '{}'
);

CREATE INDEX idx_threads_dataspace ON threads(dataspace_id);
CREATE INDEX idx_threads_identity ON threads(identity_id);
CREATE INDEX idx_thread_messages_thread ON thread_messages(thread_id);

-- ============================================================
-- SECTION 5: WORKSPACE ENGINE
-- ============================================================

CREATE TABLE workspaces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    dataspace_id UUID REFERENCES dataspaces(id),
    
    name VARCHAR(255) NOT NULL,
    workspace_mode VARCHAR(50) NOT NULL, -- 'document', 'board', 'timeline', 'spreadsheet', 'dashboard', 'diagram', 'whiteboard', 'xr', 'hybrid'
    
    layout_config JSONB DEFAULT '{}',
    view_state JSONB DEFAULT '{}',
    
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE workspace_panels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    
    panel_type VARCHAR(50) NOT NULL, -- 'editor', 'preview', 'chat', 'files', 'agents', 'timeline', 'canvas'
    position JSONB NOT NULL, -- {x, y, width, height}
    
    config JSONB DEFAULT '{}',
    is_visible BOOLEAN DEFAULT TRUE,
    z_index INTEGER DEFAULT 0,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE workspace_states (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workspace_id UUID NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
    
    state_name VARCHAR(100),
    state_data JSONB NOT NULL,
    
    is_autosave BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

-- ============================================================
-- SECTION 6: 1-CLICK ASSISTANT ENGINE
-- ============================================================

CREATE TABLE oneclick_workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    trigger_patterns TEXT[], -- Intent patterns that trigger this workflow
    
    sphere_id UUID REFERENCES spheres(id),
    domain_id UUID REFERENCES domains(id),
    
    workflow_steps JSONB NOT NULL, -- Array of step definitions
    
    required_inputs JSONB DEFAULT '[]',
    output_types TEXT[],
    
    -- GOVERNANCE: HITL requirements per workflow
    requires_hitl BOOLEAN DEFAULT TRUE,
    hitl_steps INTEGER[], -- Which steps require approval
    
    is_system BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE oneclick_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES oneclick_workflows(id),
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    input_data JSONB NOT NULL,
    input_type VARCHAR(50), -- 'prompt', 'file', 'context', 'dataspace'
    
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'needs_approval', 'running', 'completed', 'failed', 'cancelled'
    
    steps_completed INTEGER DEFAULT 0,
    total_steps INTEGER,
    
    -- GOVERNANCE: HITL tracking
    pending_approval_step INTEGER,
    approved_by UUID REFERENCES users(id),
    approved_at TIMESTAMP WITH TIME ZONE,
    
    output_data JSONB,
    output_dataspaces UUID[],
    
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    
    error_message TEXT,
    execution_log JSONB DEFAULT '[]'
);

-- ============================================================
-- SECTION 7: MEMORY & GOVERNANCE ENGINE
-- ============================================================

-- Memory Storage (Implements Ten Laws of Memory)
CREATE TABLE memory_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    identity_id UUID NOT NULL REFERENCES identities(id) ON DELETE CASCADE,
    
    memory_type VARCHAR(50) NOT NULL, -- 'short_term', 'mid_term', 'long_term', 'pinned', 'archived'
    memory_category VARCHAR(50), -- 'preference', 'instruction', 'fact', 'context', 'rule'
    
    content TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    
    dataspace_id UUID REFERENCES dataspaces(id) ON DELETE SET NULL,
    domain VARCHAR(50), -- LAW 8: Domain awareness
    
    -- LAW 1: No Hidden Memory - all visible to user
    visible_to_user BOOLEAN DEFAULT TRUE NOT NULL,
    
    -- LAW 2: Explicit Storage Approval
    user_approved BOOLEAN DEFAULT FALSE,
    approved_at TIMESTAMP WITH TIME ZONE,
    
    -- LAW 5: Reversibility
    user_deletable BOOLEAN DEFAULT TRUE NOT NULL,
    
    -- LAW 10: User-Controlled Lifespan
    lifespan VARCHAR(20) DEFAULT 'session', -- 'session', 'day', 'week', 'month', 'permanent'
    expires_at TIMESTAMP WITH TIME ZONE,
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'pinned', 'archived'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    last_accessed_at TIMESTAMP WITH TIME ZONE,
    
    -- LAW 3 & 4: Identity Scoping - enforced by constraint
    CONSTRAINT memory_identity_scope CHECK (identity_id IS NOT NULL),
    -- LAW 1: Enforced
    CONSTRAINT memory_visible CHECK (visible_to_user = TRUE),
    -- LAW 5: Enforced
    CONSTRAINT memory_deletable CHECK (user_deletable = TRUE)
);

CREATE INDEX idx_memory_user_identity ON memory_items(user_id, identity_id);
CREATE INDEX idx_memory_type ON memory_items(memory_type);
CREATE INDEX idx_memory_domain ON memory_items(domain);

-- LAW 6: Operation Logging
CREATE TABLE memory_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    memory_id UUID REFERENCES memory_items(id) ON DELETE SET NULL,
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    operation VARCHAR(50) NOT NULL, -- 'create', 'read', 'update', 'delete', 'access_attempt'
    operation_details JSONB DEFAULT '{}',
    
    -- Track blocked cross-identity access (LAW 4)
    was_blocked BOOLEAN DEFAULT FALSE,
    block_reason TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Governance Audit Log
CREATE TABLE governance_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    user_id UUID REFERENCES users(id),
    identity_id UUID REFERENCES identities(id),
    agent_id UUID,
    
    action_type VARCHAR(50) NOT NULL, -- 'create', 'read', 'update', 'delete', 'share', 'elevate'
    resource_type VARCHAR(50) NOT NULL, -- 'memory', 'dataspace', 'thread', 'file', 'agent'
    resource_id UUID NOT NULL,
    
    action_details JSONB DEFAULT '{}',
    
    -- Before/After state for reversibility
    before_state JSONB,
    after_state JSONB,
    
    -- HITL tracking
    hitl_required BOOLEAN DEFAULT FALSE,
    hitl_approved BOOLEAN,
    hitl_approved_by UUID REFERENCES users(id),
    
    ip_address INET,
    user_agent TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_user ON governance_audit_log(user_id);
CREATE INDEX idx_audit_resource ON governance_audit_log(resource_type, resource_id);
CREATE INDEX idx_audit_time ON governance_audit_log(created_at);

-- Elevation Requests (HITL)
CREATE TABLE elevation_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    requested_action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50) NOT NULL,
    resource_id UUID NOT NULL,
    
    reason TEXT,
    
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'approved', 'denied', 'expired'
    
    requested_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    responded_at TIMESTAMP WITH TIME ZONE,
    responded_by UUID REFERENCES users(id),
    
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() + INTERVAL '24 hours',
    
    metadata JSONB DEFAULT '{}'
);

-- LAW 4: Cross-Identity Protection
CREATE TABLE cross_identity_blocks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    user_id UUID NOT NULL REFERENCES users(id),
    source_identity_id UUID NOT NULL REFERENCES identities(id),
    target_identity_id UUID NOT NULL REFERENCES identities(id),
    
    blocked_action VARCHAR(100) NOT NULL,
    blocked_resource_type VARCHAR(50),
    blocked_resource_id UUID,
    
    block_reason TEXT DEFAULT 'Cross-identity access denied (Law 4)',
    
    blocked_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- SECTION 8: AGENT SYSTEM
-- ============================================================

CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    code VARCHAR(50) UNIQUE NOT NULL,
    name_fr VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    description TEXT,
    
    agent_level VARCHAR(10) NOT NULL, -- 'L0', 'L1', 'L2', 'L3'
    agent_type VARCHAR(50) NOT NULL, -- 'orchestrator', 'chief', 'specialist', 'task'
    
    sphere_id UUID REFERENCES spheres(id),
    domain_id UUID REFERENCES domains(id),
    
    capabilities JSONB DEFAULT '[]',
    
    -- GOVERNANCE: Scope definition
    scope JSONB DEFAULT '{
        "read_spheres": [],
        "write_spheres": [],
        "allowed_actions": [],
        "forbidden_actions": [],
        "requires_approval": []
    }',
    
    llm_provider VARCHAR(50) DEFAULT 'claude',
    llm_model VARCHAR(100),
    
    system_prompt TEXT,
    cost_per_exec INTEGER DEFAULT 1,
    
    -- GOVERNANCE: L0 agents cannot be hired
    is_hireable BOOLEAN DEFAULT TRUE,
    
    is_active BOOLEAN DEFAULT TRUE,
    is_system BOOLEAN DEFAULT FALSE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Enforce L0 cannot be hired
    CONSTRAINT l0_not_hireable CHECK (
        NOT (agent_level = 'L0' AND is_hireable = TRUE)
    )
);

CREATE TABLE agent_hires (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    identity_id UUID NOT NULL REFERENCES identities(id) ON DELETE CASCADE,
    
    custom_config JSONB DEFAULT '{}',
    
    -- Assignment
    assigned_dataspaces UUID[],
    assigned_threads UUID[],
    
    -- Usage tracking
    total_executions INTEGER DEFAULT 0,
    total_tokens_used INTEGER DEFAULT 0,
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'inactive', 'suspended'
    
    hired_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    fired_at TIMESTAMP WITH TIME ZONE,
    
    UNIQUE(agent_id, user_id, identity_id)
);

-- LAW 7: No Self-Directed Agent Learning
CREATE TABLE agent_memory (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    
    memory_type VARCHAR(50) NOT NULL, -- 'instruction', 'rule', 'template', 'procedure'
    memory_key VARCHAR(100) NOT NULL,
    memory_value JSONB NOT NULL,
    
    -- LAW 7: Agent cannot learn about users without permission
    contains_user_data BOOLEAN DEFAULT FALSE,
    user_data_approved BOOLEAN DEFAULT FALSE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(agent_id, memory_type, memory_key),
    -- LAW 7: Enforced
    CONSTRAINT agent_no_unauthorized_learning CHECK (
        contains_user_data = FALSE OR user_data_approved = TRUE
    )
);

CREATE TABLE agent_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES agents(id),
    hire_id UUID REFERENCES agent_hires(id),
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    thread_id UUID REFERENCES threads(id),
    dataspace_id UUID REFERENCES dataspaces(id),
    
    input_data JSONB NOT NULL,
    output_data JSONB,
    
    action_performed VARCHAR(100),
    
    -- GOVERNANCE
    scope_checked BOOLEAN DEFAULT TRUE,
    hitl_required BOOLEAN DEFAULT FALSE,
    hitl_approved BOOLEAN,
    hitl_approved_by UUID REFERENCES users(id),
    
    -- Always synthetic
    synthetic BOOLEAN DEFAULT TRUE NOT NULL,
    
    status VARCHAR(20) DEFAULT 'running', -- 'running', 'completed', 'failed', 'needs_approval', 'cancelled'
    
    tokens_used INTEGER,
    execution_time_ms INTEGER,
    
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    
    error_message TEXT,
    
    -- GOVERNANCE: Enforce synthetic
    CONSTRAINT execution_synthetic CHECK (synthetic = TRUE)
);

CREATE INDEX idx_agent_executions_agent ON agent_executions(agent_id);
CREATE INDEX idx_agent_executions_user ON agent_executions(user_id);
CREATE INDEX idx_agent_executions_status ON agent_executions(status);

-- ============================================================
-- SECTION 9: MEETING SYSTEM
-- ============================================================

CREATE TABLE meetings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dataspace_id UUID REFERENCES dataspaces(id) ON DELETE SET NULL,
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    meeting_type VARCHAR(50) NOT NULL, -- 'standup', 'planning', 'review', 'brainstorm', 'decision', 'workshop'
    
    scheduled_start TIMESTAMP WITH TIME ZONE,
    scheduled_end TIMESTAMP WITH TIME ZONE,
    actual_start TIMESTAMP WITH TIME ZONE,
    actual_end TIMESTAMP WITH TIME ZONE,
    
    status VARCHAR(20) DEFAULT 'scheduled', -- 'scheduled', 'active', 'completed', 'cancelled'
    
    location VARCHAR(255),
    is_xr_meeting BOOLEAN DEFAULT FALSE,
    xr_session_id UUID,
    
    -- GOVERNANCE: Recording consent
    recording_enabled BOOLEAN DEFAULT FALSE,
    all_consents_obtained BOOLEAN DEFAULT FALSE,
    
    agenda JSONB DEFAULT '[]',
    
    created_by UUID NOT NULL REFERENCES users(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- GOVERNANCE: Cannot record without consent
    CONSTRAINT meeting_recording_consent CHECK (
        recording_enabled = FALSE OR all_consents_obtained = TRUE
    )
);

CREATE TABLE meeting_participants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    
    role VARCHAR(50) DEFAULT 'participant', -- 'organizer', 'participant', 'observer', 'presenter'
    
    rsvp_status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'accepted', 'declined', 'tentative'
    
    -- GOVERNANCE: Recording consent per participant
    recording_consent BOOLEAN DEFAULT FALSE,
    consent_given_at TIMESTAMP WITH TIME ZONE,
    
    joined_at TIMESTAMP WITH TIME ZONE,
    left_at TIMESTAMP WITH TIME ZONE,
    
    UNIQUE(meeting_id, user_id)
);

CREATE TABLE meeting_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    
    note_type VARCHAR(50) DEFAULT 'general', -- 'general', 'decision', 'action', 'question', 'idea'
    content TEXT NOT NULL,
    
    created_by UUID REFERENCES users(id),
    agent_id UUID REFERENCES agents(id),
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    metadata JSONB DEFAULT '{}'
);

CREATE TABLE meeting_tasks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    meeting_id UUID NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    assignee_id UUID REFERENCES users(id),
    due_date DATE,
    
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'cancelled'
    priority VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- ============================================================
-- SECTION 10: IMMOBILIER DOMAIN
-- ============================================================

CREATE TABLE properties (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    dataspace_id UUID REFERENCES dataspaces(id) ON DELETE SET NULL,
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    property_type VARCHAR(50) NOT NULL, -- 'residential', 'commercial', 'industrial', 'land', 'mixed'
    ownership_type VARCHAR(50) NOT NULL, -- 'personal', 'enterprise', 'investment'
    
    address_line1 VARCHAR(255) NOT NULL,
    address_line2 VARCHAR(255),
    city VARCHAR(100) NOT NULL,
    province VARCHAR(50) DEFAULT 'QC',
    postal_code VARCHAR(10),
    country VARCHAR(50) DEFAULT 'Canada',
    
    coordinates POINT,
    
    -- Property Details
    lot_size_sqft DECIMAL(12, 2),
    building_size_sqft DECIMAL(12, 2),
    year_built INTEGER,
    num_units INTEGER DEFAULT 1,
    num_bedrooms INTEGER,
    num_bathrooms DECIMAL(3, 1),
    
    -- Financial
    purchase_price DECIMAL(12, 2),
    purchase_date DATE,
    current_value DECIMAL(12, 2),
    last_valuation_date DATE,
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'for_sale', 'sold', 'archived'
    
    -- GOVERNANCE: TAL compliance for Quebec
    tal_compliant BOOLEAN DEFAULT TRUE,
    
    metadata JSONB DEFAULT '{}',
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE property_units (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    
    unit_number VARCHAR(20),
    unit_type VARCHAR(50), -- 'apartment', 'commercial', 'storage', 'parking'
    floor INTEGER DEFAULT 1,
    
    size_sqft DECIMAL(10, 2),
    num_bedrooms INTEGER,
    num_bathrooms DECIMAL(3, 1),
    
    monthly_rent DECIMAL(10, 2),
    
    status VARCHAR(20) DEFAULT 'vacant', -- 'vacant', 'occupied', 'renovating', 'unavailable'
    
    metadata JSONB DEFAULT '{}'
);

CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    unit_id UUID REFERENCES property_units(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(255),
    phone VARCHAR(20),
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'notice_given', 'ended'
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE leases (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    property_id UUID NOT NULL REFERENCES properties(id),
    unit_id UUID REFERENCES property_units(id),
    
    lease_start DATE NOT NULL,
    lease_end DATE,
    
    monthly_rent DECIMAL(10, 2) NOT NULL,
    security_deposit DECIMAL(10, 2),
    
    -- TAL Compliance (Quebec)
    previous_rent DECIMAL(10, 2), -- Section G
    section_g_disclosed BOOLEAN DEFAULT FALSE,
    tal_registered BOOLEAN DEFAULT FALSE,
    tal_registration_number VARCHAR(50),
    
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'renewal_pending', 'terminated'
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE rent_payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lease_id UUID NOT NULL REFERENCES leases(id) ON DELETE CASCADE,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    property_id UUID NOT NULL REFERENCES properties(id),
    
    payment_date DATE NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50), -- 'cheque', 'transfer', 'cash', 'interac'
    
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    
    status VARCHAR(20) DEFAULT 'received', -- 'pending', 'received', 'late', 'partial', 'bounced'
    
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE maintenance_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    unit_id UUID REFERENCES property_units(id),
    tenant_id UUID REFERENCES tenants(id),
    
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    category VARCHAR(50), -- 'plumbing', 'electrical', 'hvac', 'appliance', 'structural', 'other'
    priority VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
    
    status VARCHAR(20) DEFAULT 'open', -- 'open', 'assigned', 'in_progress', 'completed', 'cancelled'
    
    assigned_contractor_id UUID,
    estimated_cost DECIMAL(10, 2),
    actual_cost DECIMAL(10, 2),
    
    requested_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    
    photos TEXT[],
    notes TEXT
);

CREATE INDEX idx_properties_identity ON properties(identity_id);
CREATE INDEX idx_properties_type ON properties(property_type);
CREATE INDEX idx_tenants_property ON tenants(property_id);
CREATE INDEX idx_leases_tenant ON leases(tenant_id);
CREATE INDEX idx_rent_payments_lease ON rent_payments(lease_id);
CREATE INDEX idx_maintenance_property ON maintenance_requests(property_id);

-- ============================================================
-- SECTION 11: XR SESSIONS (READ ONLY)
-- ============================================================

-- GOVERNANCE: XR is READ ONLY - no writes through XR
CREATE TABLE xr_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id),
    identity_id UUID NOT NULL REFERENCES identities(id),
    
    session_type VARCHAR(50) NOT NULL, -- 'workspace_view', 'meeting_room', 'property_tour', 'data_visualization'
    
    -- Source data (READ ONLY reference)
    source_dataspace_id UUID REFERENCES dataspaces(id),
    source_meeting_id UUID REFERENCES meetings(id),
    source_property_id UUID REFERENCES properties(id),
    
    -- XR state (view state only, no data modification)
    view_state JSONB DEFAULT '{}',
    
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ended_at TIMESTAMP WITH TIME ZONE,
    
    -- GOVERNANCE: XR cannot write
    is_read_only BOOLEAN DEFAULT TRUE NOT NULL,
    
    CONSTRAINT xr_read_only CHECK (is_read_only = TRUE)
);

-- ============================================================
-- DEFAULT DATA INSERTS
-- ============================================================

-- Insert default spheres
INSERT INTO spheres (code, name_fr, name_en, icon, color, display_order) VALUES
    ('personal', 'Personnel', 'Personal', '👤', '#3F7249', 1),
    ('business', 'Entreprise', 'Business', '💼', '#D8B26A', 2),
    ('government', 'Gouvernement', 'Government', '🏛️', '#8D8371', 3),
    ('creative', 'Studio Créatif', 'Creative Studio', '🎨', '#3EB4A2', 4),
    ('community', 'Communauté', 'Community', '🤝', '#7A593A', 5),
    ('social', 'Social & Médias', 'Social & Media', '📱', '#2F4C39', 6),
    ('entertainment', 'Divertissement', 'Entertainment', '🎬', '#E9E4D6', 7),
    ('myteam', 'Mon Équipe', 'My Team', '👥', '#1E1F22', 8),
    ('scholar', 'Érudit', 'Scholar', '📚', '#D8B26A', 9);

-- Insert default domains
INSERT INTO domains (sphere_id, code, name_fr, name_en, icon)
SELECT s.id, 'immobilier', 'Immobilier', 'Real Estate', '🏠'
FROM spheres s WHERE s.code = 'business';

INSERT INTO domains (sphere_id, code, name_fr, name_en, icon)
SELECT s.id, 'construction', 'Construction', 'Construction', '🏗️'
FROM spheres s WHERE s.code = 'business';

INSERT INTO domains (sphere_id, code, name_fr, name_en, icon)
SELECT s.id, 'finance', 'Finance', 'Finance', '💰'
FROM spheres s WHERE s.code = 'business';

-- ============================================================
-- GOVERNANCE SUMMARY
-- ============================================================
COMMENT ON SCHEMA public IS '
CHE·NU™ V70 Database Schema

GOVERNANCE RULES ENFORCED:
1. GOUVERNANCE > EXÉCUTION - All sensitive actions require HITL
2. XR READ ONLY - xr_sessions.is_read_only enforced as TRUE
3. SYNTHETIC ONLY - agent_executions.synthetic enforced as TRUE
4. TEN LAWS OF MEMORY:
   - Law 1: memory_items.visible_to_user = TRUE
   - Law 3-4: memory_items.identity_id NOT NULL (identity scoping)
   - Law 5: memory_items.user_deletable = TRUE
   - Law 7: agent_memory unauthorized learning blocked
5. L0 AGENTS NOT HIREABLE - agents constraint enforced
6. MEETING RECORDING CONSENT - meetings constraint enforced

All governance constraints are enforced at database level.
';
