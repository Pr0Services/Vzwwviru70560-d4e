"""
CHE·NU™ V70 — MEMORY & GOVERNANCE ENGINE PACKAGE
================================================
Safety core for memory operations and permissions.

Based on: MEMORY_GOVERNANCE_CHAPTER.md (Chapters 127-135)

THE TEN LAWS OF MEMORY:
1. No Hidden Memory
2. Explicit Storage Approval
3. Identity Scoping
4. No Cross-Identity Access
5. Reversibility
6. Operation Logging
7. No Self-Directed Agent Learning
8. Domain Awareness
9. DataSpace Foundation
10. User-Controlled Lifespan

GOUVERNANCE > EXÉCUTION
"""

from .engine import (
    # Enums
    MemoryType,
    MemoryLifespan,
    PermissionLevel,
    GovernanceAction,
    AuditEventType,
    # Models
    MemoryEntry,
    MemoryOperation,
    Permission,
    IdentityBoundary,
    AuditEntry,
    # Engine
    MemoryGovernanceEngine,
    get_memory_governance_engine,
)

__all__ = [
    "MemoryType",
    "MemoryLifespan",
    "PermissionLevel",
    "GovernanceAction",
    "AuditEventType",
    "MemoryEntry",
    "MemoryOperation",
    "Permission",
    "IdentityBoundary",
    "AuditEntry",
    "MemoryGovernanceEngine",
    "get_memory_governance_engine",
]

__version__ = "70.0.0"
