"""
CHE·NU™ V70 — MIGRATIONS PACKAGE
================================
Database migrations for GP2.
"""

__version__ = "70.0.0"
