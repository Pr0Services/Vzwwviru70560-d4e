"""
CHE·NU™ V70 — MAIN API ROUTER
==============================
Combines all API routers into a single FastAPI application.

Based on: CHENU_API_SPECS_v29.md

Base URL: https://api.che-nu.com/v1

GOUVERNANCE > EXÉCUTION
"""

from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from datetime import datetime
from uuid import uuid4
import logging

# Import all routers
from .routers.core import (
    identity_router,
    dataspace_router,
    thread_router,
    APIResponse,
)
from .routers.engines import (
    workspace_router,
    oneclick_router,
    backstage_router,
)
from .routers.memory_agents import (
    memory_router,
    governance_router,
    agent_router,
)
from .routers.meeting_immobilier import (
    meeting_router,
    immobilier_router,
)

logger = logging.getLogger("chenu.api")


# =============================================================================
# APPLICATION FACTORY
# =============================================================================

def create_app() -> FastAPI:
    """
    Create the CHE·NU API application.
    
    Combines all routers with proper middleware and configuration.
    """
    app = FastAPI(
        title="CHE·NU™ API",
        description="Governed Intelligence Operating System API",
        version="70.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
    )
    
    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Request ID middleware
    @app.middleware("http")
    async def add_request_id(request: Request, call_next):
        request_id = request.headers.get("X-Request-ID", str(uuid4()))
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        return response
    
    # Error handlers
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        return JSONResponse(
            status_code=exc.status_code,
            content={
                "success": False,
                "error": {
                    "code": f"HTTP_{exc.status_code}",
                    "message": exc.detail,
                    "details": {}
                },
                "meta": {
                    "request_id": request.headers.get("X-Request-ID", str(uuid4())),
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
        )
    
    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}")
        return JSONResponse(
            status_code=500,
            content={
                "success": False,
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "An internal error occurred",
                    "details": {}
                },
                "meta": {
                    "request_id": request.headers.get("X-Request-ID", str(uuid4())),
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
        )
    
    # Root endpoint
    @app.get("/", response_model=APIResponse)
    async def root():
        """API root - health and info."""
        return APIResponse(data={
            "name": "CHE·NU™ API",
            "version": "70.0.0",
            "status": "healthy",
            "governance": {
                "governance_over_execution": True,
                "xr_read_only": True,
                "synthetic_only": True,
                "hitl_required": True,
                "ten_laws_of_memory": True
            },
            "endpoints": {
                "identity": "/v1/identities",
                "dataspaces": "/v1/dataspaces",
                "threads": "/v1/threads",
                "workspaces": "/v1/workspaces",
                "oneclick": "/v1/oneclick",
                "backstage": "/v1/backstage",
                "memory": "/v1/memory",
                "governance": "/v1/governance",
                "agents": "/v1/agents",
                "meetings": "/v1/meetings",
                "immobilier": "/v1/immobilier"
            }
        })
    
    # Health check
    @app.get("/health", response_model=APIResponse)
    async def health_check():
        """Health check endpoint."""
        return APIResponse(data={
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "services": {
                "api": "up",
                "database": "up",
                "cache": "up",
                "workers": "up"
            }
        })
    
    # Include all routers under /v1 prefix
    app.include_router(identity_router, prefix="/v1")
    app.include_router(dataspace_router, prefix="/v1")
    app.include_router(thread_router, prefix="/v1")
    app.include_router(workspace_router, prefix="/v1")
    app.include_router(oneclick_router, prefix="/v1")
    app.include_router(backstage_router, prefix="/v1")
    app.include_router(memory_router, prefix="/v1")
    app.include_router(governance_router, prefix="/v1")
    app.include_router(agent_router, prefix="/v1")
    app.include_router(meeting_router, prefix="/v1")
    app.include_router(immobilier_router, prefix="/v1")
    
    logger.info("CHE·NU API initialized with all routers")
    
    return app


# Create default app instance
app = create_app()


# =============================================================================
# GOVERNANCE DOCUMENTATION
# =============================================================================

GOVERNANCE_SUMMARY = """
CHE·NU™ API GOVERNANCE RULES
============================

1. GOUVERNANCE > EXÉCUTION
   - All sensitive actions require explicit approval
   - No autonomous execution without human oversight

2. XR READ ONLY
   - XR endpoints only return visualization data
   - No writes through XR interfaces

3. SYNTHETIC ONLY
   - All simulations are synthetic=True
   - No real-world effects

4. HITL REQUIRED
   - Human-In-The-Loop for:
     * Sending external communications
     * Financial transactions
     * Data deletion
     * Publishing content
     * Cross-identity operations

5. TEN LAWS OF MEMORY
   - Law 1: No Hidden Memory
   - Law 2: Explicit Storage Approval
   - Law 3: Identity Scoping
   - Law 4: No Cross-Identity Access
   - Law 5: Reversibility
   - Law 6: Operation Logging
   - Law 7: No Self-Directed Agent Learning
   - Law 8: Domain Awareness
   - Law 9: DataSpace Foundation
   - Law 10: User-Controlled Lifespan

6. L0 AGENTS
   - System agents (L0) cannot be hired or executed directly
   - Only system can invoke L0 agents

7. TAL COMPLIANCE (Immobilier)
   - All lease operations comply with Tribunal administratif du logement
   - Section G disclosure required
   - Rent increase calculations follow TAL guidelines

8. RECORDING CONSENT (Meetings)
   - All meeting recordings require participant consent
   - Cannot start recording without explicit approval
"""
