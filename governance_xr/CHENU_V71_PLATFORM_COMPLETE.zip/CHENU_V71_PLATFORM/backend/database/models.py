"""
CHE·NU™ V70 — SQLALCHEMY ORM MODELS
===================================
Database models for GP2 system.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from datetime import datetime
from typing import Any, Optional, List
from uuid import uuid4

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    Index,
    event,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, Session
from sqlalchemy.sql import func

Base = declarative_base()


# =============================================================================
# MIXINS
# =============================================================================

class TimestampMixin:
    """Mixin for timestamp columns."""
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class GovernanceMixin:
    """Mixin for governance columns."""
    synthetic = Column(Boolean, default=True, nullable=False)
    opa_validated = Column(Boolean, default=False)
    governance_level = Column(String(32), default="strict")


# =============================================================================
# AUDIT LOG
# =============================================================================

class AuditLog(Base, TimestampMixin):
    """Audit log entry."""
    __tablename__ = "audit_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    audit_id = Column(String(32), unique=True, nullable=False, default=lambda: f"AUDIT_{uuid4().hex[:8]}")
    
    # Action info
    module = Column(String(64), nullable=False, index=True)
    action = Column(String(128), nullable=False)
    
    # Actor info
    actor_id = Column(String(64), index=True)
    actor_type = Column(String(32), default="user")
    
    # Request context
    request_id = Column(String(32))
    session_id = Column(String(64))
    
    # Governance
    opa_validated = Column(Boolean, default=False)
    hitl_approved = Column(Boolean)
    synthetic_only = Column(Boolean, default=True)
    
    # Data
    input_data = Column(JSONB, default={})
    output_data = Column(JSONB, default={})
    violations = Column(JSONB, default=[])
    
    __table_args__ = (
        Index("idx_audit_module_action", "module", "action"),
        Index("idx_audit_created", "created_at"),
    )


# =============================================================================
# OPA DECISIONS
# =============================================================================

class OPADecision(Base, TimestampMixin):
    """OPA policy decision cache."""
    __tablename__ = "opa_decisions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    decision_id = Column(String(32), unique=True, nullable=False, default=lambda: f"OPA_{uuid4().hex[:8]}")
    
    policy_path = Column(String(256), nullable=False, index=True)
    input_hash = Column(String(64), nullable=False, index=True)
    
    decision = Column(Boolean, nullable=False)
    input_data = Column(JSONB, default={})
    output_data = Column(JSONB, default={})
    
    expires_at = Column(DateTime(timezone=True))


# =============================================================================
# NOVA REQUESTS
# =============================================================================

class NovaRequest(Base, TimestampMixin, GovernanceMixin):
    """NOVA kernel request."""
    __tablename__ = "nova_requests"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    request_id = Column(String(32), unique=True, nullable=False, default=lambda: f"REQ_{uuid4().hex[:8]}")
    
    # Intent
    intent = Column(Text, nullable=False)
    context = Column(JSONB, default={})
    
    # User
    user_id = Column(String(64), ForeignKey("users.user_id"), index=True)
    
    # Processing
    processed = Column(Boolean, default=False)
    processing_started_at = Column(DateTime(timezone=True))
    processing_completed_at = Column(DateTime(timezone=True))
    
    # Result
    is_refusal = Column(Boolean, default=False)
    refusal_reason = Column(Text)
    response = Column(JSONB)
    
    # Governance
    forbidden_action_detected = Column(Boolean, default=False)
    audit_trail = Column(JSONB, default=[])
    
    # Relationships
    user = relationship("User", back_populates="nova_requests")


# =============================================================================
# ETHICS VALIDATIONS
# =============================================================================

class EthicsValidation(Base, TimestampMixin):
    """Ethics canon validation."""
    __tablename__ = "ethics_validations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    validation_id = Column(String(32), unique=True, nullable=False, default=lambda: f"ETH_{uuid4().hex[:8]}")
    
    action_description = Column(Text, nullable=False)
    actor_type = Column(String(32), default="system_intelligence")
    
    is_valid = Column(Boolean, nullable=False, index=True)
    violations = Column(JSONB, default=[])
    forbidden_state = Column(String(64))
    
    rules_checked = Column(JSONB, default=[])
    canon_version = Column(String(16), default="70.0.0")
    
    # Ethics canon is IMMUTABLE
    immutable = Column(Boolean, default=True)


# =============================================================================
# DECISION PACKAGES
# =============================================================================

class DecisionPackage(Base, TimestampMixin, GovernanceMixin):
    """Civilization decision package."""
    __tablename__ = "decision_packages"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    package_id = Column(String(32), unique=True, nullable=False, default=lambda: f"PKG_{uuid4().hex[:8]}")
    
    # Content
    title = Column(String(256))
    summary = Column(Text)
    user_intent = Column(Text, nullable=False)
    
    # Related IDs
    worldstate_id = Column(String(32))
    simulation_id = Column(String(32))
    causal_trace_id = Column(String(32))
    xr_scene_id = Column(String(32))
    
    # Options
    options = Column(JSONB, default=[])
    recommended_option = Column(Integer)
    risk_assessment = Column(JSONB, default={})
    
    # HITL
    hitl_required = Column(Boolean, default=True)
    hitl_approved = Column(Boolean, default=False, index=True)
    approved_by = Column(String(64), ForeignKey("users.user_id"))
    approved_at = Column(DateTime(timezone=True))
    
    # Export
    exported = Column(Boolean, default=False)
    export_format = Column(String(32))
    exported_at = Column(DateTime(timezone=True))
    
    # Security
    signatures = Column(JSONB, default=[])
    integrity_hash = Column(String(64))
    
    # Status
    status = Column(String(32), default="draft", index=True)
    
    # Relationships
    approver = relationship("User", foreign_keys=[approved_by])


# =============================================================================
# SIMULATIONS
# =============================================================================

class Simulation(Base, TimestampMixin, GovernanceMixin):
    """Simulation run."""
    __tablename__ = "simulations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    simulation_id = Column(String(32), unique=True, nullable=False, default=lambda: f"SIM_{uuid4().hex[:8]}")
    
    # Configuration
    mode = Column(String(32), default="deterministic")
    max_cycles = Column(Integer, default=100)
    
    # State
    initial_state = Column(JSONB, default={})
    final_state = Column(JSONB, default={})
    
    # Progress
    cycles_completed = Column(Integer, default=0)
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    
    # Results
    causal_trace_id = Column(String(32))
    status = Column(String(32), default="pending", index=True)


# =============================================================================
# FAILSAFE
# =============================================================================

class FailsafeActivation(Base, TimestampMixin):
    """Failsafe activation record."""
    __tablename__ = "failsafe_activations"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    activation_id = Column(String(32), unique=True, nullable=False, default=lambda: f"FAIL_{uuid4().hex[:8]}")
    
    crisis_type = Column(String(64), nullable=False)
    response_level = Column(String(32), nullable=False)
    
    indicators = Column(JSONB, default={})
    actions_taken = Column(JSONB, default=[])
    
    is_active = Column(Boolean, default=True, index=True)
    deactivated_at = Column(DateTime(timezone=True))
    
    triggered_by = Column(String(64))


# =============================================================================
# XR SCENES
# =============================================================================

class XRScene(Base, TimestampMixin):
    """XR scene (READ ONLY artifacts)."""
    __tablename__ = "xr_scenes"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    scene_id = Column(String(32), unique=True, nullable=False, default=lambda: f"XR_{uuid4().hex[:8]}")
    
    scene_type = Column(String(64), nullable=False, index=True)
    render_mode = Column(String(32), default="threejs")
    
    # Scene data
    nodes = Column(JSONB, default=[])
    edges = Column(JSONB, default=[])
    metadata = Column(JSONB, default={})
    
    # CRITICAL: Always read-only
    read_only = Column(Boolean, default=True, nullable=False)
    
    # Package reference
    package_id = Column(String(32), ForeignKey("decision_packages.package_id"))
    
    # Security
    integrity_hash = Column(String(64))
    signature = Column(Text)


# Ensure XR scenes are always read-only
@event.listens_for(XRScene, "before_insert")
@event.listens_for(XRScene, "before_update")
def ensure_xr_read_only(mapper, connection, target):
    """Enforce XR read-only constraint."""
    target.read_only = True


# =============================================================================
# USERS
# =============================================================================

class User(Base, TimestampMixin):
    """User account."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(32), unique=True, nullable=False, default=lambda: f"USER_{uuid4().hex[:8]}")
    
    username = Column(String(64), unique=True, nullable=False, index=True)
    email = Column(String(256), unique=True, nullable=False, index=True)
    password_hash = Column(String(256), nullable=False)
    
    roles = Column(JSONB, default=["viewer"])
    permissions = Column(JSONB, default=[])
    
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    last_login = Column(DateTime(timezone=True))
    metadata = Column(JSONB, default={})
    
    # Relationships
    nova_requests = relationship("NovaRequest", back_populates="user")
    sessions = relationship("Session", back_populates="user")


# =============================================================================
# SESSIONS
# =============================================================================

class Session(Base, TimestampMixin):
    """User session."""
    __tablename__ = "sessions"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(64), unique=True, nullable=False, default=lambda: f"SESSION_{uuid4().hex}")
    
    user_id = Column(String(32), ForeignKey("users.user_id"), nullable=False, index=True)
    
    expires_at = Column(DateTime(timezone=True), nullable=False)
    is_active = Column(Boolean, default=True)
    
    ip_address = Column(String(45))
    user_agent = Column(String(512))
    
    # Relationships
    user = relationship("User", back_populates="sessions")


# =============================================================================
# SKILL TRACES (Module 26)
# =============================================================================

class SkillTrace(Base, TimestampMixin, GovernanceMixin):
    """Skill transmission trace."""
    __tablename__ = "skill_traces"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    trace_id = Column(String(32), unique=True, nullable=False, default=lambda: f"SKILL_{uuid4().hex[:8]}")
    
    skill_name = Column(String(200), nullable=False, index=True)
    
    learner_id = Column(String(64), nullable=False, index=True)
    mentor_id = Column(String(64))
    
    source_context = Column(JSONB, default={})
    transmission_method = Column(String(64))
    
    generation_score = Column(Float, default=0.0)
    trust_score = Column(Float, default=0.0)
    
    status = Column(String(32), default="active")


# =============================================================================
# HERITAGE PACKAGES (Module 27)
# =============================================================================

class HeritagePackage(Base, TimestampMixin, GovernanceMixin):
    """Heritage preservation package."""
    __tablename__ = "heritage_packages"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    package_id = Column(String(32), unique=True, nullable=False, default=lambda: f"HER_{uuid4().hex[:8]}")
    
    content_type = Column(String(64), nullable=False)
    content = Column(JSONB, default={})
    
    preservation_level = Column(String(32), default="standard")
    expiry_date = Column(DateTime(timezone=True))
    
    compressed = Column(Boolean, default=False)
    encrypted = Column(Boolean, default=False)
    
    signatures = Column(JSONB, default=[])
    integrity_hash = Column(String(64))


# =============================================================================
# DATABASE SETUP
# =============================================================================

def create_tables(engine):
    """Create all tables."""
    Base.metadata.create_all(engine)


def drop_tables(engine):
    """Drop all tables."""
    Base.metadata.drop_all(engine)


# =============================================================================
# SESSION HELPERS
# =============================================================================

def get_by_id(session: Session, model, record_id: str, id_field: str = "id"):
    """Get record by ID."""
    return session.query(model).filter(getattr(model, id_field) == record_id).first()


def create_audit_log(
    session: Session,
    module: str,
    action: str,
    actor_id: str = None,
    input_data: dict = None,
    output_data: dict = None,
) -> AuditLog:
    """Create audit log entry."""
    log = AuditLog(
        module=module,
        action=action,
        actor_id=actor_id,
        input_data=input_data or {},
        output_data=output_data or {},
        synthetic_only=True,  # Always synthetic
    )
    session.add(log)
    session.commit()
    return log
