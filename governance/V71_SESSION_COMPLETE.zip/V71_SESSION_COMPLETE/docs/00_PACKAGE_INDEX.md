# 📦 CHE·NU™ V71 — PACKAGE BRIEFING AGENTS

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    PACKAGE COMPLET POUR 2 AGENTS                             ║
║                                                                              ║
║                      Agent Alpha (Backend)                                   ║
║                      Agent Beta (Frontend)                                   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Date:** 6 Janvier 2026  
**Version:** V71.0.0 → V72 Production  
**Timeline:** 3 semaines

---

## 📋 CONTENU DU PACKAGE

### Documents Stratégiques

| Fichier | Description | Pour |
|---------|-------------|------|
| `V71_ROADMAP_2_AGENTS.md` | Roadmap complète 3 semaines | Alpha + Beta |
| `V71_API_CONTRACTS.md` | Contrats API TypeScript | Alpha + Beta |
| `V71_IMPLEMENTATION_REPORT.md` | État actuel V71 | Alpha + Beta |

### Prompts Agents

| Fichier | Description | Pour |
|---------|-------------|------|
| `PROMPT_AGENT_ALPHA_BACKEND.md` | Briefing complet backend | Agent Alpha |
| `PROMPT_AGENT_BETA_FRONTEND.md` | Briefing complet frontend | Agent Beta |

### Code V71 (Prêt)

| Dossier | Contenu | Lignes |
|---------|---------|--------|
| `backend/core/synaptic/` | 6 modules Python | ~4,500 |
| `backend/api/routes/` | 3 routers FastAPI | ~1,800 |
| `tests/` | 50+ tests unitaires | ~1,200 |

---

## 🚀 DÉMARRAGE RAPIDE

### Pour Agent Alpha (Backend)

```bash
# 1. Lire le briefing
cat PROMPT_AGENT_ALPHA_BACKEND.md

# 2. Comprendre les contrats
cat V71_API_CONTRACTS.md

# 3. Voir le code existant
ls -la backend/core/synaptic/
ls -la backend/api/routes/

# 4. Commencer Semaine 1
# → Nova Pipeline (HTTP 423)
# → Identity Boundary (HTTP 403)
# → Tests 60%
```

### Pour Agent Beta (Frontend)

```bash
# 1. Lire le briefing
cat PROMPT_AGENT_BETA_FRONTEND.md

# 2. Comprendre les contrats API
cat V71_API_CONTRACTS.md

# 3. Commencer Semaine 1
# → API Client TypeScript
# → Synaptic Dashboard
# → Checkpoint Modal (HTTP 423)
# → WebSocket connection
```

---

## 🔄 POINTS DE SYNC

### Jour 1 — Contrats API
- Alpha expose endpoints selon `V71_API_CONTRACTS.md`
- Beta implémente client selon mêmes contrats
- **Validation:** curl/Postman test tous endpoints

### Jour 5 — WebSocket
- Alpha: Events fonctionnels
- Beta: Listener connecté
- **Validation:** Event checkpoint.pending déclenche modal

### Jour 9 — Test Data
- Alpha: Fixtures complètes
- Beta: Mock data alignés
- **Validation:** E2E golden flows passent

---

## ⚠️ RÈGLES ABSOLUES

### HTTP 423 — Checkpoint
```
Backend: DOIT retourner 423 quand checkpoint requis
Frontend: DOIT afficher modal approve/reject
Bypass: INTERDIT
```

### HTTP 403 — Identity
```
Backend: DOIT bloquer cross-identity
Frontend: DOIT afficher erreur accès refusé
Bypass: INTERDIT
```

### Human Sovereignty
```
Actions sensibles = Checkpoint obligatoire
User DOIT approuver explicitement
Aucune exécution automatique
```

---

## 📊 MÉTRIQUES SUCCÈS V72

| Métrique | Cible | Critique |
|----------|-------|----------|
| Test Coverage | ≥ 70% | ✅ |
| API Response p95 | < 200ms | ✅ |
| Uptime | 99.9% | ✅ |
| Bundle Size | < 500KB | ✅ |
| Lighthouse | > 90 | ✅ |
| Golden Flows | 100% pass | ✅ |

---

## 📁 STRUCTURE FINALE ATTENDUE

```
CHENU_V72_PRODUCTION/
├── backend/
│   ├── core/
│   │   ├── synaptic/          # V71 modules
│   │   ├── nova/              # Nova Pipeline (Alpha)
│   │   └── identity/          # Identity Boundary (Alpha)
│   ├── api/
│   │   └── routes/            # All routers
│   └── tests/
│       └── coverage ≥ 70%
├── frontend/
│   ├── src/
│   │   ├── api/               # API Client (Beta)
│   │   ├── components/
│   │   │   ├── SynapticDashboard/
│   │   │   ├── CheckpointModal/
│   │   │   └── QuantumDashboard/
│   │   └── hooks/
│   │       └── useWebSocket.ts
│   └── cypress/
│       └── e2e/
└── docs/
    ├── API_CONTRACTS.md
    └── DEPLOYMENT.md
```

---

## 🎯 COMMANDES UTILES

### Backend (Alpha)

```bash
# Tests
pytest tests/ -v --cov=backend --cov-report=html

# Lint
ruff check backend/

# Type check
mypy backend/

# Run server
uvicorn backend.main:app --reload --port 8000
```

### Frontend (Beta)

```bash
# Dev
npm run dev

# Tests
npm run test

# E2E
npm run cypress:run

# Build
npm run build

# Lint
npm run lint
```

---

## ✅ CHECKLIST PRÉ-DÉMARRAGE

### Agent Alpha
- [ ] Package ZIP reçu et extrait
- [ ] `PROMPT_AGENT_ALPHA_BACKEND.md` lu
- [ ] `V71_API_CONTRACTS.md` compris
- [ ] Code V71 examiné
- [ ] Environment setup (Python 3.11+, FastAPI)
- [ ] Prêt à commencer Nova Pipeline

### Agent Beta
- [ ] Package ZIP reçu et extrait
- [ ] `PROMPT_AGENT_BETA_FRONTEND.md` lu
- [ ] `V71_API_CONTRACTS.md` compris
- [ ] Environment setup (Node 20+, React 18+)
- [ ] Prêt à commencer API Client

---

## 📞 PROTOCOLE COMMUNICATION

### Questions Techniques
1. Chercher dans `V71_API_CONTRACTS.md`
2. Chercher dans code V71 existant
3. Documenter décision si nouveau pattern

### Blockers
1. Documenter le blocker
2. Proposer solution
3. Sync avec autre agent si cross-cutting

### Changements Contrats
1. **INTERDIT** de modifier unilatéralement
2. Proposer changement
3. Sync obligatoire Alpha ↔ Beta
4. Mettre à jour `V71_API_CONTRACTS.md`

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    "GOVERNANCE > EXECUTION"                                  ║
║                                                                              ║
║              V71 → V72 Production en 3 semaines 🚀                          ║
║                                                                              ║
║                  Alpha (Backend) + Beta (Frontend)                           ║
║                       Travail Parallèle Synchronisé                          ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

© 2026 CHE·NU™
