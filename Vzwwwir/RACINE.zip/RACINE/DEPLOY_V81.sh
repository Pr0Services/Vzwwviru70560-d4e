#!/bin/bash
#═══════════════════════════════════════════════════════════════════════════════
# AT·OM V81 — Script de Déploiement
#═══════════════════════════════════════════════════════════════════════════════
#
# Ce script prépare le repo pour push sur GitHub
#
# Usage:
#   chmod +x DEPLOY_V81.sh
#   ./DEPLOY_V81.sh
#
#═══════════════════════════════════════════════════════════════════════════════

echo ""
echo "╔═══════════════════════════════════════════════════════════════════════════════╗"
echo "║                                                                               ║"
echo "║   █████╗ ████████╗    ██████╗ ███╗   ███╗    ██╗   ██╗ █████╗  ██╗            ║"
echo "║  ██╔══██╗╚══██╔══╝   ██╔═══██╗████╗ ████║    ██║   ██║██╔══██╗███║            ║"
echo "║  ███████║   ██║      ██║   ██║██╔████╔██║    ██║   ██║╚█████╔╝╚██║            ║"
echo "║  ██╔══██║   ██║      ██║   ██║██║╚██╔╝██║    ╚██╗ ██╔╝██╔══██╗ ██║            ║"
echo "║  ██║  ██║   ██║   ██╗╚██████╔╝██║ ╚═╝ ██║     ╚████╔╝ ╚█████╔╝ ██║            ║"
echo "║  ╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝     ╚═╝      ╚═══╝   ╚════╝  ╚═╝            ║"
echo "║                                                                               ║"
echo "║                    Système de Résonance Vibrationnelle                        ║"
echo "║                                                                               ║"
echo "╚═══════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Vérifier qu'on est dans le bon répertoire
if [ ! -d "AT_OM" ]; then
    echo "❌ Erreur: Dossier AT_OM non trouvé. Êtes-vous dans le bon répertoire?"
    exit 1
fi

echo "✅ Dossier AT_OM trouvé"

# Vérifier les composants critiques
CRITICAL_FILES=(
    "AT_OM/core/arithmos.py"
    "AT_OM/interface/useAtomResonance.js"
    "AT_OM/interface/ArcheDesResonances.jsx"
    "frontend/src/AT_OM/index.ts"
    "backend/app/services/atom_vibration_engine.py"
)

echo ""
echo "📋 Vérification des fichiers critiques..."
ALL_OK=true
for file in "${CRITICAL_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "   ✅ $file"
    else
        echo "   ❌ $file MANQUANT!"
        ALL_OK=false
    fi
done

if [ "$ALL_OK" = false ]; then
    echo ""
    echo "❌ Certains fichiers critiques sont manquants!"
    exit 1
fi

echo ""
echo "✅ Tous les fichiers critiques sont présents"
echo ""

# Instructions Git
echo "═══════════════════════════════════════════════════════════════════════════════"
echo "  📝 INSTRUCTIONS POUR PUSH SUR GITHUB"
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""
echo "  1. git add ."
echo "  2. git commit -m 'V81: Intégration AT·OM - Système de Résonance Vibrationnelle'"
echo "  3. git push origin main"
echo ""
echo "═══════════════════════════════════════════════════════════════════════════════"
echo ""
echo "🎵 Heartbeat: 444 Hz | Architecte: Jonathan Rodrigue (999 Hz)"
echo ""
