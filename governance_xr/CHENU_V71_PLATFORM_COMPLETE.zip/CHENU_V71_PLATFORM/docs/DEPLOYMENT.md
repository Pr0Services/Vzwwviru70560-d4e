# CHE·NU™ V70 — DEPLOYMENT GUIDE

## Complete Deployment Documentation

---

## 1. PREREQUISITES

### System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| CPU | 4 cores | 8+ cores |
| RAM | 8 GB | 16+ GB |
| Storage | 50 GB SSD | 200+ GB NVMe |
| OS | Ubuntu 22.04 | Ubuntu 24.04 |

### Software Requirements

```bash
# Python 3.11+
python3 --version

# Node.js 20+ (for frontend)
node --version

# Docker 24+
docker --version

# PostgreSQL 15+
psql --version

# Redis 7+
redis-server --version
```

---

## 2. ENVIRONMENT SETUP

### Clone Repository

```bash
git clone https://github.com/chenu/chenu-platform.git
cd chenu-platform
```

### Create Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Environment Variables

Create `.env` from template:

```bash
cp .env.example .env
```

Edit `.env`:

```env
# Application
APP_ENV=production
APP_DEBUG=false
APP_SECRET_KEY=your-secure-secret-key-here

# Database
DATABASE_URL=postgresql://chenu:password@localhost:5432/chenu_db
DATABASE_POOL_SIZE=20
DATABASE_MAX_OVERFLOW=10

# Redis
REDIS_URL=redis://localhost:6379/0
REDIS_CACHE_TTL=3600

# Authentication
JWT_SECRET_KEY=your-jwt-secret-here
JWT_ALGORITHM=HS256
JWT_EXPIRATION_HOURS=24

# LLM Providers
ANTHROPIC_API_KEY=your-anthropic-key
OPENAI_API_KEY=your-openai-key

# Governance
GOVERNANCE_ENABLED=true
HITL_REQUIRED=true
SYNTHETIC_ONLY=true
XR_READ_ONLY=true

# Monitoring
PROMETHEUS_ENABLED=true
GRAFANA_ENABLED=true
LOG_LEVEL=INFO
```

---

## 3. DATABASE SETUP

### Create Database

```bash
# Connect to PostgreSQL
sudo -u postgres psql

# Create database and user
CREATE USER chenu WITH PASSWORD 'your-secure-password';
CREATE DATABASE chenu_db OWNER chenu;
GRANT ALL PRIVILEGES ON DATABASE chenu_db TO chenu;

# Enable extensions
\c chenu_db
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "postgis";

\q
```

### Run Migrations

```bash
# Using Alembic
alembic upgrade head

# Or run schema directly
psql -U chenu -d chenu_db -f database/complete_schema_v70.sql
```

### Seed Initial Data

```bash
python scripts/seed_data.py
```

---

## 4. DOCKER DEPLOYMENT

### Build Images

```bash
# Build all services
docker-compose build

# Or build specific service
docker build -t chenu-api:v70 -f Dockerfile .
```

### Docker Compose

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Docker Compose Override (Production)

```yaml
# docker-compose.prod.yml
version: '3.8'

services:
  api:
    image: chenu-api:v70
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '2'
          memory: 4G
    environment:
      - APP_ENV=production
      - WORKERS=4

  worker:
    image: chenu-worker:v70
    deploy:
      replicas: 2
```

---

## 5. KUBERNETES DEPLOYMENT

### Prerequisites

```bash
# Install kubectl
kubectl version --client

# Configure cluster
kubectl config use-context production
```

### Deploy with Kustomize

```bash
# Apply base configuration
kubectl apply -k k8s/base/

# Apply production overlay
kubectl apply -k k8s/overlays/production/
```

### Verify Deployment

```bash
# Check pods
kubectl get pods -n chenu

# Check services
kubectl get svc -n chenu

# Check ingress
kubectl get ingress -n chenu
```

### Scaling

```bash
# Scale API pods
kubectl scale deployment chenu-api --replicas=5 -n chenu

# Enable HPA
kubectl apply -f k8s/base/hpa.yaml
```

---

## 6. SSL/TLS CONFIGURATION

### Using Let's Encrypt

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d api.che-nu.com
```

### Nginx Configuration

```nginx
server {
    listen 443 ssl http2;
    server_name api.che-nu.com;

    ssl_certificate /etc/letsencrypt/live/api.che-nu.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.che-nu.com/privkey.pem;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

---

## 7. MONITORING SETUP

### Prometheus

```yaml
# prometheus.yml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'chenu-api'
    static_configs:
      - targets: ['api:8000']
    metrics_path: /metrics
```

### Grafana Dashboards

```bash
# Access Grafana
http://localhost:3000

# Default credentials
admin / admin
```

Import dashboards from `monitoring/grafana/dashboards/`.

### Alert Rules

```yaml
# alerts.yml
groups:
  - name: chenu-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.1
        for: 5m
        annotations:
          summary: "High error rate detected"

      - alert: GovernanceViolation
        expr: governance_violations_total > 0
        for: 1m
        annotations:
          summary: "Governance violation detected"
```

---

## 8. BACKUP & RECOVERY

### Database Backup

```bash
# Automated backup script
#!/bin/bash
BACKUP_DIR=/backups/postgresql
DATE=$(date +%Y%m%d_%H%M%S)
pg_dump -U chenu -d chenu_db | gzip > $BACKUP_DIR/chenu_$DATE.sql.gz

# Retain 30 days
find $BACKUP_DIR -type f -mtime +30 -delete
```

### Restore Database

```bash
# Restore from backup
gunzip -c backup.sql.gz | psql -U chenu -d chenu_db
```

### Redis Backup

```bash
# Trigger RDB snapshot
redis-cli BGSAVE

# Copy RDB file
cp /var/lib/redis/dump.rdb /backups/redis/
```

---

## 9. SECURITY HARDENING

### API Security

```python
# Rate limiting
from slowapi import Limiter
limiter = Limiter(key_func=get_remote_address)

@app.post("/v1/oneclick/execute")
@limiter.limit("10/minute")
async def execute_oneclick():
    pass
```

### Database Security

```sql
-- Restrict permissions
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM PUBLIC;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO chenu_api;
```

### Network Security

```bash
# UFW firewall
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

---

## 10. HEALTH CHECKS

### API Health

```bash
# Check API health
curl https://api.che-nu.com/health

# Expected response
{
  "success": true,
  "data": {
    "status": "healthy",
    "services": {
      "api": "up",
      "database": "up",
      "cache": "up",
      "workers": "up"
    }
  }
}
```

### Database Health

```bash
# Check PostgreSQL
pg_isready -h localhost -p 5432

# Check connections
psql -U chenu -d chenu_db -c "SELECT count(*) FROM pg_stat_activity;"
```

### Redis Health

```bash
# Check Redis
redis-cli ping
# PONG
```

---

## 11. GOVERNANCE VERIFICATION

### Verify Governance is Active

```bash
# Check governance status
curl https://api.che-nu.com/ | jq '.data.governance'

# Expected
{
  "governance_over_execution": true,
  "xr_read_only": true,
  "synthetic_only": true,
  "hitl_required": true,
  "ten_laws_of_memory": true
}
```

### Run Governance Tests

```bash
# Run governance test suite
pytest tests/test_governance.py -v

# Verify all pass
# ✓ test_law1_no_hidden_memory
# ✓ test_law2_long_term_requires_approval
# ✓ test_xr_read_only
# ✓ test_synthetic_only
# ✓ test_l0_cannot_be_hired
```

---

## 12. TROUBLESHOOTING

### Common Issues

**API Not Starting**
```bash
# Check logs
docker-compose logs api

# Common fix: Database connection
export DATABASE_URL=postgresql://...
```

**Database Connection Failed**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check pg_hba.conf
sudo nano /etc/postgresql/15/main/pg_hba.conf
```

**Redis Connection Failed**
```bash
# Check Redis status
sudo systemctl status redis

# Test connection
redis-cli -h localhost ping
```

**Governance Constraint Violation**
```bash
# Check audit log
psql -U chenu -d chenu_db -c "SELECT * FROM governance_audit_log ORDER BY created_at DESC LIMIT 10;"
```

---

## 13. ROLLBACK PROCEDURE

### Application Rollback

```bash
# Docker rollback
docker-compose down
docker-compose -f docker-compose.yml -f docker-compose.v69.yml up -d

# Kubernetes rollback
kubectl rollout undo deployment/chenu-api -n chenu
```

### Database Rollback

```bash
# Alembic rollback
alembic downgrade -1

# Or restore from backup
gunzip -c backup_v69.sql.gz | psql -U chenu -d chenu_db
```

---

## 14. PERFORMANCE TUNING

### PostgreSQL Tuning

```sql
-- postgresql.conf
shared_buffers = 4GB
effective_cache_size = 12GB
maintenance_work_mem = 1GB
work_mem = 256MB
max_connections = 200
```

### Redis Tuning

```conf
# redis.conf
maxmemory 2gb
maxmemory-policy allkeys-lru
tcp-keepalive 300
```

### API Tuning

```python
# Uvicorn workers
uvicorn main:app --workers 4 --host 0.0.0.0 --port 8000

# Or with Gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker
```

---

*CHE·NU™ V70 Deployment Guide — January 2026*
*GOUVERNANCE > EXÉCUTION*
