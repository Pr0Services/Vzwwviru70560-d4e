# CHE·NU™ API Reference v2.0

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║                      CHE·NU™ — GOVERNED INTELLIGENCE API                            ║
║                                                                                      ║
║                              Complete API Reference                                  ║
║                                                                                      ║
║                    Version: 2.0 | Date: January 2026 | Status: CANON               ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

## Table of Contents

1. [Overview](#overview)
2. [Authentication](#authentication)
3. [Thread API](#thread-api)
4. [Sphere API](#sphere-api)
5. [Agent API](#agent-api)
6. [Nova Pipeline API](#nova-pipeline-api)
7. [Governance API](#governance-api)
8. [Checkpoint API](#checkpoint-api)
9. [XR Environment API](#xr-environment-api)
10. [WebSocket API](#websocket-api)
11. [Error Codes](#error-codes)
12. [Rate Limiting](#rate-limiting)

---

## Overview

### Base URL
```
Production:  https://api.che-nu.com/api/v2
Development: http://localhost:8000/api/v2
```

### Request Format
All requests must include:
```http
Content-Type: application/json
Authorization: Bearer <access_token>
```

### Response Format
All responses follow the standard format:
```json
{
  "data": { ... },      // Response payload
  "meta": {             // Optional metadata
    "total": 100,
    "page": 1,
    "page_size": 20
  }
}
```

### Governance Responses
When an action requires human approval (Rule #1: Human Sovereignty):

**HTTP 423 LOCKED - Checkpoint Required**
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "governance|cost|identity|sensitive",
    "reason": "Action requires human approval",
    "requires_approval": true,
    "options": ["approve", "reject"]
  }
}
```

**HTTP 403 FORBIDDEN - Identity Boundary**
```json
{
  "error": "identity_boundary_violation",
  "message": "Access denied: resource belongs to different identity",
  "requested_identity": "uuid_a",
  "resource_identity": "uuid_b"
}
```

---

## Authentication

Base prefix: `/api/v2/auth`

### Register User
```http
POST /auth/register
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securePassword123!",
  "full_name": "John Doe"
}
```

**Response:** `201 Created`
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "created_at": "2026-01-07T10:00:00Z"
  },
  "tokens": {
    "access_token": "eyJ...",
    "refresh_token": "eyJ...",
    "token_type": "bearer",
    "expires_in": 3600
  }
}
```

### Login
```http
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "securePassword123!"
}
```

**Response:** `200 OK`
```json
{
  "access_token": "eyJ...",
  "refresh_token": "eyJ...",
  "token_type": "bearer",
  "expires_in": 3600,
  "user": {
    "id": "uuid",
    "email": "user@example.com"
  }
}
```

### Refresh Token
```http
POST /auth/refresh
```

**Request Body:**
```json
{
  "refresh_token": "eyJ..."
}
```

### Logout
```http
POST /auth/logout
Authorization: Bearer <access_token>
```

### Logout All Devices
```http
POST /auth/logout-all
Authorization: Bearer <access_token>
```

### Get Current User
```http
GET /auth/me
Authorization: Bearer <access_token>
```

### Update Profile
```http
PATCH /auth/me
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "full_name": "New Name",
  "preferences": { ... }
}
```

### Change Password
```http
POST /auth/change-password
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "current_password": "oldPassword",
  "new_password": "newSecurePassword123!"
}
```

### Validate Token
```http
GET /auth/validate
Authorization: Bearer <access_token>
```

---

## Thread API

Base prefix: `/api/v2/threads`

Threads are the **source of truth** in CHE·NU. They are immutable event logs that represent intentions, projects, or activities.

### List Threads
```http
GET /threads
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `sphere_id` | UUID | Filter by sphere |
| `status` | string | Filter by status: `active`, `paused`, `archived`, `completed` |
| `page` | int | Page number (default: 1) |
| `page_size` | int | Items per page (default: 20, max: 100) |

**Response:** `200 OK`
```json
{
  "threads": [
    {
      "id": "uuid",
      "founding_intent": "Build a personal finance tracker",
      "thread_type": "personal",
      "sphere_id": "uuid",
      "status": "active",
      "visibility": "private",
      "created_at": "2026-01-07T10:00:00Z",
      "updated_at": "2026-01-07T10:30:00Z",
      "event_count": 15,
      "snapshot_count": 2
    }
  ],
  "meta": {
    "total": 50,
    "page": 1,
    "page_size": 20
  }
}
```

### Create Thread
```http
POST /threads
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "founding_intent": "Build a personal finance tracker",
  "thread_type": "personal",
  "sphere_id": "uuid",
  "visibility": "private",
  "initial_context": {
    "tags": ["finance", "personal"],
    "priority": "high"
  }
}
```

**Response:** `201 Created`
```json
{
  "id": "uuid",
  "founding_intent": "Build a personal finance tracker",
  "thread_type": "personal",
  "sphere_id": "uuid",
  "status": "active",
  "visibility": "private",
  "created_at": "2026-01-07T10:00:00Z",
  "owner_identity_id": "uuid",
  "event_count": 1,
  "initial_event": {
    "id": "uuid",
    "event_type": "thread.created",
    "timestamp": "2026-01-07T10:00:00Z"
  }
}
```

### Get Thread
```http
GET /threads/{thread_id}
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "founding_intent": "Build a personal finance tracker",
  "thread_type": "personal",
  "sphere_id": "uuid",
  "status": "active",
  "visibility": "private",
  "created_at": "2026-01-07T10:00:00Z",
  "updated_at": "2026-01-07T10:30:00Z",
  "owner_identity_id": "uuid",
  "parent_thread_id": null,
  "event_count": 15,
  "snapshot_count": 2,
  "memory": {
    "hot": { "recent_events": 50 },
    "warm": { "indexed_days": 30 },
    "cold": { "archived": true }
  }
}
```

### Update Thread
```http
PATCH /threads/{thread_id}
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "status": "paused",
  "visibility": "semi_private"
}
```

**Note:** Cannot modify `founding_intent` - it is immutable.

### Archive Thread
```http
POST /threads/{thread_id}/archive
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "id": "uuid",
  "status": "archived",
  "archived_at": "2026-01-07T11:00:00Z",
  "archive_event": {
    "id": "uuid",
    "event_type": "thread.archived"
  }
}
```

### List Events
```http
GET /threads/{thread_id}/events
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `event_type` | string | Filter by event type |
| `since` | datetime | Events after this timestamp |
| `until` | datetime | Events before this timestamp |
| `limit` | int | Max events (default: 50, max: 200) |

**Response:** `200 OK`
```json
{
  "events": [
    {
      "id": "uuid",
      "event_type": "decision.recorded",
      "timestamp": "2026-01-07T10:15:00Z",
      "data": {
        "decision": "Use React for frontend",
        "rationale": "Team expertise"
      },
      "actor_id": "uuid",
      "parent_event_id": "uuid"
    }
  ],
  "meta": {
    "total": 15,
    "has_more": false
  }
}
```

### Append Event
```http
POST /threads/{thread_id}/events
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "event_type": "note.added",
  "data": {
    "content": "Researched React vs Vue comparison",
    "tags": ["research", "frontend"]
  }
}
```

**Response:** `201 Created`
```json
{
  "event": {
    "id": "uuid",
    "event_type": "note.added",
    "timestamp": "2026-01-07T10:20:00Z",
    "data": { ... },
    "actor_id": "uuid",
    "parent_event_id": "uuid"
  },
  "thread_updated_at": "2026-01-07T10:20:00Z"
}
```

### Refine Intent
```http
POST /threads/{thread_id}/intent/refine
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "refinement": "Focus on expense tracking with budget alerts",
  "reason": "User feedback indicates primary use case"
}
```

**Response:** `200 OK` with `intent.refined` event

### List Decisions
```http
GET /threads/{thread_id}/decisions
Authorization: Bearer <access_token>
```

### Record Decision
```http
POST /threads/{thread_id}/decisions
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "decision": "Use PostgreSQL for database",
  "rationale": "ACID compliance and JSON support",
  "alternatives_considered": [
    "MongoDB - rejected due to consistency requirements",
    "MySQL - rejected due to JSON limitations"
  ]
}
```

### List Actions
```http
GET /threads/{thread_id}/actions
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | `pending`, `in_progress`, `completed`, `cancelled` |

### Create Action
```http
POST /threads/{thread_id}/actions
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "title": "Design database schema",
  "description": "Create ERD for expense tracker",
  "priority": "high",
  "due_date": "2026-01-10T17:00:00Z"
}
```

### Complete Action
```http
POST /threads/{thread_id}/actions/{action_id}/complete
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "completion_note": "Schema finalized with 5 tables"
}
```

### Get Snapshot
```http
GET /threads/{thread_id}/snapshot
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `as_of` | datetime | Snapshot at specific point in time |

### Create Snapshot
```http
POST /threads/{thread_id}/snapshot
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "title": "End of Sprint 1",
  "summary": "Completed initial setup and database design"
}
```

---

## Sphere API

Base prefix: `/api/v2/spheres`

CHE·NU organizes life into 9 distinct spheres.

### List Spheres
```http
GET /spheres
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "spheres": [
    {
      "id": "uuid",
      "sphere_type": "personal",
      "name": "Personal",
      "icon": "🏠",
      "color": "#4A90D9",
      "description": "Personal life, notes, tasks, habits",
      "sort_order": 1,
      "is_active": true,
      "thread_count": 12,
      "active_agent_count": 5
    }
  ]
}
```

### Get Sphere
```http
GET /spheres/{sphere_id}
Authorization: Bearer <access_token>
```

### Get Sphere by Type
```http
GET /spheres/type/{sphere_type}
Authorization: Bearer <access_token>
```

**Valid Types:**
- `personal`
- `business`
- `government`
- `creative_studio`
- `community`
- `social_media`
- `entertainment`
- `my_team`
- `scholar`

### Update Sphere
```http
PATCH /spheres/{sphere_id}
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "name": "Custom Personal",
  "is_active": true,
  "preferences": {
    "default_view": "kanban"
  }
}
```

### Reorder Spheres
```http
POST /spheres/reorder
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "sphere_order": ["uuid1", "uuid2", "uuid3", ...]
}
```

### Get Sphere Stats
```http
GET /spheres/{sphere_id}/stats
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "sphere_id": "uuid",
  "thread_count": 12,
  "active_threads": 8,
  "total_events": 450,
  "active_agents": 5,
  "recent_activity": {
    "last_24h": 15,
    "last_7d": 78
  }
}
```

### List Bureau Sections
```http
GET /spheres/{sphere_id}/bureau
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "sections": [
    {
      "id": "quick_capture",
      "name": "Quick Capture",
      "icon": "📥",
      "item_count": 5
    },
    {
      "id": "resume_workspace",
      "name": "Resume Workspace",
      "icon": "📂",
      "item_count": 3
    },
    {
      "id": "threads",
      "name": "Threads",
      "icon": "🧵",
      "item_count": 12
    },
    {
      "id": "data_files",
      "name": "Data Files",
      "icon": "📁",
      "item_count": 25
    },
    {
      "id": "active_agents",
      "name": "Active Agents",
      "icon": "🤖",
      "item_count": 5
    },
    {
      "id": "meetings",
      "name": "Meetings",
      "icon": "📅",
      "item_count": 2
    }
  ]
}
```

### Get Bureau Section Content
```http
GET /spheres/{sphere_id}/bureau/{section_id}
Authorization: Bearer <access_token>
```

### Create Quick Capture
```http
POST /spheres/{sphere_id}/bureau/quick-capture
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "content": "Quick note about project idea",
  "capture_type": "note",
  "tags": ["idea", "project"]
}
```

---

## Agent API

Base prefix: `/api/v2/agents`

CHE·NU includes 226 specialized agents across all spheres.

### List Agents
```http
GET /agents
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `sphere_id` | UUID | Filter by sphere |
| `status` | string | `active`, `available`, `all` |
| `capability` | string | Filter by capability |

**Response:** `200 OK`
```json
{
  "agents": [
    {
      "id": "uuid",
      "name": "Note Organizer",
      "agent_type": "personal_assistant",
      "sphere_id": "uuid",
      "sphere_type": "personal",
      "description": "Organizes and categorizes notes automatically",
      "capabilities": ["text_analysis", "categorization", "tagging"],
      "status": "available",
      "token_budget": {
        "daily_limit": 10000,
        "used_today": 2500
      }
    }
  ],
  "meta": {
    "total": 226,
    "by_sphere": {
      "personal": 28,
      "business": 43,
      "government": 18,
      "creative_studio": 42,
      "community": 12,
      "social_media": 15,
      "entertainment": 8,
      "my_team": 35,
      "scholar": 25
    }
  }
}
```

### Get Agents by Sphere
```http
GET /agents/sphere/{sphere_type}
Authorization: Bearer <access_token>
```

### Get Sphere Agents
```http
GET /agents/spheres/{sphere_id}/agents
Authorization: Bearer <access_token>
```

### Get Agent
```http
GET /agents/{agent_id}
Authorization: Bearer <access_token>
```

### Execute Agent

**⚠️ GOVERNANCE: May return HTTP 423 checkpoint**

```http
POST /agents/{agent_id}/execute
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "thread_id": "uuid",
  "input": {
    "content": "Organize these notes by topic",
    "notes": ["note1", "note2"]
  },
  "parameters": {
    "max_categories": 5
  }
}
```

**Response if approved:** `200 OK`
```json
{
  "execution_id": "uuid",
  "status": "completed",
  "output": {
    "categories": [
      { "name": "Finance", "notes": ["note1"] },
      { "name": "Health", "notes": ["note2"] }
    ]
  },
  "tokens_used": 150,
  "execution_time_ms": 1250
}
```

**Response if checkpoint required:** `423 LOCKED`
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "governance",
    "reason": "Agent execution requires approval",
    "agent_id": "uuid",
    "action": "execute",
    "estimated_tokens": 150
  }
}
```

### Approve Execution
```http
POST /agents/executions/{execution_id}/approve
Authorization: Bearer <access_token>
```

### Reject Execution
```http
POST /agents/executions/{execution_id}/reject
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "reason": "Not needed at this time"
}
```

### List Executions
```http
GET /agents/executions
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `agent_id` | UUID | Filter by agent |
| `status` | string | `pending`, `completed`, `failed`, `rejected` |

### List Pending Approvals
```http
GET /agents/executions/pending
Authorization: Bearer <access_token>
```

### Get Execution
```http
GET /agents/executions/{execution_id}
Authorization: Bearer <access_token>
```

### Cancel Execution
```http
DELETE /agents/executions/{execution_id}
Authorization: Bearer <access_token>
```

### Get User Agent Configs
```http
GET /agents/config
Authorization: Bearer <access_token>
```

### Update User Agent Config
```http
PUT /agents/{agent_id}/config
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "is_enabled": true,
  "auto_approve": false,
  "daily_token_limit": 5000
}
```

### Get Agent Stats
```http
GET /agents/stats
Authorization: Bearer <access_token>
```

---

## Nova Pipeline API

Base prefix: `/api/v2/nova`

Nova is CHE·NU's 7-lane AI processing pipeline.

### Process Request

**⚠️ GOVERNANCE: May return HTTP 423 checkpoint**

```http
POST /nova/process
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "input": "Help me organize my project notes",
  "context": {
    "thread_id": "uuid",
    "sphere_id": "uuid"
  },
  "options": {
    "max_tokens": 1000,
    "temperature": 0.7
  }
}
```

**Response if no checkpoint:** `200 OK`
```json
{
  "request_id": "uuid",
  "status": "completed",
  "result": {
    "response": "Here's how I can help organize your project notes...",
    "suggestions": [
      { "action": "create_action", "title": "Review notes" }
    ]
  },
  "pipeline_stats": {
    "intent_analysis_ms": 50,
    "context_snapshot_ms": 30,
    "semantic_encoding_ms": 100,
    "governance_check_ms": 20,
    "execution_ms": 800,
    "total_ms": 1000
  },
  "tokens_used": 450,
  "audit_id": "uuid"
}
```

**Response if checkpoint required:** `423 LOCKED`
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "cost",
    "reason": "Request exceeds daily token budget",
    "estimated_tokens": 5000,
    "budget_remaining": 2000
  }
}
```

### Analyze Intent
```http
POST /nova/analyze-intent
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "input": "Help me organize my project notes",
  "context": { "thread_id": "uuid" }
}
```

**Response:** `200 OK`
```json
{
  "intent": {
    "primary": "organize_content",
    "confidence": 0.92,
    "entities": [
      { "type": "content_type", "value": "notes" },
      { "type": "action", "value": "organize" }
    ],
    "suggested_agents": ["note_organizer", "tagging_assistant"]
  }
}
```

### Approve Checkpoint
```http
POST /nova/checkpoints/{checkpoint_id}/approve
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "approval_note": "Approved for this specific task"
}
```

### Get Checkpoint
```http
GET /nova/checkpoints/{checkpoint_id}
Authorization: Bearer <access_token>
```

### List Pending Checkpoints
```http
GET /nova/checkpoints/pending
Authorization: Bearer <access_token>
```

### Get Audit Record
```http
GET /nova/audit/{audit_id}
Authorization: Bearer <access_token>
```

### Get Nova Stats
```http
GET /nova/stats
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "total_requests": 1500,
  "total_tokens_used": 750000,
  "checkpoints_triggered": 45,
  "checkpoints_approved": 42,
  "checkpoints_rejected": 3,
  "average_latency_ms": 850,
  "by_lane": {
    "intent_analysis": { "avg_ms": 50 },
    "context_snapshot": { "avg_ms": 30 },
    "semantic_encoding": { "avg_ms": 100 },
    "governance_check": { "avg_ms": 20 },
    "execution": { "avg_ms": 600 },
    "audit": { "avg_ms": 50 }
  }
}
```

### Health Check
```http
GET /nova/health
```

---

## Governance API

Base prefix: `/api/v2/governance`

### Governance Health
```http
GET /governance/health
```

### Governance Status
```http
GET /governance/status
Authorization: Bearer <access_token>
```

### Orchestrator Decide

**⚠️ GOVERNANCE: May return HTTP 423 checkpoint**

```http
POST /governance/orchestrator/decide
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "action_type": "cross_sphere_transfer",
  "source_sphere_id": "uuid",
  "target_sphere_id": "uuid",
  "data": { ... }
}
```

### Approve Orchestrator Checkpoint
```http
POST /governance/orchestrator/checkpoint/{checkpoint_id}/approve
Authorization: Bearer <access_token>
```

### Reject Orchestrator Checkpoint
```http
POST /governance/orchestrator/checkpoint/{checkpoint_id}/reject
Authorization: Bearer <access_token>
```

### List Orchestrator Specs
```http
GET /governance/orchestrator/specs
Authorization: Bearer <access_token>
```

### List Agent Configs
```http
GET /governance/orchestrator/configs
Authorization: Bearer <access_token>
```

### Run CEA Checks
```http
POST /governance/cea/run
Authorization: Bearer <access_token>
```

### List CEAs
```http
GET /governance/cea/registry
Authorization: Bearer <access_token>
```

### List Backlog
```http
GET /governance/backlog
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | `pending`, `resolved`, `all` |
| `priority` | string | `low`, `medium`, `high`, `critical` |

### Create Backlog Item
```http
POST /governance/backlog
Authorization: Bearer <access_token>
```

### Resolve Backlog Item
```http
POST /governance/backlog/{item_id}/resolve
Authorization: Bearer <access_token>
```

### Backlog Metrics
```http
GET /governance/backlog/metrics
Authorization: Bearer <access_token>
```

### Tune Policy
```http
POST /governance/backlog/tune-policy
Authorization: Bearer <access_token>
```

### Compute QCT (Quality-Cost-Time)
```http
POST /governance/qct/compute
Authorization: Bearer <access_token>
```

### List Decision Points
```http
GET /governance/decision-points
Authorization: Bearer <access_token>
```

### Get Decision Points Summary
```http
GET /governance/decision-points/summary
Authorization: Bearer <access_token>
```

### Get Urgent Decision Points
```http
GET /governance/decision-points/urgent
Authorization: Bearer <access_token>
```

### Get Decision Point
```http
GET /governance/decision-points/{point_id}
Authorization: Bearer <access_token>
```

### Create Decision Point
```http
POST /governance/decision-points
Authorization: Bearer <access_token>
```

### Validate Decision Point
```http
POST /governance/decision-points/{point_id}/validate
Authorization: Bearer <access_token>
```

### Redirect Decision Point
```http
POST /governance/decision-points/{point_id}/redirect
Authorization: Bearer <access_token>
```

### Comment on Decision Point
```http
POST /governance/decision-points/{point_id}/comment
Authorization: Bearer <access_token>
```

### Defer Decision Point
```http
POST /governance/decision-points/{point_id}/defer
Authorization: Bearer <access_token>
```

### Archive Decision Point
```http
POST /governance/decision-points/{point_id}/archive
Authorization: Bearer <access_token>
```

### Process Aging
```http
POST /governance/decision-points/process-aging
Authorization: Bearer <access_token>
```

---

## Checkpoint API

Base prefix: `/api/v2/checkpoints`

### List Pending Checkpoints
```http
GET /checkpoints/pending
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "checkpoints": [
    {
      "id": "uuid",
      "type": "governance",
      "status": "pending",
      "reason": "Agent execution requires approval",
      "created_at": "2026-01-07T10:00:00Z",
      "expires_at": "2026-01-07T11:00:00Z",
      "context": {
        "agent_id": "uuid",
        "action": "execute"
      }
    }
  ]
}
```

### List Checkpoints
```http
GET /checkpoints
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `status` | string | `pending`, `approved`, `rejected`, `expired` |
| `type` | string | `governance`, `cost`, `identity`, `sensitive` |
| `since` | datetime | Filter by creation time |

### Get Checkpoint
```http
GET /checkpoints/{checkpoint_id}
Authorization: Bearer <access_token>
```

### Approve Checkpoint
```http
POST /checkpoints/{checkpoint_id}/approve
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "note": "Approved for this task"
}
```

### Reject Checkpoint
```http
POST /checkpoints/{checkpoint_id}/reject
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "reason": "Not needed at this time"
}
```

### Get My Activity
```http
GET /checkpoints/activity/me
Authorization: Bearer <access_token>
```

### Get Resource History
```http
GET /checkpoints/history/{resource_type}/{resource_id}
Authorization: Bearer <access_token>
```

### Query Audit Logs
```http
GET /checkpoints/audit
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `resource_type` | string | Filter by resource type |
| `action` | string | Filter by action |
| `since` | datetime | Start time |
| `until` | datetime | End time |

---

## XR Environment API

Base prefix: `/api/v2/xr`

CHE·NU generates XR (Mixed Reality) environments from Threads.

### Get Thread Lobby
```http
GET /xr/{thread_id}/lobby
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "thread_id": "uuid",
  "lobby": {
    "intent_summary": "Build a personal finance tracker",
    "maturity": {
      "level": 3,
      "name": "WORKSHOP",
      "emoji": "🔧"
    },
    "quick_stats": {
      "events": 45,
      "decisions": 5,
      "actions_pending": 3
    },
    "available_modes": [
      {
        "mode": "2D",
        "available": true,
        "recommended": false
      },
      {
        "mode": "XR",
        "available": true,
        "recommended": true,
        "reason": "Thread has enough structure for spatial view"
      }
    ]
  }
}
```

### Get Mode Recommendation
```http
GET /xr/{thread_id}/lobby/mode-recommendation
Authorization: Bearer <access_token>
```

### Get Thread Maturity
```http
GET /xr/{thread_id}/maturity
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "thread_id": "uuid",
  "maturity": {
    "level": 3,
    "name": "WORKSHOP",
    "emoji": "🔧",
    "description": "Tasks structured, active development",
    "score": 65,
    "signals": {
      "event_count": 45,
      "decision_count": 5,
      "action_count": 12,
      "participant_count": 1,
      "linked_threads": 2
    }
  },
  "evolution_rules": [
    {
      "to_reach": "STUDIO",
      "requirements": [
        "Add 2+ participants",
        "Start a live session"
      ]
    }
  ]
}
```

**Maturity Levels:**
| Level | Name | Emoji | Description |
|-------|------|-------|-------------|
| 0 | SEED | 🌱 | Intent only |
| 1 | SPROUT | 🌿 | Chat active |
| 2 | SEEDLING | 🌾 | Decisions recorded |
| 3 | WORKSHOP | 🔧 | Tasks structured |
| 4 | STUDIO | 🎬 | Multi-participant, live |
| 5 | ECOSYSTEM | 🌐 | Many linked threads |

### Get Maturity History
```http
GET /xr/{thread_id}/maturity/history
Authorization: Bearer <access_token>
```

### Get Maturity Signals
```http
GET /xr/{thread_id}/maturity/signals
Authorization: Bearer <access_token>
```

### XR Preflight Check
```http
GET /xr/{thread_id}/xr/preflight
Authorization: Bearer <access_token>
```

**Response:** `200 OK`
```json
{
  "ready": true,
  "checks": {
    "thread_exists": true,
    "has_permission": true,
    "has_content": true,
    "xr_capable": true
  },
  "recommended_template": "personal_room",
  "estimated_zones": 4
}
```

### Get XR Blueprint
```http
GET /xr/{thread_id}/xr/blueprint
Authorization: Bearer <access_token>
```

**Query Parameters:**
| Parameter | Type | Description |
|-----------|------|-------------|
| `template` | string | Force specific template |
| `viewer_role` | string | `viewer`, `contributor`, `admin`, `owner` |

**Response:** `200 OK`
```json
{
  "thread_id": "uuid",
  "blueprint": {
    "template": "personal_room",
    "maturity_level": 3,
    "zones": [
      {
        "zone_type": "intent_wall",
        "position": { "x": 0, "y": 2, "z": -5 },
        "items": [
          {
            "id": "uuid",
            "type": "intent",
            "content": "Build a personal finance tracker",
            "source_event_id": "uuid"
          }
        ]
      },
      {
        "zone_type": "decision_wall",
        "position": { "x": -3, "y": 2, "z": 0 },
        "items": [
          {
            "id": "uuid",
            "type": "decision",
            "title": "Use PostgreSQL",
            "rationale": "ACID compliance",
            "source_event_id": "uuid"
          }
        ]
      },
      {
        "zone_type": "action_table",
        "position": { "x": 0, "y": 1, "z": 0 },
        "items": [
          {
            "id": "uuid",
            "type": "action",
            "title": "Design database schema",
            "status": "in_progress",
            "actions": ["view", "complete", "edit"]
          }
        ]
      },
      {
        "zone_type": "memory_kiosk",
        "position": { "x": 3, "y": 2, "z": 0 },
        "items": [
          {
            "id": "uuid",
            "type": "summary",
            "content": "Sprint 1 completed setup and design phase"
          }
        ]
      }
    ],
    "portals": [
      {
        "target_thread_id": "uuid",
        "target_thread_name": "Backend Implementation",
        "position": { "x": 5, "y": 1, "z": 0 }
      }
    ]
  }
}
```

**Templates:**
- `personal_room` - Cozy personal workspace
- `business_room` - Professional office environment
- `cause_room` - Community/cause focused space
- `lab_room` - Research/scholar environment
- `custom_room` - Customizable space

**Canonical Zones:**
- `intent_wall` - Displays founding intent
- `decision_wall` - History of decisions
- `action_table` - Active actions with status
- `memory_kiosk` - Summaries and context
- `timeline_strip` - Event timeline
- `resource_shelf` - Links and resources

### List XR Zones
```http
GET /xr/{thread_id}/xr/zones
Authorization: Bearer <access_token>
```

### Update Action (from XR)
```http
POST /xr/{thread_id}/xr/actions/{action_id}/update
Authorization: Bearer <access_token>
```

**Request Body:**
```json
{
  "status": "completed",
  "completion_note": "Finished design"
}
```

**Note:** This creates an event in the Thread (Rule #3: XR is projection only)

### Create Action (from XR)
```http
POST /xr/{thread_id}/xr/actions/create
Authorization: Bearer <access_token>
```

### Create Note (from XR)
```http
POST /xr/{thread_id}/xr/notes/create
Authorization: Bearer <access_token>
```

### List Portals
```http
GET /xr/{thread_id}/xr/portals
Authorization: Bearer <access_token>
```

### Traverse Portal
```http
POST /xr/{thread_id}/xr/portals/{target_thread_id}/traverse
Authorization: Bearer <access_token>
```

---

## WebSocket API

CHE·NU provides real-time updates via WebSocket connections.

### Connect to WebSocket
```
ws://localhost:8000/ws/connect?token=<access_token>
```

**Connection Flow:**
1. Connect with token
2. Receive `connection.established` message
3. Subscribe to channels
4. Receive real-time events

### Connect to Thread WebSocket
```
ws://localhost:8000/ws/thread/{thread_id}?token=<access_token>
```

Automatically subscribes to thread events.

### WebSocket Message Format

**Incoming Messages (from server):**
```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "thread.event_appended",
  "data": {
    "event": {
      "id": "uuid",
      "event_type": "note.added",
      "timestamp": "2026-01-07T10:00:00Z",
      "data": { ... }
    }
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

**Outgoing Messages (to server):**

Subscribe to channel:
```json
{
  "action": "subscribe",
  "channel": "thread:uuid"
}
```

Unsubscribe from channel:
```json
{
  "action": "unsubscribe",
  "channel": "thread:uuid"
}
```

Ping:
```json
{
  "action": "ping"
}
```

### Event Types

**Thread Events:**
- `thread.created`
- `thread.updated`
- `thread.archived`
- `thread.event_appended`

**Checkpoint Events:**
- `checkpoint.created`
- `checkpoint.approved`
- `checkpoint.rejected`
- `checkpoint.expired`

**Agent Events:**
- `agent.execution_started`
- `agent.execution_completed`
- `agent.execution_failed`

**Sphere Events:**
- `sphere.updated`
- `sphere.quick_capture_added`

### WebSocket Health
```http
GET /ws/health
```

### WebSocket Stats
```http
GET /ws/stats
Authorization: Bearer <access_token>
```

---

## Error Codes

### HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | OK - Request successful |
| 201 | Created - Resource created |
| 400 | Bad Request - Invalid input |
| 401 | Unauthorized - Authentication required |
| 403 | Forbidden - Identity boundary violation |
| 404 | Not Found - Resource not found |
| 409 | Conflict - Resource conflict |
| 422 | Unprocessable Entity - Validation error |
| **423** | **Locked - Checkpoint required (Governance)** |
| 429 | Too Many Requests - Rate limited |
| 500 | Internal Server Error |

### Error Response Format

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid input data",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ]
  },
  "request_id": "uuid"
}
```

### Error Codes

| Code | Description |
|------|-------------|
| `VALIDATION_ERROR` | Input validation failed |
| `AUTHENTICATION_ERROR` | Invalid or expired token |
| `AUTHORIZATION_ERROR` | Insufficient permissions |
| `IDENTITY_BOUNDARY_VIOLATION` | Cross-identity access denied |
| `RESOURCE_NOT_FOUND` | Requested resource doesn't exist |
| `RESOURCE_CONFLICT` | Resource already exists |
| `CHECKPOINT_REQUIRED` | Human approval needed |
| `CHECKPOINT_EXPIRED` | Checkpoint timed out |
| `RATE_LIMIT_EXCEEDED` | Too many requests |
| `TOKEN_BUDGET_EXCEEDED` | Token limit reached |
| `INTERNAL_ERROR` | Server error |

---

## Rate Limiting

CHE·NU implements rate limiting to ensure fair usage.

### Default Limits

| Endpoint Type | Rate Limit |
|---------------|------------|
| Authentication | 10 req/min |
| Read Operations | 100 req/min |
| Write Operations | 30 req/min |
| Nova Pipeline | 20 req/min |
| Agent Execution | 10 req/min |
| WebSocket | 50 msg/min |

### Rate Limit Headers

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1704628800
```

### Rate Limit Response

**HTTP 429 Too Many Requests**
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests",
    "retry_after": 30
  }
}
```

---

## Token Budget System

CHE·NU enforces token budgets per user (Rule #1: Human Sovereignty, Rule #6: Traceability).

### Budget Structure

```json
{
  "identity_id": "uuid",
  "daily_token_limit": 100000,
  "daily_cost_limit": 10.00,
  "monthly_token_limit": 2000000,
  "monthly_cost_limit": 200.00,
  "tokens_used_today": 25000,
  "cost_today": 2.50,
  "tokens_used_month": 150000,
  "cost_this_month": 15.00,
  "last_reset": "2026-01-07T00:00:00Z"
}
```

### Budget Exceeded Response

**HTTP 423 LOCKED**
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "cost",
    "reason": "Daily token budget exceeded",
    "current_usage": 100000,
    "limit": 100000,
    "options": ["increase_budget", "wait_for_reset"]
  }
}
```

---

## API Versioning

CHE·NU uses URL-based versioning:
- Current: `/api/v2`
- Legacy: `/api/v1` (deprecated)

### Version Header

Optionally specify version:
```http
X-API-Version: 2.0
```

---

## SDKs and Libraries

### Official SDKs

- **TypeScript/JavaScript**: `@che-nu/sdk`
- **Python**: `chenu-sdk`
- **React Hooks**: `@che-nu/react`

### Example: TypeScript SDK

```typescript
import { ChenuClient } from '@che-nu/sdk';

const client = new ChenuClient({
  baseUrl: 'https://api.che-nu.com/api/v2',
  token: 'your_access_token'
});

// List threads
const threads = await client.threads.list({ sphere_id: 'uuid' });

// Create thread
const thread = await client.threads.create({
  founding_intent: 'Build a finance tracker',
  sphere_id: 'uuid'
});

// Handle checkpoints
try {
  const result = await client.agents.execute('agent_id', { input: '...' });
} catch (error) {
  if (error.code === 'CHECKPOINT_REQUIRED') {
    // Show approval UI
    const approved = await showApprovalDialog(error.checkpoint);
    if (approved) {
      await client.checkpoints.approve(error.checkpoint.id);
    }
  }
}
```

---

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║            "GOVERNANCE > EXECUTION • HUMANS > AUTOMATION"                           ║
║                                                                                      ║
║                     CHE·NU™ — Built for Decades                                     ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

---

**Version:** 2.0  
**Date:** January 2026  
**Status:** CANON  

© 2026 CHE·NU™ — All Rights Reserved
