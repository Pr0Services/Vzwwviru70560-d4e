# CHE·NU — DATABASE OVERVIEW
## Architecture des Bases de Données
### Foundation Freeze V1.0.0

---

## 1. Principe d'Isolation

Chaque sphère possède sa **propre base de données isolée**.

> "Les données d'une sphère ne peuvent pas être accédées par une autre sphère sans passer par le Context Bridge."

---

## 2. Architecture

```
┌─────────────────────────────────────────────────────────┐
│              DATABASE ARCHITECTURE                       │
├─────────────────────────────────────────────────────────┤
│                                                         │
│   ┌───────────────────────────────────────────────┐     │
│   │              USER LAYER                        │     │
│   └───────────────────┬───────────────────────────┘     │
│                       │                                 │
│   ┌───────────────────┴───────────────────────────┐     │
│   │              CONTEXT BRIDGE                    │     │
│   │         (Cross-sphere access control)          │     │
│   └───────────────────┬───────────────────────────┘     │
│                       │                                 │
│   ┌───────────────────┴───────────────────────────┐     │
│   │           SPHERE DATABASE LAYER                │     │
│   │                                               │     │
│   │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐            │     │
│   │  │ DB  │ │ DB  │ │ DB  │ │ DB  │            │     │
│   │  │PERS │ │METH │ │BUSI │ │SCHO │            │     │
│   │  │🔒🔒🔒│ │ 🔒  │ │ 🔒  │ │ 🔒  │            │     │
│   │  └─────┘ └─────┘ └─────┘ └─────┘            │     │
│   │                                               │     │
│   │  ┌─────┐ ┌─────┐ ┌─────┐ ┌─────┐            │     │
│   │  │ DB  │ │ DB  │ │ DB  │ │ DB  │            │     │
│   │  │CREA │ │ XR  │ │SOCI │ │INST │            │     │
│   │  │ 🔒  │ │ 🔒  │ │ 🔒  │ │ 🔒  │            │     │
│   │  └─────┘ └─────┘ └─────┘ └─────┘            │     │
│   │                                               │     │
│   └───────────────────────────────────────────────┘     │
│                                                         │
│   🔒🔒🔒 = Chiffrement renforcé (Personnel)             │
│   🔒 = Chiffrement standard                             │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 3. Bases de Données par Sphère

| Sphère | ID Base | Isolation | Chiffrement |
|--------|---------|-----------|-------------|
| Personnel | `db_personal` | **Maximale** | E2E + AES-256 |
| Methodology | `db_methodology` | Standard | AES-256 |
| Business | `db_business` | Standard | AES-256 |
| Scholar | `db_scholar` | Standard | AES-256 |
| Creative | `db_creative` | Standard | AES-256 |
| XR Meeting | `db_xr` | Standard | AES-256 |
| Social | `db_social` | Standard | AES-256 |
| Institutions | `db_institutions` | Standard | AES-256 |

---

## 4. Règles d'Accès

### Accès Direct (Autorisé)

| Qui | Quoi | Condition |
|-----|------|-----------|
| Utilisateur | Toutes ses données | Authentifié |
| Agent L1-L3 | Données de SA sphère | Dans le scope |
| NOVA (L0) | Métadonnées uniquement | Routage |

### Accès Cross-Sphère

| Condition | Mécanisme |
|-----------|-----------|
| Consentement utilisateur | Context Bridge |
| Journalisation | Audit log |
| Révocabilité | Toujours possible |

---

## 5. Schéma de la Base Personnel

La base Personnel est **spéciale** :

```
┌─────────────────────────────────────────────────────────┐
│              DB_PERSONAL (Sanctuaire)                    │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────┐       │
│  │                CHIFFREMENT E2E               │       │
│  │                                             │       │
│  │  ┌──────────────────────────────────────┐  │       │
│  │  │  notes                               │  │       │
│  │  │  journal                             │  │       │
│  │  │  media                               │  │       │
│  │  │  reflections                         │  │       │
│  │  └──────────────────────────────────────┘  │       │
│  │                                             │       │
│  │  Clé de chiffrement = Utilisateur SEUL     │       │
│  │  Accès = Utilisateur SEUL                  │       │
│  │  Agents = DÉSACTIVÉS par défaut            │       │
│  │  Context Bridge = INTERDIT                 │       │
│  │                                             │       │
│  └─────────────────────────────────────────────┘       │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 6. Audit et Logs

| Type de Log | Contenu | Rétention |
|-------------|---------|-----------|
| Access Log | Qui a accédé quoi | 30 jours |
| Modification Log | Changements | 90 jours |
| Bridge Log | Transferts cross-sphère | 1 an |
| Deletion Log | Suppressions (preuve) | 30 jours |

---

## 7. Backup et Récupération

| Aspect | Configuration |
|--------|---------------|
| Fréquence | Quotidienne |
| Chiffrement | Oui (clé utilisateur) |
| Localisation | Choix utilisateur |
| Restauration | Par l'utilisateur |
| Rétention | Configurable |

---

## 8. Suppression des Données

| Type | Processus | Délai |
|------|-----------|-------|
| Soft delete | Corbeille | Immédiat |
| Hard delete | Purge | 30 jours |
| Account delete | Destruction complète | 30 jours |

---

## 9. Conformité aux Lois

| Loi | Application Database |
|-----|---------------------|
| Loi 1 | Données propriété utilisateur |
| Loi 2 | Pas de tables d'évaluation |
| Loi 3 | Pas de tracking comportemental |
| Loi 4 | Context Bridge pour cross-sphère |
| Loi 5 | Logs non intrusifs |
| Loi 6 | Suppression effective |

---

*Document Status: FROZEN — Foundation Freeze V1.0.0*
