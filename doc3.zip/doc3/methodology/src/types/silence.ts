export type SilenceState = {
  enabled: boolean;
  since?: number;
};
