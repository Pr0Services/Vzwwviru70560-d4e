"""
CHE·NU™ V70 — WEBSOCKET HANDLERS
================================
Real-time WebSocket communication for GP2 modules.

All events are READ ONLY notifications.
No write operations through WebSocket.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional, Set
from uuid import uuid4
import asyncio
import json
import logging

logger = logging.getLogger("chenu.ws")


class EventType(str, Enum):
    """Types of WebSocket events."""
    # System
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    HEARTBEAT = "heartbeat"
    ERROR = "error"
    
    # Governance
    GOVERNANCE_CHECK = "governance_check"
    GOVERNANCE_BLOCK = "governance_block"
    HITL_REQUIRED = "hitl_required"
    HITL_APPROVED = "hitl_approved"
    
    # Decision
    DECISION_CREATED = "decision_created"
    DECISION_UPDATED = "decision_updated"
    DECISION_EXPORTED = "decision_exported"
    
    # Simulation
    SIMULATION_STARTED = "simulation_started"
    SIMULATION_PROGRESS = "simulation_progress"
    SIMULATION_COMPLETED = "simulation_completed"
    
    # Crisis
    CRISIS_DETECTED = "crisis_detected"
    CRISIS_ESCALATED = "crisis_escalated"
    FAILSAFE_ACTIVATED = "failsafe_activated"
    
    # Ethics
    ETHICS_VIOLATION = "ethics_violation"
    FORBIDDEN_STATE = "forbidden_state"
    
    # XR
    XR_SCENE_READY = "xr_scene_ready"
    XR_SCENE_UPDATED = "xr_scene_updated"


@dataclass
class WSEvent:
    """WebSocket event."""
    event_id: str = field(default_factory=lambda: f"EVT_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    event_type: EventType = EventType.HEARTBEAT
    payload: dict = field(default_factory=dict)
    
    # Governance
    synthetic: bool = True
    read_only: bool = True
    
    def to_json(self) -> str:
        return json.dumps({
            "event_id": self.event_id,
            "timestamp": self.timestamp.isoformat(),
            "type": self.event_type.value,
            "payload": self.payload,
            "governance": {
                "synthetic": self.synthetic,
                "read_only": self.read_only,
            },
        })
    
    @classmethod
    def from_json(cls, data: str) -> "WSEvent":
        d = json.loads(data)
        return cls(
            event_id=d.get("event_id"),
            event_type=EventType(d.get("type", "heartbeat")),
            payload=d.get("payload", {}),
        )


@dataclass
class WSClient:
    """WebSocket client connection."""
    client_id: str = field(default_factory=lambda: f"CLIENT_{uuid4().hex[:8]}")
    connected_at: datetime = field(default_factory=datetime.utcnow)
    
    # Connection
    websocket: Any = None  # FastAPI WebSocket
    is_connected: bool = True
    
    # Subscriptions
    subscriptions: Set[EventType] = field(default_factory=set)
    
    # User context
    user_id: str = ""
    session_id: str = ""
    
    # Governance
    governance_token: str = ""


class WSEventBus:
    """
    Event bus for WebSocket communication.
    
    CRITICAL: All events are READ ONLY notifications.
    """
    
    def __init__(self):
        self.bus_id = f"WS_BUS_{uuid4().hex[:8]}"
        self._clients: dict[str, WSClient] = {}
        self._event_handlers: dict[EventType, list[Callable]] = {}
        self._event_history: list[WSEvent] = []
        self._max_history = 1000
        
        logger.info(f"WebSocket Event Bus initialized: {self.bus_id}")
    
    # =========================================================================
    # CLIENT MANAGEMENT
    # =========================================================================
    
    async def connect(
        self,
        websocket: Any,
        user_id: str = "",
        governance_token: str = "",
    ) -> WSClient:
        """Register new WebSocket client."""
        client = WSClient(
            websocket=websocket,
            user_id=user_id,
            governance_token=governance_token,
        )
        
        self._clients[client.client_id] = client
        
        # Send connected event
        await self._send_to_client(client, WSEvent(
            event_type=EventType.CONNECTED,
            payload={
                "client_id": client.client_id,
                "message": "Connected to CHE·NU GP2 WebSocket",
            },
        ))
        
        logger.info(f"Client connected: {client.client_id}")
        return client
    
    async def disconnect(self, client_id: str):
        """Disconnect client."""
        client = self._clients.pop(client_id, None)
        if client:
            client.is_connected = False
            logger.info(f"Client disconnected: {client_id}")
    
    def subscribe(self, client_id: str, event_types: list[EventType]):
        """Subscribe client to event types."""
        client = self._clients.get(client_id)
        if client:
            client.subscriptions.update(event_types)
            logger.debug(f"Client {client_id} subscribed to: {event_types}")
    
    def unsubscribe(self, client_id: str, event_types: list[EventType]):
        """Unsubscribe client from event types."""
        client = self._clients.get(client_id)
        if client:
            client.subscriptions.difference_update(event_types)
    
    # =========================================================================
    # EVENT PUBLISHING
    # =========================================================================
    
    async def publish(self, event: WSEvent):
        """Publish event to all subscribed clients."""
        # Ensure governance
        event.read_only = True
        event.synthetic = True
        
        # Store in history
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]
        
        # Call registered handlers
        handlers = self._event_handlers.get(event.event_type, [])
        for handler in handlers:
            try:
                await handler(event)
            except Exception as e:
                logger.error(f"Handler error: {e}")
        
        # Send to subscribed clients
        for client in self._clients.values():
            if event.event_type in client.subscriptions:
                await self._send_to_client(client, event)
        
        logger.debug(f"Event published: {event.event_type.value}")
    
    async def _send_to_client(self, client: WSClient, event: WSEvent):
        """Send event to specific client."""
        if not client.is_connected or not client.websocket:
            return
        
        try:
            await client.websocket.send_text(event.to_json())
        except Exception as e:
            logger.error(f"Failed to send to {client.client_id}: {e}")
            client.is_connected = False
    
    # =========================================================================
    # EVENT HANDLERS
    # =========================================================================
    
    def on(self, event_type: EventType, handler: Callable):
        """Register event handler."""
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)
    
    # =========================================================================
    # CONVENIENCE METHODS
    # =========================================================================
    
    async def notify_governance_block(
        self,
        reason: str,
        action: str,
        violations: list[str] = None,
    ):
        """Notify about governance block."""
        await self.publish(WSEvent(
            event_type=EventType.GOVERNANCE_BLOCK,
            payload={
                "reason": reason,
                "action": action,
                "violations": violations or [],
            },
        ))
    
    async def notify_hitl_required(
        self,
        package_id: str,
        description: str,
        options: list[dict] = None,
    ):
        """Notify HITL approval required."""
        await self.publish(WSEvent(
            event_type=EventType.HITL_REQUIRED,
            payload={
                "package_id": package_id,
                "description": description,
                "options": options or [],
            },
        ))
    
    async def notify_decision_created(
        self,
        package_id: str,
        title: str,
        xr_scene_id: str = "",
    ):
        """Notify decision package created."""
        await self.publish(WSEvent(
            event_type=EventType.DECISION_CREATED,
            payload={
                "package_id": package_id,
                "title": title,
                "xr_scene_id": xr_scene_id,
            },
        ))
    
    async def notify_simulation_progress(
        self,
        simulation_id: str,
        progress: float,
        cycle: int,
        total_cycles: int,
    ):
        """Notify simulation progress."""
        await self.publish(WSEvent(
            event_type=EventType.SIMULATION_PROGRESS,
            payload={
                "simulation_id": simulation_id,
                "progress": progress,
                "cycle": cycle,
                "total_cycles": total_cycles,
            },
        ))
    
    async def notify_crisis_detected(
        self,
        crisis_type: str,
        severity: str,
        indicators: dict,
    ):
        """Notify crisis detected."""
        await self.publish(WSEvent(
            event_type=EventType.CRISIS_DETECTED,
            payload={
                "crisis_type": crisis_type,
                "severity": severity,
                "indicators": indicators,
            },
        ))
    
    async def notify_failsafe_activated(
        self,
        level: str,
        actions: list[str],
    ):
        """Notify failsafe activated."""
        await self.publish(WSEvent(
            event_type=EventType.FAILSAFE_ACTIVATED,
            payload={
                "level": level,
                "actions": actions,
            },
        ))
    
    async def notify_ethics_violation(
        self,
        violation_type: str,
        description: str,
        action_blocked: str,
    ):
        """Notify ethics violation."""
        await self.publish(WSEvent(
            event_type=EventType.ETHICS_VIOLATION,
            payload={
                "violation_type": violation_type,
                "description": description,
                "action_blocked": action_blocked,
            },
        ))
    
    async def notify_xr_scene_ready(
        self,
        scene_id: str,
        scene_type: str,
        url: str = "",
    ):
        """Notify XR scene ready."""
        await self.publish(WSEvent(
            event_type=EventType.XR_SCENE_READY,
            payload={
                "scene_id": scene_id,
                "scene_type": scene_type,
                "url": url,
                "read_only": True,
            },
        ))
    
    # =========================================================================
    # HEARTBEAT
    # =========================================================================
    
    async def start_heartbeat(self, interval: float = 30.0):
        """Start heartbeat loop."""
        while True:
            await asyncio.sleep(interval)
            await self.publish(WSEvent(
                event_type=EventType.HEARTBEAT,
                payload={"alive": True},
            ))
    
    # =========================================================================
    # STATS
    # =========================================================================
    
    def get_stats(self) -> dict:
        """Get event bus statistics."""
        return {
            "bus_id": self.bus_id,
            "connected_clients": len([c for c in self._clients.values() if c.is_connected]),
            "total_clients": len(self._clients),
            "event_history_size": len(self._event_history),
            "registered_handlers": {
                t.value: len(h) for t, h in self._event_handlers.items()
            },
        }


# =============================================================================
# FASTAPI INTEGRATION
# =============================================================================

def create_websocket_router():
    """Create FastAPI WebSocket router."""
    from fastapi import APIRouter, WebSocket, WebSocketDisconnect
    
    router = APIRouter()
    event_bus = WSEventBus()
    
    @router.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        await websocket.accept()
        
        # Extract headers
        user_id = websocket.headers.get("X-User-ID", "anonymous")
        governance_token = websocket.headers.get("X-Governance-Token", "")
        
        client = await event_bus.connect(
            websocket=websocket,
            user_id=user_id,
            governance_token=governance_token,
        )
        
        # Default subscriptions
        event_bus.subscribe(client.client_id, [
            EventType.GOVERNANCE_BLOCK,
            EventType.HITL_REQUIRED,
            EventType.DECISION_CREATED,
            EventType.CRISIS_DETECTED,
            EventType.ETHICS_VIOLATION,
            EventType.XR_SCENE_READY,
        ])
        
        try:
            while True:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                # Handle client messages
                action = message.get("action")
                
                if action == "subscribe":
                    event_types = [EventType(t) for t in message.get("events", [])]
                    event_bus.subscribe(client.client_id, event_types)
                
                elif action == "unsubscribe":
                    event_types = [EventType(t) for t in message.get("events", [])]
                    event_bus.unsubscribe(client.client_id, event_types)
                
                elif action == "ping":
                    await websocket.send_text(json.dumps({"action": "pong"}))
                
        except WebSocketDisconnect:
            await event_bus.disconnect(client.client_id)
        except Exception as e:
            logger.error(f"WebSocket error: {e}")
            await event_bus.disconnect(client.client_id)
    
    @router.get("/ws/stats")
    async def websocket_stats():
        return event_bus.get_stats()
    
    return router, event_bus


# =============================================================================
# SINGLETON
# =============================================================================

_event_bus: Optional[WSEventBus] = None


def get_event_bus() -> WSEventBus:
    """Get the event bus singleton."""
    global _event_bus
    if _event_bus is None:
        _event_bus = WSEventBus()
    return _event_bus
