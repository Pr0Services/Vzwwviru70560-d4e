"""
CHE·NU™ V71 — Test Suite
========================
Pytest tests for all V71 modules.
"""
