# Wireframe (Text) — Thread Lobby

┌─────────────────────────────────────────────────────────────┐
│  [Thread Title]                                             │
│  Founding intent: "..."                                     │
│                                                             │
│  ┌──────────── Where we are ────────────┐                   │
│  │ Maturity: Studio (Level 3)           │                   │
│  │ Last update: 2h ago                  │                   │
│  │ Summary: "..."                       │                   │
│  └──────────────────────────────────────┘                   │
│                                                             │
│  [ Continue in Chat ]  [ Enter XR Room ]  [ Start/Join Live ]│
│                                                             │
│  Secondary:  Timeline · Decisions · Actions · Links          │
└─────────────────────────────────────────────────────────────┘

XR Preflight modal:
- Zones you'll see: Intent, Decisions, Actions, Memory, Timeline, Resources
- Your permissions: Read/Write (based on role)
- Privacy: Redaction enforced
[ Enter ]
