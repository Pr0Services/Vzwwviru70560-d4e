"""
CHE·NU™ V70 — MODULE 30: CIVILIZATION OS LAYER
===============================================
Makes CHE·NU™ behave like a SYSTEM OF OPERATION.

OS Primitives:
- Identity (personal, institutional, cultural, heritage)
- State (world, civic, skill, culture, planetary)
- Policy (OPA rules)
- Action (always sandboxed first)

The Decision Loop:
Intent → Slot Filling → Causal Model → Simulation → XR → Governance → Sign → Export

Shell Modes:
- Citizen Mode
- Enterprise Mode
- Scholar Mode
- Planetary Mode
"""

from .engine import (
    IdentityType,
    StateType,
    ShellMode,
    DecisionLoopStage,
    OSIdentity,
    OSState,
    OSPolicy,
    OSAction,
    DecisionLoopContext,
    DecisionPackage,
    CivilizationKernel,
    CivilizationOS,
)

__all__ = [
    "IdentityType",
    "StateType",
    "ShellMode",
    "DecisionLoopStage",
    "OSIdentity",
    "OSState",
    "OSPolicy",
    "OSAction",
    "DecisionLoopContext",
    "DecisionPackage",
    "CivilizationKernel",
    "CivilizationOS",
]

__version__ = "70.0.0"
