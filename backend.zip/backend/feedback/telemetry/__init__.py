"""CHE·NU™ V69 — Telemetry module"""
