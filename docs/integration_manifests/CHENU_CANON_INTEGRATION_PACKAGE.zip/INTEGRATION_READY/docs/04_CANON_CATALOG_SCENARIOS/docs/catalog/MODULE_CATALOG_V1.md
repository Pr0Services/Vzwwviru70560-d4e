# Module Catalog v1

See: `catalog/module_catalog.v1.yaml`

This catalog is designed for scenario-lock simulation.
