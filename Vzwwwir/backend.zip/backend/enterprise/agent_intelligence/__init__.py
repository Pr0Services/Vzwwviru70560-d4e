"""CHE·NU™ V69 — Enterprise"""
