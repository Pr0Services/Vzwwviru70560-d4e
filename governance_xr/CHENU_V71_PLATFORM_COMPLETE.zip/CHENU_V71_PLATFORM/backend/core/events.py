"""
CHE·NU™ V70 — EVENT SYSTEM
==========================
Inter-module event communication system.

All events are governed and audited.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional, TypeVar
from uuid import uuid4
import asyncio
import logging
from collections import defaultdict

logger = logging.getLogger("chenu.events")

T = TypeVar('T')


class ModuleEventType(str, Enum):
    """Event types for inter-module communication."""
    
    # NOVA Kernel
    NOVA_REQUEST_RECEIVED = "nova.request.received"
    NOVA_REQUEST_VALIDATED = "nova.request.validated"
    NOVA_REQUEST_REFUSED = "nova.request.refused"
    
    # Ethics Canon
    ETHICS_CHECK_STARTED = "ethics.check.started"
    ETHICS_CHECK_PASSED = "ethics.check.passed"
    ETHICS_VIOLATION_DETECTED = "ethics.violation.detected"
    
    # Civilization OS
    DECISION_LOOP_STARTED = "civilization.decision.started"
    DECISION_LOOP_COMPLETED = "civilization.decision.completed"
    DECISION_EXPORTED = "civilization.decision.exported"
    HITL_CHECKPOINT_REACHED = "civilization.hitl.checkpoint"
    HITL_APPROVAL_RECEIVED = "civilization.hitl.approved"
    
    # Simulation
    SIMULATION_STARTED = "simulation.started"
    SIMULATION_CYCLE_COMPLETED = "simulation.cycle.completed"
    SIMULATION_FINISHED = "simulation.finished"
    
    # Failsafe
    CRISIS_INDICATOR_UPDATED = "failsafe.indicator.updated"
    CRISIS_DETECTED = "failsafe.crisis.detected"
    FAILSAFE_LEVEL_CHANGED = "failsafe.level.changed"
    
    # Transmission
    SKILL_TRACE_CREATED = "transmission.skill.created"
    SKILL_TRANSMITTED = "transmission.skill.transmitted"
    
    # Collapse Prevention
    COLLAPSE_RISK_DETECTED = "collapse.risk.detected"
    PREVENTIVE_ACTION_TRIGGERED = "collapse.prevention.triggered"
    
    # External Interface
    EXTERNAL_REQUEST_RECEIVED = "external.request.received"
    EXTERNAL_REQUEST_BLOCKED = "external.request.blocked"
    
    # XR
    XR_SCENE_GENERATED = "xr.scene.generated"
    XR_SCENE_UPDATED = "xr.scene.updated"
    
    # Generic
    MODULE_INITIALIZED = "module.initialized"
    MODULE_ERROR = "module.error"
    AUDIT_LOG_ENTRY = "audit.log.entry"


@dataclass
class ModuleEvent:
    """Event for inter-module communication."""
    event_id: str = field(default_factory=lambda: f"MEVT_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Event info
    event_type: ModuleEventType = ModuleEventType.AUDIT_LOG_ENTRY
    source_module: str = ""
    target_module: str = ""  # Empty = broadcast
    
    # Payload
    payload: dict = field(default_factory=dict)
    
    # Governance
    synthetic: bool = True
    governance_validated: bool = False
    
    # Tracing
    correlation_id: str = ""
    causation_id: str = ""
    
    def to_dict(self) -> dict:
        return {
            "event_id": self.event_id,
            "timestamp": self.timestamp.isoformat(),
            "event_type": self.event_type.value,
            "source_module": self.source_module,
            "target_module": self.target_module,
            "payload": self.payload,
            "governance": {
                "synthetic": self.synthetic,
                "validated": self.governance_validated,
            },
            "tracing": {
                "correlation_id": self.correlation_id,
                "causation_id": self.causation_id,
            },
        }


@dataclass
class EventSubscription:
    """Subscription to events."""
    subscription_id: str = field(default_factory=lambda: f"SUB_{uuid4().hex[:8]}")
    event_types: list[ModuleEventType] = field(default_factory=list)
    handler: Callable = None
    filter_fn: Optional[Callable[[ModuleEvent], bool]] = None
    is_async: bool = True


class EventBus:
    """
    Central event bus for inter-module communication.
    
    All events are:
    - Governance validated
    - Audit logged
    - Async by default
    """
    
    def __init__(self):
        self.bus_id = f"EBUS_{uuid4().hex[:8]}"
        self._subscriptions: dict[ModuleEventType, list[EventSubscription]] = defaultdict(list)
        self._event_history: list[ModuleEvent] = []
        self._max_history = 5000
        self._middlewares: list[Callable] = []
        
        logger.info(f"Event Bus initialized: {self.bus_id}")
    
    # =========================================================================
    # SUBSCRIPTION
    # =========================================================================
    
    def subscribe(
        self,
        event_types: list[ModuleEventType],
        handler: Callable,
        filter_fn: Optional[Callable[[ModuleEvent], bool]] = None,
    ) -> str:
        """Subscribe to events."""
        subscription = EventSubscription(
            event_types=event_types,
            handler=handler,
            filter_fn=filter_fn,
            is_async=asyncio.iscoroutinefunction(handler),
        )
        
        for event_type in event_types:
            self._subscriptions[event_type].append(subscription)
        
        logger.debug(f"Subscription created: {subscription.subscription_id}")
        return subscription.subscription_id
    
    def unsubscribe(self, subscription_id: str):
        """Unsubscribe from events."""
        for event_type in self._subscriptions:
            self._subscriptions[event_type] = [
                s for s in self._subscriptions[event_type]
                if s.subscription_id != subscription_id
            ]
    
    # =========================================================================
    # PUBLISHING
    # =========================================================================
    
    async def publish(self, event: ModuleEvent):
        """Publish event to subscribers."""
        # Apply middlewares
        for middleware in self._middlewares:
            event = await self._run_middleware(middleware, event)
            if event is None:
                return  # Event cancelled by middleware
        
        # Ensure governance
        event.synthetic = True
        
        # Store in history
        self._event_history.append(event)
        if len(self._event_history) > self._max_history:
            self._event_history = self._event_history[-self._max_history:]
        
        # Get subscriptions
        subscriptions = self._subscriptions.get(event.event_type, [])
        
        # Execute handlers
        for subscription in subscriptions:
            # Apply filter
            if subscription.filter_fn and not subscription.filter_fn(event):
                continue
            
            # Execute handler
            try:
                if subscription.is_async:
                    await subscription.handler(event)
                else:
                    subscription.handler(event)
            except Exception as e:
                logger.error(f"Handler error for {event.event_type}: {e}")
        
        logger.debug(f"Event published: {event.event_type.value} ({len(subscriptions)} handlers)")
    
    def publish_sync(self, event: ModuleEvent):
        """Synchronous publish (creates async task)."""
        asyncio.create_task(self.publish(event))
    
    async def _run_middleware(
        self,
        middleware: Callable,
        event: ModuleEvent,
    ) -> Optional[ModuleEvent]:
        """Run middleware on event."""
        if asyncio.iscoroutinefunction(middleware):
            return await middleware(event)
        return middleware(event)
    
    # =========================================================================
    # MIDDLEWARE
    # =========================================================================
    
    def use_middleware(self, middleware: Callable):
        """Add middleware to event processing."""
        self._middlewares.append(middleware)
    
    # =========================================================================
    # CONVENIENCE METHODS
    # =========================================================================
    
    async def emit_nova_validated(
        self,
        request_id: str,
        validation_result: dict,
    ):
        """Emit NOVA validation event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.NOVA_REQUEST_VALIDATED,
            source_module="nova_kernel",
            payload={
                "request_id": request_id,
                "result": validation_result,
            },
        ))
    
    async def emit_ethics_violation(
        self,
        action: str,
        violations: list[str],
    ):
        """Emit ethics violation event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.ETHICS_VIOLATION_DETECTED,
            source_module="ethics_canon",
            payload={
                "action": action,
                "violations": violations,
            },
        ))
    
    async def emit_decision_created(
        self,
        package_id: str,
        package_data: dict,
    ):
        """Emit decision created event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.DECISION_LOOP_COMPLETED,
            source_module="civilization_os",
            payload={
                "package_id": package_id,
                "data": package_data,
            },
        ))
    
    async def emit_hitl_checkpoint(
        self,
        package_id: str,
        description: str,
    ):
        """Emit HITL checkpoint event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.HITL_CHECKPOINT_REACHED,
            source_module="civilization_os",
            payload={
                "package_id": package_id,
                "description": description,
                "requires_approval": True,
            },
        ))
    
    async def emit_crisis_detected(
        self,
        crisis_type: str,
        indicators: dict,
    ):
        """Emit crisis detected event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.CRISIS_DETECTED,
            source_module="failsafe",
            payload={
                "crisis_type": crisis_type,
                "indicators": indicators,
            },
        ))
    
    async def emit_xr_scene_ready(
        self,
        scene_id: str,
        scene_type: str,
    ):
        """Emit XR scene ready event."""
        await self.publish(ModuleEvent(
            event_type=ModuleEventType.XR_SCENE_GENERATED,
            source_module="xr_manager",
            payload={
                "scene_id": scene_id,
                "scene_type": scene_type,
                "read_only": True,
            },
        ))
    
    # =========================================================================
    # STATS & DEBUG
    # =========================================================================
    
    def get_stats(self) -> dict:
        """Get event bus statistics."""
        event_counts = defaultdict(int)
        for event in self._event_history:
            event_counts[event.event_type.value] += 1
        
        return {
            "bus_id": self.bus_id,
            "total_events": len(self._event_history),
            "subscription_count": sum(
                len(subs) for subs in self._subscriptions.values()
            ),
            "middleware_count": len(self._middlewares),
            "events_by_type": dict(event_counts),
        }
    
    def get_recent_events(self, limit: int = 50) -> list[dict]:
        """Get recent events."""
        return [e.to_dict() for e in self._event_history[-limit:]]


# =============================================================================
# GOVERNANCE MIDDLEWARE
# =============================================================================

async def governance_middleware(event: ModuleEvent) -> Optional[ModuleEvent]:
    """Middleware to enforce governance on all events."""
    # Always ensure synthetic
    event.synthetic = True
    
    # Mark as governance validated
    event.governance_validated = True
    
    return event


async def audit_middleware(event: ModuleEvent) -> Optional[ModuleEvent]:
    """Middleware to audit all events."""
    logger.info(
        f"AUDIT: {event.event_type.value} from {event.source_module} "
        f"[{event.event_id}]"
    )
    return event


# =============================================================================
# SINGLETON
# =============================================================================

_event_bus: Optional[EventBus] = None


def get_event_bus() -> EventBus:
    """Get the event bus singleton."""
    global _event_bus
    if _event_bus is None:
        _event_bus = EventBus()
        _event_bus.use_middleware(governance_middleware)
        _event_bus.use_middleware(audit_middleware)
    return _event_bus
