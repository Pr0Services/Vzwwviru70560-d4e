"""
CHE·NU™ V70 — API TESTS
=======================
Complete test suite for all API endpoints.

GOUVERNANCE > EXÉCUTION
"""

import pytest
from fastapi.testclient import TestClient
from uuid import uuid4
from datetime import datetime, timedelta

# Import the app
import sys
sys.path.insert(0, '/home/claude/chenu_work/chenu_v70')

from api.main import app


# =============================================================================
# TEST CLIENT SETUP
# =============================================================================

client = TestClient(app)

# Mock auth headers
AUTH_HEADERS = {
    "Authorization": "Bearer test_jwt_token",
    "X-Identity-ID": str(uuid4()),
    "X-Request-ID": str(uuid4())
}


# =============================================================================
# ROOT & HEALTH TESTS
# =============================================================================

class TestRoot:
    """Test root and health endpoints."""
    
    def test_root_returns_api_info(self):
        """GET / returns API information."""
        response = client.get("/")
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["name"] == "CHE·NU™ API"
        assert data["data"]["version"] == "70.0.0"
        assert data["data"]["governance"]["governance_over_execution"] is True
    
    def test_health_check(self):
        """GET /health returns healthy status."""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["status"] == "healthy"


# =============================================================================
# IDENTITY API TESTS
# =============================================================================

class TestIdentityAPI:
    """Test Identity endpoints."""
    
    def test_create_identity(self):
        """POST /v1/identities creates an identity."""
        response = client.post(
            "/v1/identities",
            json={
                "identity_type": "enterprise",
                "identity_name": "Test Company",
                "config": {"industry": "construction"}
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["identity_type"] == "enterprise"
        assert data["data"]["identity_name"] == "Test Company"
    
    def test_list_identities(self):
        """GET /v1/identities lists identities."""
        response = client.get("/v1/identities", headers=AUTH_HEADERS)
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert "identities" in data["data"]
    
    def test_activate_identity(self):
        """POST /v1/identities/{id}/activate activates identity."""
        identity_id = str(uuid4())
        response = client.post(
            f"/v1/identities/{identity_id}/activate",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["activated"] is True
    
    def test_get_permissions(self):
        """GET /v1/identities/{id}/permissions returns permissions."""
        identity_id = str(uuid4())
        response = client.get(
            f"/v1/identities/{identity_id}/permissions",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert "permissions" in data["data"]


# =============================================================================
# DATASPACE API TESTS
# =============================================================================

class TestDataSpaceAPI:
    """Test DataSpace endpoints."""
    
    def test_create_dataspace(self):
        """POST /v1/dataspaces creates a DataSpace."""
        response = client.post(
            "/v1/dataspaces",
            json={
                "name": "Test Project",
                "description": "A test project",
                "dataspace_type": "project",
                "tags": ["test", "construction"]
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["success"] is True
        assert data["data"]["name"] == "Test Project"
        assert "dataspace_id" in data["data"]
    
    def test_list_dataspaces_with_filters(self):
        """GET /v1/dataspaces supports filtering."""
        response = client.get(
            "/v1/dataspaces?status=active&page=1&limit=10",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["page"] == 1
        assert data["data"]["limit"] == 10
    
    def test_archive_dataspace(self):
        """POST /v1/dataspaces/{id}/archive archives DataSpace."""
        dataspace_id = str(uuid4())
        response = client.post(
            f"/v1/dataspaces/{dataspace_id}/archive",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["archived"] is True
    
    def test_link_dataspaces(self):
        """POST /v1/dataspaces/{id}/links creates link."""
        source_id = str(uuid4())
        target_id = str(uuid4())
        response = client.post(
            f"/v1/dataspaces/{source_id}/links",
            json={
                "target_dataspace_id": target_id,
                "link_type": "reference"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["created"] is True


# =============================================================================
# THREAD API TESTS
# =============================================================================

class TestThreadAPI:
    """Test Thread endpoints."""
    
    def test_create_thread(self):
        """POST /v1/threads creates a Thread."""
        response = client.post(
            "/v1/threads",
            json={
                "title": "Project Discussion",
                "thread_type": "conversation",
                "participants": [str(uuid4())]
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["title"] == "Project Discussion"
    
    def test_add_message(self):
        """POST /v1/threads/{id}/messages adds message."""
        thread_id = str(uuid4())
        response = client.post(
            f"/v1/threads/{thread_id}/messages",
            json={
                "message_type": "text",
                "content": "Hello, this is a test message"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert "message_id" in data["data"]
    
    def test_record_decision_requires_hitl(self):
        """POST /v1/threads/{id}/decisions includes HITL flag."""
        thread_id = str(uuid4())
        response = client.post(
            f"/v1/threads/{thread_id}/decisions",
            json={
                "decision_text": "Approved to proceed",
                "decision_type": "approval",
                "affected_dataspaces": []
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: Decisions require HITL
        assert data["data"]["requires_hitl"] is True


# =============================================================================
# WORKSPACE API TESTS
# =============================================================================

class TestWorkspaceAPI:
    """Test Workspace endpoints."""
    
    def test_create_workspace(self):
        """POST /v1/workspaces creates Workspace."""
        response = client.post(
            "/v1/workspaces",
            json={
                "name": "My Workspace",
                "workspace_mode": "document"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["mode"] == "document"
        # GOVERNANCE: synthetic flag
        assert data["data"]["synthetic"] is True
    
    def test_transform_workspace(self):
        """POST /v1/workspaces/{id}/transform changes mode."""
        workspace_id = str(uuid4())
        response = client.post(
            f"/v1/workspaces/{workspace_id}/transform",
            json={
                "target_mode": "dashboard",
                "preserve_data": True
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["new_mode"] == "dashboard"
        assert data["data"]["data_preserved"] is True
    
    def test_save_and_revert_state(self):
        """Workspace state can be saved and reverted."""
        workspace_id = str(uuid4())
        
        # Save state
        save_response = client.post(
            f"/v1/workspaces/{workspace_id}/states",
            json={"state_name": "checkpoint_1", "state_data": {"panels": []}},
            headers=AUTH_HEADERS
        )
        assert save_response.status_code == 200
        state_id = save_response.json()["data"]["state_id"]
        
        # Revert state
        revert_response = client.post(
            f"/v1/workspaces/{workspace_id}/revert",
            json={"state_id": state_id},
            headers=AUTH_HEADERS
        )
        assert revert_response.status_code == 200


# =============================================================================
# ONECLICK API TESTS
# =============================================================================

class TestOneClickAPI:
    """Test 1-Click Assistant endpoints."""
    
    def test_execute_requires_hitl_by_default(self):
        """POST /v1/oneclick/execute requires HITL by default."""
        response = client.post(
            "/v1/oneclick/execute",
            json={
                "input": "Create a construction estimate",
                "input_type": "prompt",
                "options": {"auto_approve": False}
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: HITL required
        assert data["data"]["status"] == "needs_approval"
        assert data["data"]["requires_hitl"] is True
    
    def test_approve_execution(self):
        """POST /v1/oneclick/executions/{id}/approve approves step."""
        execution_id = str(uuid4())
        response = client.post(
            f"/v1/oneclick/executions/{execution_id}/approve",
            json={"step_index": 0},
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["approved"] is True
        assert data["data"]["hitl_confirmed"] is True
    
    def test_cancel_execution(self):
        """POST /v1/oneclick/executions/{id}/cancel cancels execution."""
        execution_id = str(uuid4())
        response = client.post(
            f"/v1/oneclick/executions/{execution_id}/cancel",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["status"] == "cancelled"
    
    def test_list_workflows(self):
        """GET /v1/oneclick/workflows returns workflows."""
        response = client.get("/v1/oneclick/workflows", headers=AUTH_HEADERS)
        assert response.status_code == 200
        data = response.json()
        assert "workflows" in data["data"]


# =============================================================================
# BACKSTAGE API TESTS
# =============================================================================

class TestBackstageAPI:
    """Test Backstage Intelligence endpoints."""
    
    def test_get_suggestions_is_synthetic(self):
        """POST /v1/backstage/suggest returns synthetic suggestions."""
        response = client.post(
            "/v1/backstage/suggest",
            json={
                "context_type": "workspace",
                "current_state": {},
                "user_intent": "construction estimate"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert "suggestions" in data["data"]
        # GOVERNANCE: Backstage is synthetic only
        assert data["data"]["synthetic"] is True
    
    def test_classify_content(self):
        """POST /v1/backstage/classify classifies content."""
        response = client.post(
            "/v1/backstage/classify",
            json={
                "content": "Construction project estimate",
                "content_type": "text"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert "classification" in data["data"]


# =============================================================================
# MEMORY API TESTS
# =============================================================================

class TestMemoryAPI:
    """Test Memory endpoints with Ten Laws enforcement."""
    
    def test_store_memory_visible_to_user(self):
        """POST /v1/memory creates visible memory (Law 1)."""
        response = client.post(
            "/v1/memory",
            json={
                "memory_type": "short_term",
                "memory_category": "preference",
                "content": "User prefers detailed estimates"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # LAW 1: No Hidden Memory
        assert data["data"]["visible_to_user"] is True
    
    def test_long_term_memory_requires_approval(self):
        """Long-term memory requires approval (Law 2)."""
        response = client.post(
            "/v1/memory",
            json={
                "memory_type": "long_term",
                "memory_category": "fact",
                "content": "User's company is ABC Construction"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # LAW 2: Explicit Storage Approval
        assert data["data"]["requires_approval"] is True
    
    def test_memory_is_deletable(self):
        """Memory can be deleted (Law 5)."""
        response = client.post(
            "/v1/memory",
            json={
                "memory_type": "mid_term",
                "memory_category": "context",
                "content": "Current project is Phase 2"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # LAW 5: Reversibility
        assert data["data"]["user_deletable"] is True
    
    def test_delete_memory_true_deletion(self):
        """DELETE /v1/memory/{id} performs true deletion."""
        memory_id = str(uuid4())
        response = client.delete(
            f"/v1/memory/{memory_id}",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # True deletion, no residual patterns
        assert data["data"]["true_deletion"] is True


# =============================================================================
# GOVERNANCE API TESTS
# =============================================================================

class TestGovernanceAPI:
    """Test Governance endpoints."""
    
    def test_get_audit_log(self):
        """GET /v1/governance/audit returns audit log."""
        response = client.get(
            "/v1/governance/audit?page=1&limit=10",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["governance"]["complete_log"] is True
    
    def test_request_elevation(self):
        """POST /v1/governance/elevate creates HITL request."""
        response = client.post(
            "/v1/governance/elevate",
            json={
                "requested_action": "delete_dataspace",
                "resource_type": "dataspace",
                "resource_id": str(uuid4()),
                "reason": "Project completed"
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["status"] == "pending_approval"
        assert data["data"]["requires_hitl"] is True
    
    def test_approve_elevation(self):
        """POST /v1/governance/elevate/{id}/approve approves request."""
        request_id = str(uuid4())
        response = client.post(
            f"/v1/governance/elevate/{request_id}/approve",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        assert data["data"]["status"] == "approved"


# =============================================================================
# AGENT API TESTS
# =============================================================================

class TestAgentAPI:
    """Test Agent endpoints with governance."""
    
    def test_list_agents_shows_l0_not_hireable(self):
        """GET /v1/agents shows L0 agents as not hireable."""
        response = client.get("/v1/agents", headers=AUTH_HEADERS)
        assert response.status_code == 200
        data = response.json()
        # Find L0 agent
        l0_agents = [a for a in data["data"]["agents"] if a["level"] == "L0"]
        for agent in l0_agents:
            assert agent["hireable"] is False
    
    def test_execute_l0_agent_forbidden(self):
        """POST /v1/agents/{L0}/execute returns 403."""
        response = client.post(
            "/v1/agents/AGT_NOVA_L0/execute",
            json={"input": {"task": "test"}},
            headers=AUTH_HEADERS
        )
        # GOVERNANCE: L0 cannot be executed directly
        assert response.status_code == 403
    
    def test_hire_l0_agent_forbidden(self):
        """POST /v1/agents/{L0}/hire returns 403."""
        response = client.post(
            "/v1/agents/AGT_NOVA_L0/hire",
            headers=AUTH_HEADERS
        )
        # GOVERNANCE: L0 cannot be hired
        assert response.status_code == 403
    
    def test_execute_l2_agent_synthetic(self):
        """POST /v1/agents/{L2}/execute returns synthetic result."""
        response = client.post(
            "/v1/agents/AGT_CONSTRUCTION_CHIEF_L2/execute",
            json={"input": {"task": "analyze"}},
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: All executions are synthetic
        assert data["data"]["governance"]["synthetic"] is True


# =============================================================================
# MEETING API TESTS
# =============================================================================

class TestMeetingAPI:
    """Test Meeting endpoints with consent governance."""
    
    def test_create_meeting(self):
        """POST /v1/meetings creates meeting."""
        response = client.post(
            "/v1/meetings",
            json={
                "title": "Project Kickoff",
                "meeting_type": "planning",
                "scheduled_start": (datetime.utcnow() + timedelta(days=1)).isoformat(),
                "scheduled_end": (datetime.utcnow() + timedelta(days=1, hours=1)).isoformat(),
                "participants": ["user@example.com"]
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: Recording consent required
        assert data["data"]["governance"]["recording_consent_required"] is True
    
    def test_start_meeting_consent_check(self):
        """POST /v1/meetings/{id}/start checks consent."""
        meeting_id = str(uuid4())
        response = client.post(
            f"/v1/meetings/{meeting_id}/start",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # Recording not active until all consent
        assert data["data"]["governance"]["consent_required"] is True
        assert data["data"]["governance"]["recording_active"] is False


# =============================================================================
# IMMOBILIER API TESTS
# =============================================================================

class TestImmobilierAPI:
    """Test Immobilier endpoints with TAL compliance."""
    
    def test_create_property_tal_compliant(self):
        """POST /v1/immobilier/properties is TAL compliant."""
        response = client.post(
            "/v1/immobilier/properties",
            json={
                "property_type": "residential",
                "ownership_type": "investment",
                "address": {
                    "line1": "123 Rue Test",
                    "city": "Montreal",
                    "province": "QC",
                    "postal_code": "H2X 1A1"
                }
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: TAL compliance
        assert data["data"]["tal_compliant"] is True
    
    def test_create_tenant_section_g(self):
        """POST /v1/immobilier/properties/{id}/tenants provides Section G."""
        property_id = str(uuid4())
        response = client.post(
            f"/v1/immobilier/properties/{property_id}/tenants",
            json={
                "first_name": "Jean",
                "last_name": "Dupont",
                "email": "jean@example.com",
                "phone": "514-555-1234",
                "lease": {
                    "start_date": "2026-02-01",
                    "end_date": "2027-01-31",
                    "monthly_rent": 1400,
                    "security_deposit": 0
                }
            },
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # GOVERNANCE: TAL Section G required
        assert data["data"]["lease"]["section_g_provided"] is True
    
    def test_rent_increase_tal_calculation(self):
        """POST /v1/immobilier/leases/{id}/increase uses TAL formula."""
        lease_id = str(uuid4())
        response = client.post(
            f"/v1/immobilier/leases/{lease_id}/increase",
            headers=AUTH_HEADERS
        )
        assert response.status_code == 200
        data = response.json()
        # TAL calculation factors
        assert "tal_calculation" in data["data"]
        assert data["data"]["governance"]["tal_compliant"] is True


# =============================================================================
# GOVERNANCE INTEGRATION TESTS
# =============================================================================

class TestGovernanceIntegration:
    """Integration tests for governance rules."""
    
    def test_all_responses_have_synthetic_flag(self):
        """All creation endpoints return synthetic flag."""
        endpoints = [
            ("/v1/workspaces", {"name": "Test", "workspace_mode": "document"}),
            ("/v1/backstage/suggest", {"context_type": "workspace", "current_state": {}}),
        ]
        for endpoint, payload in endpoints:
            response = client.post(endpoint, json=payload, headers=AUTH_HEADERS)
            assert response.status_code == 200
            data = response.json()
            assert data["data"].get("synthetic") is True
    
    def test_meta_includes_request_id(self):
        """All responses include request_id in meta."""
        response = client.get("/", headers=AUTH_HEADERS)
        assert response.status_code == 200
        data = response.json()
        assert "request_id" in data["meta"]
        assert "timestamp" in data["meta"]


# =============================================================================
# RUN TESTS
# =============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
