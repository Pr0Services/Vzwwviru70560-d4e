"""
CHE·NU™ V70 — STRUCTURED LOGGING
================================
JSON-formatted structured logging for GP2.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import json
import logging
import sys
import traceback


class LogLevel(str, Enum):
    """Log levels."""
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class LogContext:
    """Context for structured logging."""
    request_id: str = ""
    user_id: str = ""
    session_id: str = ""
    correlation_id: str = ""
    module: str = ""
    
    # Governance
    synthetic: bool = True
    governance_level: str = "strict"


@dataclass
class LogEntry:
    """Structured log entry."""
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    level: str = "info"
    message: str = ""
    
    # Context
    request_id: str = ""
    user_id: str = ""
    session_id: str = ""
    correlation_id: str = ""
    
    # Source
    module: str = ""
    function: str = ""
    line: int = 0
    
    # Additional data
    data: dict = field(default_factory=dict)
    
    # Error info
    error_type: str = ""
    error_message: str = ""
    stack_trace: str = ""
    
    # Governance
    governance: dict = field(default_factory=lambda: {
        "synthetic": True,
        "level": "strict",
    })
    
    def to_json(self) -> str:
        """Convert to JSON string."""
        d = asdict(self)
        # Remove empty values
        d = {k: v for k, v in d.items() if v}
        return json.dumps(d)


class JSONFormatter(logging.Formatter):
    """JSON log formatter."""
    
    def __init__(self, context: LogContext = None):
        super().__init__()
        self.context = context or LogContext()
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        entry = LogEntry(
            level=record.levelname.lower(),
            message=record.getMessage(),
            module=record.module,
            function=record.funcName,
            line=record.lineno,
            request_id=getattr(record, 'request_id', self.context.request_id),
            user_id=getattr(record, 'user_id', self.context.user_id),
            session_id=getattr(record, 'session_id', self.context.session_id),
            correlation_id=getattr(record, 'correlation_id', self.context.correlation_id),
        )
        
        # Add extra data
        if hasattr(record, 'data'):
            entry.data = record.data
        
        # Add exception info
        if record.exc_info:
            entry.error_type = record.exc_info[0].__name__ if record.exc_info[0] else ""
            entry.error_message = str(record.exc_info[1]) if record.exc_info[1] else ""
            entry.stack_trace = ''.join(traceback.format_exception(*record.exc_info))
        
        return entry.to_json()


class StructuredLogger:
    """
    Structured logger for GP2.
    
    Features:
    - JSON output
    - Context propagation
    - Correlation IDs
    - Governance metadata
    """
    
    def __init__(
        self,
        name: str = "chenu",
        level: str = "INFO",
        json_output: bool = True,
    ):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))
        
        # Context
        self._context = LogContext()
        
        # Setup handlers
        if json_output:
            self._setup_json_handler()
        else:
            self._setup_text_handler()
    
    def _setup_json_handler(self):
        """Setup JSON formatter handler."""
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JSONFormatter(self._context))
        self.logger.handlers = [handler]
    
    def _setup_text_handler(self):
        """Setup text formatter handler."""
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.logger.handlers = [handler]
    
    # =========================================================================
    # CONTEXT
    # =========================================================================
    
    def set_context(self, **kwargs):
        """Set logging context."""
        for key, value in kwargs.items():
            if hasattr(self._context, key):
                setattr(self._context, key, value)
    
    def clear_context(self):
        """Clear logging context."""
        self._context = LogContext()
    
    def with_context(self, **kwargs) -> "StructuredLogger":
        """Create logger with additional context."""
        new_logger = StructuredLogger.__new__(StructuredLogger)
        new_logger.logger = self.logger
        new_logger._context = LogContext(
            request_id=kwargs.get('request_id', self._context.request_id),
            user_id=kwargs.get('user_id', self._context.user_id),
            session_id=kwargs.get('session_id', self._context.session_id),
            correlation_id=kwargs.get('correlation_id', self._context.correlation_id),
            module=kwargs.get('module', self._context.module),
        )
        return new_logger
    
    # =========================================================================
    # LOGGING METHODS
    # =========================================================================
    
    def _log(
        self,
        level: int,
        message: str,
        data: dict = None,
        exc_info: bool = False,
        **kwargs,
    ):
        """Internal log method."""
        extra = {
            'request_id': kwargs.get('request_id', self._context.request_id),
            'user_id': kwargs.get('user_id', self._context.user_id),
            'session_id': kwargs.get('session_id', self._context.session_id),
            'correlation_id': kwargs.get('correlation_id', self._context.correlation_id),
            'data': data or {},
        }
        
        self.logger.log(level, message, exc_info=exc_info, extra=extra)
    
    def debug(self, message: str, data: dict = None, **kwargs):
        """Log debug message."""
        self._log(logging.DEBUG, message, data, **kwargs)
    
    def info(self, message: str, data: dict = None, **kwargs):
        """Log info message."""
        self._log(logging.INFO, message, data, **kwargs)
    
    def warning(self, message: str, data: dict = None, **kwargs):
        """Log warning message."""
        self._log(logging.WARNING, message, data, **kwargs)
    
    def error(self, message: str, data: dict = None, exc_info: bool = True, **kwargs):
        """Log error message."""
        self._log(logging.ERROR, message, data, exc_info=exc_info, **kwargs)
    
    def critical(self, message: str, data: dict = None, exc_info: bool = True, **kwargs):
        """Log critical message."""
        self._log(logging.CRITICAL, message, data, exc_info=exc_info, **kwargs)
    
    # =========================================================================
    # SPECIALIZED LOGGING
    # =========================================================================
    
    def governance_check(
        self,
        module: str,
        action: str,
        passed: bool,
        details: dict = None,
    ):
        """Log governance check."""
        self.info(
            f"Governance check: {module}.{action} -> {'PASS' if passed else 'FAIL'}",
            data={
                "type": "governance_check",
                "module": module,
                "action": action,
                "passed": passed,
                "details": details or {},
            }
        )
    
    def governance_violation(
        self,
        module: str,
        violation_type: str,
        description: str,
        blocked: bool = True,
    ):
        """Log governance violation."""
        self.warning(
            f"Governance violation: {violation_type} in {module}",
            data={
                "type": "governance_violation",
                "module": module,
                "violation_type": violation_type,
                "description": description,
                "blocked": blocked,
            }
        )
    
    def nova_request(
        self,
        request_id: str,
        intent: str,
        is_refusal: bool,
        duration_ms: float,
    ):
        """Log NOVA request."""
        self.info(
            f"NOVA request: {request_id} -> {'REFUSED' if is_refusal else 'VALIDATED'}",
            data={
                "type": "nova_request",
                "request_id": request_id,
                "intent": intent[:100],  # Truncate
                "is_refusal": is_refusal,
                "duration_ms": duration_ms,
            }
        )
    
    def ethics_validation(
        self,
        validation_id: str,
        is_valid: bool,
        violations: list[str] = None,
    ):
        """Log ethics validation."""
        self.info(
            f"Ethics validation: {validation_id} -> {'VALID' if is_valid else 'INVALID'}",
            data={
                "type": "ethics_validation",
                "validation_id": validation_id,
                "is_valid": is_valid,
                "violations": violations or [],
            }
        )
    
    def decision_loop(
        self,
        package_id: str,
        status: str,
        cycles: int,
        requires_hitl: bool,
    ):
        """Log decision loop."""
        self.info(
            f"Decision loop: {package_id} -> {status}",
            data={
                "type": "decision_loop",
                "package_id": package_id,
                "status": status,
                "cycles": cycles,
                "requires_hitl": requires_hitl,
            }
        )
    
    def hitl_event(
        self,
        package_id: str,
        event: str,  # "checkpoint", "approved", "rejected"
        user_id: str = "",
    ):
        """Log HITL event."""
        self.info(
            f"HITL event: {package_id} -> {event}",
            data={
                "type": "hitl_event",
                "package_id": package_id,
                "event": event,
                "user_id": user_id,
            }
        )
    
    def crisis_event(
        self,
        crisis_type: str,
        response_level: str,
        indicators: dict = None,
    ):
        """Log crisis event."""
        self.warning(
            f"Crisis detected: {crisis_type} (level: {response_level})",
            data={
                "type": "crisis_event",
                "crisis_type": crisis_type,
                "response_level": response_level,
                "indicators": indicators or {},
            }
        )
    
    def audit(
        self,
        action: str,
        actor_id: str,
        resource: str,
        details: dict = None,
    ):
        """Log audit event."""
        self.info(
            f"AUDIT: {action} on {resource} by {actor_id}",
            data={
                "type": "audit",
                "action": action,
                "actor_id": actor_id,
                "resource": resource,
                "details": details or {},
            }
        )


# =============================================================================
# LOG AGGREGATOR
# =============================================================================

class LogAggregator:
    """
    Aggregates and buffers logs for batch processing.
    """
    
    def __init__(self, max_buffer_size: int = 1000):
        self._buffer: list[LogEntry] = []
        self._max_size = max_buffer_size
    
    def add(self, entry: LogEntry):
        """Add log entry to buffer."""
        self._buffer.append(entry)
        
        if len(self._buffer) >= self._max_size:
            self.flush()
    
    def flush(self) -> list[LogEntry]:
        """Flush and return buffered logs."""
        entries = self._buffer.copy()
        self._buffer.clear()
        return entries
    
    def export_json(self) -> str:
        """Export buffer as JSON array."""
        entries = self.flush()
        return json.dumps([asdict(e) for e in entries])


# =============================================================================
# REQUEST CONTEXT MANAGER
# =============================================================================

class RequestLogContext:
    """
    Context manager for request-scoped logging.
    
    Usage:
        with RequestLogContext(request_id="REQ_123") as ctx:
            ctx.logger.info("Processing request")
    """
    
    def __init__(
        self,
        request_id: str = None,
        user_id: str = "",
        **kwargs,
    ):
        self.request_id = request_id or f"REQ_{uuid4().hex[:8]}"
        self.user_id = user_id
        self.extra = kwargs
        self._logger = None
    
    def __enter__(self) -> "RequestLogContext":
        self._logger = get_logger().with_context(
            request_id=self.request_id,
            user_id=self.user_id,
            **self.extra,
        )
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self._logger.error(
                f"Request failed: {exc_val}",
                data={"request_id": self.request_id},
            )
        return False
    
    @property
    def logger(self) -> StructuredLogger:
        return self._logger


# =============================================================================
# SINGLETON
# =============================================================================

_logger: Optional[StructuredLogger] = None


def get_logger(name: str = "chenu") -> StructuredLogger:
    """Get the structured logger singleton."""
    global _logger
    if _logger is None:
        import os
        json_output = os.getenv("LOG_FORMAT", "json").lower() == "json"
        level = os.getenv("LOG_LEVEL", "INFO")
        _logger = StructuredLogger(name, level, json_output)
    return _logger


def setup_logging(
    level: str = "INFO",
    json_output: bool = True,
    name: str = "chenu",
):
    """Setup structured logging."""
    global _logger
    _logger = StructuredLogger(name, level, json_output)
    return _logger
