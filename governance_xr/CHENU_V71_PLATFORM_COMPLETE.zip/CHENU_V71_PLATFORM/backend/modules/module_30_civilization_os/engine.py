"""
CHE·NU™ V70 — MODULE 30: CIVILIZATION OS LAYER
===============================================
Makes CHE·NU™ behave like a SYSTEM OF OPERATION for communities.

Components:
- Policies (governance)
- Processes (workflows)
- Memory (artifacts)
- Learning (skills)
- Culture (narratives)
- Coordination (planetary federation)

This layer turns "modules" into ONE COHERENT OS.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Optional
from uuid import uuid4
import hashlib
import json
import logging

logger = logging.getLogger("chenu.module_30")


class IdentityType(str, Enum):
    """Types d'identité dans l'OS."""
    PERSONAL = "personal"  # User
    INSTITUTIONAL = "institutional"  # Org/Node
    CULTURAL = "cultural"  # Community
    HERITAGE = "heritage"  # Long-term continuity


class StateType(str, Enum):
    """Types d'état dans l'OS."""
    WORLD = "world"  # WorldState (Module 04)
    CIVIC = "civic"  # CivicState (Module 17)
    SKILL = "skill"  # SkillState (Module 21)
    CULTURE = "culture"  # CultureState (Module 28)
    PLANETARY = "planetary"  # PlanetaryState (Module 29)


class ShellMode(str, Enum):
    """UI modes (shells) de l'OS."""
    CITIZEN = "citizen"
    ENTERPRISE = "enterprise"
    SCHOLAR = "scholar"
    PLANETARY = "planetary"


class DecisionLoopStage(str, Enum):
    """Stages of the standard decision loop."""
    INTENT = "intent"
    SLOT_FILLING = "slot_filling"
    CAUSAL_MODEL = "causal_model"
    WORLD_SIMULATION = "world_simulation"
    XR_VISUALIZATION = "xr_visualization"
    GOVERNANCE_CHECK = "governance_check"
    ARTIFACT_SIGNING = "artifact_signing"
    EXPORT = "export"


@dataclass
class OSIdentity:
    """
    Identity primitive in Civilization OS.
    Privacy-first and consent-driven.
    """
    identity_id: str = field(default_factory=lambda: f"ID_{uuid4().hex[:8]}")
    identity_type: IdentityType = IdentityType.PERSONAL
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Identity data
    display_name: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    
    # Consent
    consent_scope: list[str] = field(default_factory=list)
    privacy_level: str = "private"  # private, community, public


@dataclass
class OSState:
    """
    State primitive in Civilization OS.
    """
    state_id: str = field(default_factory=lambda: f"STATE_{uuid4().hex[:8]}")
    state_type: StateType = StateType.WORLD
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_updated: datetime = field(default_factory=datetime.utcnow)
    
    # State data
    data: dict[str, Any] = field(default_factory=dict)
    version: int = 1
    
    # Hash for integrity
    state_hash: str = ""


@dataclass
class OSPolicy:
    """
    OPA Policy in Civilization OS.
    Defines what is allowed, forbidden, requires approval, or audit.
    """
    policy_id: str = field(default_factory=lambda: f"POL_{uuid4().hex[:8]}")
    policy_name: str = ""
    
    # Rules
    allowed_actions: list[str] = field(default_factory=list)
    forbidden_actions: list[str] = field(default_factory=list)
    requires_approval: list[str] = field(default_factory=list)
    requires_audit: list[str] = field(default_factory=list)
    
    # Status
    is_active: bool = True
    version: str = "1.0"


@dataclass
class OSAction:
    """
    Action in Civilization OS.
    Always sandboxed first - no real execution by default.
    
    Flow: Propose → Simulate → Explain → Approve → Export
    """
    action_id: str = field(default_factory=lambda: f"ACT_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Action definition
    action_type: str = ""
    description: str = ""
    parameters: dict[str, Any] = field(default_factory=dict)
    
    # Governance
    requires_simulation: bool = True
    requires_approval: bool = False
    requires_audit: bool = True
    
    # Status
    status: str = "proposed"  # proposed, simulated, approved, exported, rejected
    simulation_id: Optional[str] = None
    approval_id: Optional[str] = None


@dataclass
class DecisionLoopContext:
    """
    Context for the standard decision loop pipeline.
    """
    context_id: str = field(default_factory=lambda: f"CTX_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Current stage
    current_stage: DecisionLoopStage = DecisionLoopStage.INTENT
    
    # Pipeline data
    intent: str = ""
    filled_slots: dict[str, Any] = field(default_factory=dict)
    causal_dag: Optional[dict[str, Any]] = None
    simulation_results: Optional[dict[str, Any]] = None
    xr_scene_id: Optional[str] = None
    governance_result: Optional[dict[str, Any]] = None
    artifact: Optional[dict[str, Any]] = None
    export_path: Optional[str] = None
    
    # Tracking
    stage_history: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class DecisionPackage:
    """
    Final output of the decision loop.
    Board-ready, signed artifact.
    """
    package_id: str = field(default_factory=lambda: f"PKG_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    decision_summary: str = ""
    simulation_digest: str = ""
    causal_trace_digest: str = ""
    
    # Outputs
    pdf_path: Optional[str] = None
    json_artifact_path: Optional[str] = None
    
    # Governance
    opa_validated: bool = False
    hitl_approved: bool = False
    approver_id: Optional[str] = None
    
    # Signatures
    signatures: list[str] = field(default_factory=list)


class CivilizationKernel:
    """
    The Civilization Kernel (CK) - Core of the OS.
    
    Responsibilities:
    - Schedule tasks to agents (L0-L3)
    - Enforce OPA gates
    - Manage deterministic simulation runs
    - Generate signed artifacts
    - Provide audit trail + observability
    """
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,
        worldengine: Optional[Any] = None,
        nova_kernel: Optional[Any] = None,
    ):
        self.kernel_id = f"CK_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies
        self.opa_client = opa_client
        self.worldengine = worldengine
        self.nova_kernel = nova_kernel
        
        # Storage
        self._identities: dict[str, OSIdentity] = {}
        self._states: dict[str, OSState] = {}
        self._policies: dict[str, OSPolicy] = {}
        self._actions: dict[str, OSAction] = {}
        self._decision_contexts: dict[str, DecisionLoopContext] = {}
        self._packages: dict[str, DecisionPackage] = {}
        
        # Audit log
        self._audit_log: list[dict[str, Any]] = []
        
        logger.info(f"Civilization Kernel initialized: {self.kernel_id}")
    
    # =========================================================================
    # KERNEL INTERFACES
    # =========================================================================
    
    def run_simulation(
        self,
        worldstate: dict[str, Any],
        policies: list[str],
        constraints: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Kernel.run_simulation - Run deterministic simulation.
        """
        if not self.worldengine:
            # Mock simulation
            return {
                "simulation_id": f"SIM_{uuid4().hex[:8]}",
                "worldstate_hash": hashlib.sha256(
                    json.dumps(worldstate, sort_keys=True).encode()
                ).hexdigest()[:16],
                "cycles_run": 10,
                "synthetic": True,
            }
        
        return self.worldengine.run(
            worldstate=worldstate,
            policies=policies,
            constraints=constraints,
        )
    
    def generate_artifact(
        self,
        trace: dict[str, Any],
        outputs: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Kernel.generate_artifact - Generate signed artifact.
        """
        artifact_id = f"ART_{uuid4().hex[:8]}"
        
        artifact = {
            "artifact_id": artifact_id,
            "created_at": datetime.utcnow().isoformat(),
            "trace_digest": hashlib.sha256(
                json.dumps(trace, sort_keys=True).encode()
            ).hexdigest()[:16],
            "outputs": outputs,
            "signature": f"CK_SIG:{hashlib.sha256(artifact_id.encode()).hexdigest()[:16]}",
        }
        
        self._log_audit("artifact_generated", artifact_id)
        return artifact
    
    def require_human_approval(
        self,
        impact_level: str,  # low, medium, high, critical
        context: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Kernel.require_human_approval - HITL gate.
        """
        approval_id = f"APPR_{uuid4().hex[:8]}"
        
        approval_request = {
            "approval_id": approval_id,
            "impact_level": impact_level,
            "context_summary": str(context)[:200],
            "status": "pending",
            "created_at": datetime.utcnow().isoformat(),
        }
        
        self._log_audit("approval_requested", approval_id)
        return approval_request
    
    def export(
        self,
        decision_package: DecisionPackage,
        format_type: str = "pdf",  # pdf, json, sheets
    ) -> str:
        """
        Kernel.export - Export decision package.
        Never auto-execute without explicit integration.
        """
        export_id = f"EXP_{uuid4().hex[:8]}"
        export_path = f"/exports/{decision_package.package_id}.{format_type}"
        
        self._log_audit("package_exported", export_id)
        return export_path
    
    # =========================================================================
    # DECISION LOOP
    # =========================================================================
    
    def start_decision_loop(self, intent: str) -> DecisionLoopContext:
        """
        Start the standard decision loop pipeline.
        
        Pipeline:
        1. Intent - user goal in semantic form
        2. Slot Filling - fill missing inputs
        3. Causal Model - build/validate DAG
        4. World Simulation - deterministic run
        5. XR Visualization - causal sandbox
        6. Governance Check - OPA + HITL
        7. Artifact Signing - immutable package
        8. Export - PDF/JSON (never auto-execute)
        """
        context = DecisionLoopContext(intent=intent)
        context.stage_history.append(DecisionLoopStage.INTENT.value)
        
        self._decision_contexts[context.context_id] = context
        self._log_audit("decision_loop_started", context.context_id)
        
        return context
    
    def advance_decision_loop(
        self, 
        context_id: str,
        stage_data: Optional[dict[str, Any]] = None,
    ) -> DecisionLoopContext:
        """
        Advance the decision loop to the next stage.
        """
        context = self._decision_contexts.get(context_id)
        if not context:
            raise ValueError(f"Context not found: {context_id}")
        
        stage_data = stage_data or {}
        current = context.current_stage
        
        # Process current stage and advance
        if current == DecisionLoopStage.INTENT:
            context.current_stage = DecisionLoopStage.SLOT_FILLING
            
        elif current == DecisionLoopStage.SLOT_FILLING:
            context.filled_slots = stage_data.get("slots", {})
            context.current_stage = DecisionLoopStage.CAUSAL_MODEL
            
        elif current == DecisionLoopStage.CAUSAL_MODEL:
            context.causal_dag = stage_data.get("dag")
            context.current_stage = DecisionLoopStage.WORLD_SIMULATION
            
        elif current == DecisionLoopStage.WORLD_SIMULATION:
            context.simulation_results = stage_data.get("results")
            context.current_stage = DecisionLoopStage.XR_VISUALIZATION
            
        elif current == DecisionLoopStage.XR_VISUALIZATION:
            context.xr_scene_id = stage_data.get("scene_id")
            context.current_stage = DecisionLoopStage.GOVERNANCE_CHECK
            
        elif current == DecisionLoopStage.GOVERNANCE_CHECK:
            context.governance_result = stage_data.get("governance")
            if context.governance_result and context.governance_result.get("approved"):
                context.current_stage = DecisionLoopStage.ARTIFACT_SIGNING
            else:
                context.errors.append("Governance check failed")
                
        elif current == DecisionLoopStage.ARTIFACT_SIGNING:
            context.artifact = stage_data.get("artifact")
            context.current_stage = DecisionLoopStage.EXPORT
            
        elif current == DecisionLoopStage.EXPORT:
            context.export_path = stage_data.get("path")
        
        context.stage_history.append(context.current_stage.value)
        return context
    
    def complete_decision_loop(
        self, 
        context_id: str
    ) -> DecisionPackage:
        """
        Complete the decision loop and generate final package.
        """
        context = self._decision_contexts.get(context_id)
        if not context:
            raise ValueError(f"Context not found: {context_id}")
        
        if context.current_stage != DecisionLoopStage.EXPORT:
            raise ValueError("Decision loop not complete")
        
        package = DecisionPackage(
            decision_summary=context.intent,
            simulation_digest=str(context.simulation_results)[:100] if context.simulation_results else "",
            causal_trace_digest=str(context.causal_dag)[:100] if context.causal_dag else "",
            opa_validated=context.governance_result.get("opa_valid", False) if context.governance_result else False,
            hitl_approved=context.governance_result.get("hitl_approved", False) if context.governance_result else False,
        )
        
        # Sign package
        package.signatures = [self._sign_package(package)]
        
        self._packages[package.package_id] = package
        self._log_audit("decision_package_created", package.package_id)
        
        return package
    
    def _sign_package(self, package: DecisionPackage) -> str:
        """Sign a decision package."""
        content = f"{package.package_id}:{package.decision_summary[:50]}:{package.created_at.isoformat()}"
        return f"CK_PKG_SIG:{hashlib.sha256(content.encode()).hexdigest()[:24]}"
    
    # =========================================================================
    # STATE MANAGEMENT
    # =========================================================================
    
    def create_state(
        self,
        state_type: StateType,
        data: dict[str, Any],
    ) -> OSState:
        """Create a new state."""
        state = OSState(
            state_type=state_type,
            data=data,
        )
        state.state_hash = hashlib.sha256(
            json.dumps(data, sort_keys=True).encode()
        ).hexdigest()[:16]
        
        self._states[state.state_id] = state
        return state
    
    def update_state(
        self,
        state_id: str,
        data: dict[str, Any],
    ) -> OSState:
        """Update an existing state."""
        state = self._states.get(state_id)
        if not state:
            raise ValueError(f"State not found: {state_id}")
        
        state.data.update(data)
        state.version += 1
        state.last_updated = datetime.utcnow()
        state.state_hash = hashlib.sha256(
            json.dumps(state.data, sort_keys=True).encode()
        ).hexdigest()[:16]
        
        return state
    
    # =========================================================================
    # AUDIT
    # =========================================================================
    
    def _log_audit(self, event_type: str, entity_id: str) -> None:
        """Log audit event."""
        self._audit_log.append({
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": event_type,
            "entity_id": entity_id,
            "kernel_id": self.kernel_id,
        })
    
    def get_audit_log(self) -> list[dict[str, Any]]:
        """Get audit log."""
        return self._audit_log.copy()
    
    # =========================================================================
    # STATS
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get kernel statistics."""
        return {
            "kernel_id": self.kernel_id,
            "identities": len(self._identities),
            "states": len(self._states),
            "policies": len(self._policies),
            "actions": len(self._actions),
            "decision_contexts": len(self._decision_contexts),
            "packages": len(self._packages),
            "audit_entries": len(self._audit_log),
        }


class CivilizationOS:
    """
    Module 30 — Civilization OS Layer
    
    The complete operating system that integrates all CHE·NU™ modules.
    """
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,
        worldengine: Optional[Any] = None,
        nova_kernel: Optional[Any] = None,
    ):
        self.os_id = f"CIVOSV1_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Core kernel
        self.kernel = CivilizationKernel(
            opa_client=opa_client,
            worldengine=worldengine,
            nova_kernel=nova_kernel,
        )
        
        # Current shell mode
        self._current_shell: ShellMode = ShellMode.CITIZEN
        
        logger.info(f"Civilization OS initialized: {self.os_id}")
    
    # =========================================================================
    # SHELL MODES
    # =========================================================================
    
    def set_shell_mode(self, mode: ShellMode) -> None:
        """Set the current UI shell mode."""
        self._current_shell = mode
        logger.info(f"Shell mode set to: {mode.value}")
    
    def get_shell_config(self) -> dict[str, Any]:
        """
        Get configuration for current shell mode.
        """
        configs = {
            ShellMode.CITIZEN: {
                "mode": "citizen",
                "features": [
                    "community_dashboard",
                    "tasks_equity",
                    "education_jit",
                    "culture_narratives",
                ],
                "complexity": "low",
            },
            ShellMode.ENTERPRISE: {
                "mode": "enterprise",
                "features": [
                    "multi_department_workspace",
                    "compliance_audit_trail",
                    "serious_games",
                    "board_demos",
                ],
                "complexity": "medium",
            },
            ShellMode.SCHOLAR: {
                "mode": "scholar",
                "features": [
                    "reproducibility",
                    "cross_sector_analogies",
                    "vlu_labs",
                    "open_verified_artifacts",
                ],
                "complexity": "high",
            },
            ShellMode.PLANETARY: {
                "mode": "planetary",
                "features": [
                    "federation_view",
                    "diplomacy_simulations",
                    "global_resource_flows",
                ],
                "complexity": "expert",
            },
        }
        
        return configs.get(self._current_shell, configs[ShellMode.CITIZEN])
    
    # =========================================================================
    # HELLO CIVILIZATION POC
    # =========================================================================
    
    def run_hello_civilization_poc(self) -> DecisionPackage:
        """
        Run the minimal "Hello Civilization" POC.
        
        Goal: Show a full loop end-to-end.
        1. Create WorldState with 5 slots
        2. Run causal rule set + 10-cycle feedback
        3. Visualize in XR/2D
        4. Require HITL approval
        5. Export signed report
        """
        # 1. Create WorldState
        worldstate = {
            "budget": 100000,
            "staff": 10,
            "energy": 500,
            "output": 0,
            "stability": 0.8,
        }
        
        # Start decision loop
        context = self.kernel.start_decision_loop(
            intent="Hello Civilization - Full Loop Demo"
        )
        
        # 2. Slot filling
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"slots": worldstate}
        )
        
        # 3. Causal model
        causal_dag = {
            "nodes": ["budget", "staff", "energy", "output", "stability"],
            "edges": [
                {"from": "budget", "to": "staff", "weight": 0.3},
                {"from": "staff", "to": "output", "weight": 0.5},
                {"from": "energy", "to": "output", "weight": 0.4},
                {"from": "output", "to": "stability", "weight": 0.6},
            ],
        }
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"dag": causal_dag}
        )
        
        # 4. World simulation (10 cycles)
        simulation = self.kernel.run_simulation(
            worldstate=worldstate,
            policies=["OPA_CIVIC_V1"],
            constraints={"max_cycles": 10},
        )
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"results": simulation}
        )
        
        # 5. XR visualization
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"scene_id": f"XR_HELLO_{context.context_id[:8]}"}
        )
        
        # 6. Governance check (requires HITL)
        approval = self.kernel.require_human_approval(
            impact_level="medium",
            context={"simulation": simulation},
        )
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"governance": {"opa_valid": True, "hitl_approved": True, "approval": approval}}
        )
        
        # 7. Artifact signing
        artifact = self.kernel.generate_artifact(
            trace=causal_dag,
            outputs=simulation,
        )
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"artifact": artifact}
        )
        
        # 8. Export
        context = self.kernel.advance_decision_loop(
            context.context_id,
            {"path": "/exports/hello_civilization.pdf"}
        )
        
        # Complete and return package
        return self.kernel.complete_decision_loop(context.context_id)
    
    # =========================================================================
    # GOVERNANCE CONTRACT
    # =========================================================================
    
    def get_governance_contract(self) -> dict[str, Any]:
        """
        The governance contract that Civilization OS guarantees.
        """
        return {
            "explainability": "All decisions can be traced and explained",
            "auditability": "Complete audit trail for all actions",
            "consent": "User consent required for data usage",
            "safety": "OPA governance prevents harmful actions",
            "non_coercion": "No manipulative or coercive patterns",
            "sovereignty": "Local nodes retain sovereignty",
        }
    
    def get_stats(self) -> dict[str, Any]:
        """Get OS statistics."""
        return {
            "os_id": self.os_id,
            "current_shell": self._current_shell.value,
            "kernel_stats": self.kernel.get_stats(),
        }
