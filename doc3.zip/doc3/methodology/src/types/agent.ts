export type AgentRequest = {
  input: string;
};

export type AgentResponse = {
  output: string;
  createdAt: number;
};
