# 🏗️ CHE·NU V71 — Architecture Document

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                      ARCHITECTURE TECHNIQUE COMPLÈTE                         ║
║                              CHE·NU™ V71                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Version:** 71.0.0  
**Date:** Janvier 2026  
**Status:** Production Ready

---

## 📋 Table des Matières

1. [Vue d'Ensemble](#1-vue-densemble)
2. [Principes Architecturaux](#2-principes-architecturaux)
3. [Couches du Système](#3-couches-du-système)
4. [Thread System V2](#4-thread-system-v2)
5. [Agent Architecture](#5-agent-architecture)
6. [Data Flow](#6-data-flow)
7. [Security Architecture](#7-security-architecture)
8. [Deployment Architecture](#8-deployment-architecture)

---

## 1. Vue d'Ensemble

### 1.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           PRESENTATION LAYER                                │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐         │
│  │   Web   │  │ Mobile  │  │ Desktop │  │   XR    │  │   CLI   │         │
│  │ (React) │  │ (Expo)  │  │ (Tauri) │  │ (Unity) │  │(Python) │         │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘         │
│       └────────────┴────────────┴────────────┴────────────┘               │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │ HTTPS/WSS
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                             API GATEWAY                                     │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │  FastAPI + Uvicorn                                                   │  │
│  │  • Rate Limiting  • Auth Middleware  • CORS  • Logging              │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │  Auth    │ │ Thread   │ │  Agent   │ │   XR     │ │   Nova   │       │
│  │ Routes   │ │ Routes   │ │ Routes   │ │ Routes   │ │ Routes   │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            SERVICE LAYER                                    │
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐  │
│  │                    THREAD SERVICE V2 (CORE)                          │  │
│  │  • Event Log (append-only)  • Memory Agent  • Permissions            │  │
│  │  • Snapshots  • Corrections  • Links  • XR Projection               │  │
│  └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ Identity │ │  Agent   │ │   Nova   │ │    XR    │ │ Knowledge│       │
│  │ Boundary │ │ Runtime  │ │ Pipeline │ │Generator │ │   Base   │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              DATA LAYER                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │PostgreSQL│ │  Redis   │ │ VectorDB │ │ S3/Minio │ │ EventStore│       │
│  │ (Primary)│ │ (Cache)  │ │(Semantic)│ │ (Files)  │ │ (Backup) │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Technology Stack

| Layer | Technology | Purpose |
|-------|------------|---------|
| Frontend Web | React 18 + TypeScript | Single Page Application |
| Frontend Mobile | Expo (React Native) | iOS/Android apps |
| Frontend Desktop | Tauri | Native desktop |
| Frontend XR | Unity + WebXR | Mixed reality |
| API Gateway | FastAPI + Uvicorn | REST + WebSocket |
| Backend | Python 3.11+ | Business logic |
| Primary DB | PostgreSQL 15+ | Events, threads |
| Cache | Redis 7+ | Session, XR cache |
| Vector DB | pgvector / Qdrant | Semantic search |
| File Storage | S3 / MinIO | Attachments |
| Message Queue | Redis Streams | Async tasks |

---

## 2. Principes Architecturaux

### 2.1 CQRS (Command Query Responsibility Segregation)

```
┌─────────────────────────────────────────────────────────────────┐
│                        CQRS PATTERN                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  COMMANDS (Write)                 QUERIES (Read)                │
│  ┌─────────────────┐             ┌─────────────────┐           │
│  │ post_message()  │             │ get_events()    │           │
│  │ record_decision│             │ get_thread()    │           │
│  │ create_action() │             │ get_xr_state()  │           │
│  └────────┬────────┘             └────────┬────────┘           │
│           │                               │                     │
│           ▼                               ▼                     │
│  ┌─────────────────┐             ┌─────────────────┐           │
│  │  EVENT STORE    │ ──────────▶ │   READ MODELS   │           │
│  │  (append-only)  │             │   (projections) │           │
│  └─────────────────┘             └─────────────────┘           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Event Sourcing

```python
# Tous les changements d'état sont des événements
class ThreadEvent:
    event_id: str           # Unique
    event_type: EventType   # MESSAGE_POSTED, DECISION_RECORDED, etc.
    thread_id: str          # Parent thread
    actor_id: str           # Who did it
    actor_type: ActorType   # HUMAN or AGENT
    payload: dict           # Event data
    created_at: datetime    # When
    integrity_hash: str     # Verification
```

### 2.3 Projection-Only Pattern

```
┌─────────────────────────────────────────────────────────────────┐
│                   PROJECTION-ONLY PATTERN                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  SOURCE OF TRUTH              PROJECTIONS (derived)             │
│  ┌─────────────┐              ┌─────────────┐                  │
│  │   THREAD    │ ──────────▶ │  XR Blueprint │                  │
│  │  (events)   │ ──────────▶ │  Chat View    │                  │
│  │             │ ──────────▶ │  Timeline     │                  │
│  │             │ ──────────▶ │  Analytics    │                  │
│  └─────────────┘              └─────────────┘                  │
│                                                                 │
│  RÈGLE: Les projections NE MODIFIENT JAMAIS la source          │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Couches du Système

### 3.1 Presentation Layer

```
frontend/
├── src/
│   ├── components/           # Composants réutilisables
│   │   ├── ui/              # Design system (UIKit V71)
│   │   ├── thread/          # Thread components
│   │   ├── agent/           # Agent components
│   │   └── xr/              # XR components
│   ├── pages/               # Pages/routes
│   ├── hooks/               # Custom React hooks
│   ├── services/            # API clients
│   ├── stores/              # State management (Zustand)
│   └── utils/               # Utilities
```

### 3.2 API Layer

```
backend/api/
├── routes/
│   ├── auth_routes.py       # Authentication
│   ├── thread_routes.py     # Thread CRUD
│   ├── agent_routes.py      # Agent management
│   ├── nova_routes.py       # Nova pipeline
│   └── xr_routes.py         # XR generation
├── middleware/
│   ├── auth_middleware.py   # JWT validation
│   ├── rate_limiter.py      # Rate limiting
│   └── logging_middleware.py # Request logging
└── schemas/
    ├── thread_schemas.py    # Pydantic models
    └── agent_schemas.py     # Agent schemas
```

### 3.3 Service Layer

```
backend/services/
├── thread_service_v2.py     # Core thread service
├── agent_runtime.py         # Agent execution
├── nova_pipeline.py         # Nova orchestration
├── xr_environment_generator.py # XR projection
├── identity_boundary.py     # Identity isolation
└── knowledge_base.py        # Semantic search
```

### 3.4 Data Layer

```
backend/models/
├── thread.py                # Thread model
├── event.py                 # Event model
├── user.py                  # User model
├── agent.py                 # Agent model
└── snapshot.py              # Snapshot model
```

---

## 4. Thread System V2

### 4.1 Event Log Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    THREAD EVENT LOG                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Event 1: THREAD_CREATED                                        │
│  ├── thread_id: "t_001"                                        │
│  ├── founding_intent: "Develop CHE·NU V71"                     │
│  ├── created_by: "user_001"                                    │
│  └── integrity_hash: "a1b2c3..."                               │
│                                                                 │
│  Event 2: MESSAGE_POSTED                                        │
│  ├── content: "Starting the project"                           │
│  ├── actor_id: "user_001"                                      │
│  └── integrity_hash: "d4e5f6..."                               │
│                                                                 │
│  Event 3: DECISION_RECORDED                                     │
│  ├── decision: "Use Python/FastAPI"                            │
│  ├── rationale: "Team expertise"                               │
│  └── integrity_hash: "g7h8i9..."                               │
│                                                                 │
│  ... (append-only, immutable)                                   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 4.2 Memory Agent Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    MEMORY AGENT                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  CONSTRAINTS:                                                   │
│  • Exactly ONE per thread                                       │
│  • NEVER always-on                                              │
│  • Limited to: SUMMARY_SNAPSHOT, CORRECTION_APPENDED           │
│                                                                 │
│  CAPABILITIES:                                                  │
│  • Generate periodic summaries                                  │
│  • Create corrections (append-only)                             │
│  • Derive onboarding briefs                                     │
│                                                                 │
│  ACTIVATION:                                                    │
│  • On-demand only                                               │
│  • Triggered by: snapshot request, correction request           │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 5. Agent Architecture

### 5.1 Agent Hierarchy

```
┌─────────────────────────────────────────────────────────────────┐
│                    AGENT HIERARCHY                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  NOVA (System Intelligence)                                     │
│  └── Purpose: Pipeline orchestration                            │
│  └── Scope: System-wide                                         │
│  └── Status: Always available (never hired)                     │
│                                                                 │
│  USER ORCHESTRATOR                                              │
│  └── Purpose: User's personal agent manager                     │
│  └── Scope: User-bound                                          │
│  └── Status: Hired by user                                      │
│                                                                 │
│  SPECIALIZED AGENTS                                             │
│  ├── Memory Agent (one per thread)                              │
│  ├── Task Agent (on-demand)                                     │
│  ├── Creative Agent (on-demand)                                 │
│  └── Analysis Agent (on-demand)                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 5.2 Nova Pipeline

```
┌─────────────────────────────────────────────────────────────────┐
│                    NOVA MULTI-LANE PIPELINE                     │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Lane A: INTENT ANALYSIS                                        │
│  └── Analyze user query intent                                  │
│                                                                 │
│  Lane B: CONTEXT SNAPSHOT                                       │
│  └── Create immutable context                                   │
│                                                                 │
│  Lane C: SEMANTIC ENCODING                                      │
│  └── Encode for retrieval                                       │
│                                                                 │
│  Lane D: GOVERNANCE CHECK                                       │
│  └── Verify rules and policies                                  │
│                                                                 │
│  Lane E: CHECKPOINT                                             │
│  └── Human approval gate (HTTP 423)                             │
│                                                                 │
│  Lane F: EXECUTION                                              │
│  └── Run agent task                                             │
│                                                                 │
│  Lane G: AUDIT                                                  │
│  └── Log everything                                             │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 6. Data Flow

### 6.1 Write Path

```
User Action
     │
     ▼
┌──────────────┐
│  API Route   │
└──────┬───────┘
       │
       ▼
┌──────────────┐     ┌──────────────┐
│   Service    │────▶│  Governance  │
└──────┬───────┘     └──────────────┘
       │
       ▼
┌──────────────┐
│ Event Store  │ (PostgreSQL)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Invalidate   │ (Redis Cache)
│    Cache     │
└──────────────┘
```

### 6.2 Read Path

```
User Query
     │
     ▼
┌──────────────┐
│  API Route   │
└──────┬───────┘
       │
       ▼
┌──────────────┐     ┌──────────────┐
│ Check Cache  │────▶│    Redis     │
└──────┬───────┘     └──────────────┘
       │ (miss)
       ▼
┌──────────────┐
│  Service     │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Event Store  │
└──────┬───────┘
       │
       ▼
┌──────────────┐
│  Projection  │ (Build view)
└──────┬───────┘
       │
       ▼
┌──────────────┐
│ Update Cache │
└──────────────┘
```

---

## 7. Security Architecture

### 7.1 Identity Boundary

```
┌─────────────────────────────────────────────────────────────────┐
│                    IDENTITY BOUNDARY                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  RULE: No cross-identity access without explicit permission     │
│                                                                 │
│  User A                         User B                          │
│  ┌─────────────┐               ┌─────────────┐                 │
│  │  Threads    │               │  Threads    │                 │
│  │  Agents     │ ──── ✖ ────── │  Agents     │                 │
│  │  Data       │               │  Data       │                 │
│  └─────────────┘               └─────────────┘                 │
│                                                                 │
│  Cross-access attempt → HTTP 403 Forbidden                     │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 Permission Model

```
┌─────────────────────────────────────────────────────────────────┐
│                    PERMISSION LEVELS                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  OWNER (Full control)                                           │
│  ├── Read all events                                            │
│  ├── Write any event type                                       │
│  ├── Manage participants                                        │
│  ├── Archive thread                                             │
│  └── Delete (archive, never hard delete)                        │
│                                                                 │
│  MEMBER (Collaborate)                                           │
│  ├── Read: PUBLIC + SEMI_PRIVATE                               │
│  ├── Write: MESSAGE, ACTION (own)                              │
│  └── No admin actions                                           │
│                                                                 │
│  VIEWER (Read-only)                                             │
│  ├── Read: PUBLIC only                                          │
│  ├── Write: None                                                │
│  └── PermissionError on any write                              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 8. Deployment Architecture

### 8.1 Production Topology

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRODUCTION TOPOLOGY                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                     LOAD BALANCER                        │   │
│  │                    (Nginx / HAProxy)                     │   │
│  └─────────────────────────┬───────────────────────────────┘   │
│                            │                                    │
│           ┌────────────────┼────────────────┐                  │
│           ▼                ▼                ▼                  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │  API Node 1 │  │  API Node 2 │  │  API Node 3 │            │
│  │  (FastAPI)  │  │  (FastAPI)  │  │  (FastAPI)  │            │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘            │
│         └────────────────┼────────────────┘                    │
│                          │                                      │
│           ┌──────────────┼──────────────┐                      │
│           ▼              ▼              ▼                      │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐              │
│  │ PostgreSQL  │ │   Redis     │ │  S3/MinIO   │              │
│  │  (Primary)  │ │  (Cluster)  │ │  (Storage)  │              │
│  └─────────────┘ └─────────────┘ └─────────────┘              │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 8.2 Container Architecture

```yaml
# docker-compose.prod.yml
services:
  api:
    image: chenu/api:v71
    replicas: 3
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]

  postgres:
    image: postgres:15
    volumes:
      - pgdata:/var/lib/postgresql/data

  redis:
    image: redis:7
    command: redis-server --appendonly yes

  frontend:
    image: chenu/frontend:v71
    depends_on:
      - api
```

---

## Annexes

### A. Event Types Reference

| Event Type | Payload | Actor |
|------------|---------|-------|
| THREAD_CREATED | founding_intent, title | SYSTEM |
| MESSAGE_POSTED | content | HUMAN, AGENT |
| DECISION_RECORDED | decision, rationale, options | HUMAN |
| ACTION_CREATED | action, assigned_to | HUMAN, AGENT |
| ACTION_UPDATED | action_id, status | HUMAN |
| LIVE_STARTED | session_id | HUMAN |
| LIVE_ENDED | session_id, duration | HUMAN, SYSTEM |
| SUMMARY_SNAPSHOT | content | MEMORY_AGENT |
| CORRECTION_APPENDED | correction, links | HUMAN, MEMORY_AGENT |
| LINK_ADDED | target_id, link_type | HUMAN |
| PERMISSION_CHANGED | user_id, role | OWNER |
| THREAD_ARCHIVED | reason | OWNER |

### B. API Response Codes

| Code | Meaning | Action |
|------|---------|--------|
| 200 | Success | - |
| 201 | Created | - |
| 400 | Bad Request | Fix request |
| 401 | Unauthorized | Login |
| 403 | Forbidden | Check permissions |
| 404 | Not Found | Check ID |
| 423 | Locked (Checkpoint) | Approve/Reject |
| 429 | Rate Limited | Wait |
| 500 | Server Error | Report bug |

---

**© 2025-2026 CHE·NU™**  
**Architecture Document V71**
