"""CHE·NU™ V69 — POC Module"""
from .poc import *
__version__ = "1.0.0"
