# 08_GRAPHS

## Files
- SYNAPTIC_GRAPH.mmd - Mermaid diagram
- SYNAPTIC_GRAPH.json - JSON representation
- MODULE_DEPENDENCIES.md - Dependencies map

## Implementation
backend/core/synaptic/synaptic_graph.py
