# CHE·NU™ API Contracts

This directory contains OpenAPI 3.1 specifications for all CHE·NU APIs.

## Contracts

| File | Description | Status |
|------|-------------|--------|
| `auth.yaml` | Authentication & authorization | ✅ Complete |
| `spheres.yaml` | Sphere & Bureau management | ✅ Complete |
| `threads.yaml` | Thread & Event management | ✅ Complete |
| `governance.yaml` | CEA, Orchestrator, Decision Points | 🔄 Planned |
| `agents.yaml` | Agent registry & execution | 🔄 Planned |
| `nova.yaml` | Nova pipeline & AI | 🔄 Planned |
| `xr.yaml` | XR rendering & maturity | 🔄 Planned |

## Usage

### For Backend (Python/FastAPI)
```python
# Routes are auto-documented via FastAPI
# Contracts serve as source of truth for AGENT-B (Frontend)
```

### For Frontend (TypeScript)
```bash
# Generate TypeScript types from OpenAPI
npx openapi-typescript ./shared/api-contracts/auth.yaml -o ./frontend/src/types/api/auth.ts
npx openapi-typescript ./shared/api-contracts/spheres.yaml -o ./frontend/src/types/api/spheres.ts
npx openapi-typescript ./shared/api-contracts/threads.yaml -o ./frontend/src/types/api/threads.ts
```

## Key Patterns

### Authentication
All endpoints except public ones require `Authorization: Bearer <token>` header.

### Identity Boundary (HTTP 403)
Resources are scoped to `identity_id`. Cross-identity access returns:
```json
{
  "error": "identity_boundary_violation",
  "message": "Access denied: resource belongs to different identity"
}
```

### Checkpoints (HTTP 423)
Sensitive operations return checkpoint requiring human approval:
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "governance",
    "reason": "Action requires approval",
    "options": ["approve", "reject"]
  }
}
```

### Append-Only Threads
Thread events are NEVER modified or deleted:
- No PUT on events
- No DELETE on events
- Corrections = new event referencing old one

## Versioning

All contracts are versioned in `info.version`.
Breaking changes require major version bump.
