# CHE·NU™ Error Codes Reference

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║                      CHE·NU™ — ERROR CODES & HANDLING                               ║
║                                                                                      ║
║                    Version: 2.0 | Date: January 2026 | Status: CANON               ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

## Overview

CHE·NU uses a comprehensive error handling system that provides:
- Consistent error response format
- Detailed error codes for debugging
- Governance-specific error types
- Actionable error messages

## Error Response Format

All errors follow this standard format:

```json
{
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message",
    "details": [
      {
        "field": "field_name",
        "message": "Field-specific error"
      }
    ],
    "trace_id": "uuid"
  },
  "request_id": "uuid",
  "timestamp": "2026-01-07T10:00:00Z"
}
```

## HTTP Status Codes

### Standard HTTP Codes

| Code | Name | Description |
|------|------|-------------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 204 | No Content | Request successful, no response body |
| 400 | Bad Request | Invalid input data |
| 401 | Unauthorized | Authentication required or failed |
| 403 | Forbidden | Access denied (identity boundary) |
| 404 | Not Found | Resource not found |
| 409 | Conflict | Resource conflict (duplicate) |
| 422 | Unprocessable Entity | Validation error |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server error |
| 503 | Service Unavailable | Service temporarily unavailable |

### CHE·NU Governance Code

| Code | Name | Description |
|------|------|-------------|
| **423** | **Locked** | **Checkpoint required - Human approval needed** |

This is CHE·NU's unique governance response. When returned, the client must:
1. Display checkpoint information to user
2. Wait for user to approve or reject
3. Call the appropriate endpoint to resolve checkpoint

## Error Codes by Category

### Authentication Errors (AUTH_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUTH_INVALID_CREDENTIALS` | 401 | Email or password incorrect |
| `AUTH_TOKEN_EXPIRED` | 401 | JWT token has expired |
| `AUTH_TOKEN_INVALID` | 401 | JWT token is malformed or invalid |
| `AUTH_TOKEN_REVOKED` | 401 | Token has been revoked (logout) |
| `AUTH_REFRESH_FAILED` | 401 | Refresh token invalid or expired |
| `AUTH_REQUIRED` | 401 | Authentication required for endpoint |
| `AUTH_PASSWORD_WEAK` | 400 | Password doesn't meet requirements |
| `AUTH_EMAIL_EXISTS` | 409 | Email already registered |
| `AUTH_ACCOUNT_DISABLED` | 403 | User account is disabled |
| `AUTH_SESSION_LIMIT` | 403 | Maximum concurrent sessions reached |

**Example:**
```json
{
  "error": {
    "code": "AUTH_TOKEN_EXPIRED",
    "message": "Your session has expired. Please log in again.",
    "details": [
      {
        "field": "token",
        "message": "Token expired at 2026-01-07T09:00:00Z"
      }
    ]
  }
}
```

### Identity Boundary Errors (IDENTITY_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `IDENTITY_BOUNDARY_VIOLATION` | 403 | Accessing resource owned by different identity |
| `IDENTITY_NOT_FOUND` | 404 | Referenced identity doesn't exist |
| `IDENTITY_PERMISSION_DENIED` | 403 | Insufficient permissions for action |
| `IDENTITY_CROSS_SPHERE_DENIED` | 403 | Cross-sphere access without workflow |

**Example:**
```json
{
  "error": {
    "code": "IDENTITY_BOUNDARY_VIOLATION",
    "message": "Access denied: resource belongs to different identity",
    "details": [
      {
        "field": "thread_id",
        "message": "Thread owned by different user"
      }
    ]
  },
  "requested_identity": "uuid_a",
  "resource_identity": "uuid_b"
}
```

### Governance Errors (GOV_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `GOV_CHECKPOINT_REQUIRED` | 423 | Action requires human approval |
| `GOV_CHECKPOINT_EXPIRED` | 410 | Checkpoint timed out |
| `GOV_CHECKPOINT_ALREADY_RESOLVED` | 409 | Checkpoint already approved/rejected |
| `GOV_CHECKPOINT_NOT_FOUND` | 404 | Checkpoint doesn't exist |
| `GOV_BUDGET_EXCEEDED` | 423 | Token/cost budget exceeded |
| `GOV_RATE_LIMIT_EXCEEDED` | 429 | Too many requests |
| `GOV_ACTION_DENIED` | 403 | Action not permitted by governance rules |
| `GOV_WORKFLOW_REQUIRED` | 423 | Explicit workflow required for action |

**Example (HTTP 423):**
```json
{
  "status": "checkpoint_pending",
  "checkpoint": {
    "id": "uuid",
    "type": "governance",
    "reason": "Agent execution requires human approval",
    "requires_approval": true,
    "options": ["approve", "reject"],
    "expires_at": "2026-01-07T11:00:00Z",
    "context": {
      "agent_id": "uuid",
      "agent_name": "Note Organizer",
      "action": "execute",
      "estimated_tokens": 150
    }
  }
}
```

### Thread Errors (THREAD_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `THREAD_NOT_FOUND` | 404 | Thread doesn't exist |
| `THREAD_ARCHIVED` | 409 | Cannot modify archived thread |
| `THREAD_INVALID_STATUS` | 400 | Invalid status transition |
| `THREAD_INVALID_TYPE` | 400 | Invalid thread type |
| `THREAD_INVALID_EVENT` | 400 | Invalid event type or data |
| `THREAD_INTENT_IMMUTABLE` | 409 | Cannot modify founding intent |
| `THREAD_ACCESS_DENIED` | 403 | No access to thread |
| `THREAD_PARENT_NOT_FOUND` | 404 | Parent thread doesn't exist |

**Example:**
```json
{
  "error": {
    "code": "THREAD_INTENT_IMMUTABLE",
    "message": "Founding intent cannot be modified. Use refine_intent to add refinements.",
    "details": [
      {
        "field": "founding_intent",
        "message": "This field is immutable after thread creation"
      }
    ]
  }
}
```

### Sphere Errors (SPHERE_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `SPHERE_NOT_FOUND` | 404 | Sphere doesn't exist |
| `SPHERE_INVALID_TYPE` | 400 | Invalid sphere type |
| `SPHERE_ACCESS_DENIED` | 403 | No access to sphere |
| `SPHERE_CROSS_ACCESS_DENIED` | 403 | Cross-sphere access not permitted |
| `SPHERE_SECTION_NOT_FOUND` | 404 | Bureau section not found |

**Example:**
```json
{
  "error": {
    "code": "SPHERE_CROSS_ACCESS_DENIED",
    "message": "Cross-sphere data transfer requires explicit workflow approval",
    "details": [
      {
        "field": "source_sphere",
        "message": "personal"
      },
      {
        "field": "target_sphere",
        "message": "business"
      }
    ]
  }
}
```

### Agent Errors (AGENT_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AGENT_NOT_FOUND` | 404 | Agent doesn't exist |
| `AGENT_DISABLED` | 403 | Agent is disabled |
| `AGENT_EXECUTION_FAILED` | 500 | Agent execution error |
| `AGENT_BUDGET_EXCEEDED` | 423 | Agent token budget exceeded |
| `AGENT_SCOPE_VIOLATION` | 403 | Action outside agent scope |
| `AGENT_APPROVAL_REQUIRED` | 423 | Agent execution needs approval |
| `AGENT_EXECUTION_CANCELLED` | 409 | Execution was cancelled |
| `AGENT_CONFIG_INVALID` | 400 | Invalid agent configuration |

**Example:**
```json
{
  "error": {
    "code": "AGENT_BUDGET_EXCEEDED",
    "message": "Agent token budget exceeded for today",
    "details": [
      {
        "field": "tokens_used",
        "message": "10500"
      },
      {
        "field": "daily_limit",
        "message": "10000"
      }
    ]
  }
}
```

### Nova Pipeline Errors (NOVA_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `NOVA_PROCESSING_ERROR` | 500 | Pipeline processing failed |
| `NOVA_INTENT_UNCLEAR` | 400 | Could not determine intent |
| `NOVA_CONTEXT_MISSING` | 400 | Required context not provided |
| `NOVA_EXECUTION_TIMEOUT` | 504 | Execution timed out |
| `NOVA_MODEL_ERROR` | 502 | LLM model error |
| `NOVA_BUDGET_EXCEEDED` | 423 | Request exceeds budget |

**Example:**
```json
{
  "error": {
    "code": "NOVA_BUDGET_EXCEEDED",
    "message": "Request exceeds daily token budget",
    "details": [
      {
        "field": "estimated_tokens",
        "message": "5000"
      },
      {
        "field": "budget_remaining",
        "message": "2000"
      }
    ]
  }
}
```

### XR Errors (XR_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `XR_THREAD_NOT_READY` | 400 | Thread not ready for XR view |
| `XR_TEMPLATE_NOT_FOUND` | 404 | XR template doesn't exist |
| `XR_BLUEPRINT_FAILED` | 500 | Blueprint generation failed |
| `XR_MATURITY_LOW` | 400 | Thread maturity too low for XR |
| `XR_PORTAL_DENIED` | 403 | No access to target thread |

**Example:**
```json
{
  "error": {
    "code": "XR_MATURITY_LOW",
    "message": "Thread maturity level too low for XR environment",
    "details": [
      {
        "field": "current_level",
        "message": "0 (SEED)"
      },
      {
        "field": "required_level",
        "message": "2 (SEEDLING)"
      }
    ]
  }
}
```

### Validation Errors (VALIDATION_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `VALIDATION_ERROR` | 422 | Input validation failed |
| `VALIDATION_REQUIRED_FIELD` | 422 | Required field missing |
| `VALIDATION_INVALID_FORMAT` | 422 | Field format invalid |
| `VALIDATION_INVALID_VALUE` | 422 | Field value not allowed |
| `VALIDATION_TOO_LONG` | 422 | Field exceeds max length |
| `VALIDATION_TOO_SHORT` | 422 | Field below min length |

**Example:**
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Input validation failed",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      },
      {
        "field": "password",
        "message": "Password must be at least 8 characters"
      }
    ]
  }
}
```

### Resource Errors (RESOURCE_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `RESOURCE_NOT_FOUND` | 404 | Resource doesn't exist |
| `RESOURCE_ALREADY_EXISTS` | 409 | Resource already exists |
| `RESOURCE_LOCKED` | 423 | Resource is locked |
| `RESOURCE_DELETED` | 410 | Resource was deleted |

### System Errors (SYSTEM_*)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `SYSTEM_ERROR` | 500 | Internal server error |
| `SYSTEM_DATABASE_ERROR` | 500 | Database operation failed |
| `SYSTEM_EXTERNAL_ERROR` | 502 | External service error |
| `SYSTEM_TIMEOUT` | 504 | Operation timed out |
| `SYSTEM_MAINTENANCE` | 503 | System under maintenance |
| `SYSTEM_RATE_LIMITED` | 429 | System rate limit exceeded |

**Example:**
```json
{
  "error": {
    "code": "SYSTEM_ERROR",
    "message": "An unexpected error occurred. Please try again later.",
    "trace_id": "abc123"
  }
}
```

## Client Error Handling

### TypeScript/JavaScript

```typescript
// Error types
interface ChenuError {
  code: string;
  message: string;
  details?: Array<{
    field: string;
    message: string;
  }>;
  trace_id?: string;
}

interface ChenuCheckpoint {
  id: string;
  type: 'governance' | 'cost' | 'identity' | 'sensitive';
  reason: string;
  requires_approval: boolean;
  options: string[];
  expires_at?: string;
  context?: Record<string, any>;
}

// Error handler
class ChenuApiError extends Error {
  constructor(
    public code: string,
    message: string,
    public details?: any[],
    public httpStatus?: number,
    public checkpoint?: ChenuCheckpoint
  ) {
    super(message);
    this.name = 'ChenuApiError';
  }
  
  isCheckpointRequired(): boolean {
    return this.httpStatus === 423;
  }
  
  isIdentityBoundary(): boolean {
    return this.httpStatus === 403 && this.code === 'IDENTITY_BOUNDARY_VIOLATION';
  }
  
  isAuthError(): boolean {
    return this.httpStatus === 401;
  }
  
  isValidationError(): boolean {
    return this.httpStatus === 422;
  }
}

// API client with error handling
async function apiRequest<T>(
  url: string,
  options: RequestInit
): Promise<T> {
  const response = await fetch(url, options);
  
  if (!response.ok) {
    const errorData = await response.json();
    
    // Handle checkpoint response
    if (response.status === 423) {
      throw new ChenuApiError(
        'GOV_CHECKPOINT_REQUIRED',
        errorData.checkpoint.reason,
        [],
        423,
        errorData.checkpoint
      );
    }
    
    // Handle other errors
    const error = errorData.error;
    throw new ChenuApiError(
      error.code,
      error.message,
      error.details,
      response.status
    );
  }
  
  return response.json();
}

// Usage with error handling
async function executeAgent(agentId: string, input: any) {
  try {
    const result = await apiRequest(`/api/v2/agents/${agentId}/execute`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ input }),
    });
    return result;
  } catch (error) {
    if (error instanceof ChenuApiError) {
      if (error.isCheckpointRequired()) {
        // Show checkpoint approval UI
        const approved = await showCheckpointDialog(error.checkpoint!);
        if (approved) {
          await approveCheckpoint(error.checkpoint!.id);
          // Retry execution
          return executeAgent(agentId, input);
        } else {
          await rejectCheckpoint(error.checkpoint!.id);
          throw new Error('Execution cancelled by user');
        }
      }
      
      if (error.isAuthError()) {
        // Redirect to login
        redirectToLogin();
      }
      
      if (error.isIdentityBoundary()) {
        // Show access denied message
        showErrorToast('You do not have access to this resource');
      }
      
      if (error.isValidationError()) {
        // Show field-level errors
        showValidationErrors(error.details);
      }
    }
    throw error;
  }
}
```

### React Error Boundary

```tsx
import React from 'react';

interface ErrorBoundaryState {
  hasError: boolean;
  error?: ChenuApiError;
}

class ChenuErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    if (error instanceof ChenuApiError) {
      return { hasError: true, error };
    }
    return { hasError: true };
  }
  
  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('CHE·NU Error:', error, errorInfo);
  }
  
  render() {
    if (this.state.hasError) {
      const { error } = this.state;
      
      if (error?.isCheckpointRequired()) {
        return <CheckpointDialog checkpoint={error.checkpoint!} />;
      }
      
      if (error?.isIdentityBoundary()) {
        return <AccessDeniedPage />;
      }
      
      return <GenericErrorPage error={error} />;
    }
    
    return this.props.children;
  }
}
```

### Python

```python
from dataclasses import dataclass
from typing import List, Optional, Dict, Any
import httpx

@dataclass
class ChenuErrorDetail:
    field: str
    message: str

@dataclass
class ChenuCheckpoint:
    id: str
    type: str
    reason: str
    requires_approval: bool
    options: List[str]
    expires_at: Optional[str] = None
    context: Optional[Dict[str, Any]] = None

class ChenuApiError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        http_status: int,
        details: Optional[List[ChenuErrorDetail]] = None,
        checkpoint: Optional[ChenuCheckpoint] = None
    ):
        super().__init__(message)
        self.code = code
        self.http_status = http_status
        self.details = details or []
        self.checkpoint = checkpoint
    
    @property
    def is_checkpoint_required(self) -> bool:
        return self.http_status == 423
    
    @property
    def is_identity_boundary(self) -> bool:
        return self.http_status == 403 and self.code == "IDENTITY_BOUNDARY_VIOLATION"
    
    @property
    def is_auth_error(self) -> bool:
        return self.http_status == 401
    
    @classmethod
    def from_response(cls, response: httpx.Response) -> "ChenuApiError":
        data = response.json()
        
        if response.status_code == 423:
            checkpoint_data = data.get("checkpoint", {})
            checkpoint = ChenuCheckpoint(
                id=checkpoint_data["id"],
                type=checkpoint_data["type"],
                reason=checkpoint_data["reason"],
                requires_approval=checkpoint_data.get("requires_approval", True),
                options=checkpoint_data.get("options", []),
                expires_at=checkpoint_data.get("expires_at"),
                context=checkpoint_data.get("context"),
            )
            return cls(
                code="GOV_CHECKPOINT_REQUIRED",
                message=checkpoint.reason,
                http_status=423,
                checkpoint=checkpoint,
            )
        
        error_data = data.get("error", {})
        details = [
            ChenuErrorDetail(field=d["field"], message=d["message"])
            for d in error_data.get("details", [])
        ]
        
        return cls(
            code=error_data.get("code", "UNKNOWN_ERROR"),
            message=error_data.get("message", "Unknown error"),
            http_status=response.status_code,
            details=details,
        )

# Usage
async def execute_agent(client: httpx.AsyncClient, agent_id: str, input_data: dict):
    response = await client.post(
        f"/api/v2/agents/{agent_id}/execute",
        json={"input": input_data},
    )
    
    if not response.is_success:
        error = ChenuApiError.from_response(response)
        
        if error.is_checkpoint_required:
            # Handle checkpoint
            checkpoint = error.checkpoint
            print(f"Approval required: {checkpoint.reason}")
            
            # In real app, prompt user for approval
            approved = await prompt_user_approval(checkpoint)
            if approved:
                await client.post(f"/api/v2/checkpoints/{checkpoint.id}/approve")
                # Retry
                return await execute_agent(client, agent_id, input_data)
            else:
                await client.post(f"/api/v2/checkpoints/{checkpoint.id}/reject")
                raise Exception("Execution cancelled")
        
        raise error
    
    return response.json()
```

## Best Practices

### 1. Always Handle Checkpoints (HTTP 423)

Checkpoints are core to CHE·NU's governance. Always:
- Display checkpoint reason to user
- Show approve/reject options
- Handle checkpoint timeout
- Retry or cancel gracefully

### 2. Check Identity Boundaries

When accessing shared resources:
- Verify ownership before operations
- Handle 403 responses gracefully
- Show appropriate access denied messages

### 3. Validate Before Submit

Use schema validation client-side to catch errors before:
- Reducing API calls
- Better user experience
- Faster feedback

### 4. Log Errors with Trace IDs

Always log the `trace_id` from error responses:
- Helps debugging
- Enables support requests
- Correlates with server logs

### 5. Implement Retry Logic

For transient errors (500, 502, 503, 504):
- Implement exponential backoff
- Set maximum retry count
- Show user feedback during retries

---

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║            "GOVERNANCE > EXECUTION • HUMANS > AUTOMATION"                           ║
║                                                                                      ║
║                     CHE·NU™ — Built for Decades                                     ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

---

**Version:** 2.0  
**Date:** January 2026  
**Status:** CANON  

© 2026 CHE·NU™ — All Rights Reserved
