"""
CHE·NU™ V70 — MEMORY & GOVERNANCE ENGINE
========================================
Safety core for memory operations and permissions.

Based on: MEMORY_GOVERNANCE_CHAPTER.md (Chapters 127-135)

The Memory & Governance Engine stands as CHE·NU's safety core—
the foundational system that controls all memory operations,
all permissions, all access patterns, and all agent actions.

THE TEN LAWS OF MEMORY:
1. No Hidden Memory
2. Explicit Storage Approval
3. Identity Scoping
4. No Cross-Identity Access
5. Reversibility
6. Operation Logging
7. No Self-Directed Agent Learning
8. Domain Awareness
9. DataSpace Foundation
10. User-Controlled Lifespan

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.memory_governance")


# =============================================================================
# ENUMS
# =============================================================================

class MemoryType(str, Enum):
    """Types of memory."""
    SHORT_TERM = "short_term"      # Session only
    MID_TERM = "mid_term"          # DataSpace/Thread
    LONG_TERM = "long_term"        # Explicit approval
    PINNED = "pinned"              # Protected
    ARCHIVED = "archived"          # Compressed


class MemoryLifespan(str, Enum):
    """Memory duration control."""
    SESSION = "session"            # Cleared on session end
    PERSISTENT = "persistent"      # Until deleted
    PINNED = "pinned"             # Protected from deletion
    ARCHIVED = "archived"         # Compressed storage
    EXPIRING = "expiring"         # Auto-delete after time


class PermissionLevel(str, Enum):
    """Permission levels."""
    NONE = "none"
    READ = "read"
    WRITE = "write"
    ADMIN = "admin"
    OWNER = "owner"


class GovernanceAction(str, Enum):
    """Actions requiring governance."""
    MEMORY_STORE = "memory_store"
    MEMORY_ACCESS = "memory_access"
    MEMORY_DELETE = "memory_delete"
    CROSS_IDENTITY = "cross_identity"
    AGENT_ACTION = "agent_action"
    DATA_EXPORT = "data_export"
    PERMISSION_CHANGE = "permission_change"


class AuditEventType(str, Enum):
    """Types of audit events."""
    MEMORY_CREATED = "memory_created"
    MEMORY_ACCESSED = "memory_accessed"
    MEMORY_MODIFIED = "memory_modified"
    MEMORY_DELETED = "memory_deleted"
    PERMISSION_GRANTED = "permission_granted"
    PERMISSION_REVOKED = "permission_revoked"
    AGENT_ACTION = "agent_action"
    GOVERNANCE_VIOLATION = "governance_violation"


# =============================================================================
# MEMORY MODELS
# =============================================================================

@dataclass
class MemoryEntry:
    """Individual memory entry."""
    memory_id: str = field(default_factory=lambda: f"MEM_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    key: str = ""
    value: Any = None
    content_type: str = "text"
    
    # Classification
    memory_type: MemoryType = MemoryType.SHORT_TERM
    lifespan: MemoryLifespan = MemoryLifespan.SESSION
    
    # Scoping (Law 3 & 4)
    identity_id: str = ""
    sphere: str = ""
    domain: str = ""
    dataspace_id: Optional[str] = None
    
    # Approval (Law 2)
    user_approved: bool = False
    approval_timestamp: Optional[datetime] = None
    
    # Visibility (Law 1)
    visible_to_user: bool = True  # ALWAYS TRUE
    
    # Reversibility (Law 5)
    can_be_deleted: bool = True
    
    # Expiry
    expires_at: Optional[datetime] = None
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    source: str = ""  # Where this memory came from
    
    # Governance
    synthetic: bool = True


@dataclass
class MemoryOperation:
    """Record of a memory operation (Law 6)."""
    operation_id: str = field(default_factory=lambda: f"MEMOP_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # What
    action: str = ""  # create, read, update, delete
    memory_id: str = ""
    
    # Who
    actor_id: str = ""
    actor_type: str = "user"  # user, agent, system
    
    # Context
    identity_id: str = ""
    session_id: Optional[str] = None
    
    # Result
    success: bool = True
    error: Optional[str] = None


# =============================================================================
# PERMISSION MODELS
# =============================================================================

@dataclass
class Permission:
    """Permission entry."""
    permission_id: str = field(default_factory=lambda: f"PERM_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Subject
    subject_id: str = ""
    subject_type: str = "user"  # user, agent, role
    
    # Resource
    resource_type: str = ""  # memory, dataspace, meeting, etc.
    resource_id: Optional[str] = None  # Specific or all
    
    # Level
    level: PermissionLevel = PermissionLevel.NONE
    
    # Scope
    identity_id: str = ""
    sphere: Optional[str] = None
    domain: Optional[str] = None
    
    # Validity
    valid_from: datetime = field(default_factory=datetime.utcnow)
    valid_until: Optional[datetime] = None
    
    # Granted by
    granted_by: str = ""


@dataclass
class IdentityBoundary:
    """Identity boundary definition (Law 4)."""
    identity_id: str = ""
    
    # Spheres belonging to this identity
    spheres: List[str] = field(default_factory=list)
    
    # Domains within spheres
    domains: Dict[str, List[str]] = field(default_factory=dict)
    
    # Cannot access
    blocked_identities: Set[str] = field(default_factory=set)


# =============================================================================
# AUDIT MODELS
# =============================================================================

@dataclass
class AuditEntry:
    """Audit log entry (Law 6)."""
    audit_id: str = field(default_factory=lambda: f"AUDIT_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Event
    event_type: AuditEventType
    description: str = ""
    
    # Actor
    actor_id: str = ""
    actor_type: str = "user"
    
    # Target
    target_type: str = ""
    target_id: str = ""
    
    # Context
    identity_id: str = ""
    session_id: Optional[str] = None
    
    # Details
    details: Dict[str, Any] = field(default_factory=dict)
    
    # Governance
    governance_action: Optional[GovernanceAction] = None
    governance_result: str = "allowed"  # allowed, denied, flagged


# =============================================================================
# GOVERNANCE ENGINE
# =============================================================================

class MemoryGovernanceEngine:
    """
    CHE·NU Memory & Governance Engine.
    
    Enforces the Ten Laws of Memory and controls all
    permissions and access patterns.
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        # Memory storage by identity
        self._memories: Dict[str, Dict[str, MemoryEntry]] = {}
        
        # Operations log (Law 6)
        self._operations: List[MemoryOperation] = []
        
        # Permissions
        self._permissions: Dict[str, Permission] = {}
        
        # Identity boundaries (Law 4)
        self._boundaries: Dict[str, IdentityBoundary] = {}
        
        # Audit log
        self._audit: List[AuditEntry] = []
        
        logger.info("MemoryGovernanceEngine initialized with Ten Laws enforced")
    
    # =========================================================================
    # LAW 1: NO HIDDEN MEMORY
    # =========================================================================
    
    def list_all_memory(self, identity_id: str) -> List[MemoryEntry]:
        """
        List ALL memory for an identity.
        
        Law 1: Every piece of stored information is visible to the user.
        """
        if identity_id not in self._memories:
            return []
        
        memories = list(self._memories[identity_id].values())
        
        # Log access
        self._log_operation("list", "", identity_id, "user")
        
        return memories
    
    # =========================================================================
    # LAW 2: EXPLICIT STORAGE APPROVAL
    # =========================================================================
    
    def store_memory(
        self,
        identity_id: str,
        key: str,
        value: Any,
        memory_type: MemoryType = MemoryType.SHORT_TERM,
        user_approved: bool = False,
        sphere: str = "",
        domain: str = "",
        dataspace_id: Optional[str] = None,
    ) -> Optional[MemoryEntry]:
        """
        Store memory with explicit approval requirement.
        
        Law 2: Nothing enters long-term storage without explicit user approval.
        """
        # For long-term, require approval
        if memory_type == MemoryType.LONG_TERM and not user_approved:
            self._log_audit(
                AuditEventType.GOVERNANCE_VIOLATION,
                "Long-term memory requires explicit approval",
                identity_id=identity_id,
                governance_action=GovernanceAction.MEMORY_STORE,
                governance_result="denied",
            )
            logger.warning(f"Denied long-term memory without approval for {identity_id}")
            return None
        
        # Create entry
        entry = MemoryEntry(
            key=key,
            value=value,
            memory_type=memory_type,
            identity_id=identity_id,
            sphere=sphere,
            domain=domain,
            dataspace_id=dataspace_id,
            user_approved=user_approved,
            approval_timestamp=datetime.utcnow() if user_approved else None,
            visible_to_user=True,  # Law 1: Always visible
            lifespan=self._determine_lifespan(memory_type),
            synthetic=True,
        )
        
        # Store
        if identity_id not in self._memories:
            self._memories[identity_id] = {}
        self._memories[identity_id][entry.memory_id] = entry
        
        # Log
        self._log_operation("create", entry.memory_id, identity_id, "user")
        self._log_audit(
            AuditEventType.MEMORY_CREATED,
            f"Memory stored: {key}",
            identity_id=identity_id,
            target_type="memory",
            target_id=entry.memory_id,
        )
        
        logger.debug(f"Stored memory {entry.memory_id} for identity {identity_id}")
        
        return entry
    
    def _determine_lifespan(self, memory_type: MemoryType) -> MemoryLifespan:
        """Determine lifespan based on type."""
        mapping = {
            MemoryType.SHORT_TERM: MemoryLifespan.SESSION,
            MemoryType.MID_TERM: MemoryLifespan.PERSISTENT,
            MemoryType.LONG_TERM: MemoryLifespan.PERSISTENT,
            MemoryType.PINNED: MemoryLifespan.PINNED,
            MemoryType.ARCHIVED: MemoryLifespan.ARCHIVED,
        }
        return mapping.get(memory_type, MemoryLifespan.SESSION)
    
    # =========================================================================
    # LAW 3 & 4: IDENTITY SCOPING & NO CROSS-IDENTITY ACCESS
    # =========================================================================
    
    def access_memory(
        self,
        identity_id: str,
        memory_id: str,
        accessor_identity: str,
    ) -> Optional[MemoryEntry]:
        """
        Access memory with identity boundary enforcement.
        
        Law 3: All memory is bound to a specific identity.
        Law 4: Memory from one identity cannot be accessed from another.
        """
        # CRITICAL: Enforce identity boundary
        if accessor_identity != identity_id:
            self._log_audit(
                AuditEventType.GOVERNANCE_VIOLATION,
                f"Cross-identity access denied: {accessor_identity} -> {identity_id}",
                identity_id=accessor_identity,
                governance_action=GovernanceAction.CROSS_IDENTITY,
                governance_result="denied",
            )
            logger.warning(
                f"BLOCKED cross-identity access: {accessor_identity} tried to access {identity_id}"
            )
            return None
        
        # Get memory
        if identity_id not in self._memories:
            return None
        
        entry = self._memories[identity_id].get(memory_id)
        
        if entry:
            self._log_operation("read", memory_id, identity_id, "user")
            self._log_audit(
                AuditEventType.MEMORY_ACCESSED,
                f"Memory accessed: {entry.key}",
                identity_id=identity_id,
                target_type="memory",
                target_id=memory_id,
            )
        
        return entry
    
    def set_identity_boundary(
        self,
        identity_id: str,
        spheres: List[str],
    ) -> IdentityBoundary:
        """Set identity boundary."""
        boundary = IdentityBoundary(
            identity_id=identity_id,
            spheres=spheres,
        )
        self._boundaries[identity_id] = boundary
        return boundary
    
    # =========================================================================
    # LAW 5: REVERSIBILITY
    # =========================================================================
    
    def delete_memory(
        self,
        identity_id: str,
        memory_id: str,
        requestor_identity: str,
    ) -> bool:
        """
        Delete memory - truly forget.
        
        Law 5: All memory operations can be undone.
        """
        # Verify identity
        if requestor_identity != identity_id:
            self._log_audit(
                AuditEventType.GOVERNANCE_VIOLATION,
                "Cross-identity delete denied",
                identity_id=requestor_identity,
                governance_action=GovernanceAction.MEMORY_DELETE,
                governance_result="denied",
            )
            return False
        
        if identity_id not in self._memories:
            return False
        
        if memory_id not in self._memories[identity_id]:
            return False
        
        entry = self._memories[identity_id][memory_id]
        
        # Check if pinned
        if entry.lifespan == MemoryLifespan.PINNED:
            logger.info(f"Memory {memory_id} is pinned - requires unpin first")
            return False
        
        # DELETE - truly forget
        del self._memories[identity_id][memory_id]
        
        # Log
        self._log_operation("delete", memory_id, identity_id, "user")
        self._log_audit(
            AuditEventType.MEMORY_DELETED,
            f"Memory permanently deleted: {entry.key}",
            identity_id=identity_id,
            target_type="memory",
            target_id=memory_id,
        )
        
        logger.info(f"Permanently deleted memory {memory_id}")
        
        return True
    
    def delete_all_identity_memory(
        self,
        identity_id: str,
        requestor_identity: str,
    ) -> int:
        """Delete ALL memory for an identity (full forget)."""
        if requestor_identity != identity_id:
            return 0
        
        if identity_id not in self._memories:
            return 0
        
        count = len(self._memories[identity_id])
        self._memories[identity_id] = {}
        
        self._log_audit(
            AuditEventType.MEMORY_DELETED,
            f"All memory deleted for identity: {count} entries",
            identity_id=identity_id,
        )
        
        return count
    
    # =========================================================================
    # LAW 6: OPERATION LOGGING
    # =========================================================================
    
    def _log_operation(
        self,
        action: str,
        memory_id: str,
        identity_id: str,
        actor_type: str,
    ):
        """Log memory operation."""
        op = MemoryOperation(
            action=action,
            memory_id=memory_id,
            identity_id=identity_id,
            actor_type=actor_type,
        )
        self._operations.append(op)
    
    def _log_audit(
        self,
        event_type: AuditEventType,
        description: str,
        identity_id: str = "",
        target_type: str = "",
        target_id: str = "",
        governance_action: Optional[GovernanceAction] = None,
        governance_result: str = "allowed",
    ):
        """Log audit entry."""
        entry = AuditEntry(
            event_type=event_type,
            description=description,
            identity_id=identity_id,
            target_type=target_type,
            target_id=target_id,
            governance_action=governance_action,
            governance_result=governance_result,
        )
        self._audit.append(entry)
    
    def get_audit_log(
        self,
        identity_id: str,
        limit: int = 100,
    ) -> List[AuditEntry]:
        """Get audit log for identity (Law 6: viewable)."""
        return [
            e for e in self._audit
            if e.identity_id == identity_id
        ][-limit:]
    
    # =========================================================================
    # LAW 7: NO SELF-DIRECTED AGENT LEARNING
    # =========================================================================
    
    def agent_access_memory(
        self,
        agent_id: str,
        identity_id: str,
        memory_id: str,
        purpose: str,
    ) -> Optional[MemoryEntry]:
        """
        Agent memory access - READ ONLY, no autonomous behavior.
        
        Law 7: Agents cannot use stored memory for self-directed actions.
        """
        # Log agent access with purpose
        self._log_audit(
            AuditEventType.AGENT_ACTION,
            f"Agent {agent_id} accessed memory for: {purpose}",
            identity_id=identity_id,
            target_type="memory",
            target_id=memory_id,
            governance_action=GovernanceAction.AGENT_ACTION,
        )
        
        # Agent gets read-only copy
        if identity_id in self._memories and memory_id in self._memories[identity_id]:
            entry = self._memories[identity_id][memory_id]
            # Return copy, not reference
            return MemoryEntry(
                memory_id=entry.memory_id,
                key=entry.key,
                value=entry.value,  # Value only, no write capability
                visible_to_user=True,
                synthetic=True,
            )
        
        return None
    
    # =========================================================================
    # LAW 8: DOMAIN AWARENESS
    # =========================================================================
    
    def get_memory_by_domain(
        self,
        identity_id: str,
        domain: str,
    ) -> List[MemoryEntry]:
        """Get memory organized by domain (Law 8)."""
        if identity_id not in self._memories:
            return []
        
        return [
            m for m in self._memories[identity_id].values()
            if m.domain == domain
        ]
    
    def get_memory_by_sphere(
        self,
        identity_id: str,
        sphere: str,
    ) -> List[MemoryEntry]:
        """Get memory organized by sphere."""
        if identity_id not in self._memories:
            return []
        
        return [
            m for m in self._memories[identity_id].values()
            if m.sphere == sphere
        ]
    
    # =========================================================================
    # LAW 9: DATASPACE FOUNDATION
    # =========================================================================
    
    def get_dataspace_memory(
        self,
        identity_id: str,
        dataspace_id: str,
    ) -> List[MemoryEntry]:
        """Get memory for a DataSpace (Law 9)."""
        if identity_id not in self._memories:
            return []
        
        return [
            m for m in self._memories[identity_id].values()
            if m.dataspace_id == dataspace_id
        ]
    
    # =========================================================================
    # LAW 10: USER-CONTROLLED LIFESPAN
    # =========================================================================
    
    def set_memory_lifespan(
        self,
        identity_id: str,
        memory_id: str,
        lifespan: MemoryLifespan,
        expires_at: Optional[datetime] = None,
    ) -> bool:
        """Set memory lifespan (Law 10: user control)."""
        if identity_id not in self._memories:
            return False
        
        if memory_id not in self._memories[identity_id]:
            return False
        
        entry = self._memories[identity_id][memory_id]
        entry.lifespan = lifespan
        entry.expires_at = expires_at
        entry.updated_at = datetime.utcnow()
        
        self._log_audit(
            AuditEventType.MEMORY_MODIFIED,
            f"Lifespan changed to {lifespan.value}",
            identity_id=identity_id,
            target_type="memory",
            target_id=memory_id,
        )
        
        return True
    
    def pin_memory(self, identity_id: str, memory_id: str) -> bool:
        """Pin memory (protected from deletion)."""
        return self.set_memory_lifespan(identity_id, memory_id, MemoryLifespan.PINNED)
    
    def unpin_memory(self, identity_id: str, memory_id: str) -> bool:
        """Unpin memory."""
        return self.set_memory_lifespan(identity_id, memory_id, MemoryLifespan.PERSISTENT)
    
    def cleanup_expired(self) -> int:
        """Clean up expired memories."""
        now = datetime.utcnow()
        count = 0
        
        for identity_id, memories in self._memories.items():
            expired_ids = [
                mid for mid, m in memories.items()
                if m.expires_at and m.expires_at < now
            ]
            for mid in expired_ids:
                del memories[mid]
                count += 1
        
        if count > 0:
            logger.info(f"Cleaned up {count} expired memories")
        
        return count
    
    # =========================================================================
    # PERMISSIONS
    # =========================================================================
    
    def grant_permission(
        self,
        subject_id: str,
        resource_type: str,
        level: PermissionLevel,
        identity_id: str,
        granted_by: str,
        resource_id: Optional[str] = None,
    ) -> Permission:
        """Grant permission."""
        perm = Permission(
            subject_id=subject_id,
            subject_type="user",
            resource_type=resource_type,
            resource_id=resource_id,
            level=level,
            identity_id=identity_id,
            granted_by=granted_by,
        )
        
        self._permissions[perm.permission_id] = perm
        
        self._log_audit(
            AuditEventType.PERMISSION_GRANTED,
            f"Permission {level.value} granted to {subject_id}",
            identity_id=identity_id,
            target_type=resource_type,
            target_id=resource_id or "all",
        )
        
        return perm
    
    def check_permission(
        self,
        subject_id: str,
        resource_type: str,
        required_level: PermissionLevel,
        identity_id: str,
        resource_id: Optional[str] = None,
    ) -> bool:
        """Check if subject has required permission."""
        level_order = [
            PermissionLevel.NONE,
            PermissionLevel.READ,
            PermissionLevel.WRITE,
            PermissionLevel.ADMIN,
            PermissionLevel.OWNER,
        ]
        
        for perm in self._permissions.values():
            if (perm.subject_id == subject_id and
                perm.resource_type == resource_type and
                perm.identity_id == identity_id):
                
                # Check specific resource or all
                if perm.resource_id and perm.resource_id != resource_id:
                    continue
                
                # Check level
                if level_order.index(perm.level) >= level_order.index(required_level):
                    return True
        
        return False
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get governance statistics."""
        total_memories = sum(len(m) for m in self._memories.values())
        
        return {
            "total_memories": total_memories,
            "identities": len(self._memories),
            "operations_logged": len(self._operations),
            "audit_entries": len(self._audit),
            "permissions": len(self._permissions),
            "ten_laws_enforced": True,
            "governance": {
                "no_hidden_memory": True,
                "explicit_approval": True,
                "identity_scoping": True,
                "no_cross_identity": True,
                "reversibility": True,
                "operation_logging": True,
                "no_agent_self_learning": True,
                "domain_awareness": True,
                "dataspace_foundation": True,
                "user_controlled_lifespan": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_memory_governance_engine: Optional[MemoryGovernanceEngine] = None


def get_memory_governance_engine() -> MemoryGovernanceEngine:
    """Get the memory governance engine singleton."""
    global _memory_governance_engine
    if _memory_governance_engine is None:
        _memory_governance_engine = MemoryGovernanceEngine()
    return _memory_governance_engine
