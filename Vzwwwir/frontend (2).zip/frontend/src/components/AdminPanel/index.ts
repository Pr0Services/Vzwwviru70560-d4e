/**
 * CHE·NU V51 — ADMIN PANEL COMPONENTS
 * ====================================
 */

export { default as AdminPanelPage } from './AdminPanelPage';
export type { AdminPanelPageProps } from './AdminPanelPage';
