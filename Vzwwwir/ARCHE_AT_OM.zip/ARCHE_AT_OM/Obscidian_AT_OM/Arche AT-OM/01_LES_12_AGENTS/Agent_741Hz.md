# Agent 741Hz — Nettoyage

**Mission:** Dédupliquer, archiver, assainir.

**Outputs:** 1–3 décisions actionnables + 1 garde-fou + 1 prochain pas.
