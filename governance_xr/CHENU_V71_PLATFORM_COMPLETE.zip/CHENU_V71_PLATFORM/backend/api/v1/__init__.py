"""
CHE·NU™ V70 — API PACKAGE
=========================
Complete REST API based on CHENU_API_SPECS_v29.md

Base URL: https://api.che-nu.com/v1

GOUVERNANCE > EXÉCUTION
"""

from .main import app, create_app, GOVERNANCE_SUMMARY
from .routers import (
    identity_router,
    dataspace_router,
    thread_router,
    workspace_router,
    oneclick_router,
    backstage_router,
    memory_router,
    governance_router,
    agent_router,
    meeting_router,
    immobilier_router,
    APIResponse,
)

__all__ = [
    "app",
    "create_app",
    "GOVERNANCE_SUMMARY",
    "identity_router",
    "dataspace_router",
    "thread_router",
    "workspace_router",
    "oneclick_router",
    "backstage_router",
    "memory_router",
    "governance_router",
    "agent_router",
    "meeting_router",
    "immobilier_router",
    "APIResponse",
]

__version__ = "70.0.0"
