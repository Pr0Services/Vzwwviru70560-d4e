-- ============================================================================
-- CHE·NU™ V70 — GP2 DATABASE SCHEMAS
-- ============================================================================
-- GOUVERNANCE > EXÉCUTION
-- All tables include audit columns and governance flags
-- ============================================================================

-- ============================================================================
-- CORE GOVERNANCE TABLES
-- ============================================================================

-- Audit log for all GP2 operations
CREATE TABLE IF NOT EXISTS gp2_audit_log (
    id BIGSERIAL PRIMARY KEY,
    audit_id VARCHAR(32) NOT NULL UNIQUE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Action details
    module VARCHAR(64) NOT NULL,
    action VARCHAR(128) NOT NULL,
    actor_id VARCHAR(64),
    actor_type VARCHAR(32) DEFAULT 'user',
    
    -- Context
    request_id VARCHAR(32),
    session_id VARCHAR(64),
    
    -- Governance
    opa_validated BOOLEAN DEFAULT FALSE,
    hitl_approved BOOLEAN,
    synthetic_only BOOLEAN DEFAULT TRUE,
    
    -- Details
    input_data JSONB,
    output_data JSONB,
    violations JSONB,
    
    -- Indexing
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_timestamp ON gp2_audit_log(timestamp DESC);
CREATE INDEX idx_audit_module ON gp2_audit_log(module);
CREATE INDEX idx_audit_actor ON gp2_audit_log(actor_id);

-- OPA decision cache
CREATE TABLE IF NOT EXISTS gp2_opa_decisions (
    id BIGSERIAL PRIMARY KEY,
    decision_id VARCHAR(32) NOT NULL UNIQUE,
    timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Decision
    policy_path VARCHAR(256) NOT NULL,
    input_hash VARCHAR(64) NOT NULL,
    decision BOOLEAN NOT NULL,
    
    -- Details
    input_data JSONB,
    output_data JSONB,
    
    -- Cache
    expires_at TIMESTAMPTZ
);

CREATE INDEX idx_opa_policy ON gp2_opa_decisions(policy_path);
CREATE INDEX idx_opa_hash ON gp2_opa_decisions(input_hash);

-- ============================================================================
-- NOVA KERNEL TABLES
-- ============================================================================

-- NOVA requests
CREATE TABLE IF NOT EXISTS nova_requests (
    id BIGSERIAL PRIMARY KEY,
    request_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Request
    intent TEXT NOT NULL,
    context JSONB DEFAULT '{}',
    user_id VARCHAR(64),
    
    -- Processing
    processed BOOLEAN DEFAULT FALSE,
    processing_started_at TIMESTAMPTZ,
    processing_completed_at TIMESTAMPTZ,
    
    -- Result
    is_refusal BOOLEAN DEFAULT FALSE,
    refusal_reason TEXT,
    response JSONB,
    
    -- Governance
    opa_validated BOOLEAN DEFAULT FALSE,
    forbidden_action_detected BOOLEAN DEFAULT FALSE,
    
    -- Audit
    audit_trail JSONB DEFAULT '[]'
);

CREATE INDEX idx_nova_user ON nova_requests(user_id);
CREATE INDEX idx_nova_created ON nova_requests(created_at DESC);

-- ============================================================================
-- ETHICS CANON TABLES
-- ============================================================================

-- Ethics validations
CREATE TABLE IF NOT EXISTS ethics_validations (
    id BIGSERIAL PRIMARY KEY,
    validation_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Validation
    action_description TEXT NOT NULL,
    actor_type VARCHAR(32) DEFAULT 'system_intelligence',
    
    -- Result
    is_valid BOOLEAN NOT NULL,
    violations JSONB DEFAULT '[]',
    forbidden_state VARCHAR(64),
    
    -- Canon
    rules_checked JSONB DEFAULT '[]',
    canon_version VARCHAR(16) DEFAULT '70.0.0',
    
    -- Governance
    immutable BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_ethics_valid ON ethics_validations(is_valid);
CREATE INDEX idx_ethics_created ON ethics_validations(created_at DESC);

-- ============================================================================
-- CIVILIZATION OS TABLES
-- ============================================================================

-- Decision packages
CREATE TABLE IF NOT EXISTS civilization_decision_packages (
    id BIGSERIAL PRIMARY KEY,
    package_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Content
    title VARCHAR(256),
    summary TEXT,
    user_intent TEXT NOT NULL,
    
    -- Linked artifacts
    worldstate_id VARCHAR(32),
    simulation_id VARCHAR(32),
    causal_trace_id VARCHAR(32),
    xr_scene_id VARCHAR(32),
    
    -- Options
    options JSONB DEFAULT '[]',
    recommended_option INTEGER,
    risk_assessment JSONB DEFAULT '{}',
    
    -- Governance
    opa_validated BOOLEAN DEFAULT FALSE,
    hitl_required BOOLEAN DEFAULT TRUE,
    hitl_approved BOOLEAN DEFAULT FALSE,
    approved_by VARCHAR(64),
    approved_at TIMESTAMPTZ,
    
    -- Export
    exported BOOLEAN DEFAULT FALSE,
    export_format VARCHAR(32),
    exported_at TIMESTAMPTZ,
    
    -- Signatures
    signatures JSONB DEFAULT '[]'
);

CREATE INDEX idx_decision_hitl ON civilization_decision_packages(hitl_approved);
CREATE INDEX idx_decision_created ON civilization_decision_packages(created_at DESC);

-- ============================================================================
-- TRANSMISSION ENGINE TABLES (Module 26)
-- ============================================================================

-- Skill traces
CREATE TABLE IF NOT EXISTS transmission_skill_traces (
    id BIGSERIAL PRIMARY KEY,
    trace_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Skill
    skill_name VARCHAR(256) NOT NULL,
    skill_domain VARCHAR(128),
    
    -- Participants
    learner_id VARCHAR(64) NOT NULL,
    mentor_id VARCHAR(64),
    
    -- Metrics
    trust_score DECIMAL(3,2) DEFAULT 0.0,
    generation_score DECIMAL(3,2) DEFAULT 0.0,
    
    -- Status
    is_transmitted BOOLEAN DEFAULT FALSE,
    transmitted_at TIMESTAMPTZ,
    
    -- Verification
    worldengine_verified BOOLEAN DEFAULT FALSE,
    signatures JSONB DEFAULT '[]'
);

CREATE INDEX idx_skill_learner ON transmission_skill_traces(learner_id);
CREATE INDEX idx_skill_mentor ON transmission_skill_traces(mentor_id);

-- Transmission seeds
CREATE TABLE IF NOT EXISTS transmission_seeds (
    id BIGSERIAL PRIMARY KEY,
    seed_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Content
    title VARCHAR(256) NOT NULL,
    content JSONB NOT NULL,
    skill_domain VARCHAR(128),
    
    -- Verification
    opa_validated BOOLEAN DEFAULT FALSE,
    signatures JSONB DEFAULT '[]'
);

-- ============================================================================
-- HERITAGE & IDENTITY TABLES (Module 27)
-- ============================================================================

-- Identity graphs
CREATE TABLE IF NOT EXISTS heritage_identity_graphs (
    id BIGSERIAL PRIMARY KEY,
    graph_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Entity
    entity_id VARCHAR(64) NOT NULL,
    entity_type VARCHAR(32) NOT NULL,
    
    -- Content
    values JSONB DEFAULT '[]',
    principles JSONB DEFAULT '[]',
    historical_depth INTEGER DEFAULT 0,
    cultural_markers JSONB DEFAULT '[]',
    
    -- Score
    heritage_score DECIMAL(3,2) DEFAULT 0.0
);

CREATE INDEX idx_heritage_entity ON heritage_identity_graphs(entity_id);

-- Digital monuments
CREATE TABLE IF NOT EXISTS heritage_digital_monuments (
    id BIGSERIAL PRIMARY KEY,
    monument_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Content
    title VARCHAR(256) NOT NULL,
    description TEXT,
    founding_moment_date DATE,
    
    -- Links
    community_id VARCHAR(64),
    xr_scene_id VARCHAR(32),
    
    -- Verification
    signatures JSONB DEFAULT '[]'
);

-- ============================================================================
-- CULTURE & MYTH TABLES (Module 28)
-- ============================================================================

-- Culture profiles
CREATE TABLE IF NOT EXISTS culture_profiles (
    id BIGSERIAL PRIMARY KEY,
    profile_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Entity
    community_id VARCHAR(64) NOT NULL,
    
    -- Content
    values JSONB DEFAULT '[]',
    taboos JSONB DEFAULT '[]',
    rituals JSONB DEFAULT '[]',
    symbols JSONB DEFAULT '[]',
    
    -- Consent
    opt_in_consent BOOLEAN NOT NULL DEFAULT FALSE,
    consent_timestamp TIMESTAMPTZ,
    
    -- Governance
    opa_validated BOOLEAN DEFAULT FALSE
);

CREATE INDEX idx_culture_community ON culture_profiles(community_id);

-- Myth artifacts
CREATE TABLE IF NOT EXISTS culture_myth_artifacts (
    id BIGSERIAL PRIMARY KEY,
    artifact_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Content
    community_id VARCHAR(64) NOT NULL,
    title VARCHAR(256) NOT NULL,
    narrative TEXT NOT NULL,
    
    -- Links
    worldstate_id VARCHAR(32),
    causal_trace_id VARCHAR(32),
    
    -- Truth constraints
    contains_false_claims BOOLEAN DEFAULT FALSE,
    citations JSONB DEFAULT '[]',
    counterfactuals_labeled BOOLEAN DEFAULT TRUE,
    
    -- Governance
    hitl_approved BOOLEAN DEFAULT FALSE
);

-- ============================================================================
-- PLANETARY COORDINATION TABLES (Module 29)
-- ============================================================================

-- Sovereign nodes
CREATE TABLE IF NOT EXISTS planetary_sovereign_nodes (
    id BIGSERIAL PRIMARY KEY,
    node_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Identity
    name VARCHAR(256) NOT NULL,
    jurisdiction VARCHAR(256),
    
    -- Sovereignty
    local_policies JSONB DEFAULT '{}',
    data_stays_local BOOLEAN DEFAULT TRUE,
    
    -- Trust
    trust_level DECIMAL(3,2) DEFAULT 0.5,
    verified BOOLEAN DEFAULT FALSE,
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE
);

-- Cross-node requests
CREATE TABLE IF NOT EXISTS planetary_cross_node_requests (
    id BIGSERIAL PRIMARY KEY,
    request_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Nodes
    source_node_id VARCHAR(32) NOT NULL,
    target_node_id VARCHAR(32) NOT NULL,
    
    -- Request
    intent TEXT NOT NULL,
    payload JSONB DEFAULT '{}',
    
    -- Constraints (MANDATORY)
    no_real_execution BOOLEAN DEFAULT TRUE,
    opa_required BOOLEAN DEFAULT TRUE,
    summary_only BOOLEAN DEFAULT TRUE,
    synthetic BOOLEAN DEFAULT TRUE,
    
    -- Status
    status VARCHAR(32) DEFAULT 'pending'
);

-- ============================================================================
-- FAILSAFE TABLES (Module 36)
-- ============================================================================

-- World snapshots
CREATE TABLE IF NOT EXISTS failsafe_world_snapshots (
    id BIGSERIAL PRIMARY KEY,
    snapshot_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- State
    worldstate_hash VARCHAR(64) NOT NULL,
    critical_data JSONB,
    
    -- Context
    crisis_type VARCHAR(64),
    response_level VARCHAR(32),
    
    -- Verification
    integrity_hash VARCHAR(64) NOT NULL,
    signatures JSONB DEFAULT '[]'
);

-- Failsafe activations
CREATE TABLE IF NOT EXISTS failsafe_activations (
    id BIGSERIAL PRIMARY KEY,
    activation_id VARCHAR(32) NOT NULL UNIQUE,
    activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Crisis
    crisis_type VARCHAR(64) NOT NULL,
    response_level VARCHAR(32) NOT NULL,
    
    -- Actions
    actions JSONB DEFAULT '[]',
    
    -- Status
    is_active BOOLEAN DEFAULT TRUE,
    deactivated_at TIMESTAMPTZ
);

-- DNA Ledgers
CREATE TABLE IF NOT EXISTS failsafe_dna_ledgers (
    id BIGSERIAL PRIMARY KEY,
    ledger_id VARCHAR(32) NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Essential elements
    core_values JSONB NOT NULL,
    critical_skills JSONB NOT NULL,
    governance_rules JSONB NOT NULL,
    survival_procedures JSONB NOT NULL,
    
    -- Verification
    verified BOOLEAN DEFAULT FALSE,
    signatures JSONB DEFAULT '[]'
);

-- ============================================================================
-- POST-HUMAN ETHICS TABLES (Module 39)
-- ============================================================================

-- Human primacy checks
CREATE TABLE IF NOT EXISTS posthuman_primacy_checks (
    id BIGSERIAL PRIMARY KEY,
    check_id VARCHAR(32) NOT NULL UNIQUE,
    checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Check
    action_description TEXT NOT NULL,
    actor_type VARCHAR(32) NOT NULL,
    
    -- Result
    compliant BOOLEAN NOT NULL,
    violations JSONB DEFAULT '[]',
    blocked BOOLEAN DEFAULT FALSE,
    block_reason TEXT
);

-- Forbidden state detections
CREATE TABLE IF NOT EXISTS posthuman_forbidden_detections (
    id BIGSERIAL PRIMARY KEY,
    detection_id VARCHAR(32) NOT NULL UNIQUE,
    detected_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    -- Detection
    forbidden_state VARCHAR(64) NOT NULL,
    evidence JSONB DEFAULT '[]',
    confidence DECIMAL(3,2) NOT NULL,
    
    -- Response
    action_taken TEXT,
    escalated BOOLEAN DEFAULT FALSE
);

-- ============================================================================
-- INDEXES & CONSTRAINTS
-- ============================================================================

-- Add foreign key constraints (if needed in production)
-- ALTER TABLE transmission_skill_traces 
--   ADD CONSTRAINT fk_mentor FOREIGN KEY (mentor_id) REFERENCES users(user_id);

-- ============================================================================
-- VIEWS
-- ============================================================================

-- Governance compliance view
CREATE OR REPLACE VIEW v_governance_compliance AS
SELECT 
    'nova_requests' as module,
    COUNT(*) as total_requests,
    COUNT(*) FILTER (WHERE opa_validated) as opa_validated,
    COUNT(*) FILTER (WHERE is_refusal) as refused
FROM nova_requests
UNION ALL
SELECT 
    'ethics_validations',
    COUNT(*),
    COUNT(*),
    COUNT(*) FILTER (WHERE NOT is_valid)
FROM ethics_validations
UNION ALL
SELECT 
    'decision_packages',
    COUNT(*),
    COUNT(*) FILTER (WHERE opa_validated),
    COUNT(*) FILTER (WHERE NOT hitl_approved AND hitl_required)
FROM civilization_decision_packages;

-- Active crisis view
CREATE OR REPLACE VIEW v_active_crises AS
SELECT 
    activation_id,
    crisis_type,
    response_level,
    activated_at,
    actions
FROM failsafe_activations
WHERE is_active = TRUE;

-- ============================================================================
-- FUNCTIONS
-- ============================================================================

-- Function to log audit entry
CREATE OR REPLACE FUNCTION log_gp2_audit(
    p_module VARCHAR,
    p_action VARCHAR,
    p_actor_id VARCHAR,
    p_input_data JSONB DEFAULT NULL,
    p_output_data JSONB DEFAULT NULL
) RETURNS VARCHAR AS $$
DECLARE
    v_audit_id VARCHAR;
BEGIN
    v_audit_id := 'AUDIT_' || substr(md5(random()::text), 1, 8);
    
    INSERT INTO gp2_audit_log (
        audit_id, module, action, actor_id, input_data, output_data
    ) VALUES (
        v_audit_id, p_module, p_action, p_actor_id, p_input_data, p_output_data
    );
    
    RETURN v_audit_id;
END;
$$ LANGUAGE plpgsql;

-- Function to check governance compliance
CREATE OR REPLACE FUNCTION check_governance_compliance(
    p_module VARCHAR,
    p_action VARCHAR
) RETURNS BOOLEAN AS $$
BEGIN
    -- All actions must be logged
    PERFORM log_gp2_audit(p_module, p_action || '_check', 'system');
    
    -- For now, always return true (OPA handles actual validation)
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Auto-update timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER tr_heritage_update
    BEFORE UPDATE ON heritage_identity_graphs
    FOR EACH ROW
    EXECUTE FUNCTION update_timestamp();

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================

-- Initial data: Create admin audit entry
INSERT INTO gp2_audit_log (audit_id, module, action, actor_id, input_data)
VALUES (
    'AUDIT_INIT_001',
    'system',
    'schema_initialized',
    'system',
    '{"version": "70.0.0", "governance": "strict"}'::jsonb
);

COMMENT ON TABLE gp2_audit_log IS 'CHE·NU GP2 audit log - GOUVERNANCE > EXÉCUTION';
