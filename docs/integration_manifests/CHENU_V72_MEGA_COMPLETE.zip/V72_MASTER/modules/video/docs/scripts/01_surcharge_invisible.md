
# SCRIPT 1 — LA SURCHARGE INVISIBLE
Date: 2026-01-07

[VISUEL]
Route vide. Une voiture moderne roule. Silencieuse.
Le compteur monte. Tout semble fluide.

[VOIX]
"On croit avancer vite.
Mais on ne se rend pas compte du poids qu’on traîne."

"Dans le monde numérique, on repasse les mêmes données,
les mêmes conversations,
les mêmes décisions,
encore et encore."

"On appelle ça du travail.
Mais en réalité, c’est du poids invisible."

[COUPURE VISUELLE]
La voiture est révélée avec une remorque lourde, invisible jusqu’ici.

"On roule tous avec une remorque pleine de béton.
Sans le savoir."
