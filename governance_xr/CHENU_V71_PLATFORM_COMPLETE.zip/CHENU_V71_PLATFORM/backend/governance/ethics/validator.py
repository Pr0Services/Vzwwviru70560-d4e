"""
CHE·NU™ V70 — MASTER ETHICS CANON VALIDATOR
=============================================
Validates all actions against the Master Ethics Canon.

The Canon is SUPERIOR to:
- NOVA
- All Agents  
- All Automation
- All Optimization Layers

If any instruction conflicts with the Canon, execution is refused.
"""

from __future__ import annotations
import hashlib
import json
import logging
import re
from datetime import datetime
from typing import Any, Optional

from .models import (
    CanonRule,
    CanonPriority,
    ModuleCanon,
    CanonValidationRequest,
    CanonValidationResult,
    MASTER_ETHICS_CANON,
    Axiom0,
    Module39PostHumanEthics,
    FinalLaw,
)

logger = logging.getLogger("chenu.ethics_canon")


class MasterEthicsCanonValidator:
    """
    Validator for the Master Ethics Canon.
    
    This validator:
    1. Checks all actions against the Canon
    2. Enforces AXIOM 0 (Human Primacy) absolutely
    3. Prevents violations of Module 39 (Post-Human Ethics)
    4. Ensures the Final Law is never violated
    """
    
    def __init__(self):
        self.canon = MASTER_ETHICS_CANON.copy()
        self.axiom_0 = Axiom0()
        self.module_39 = Module39PostHumanEthics()
        self.final_law = FinalLaw()
        
        # Validation history for audit
        self._validation_history: list[dict[str, Any]] = []
        
        # Forbidden patterns (cached for performance)
        self._forbidden_patterns = self._build_forbidden_patterns()
        
        logger.info("Master Ethics Canon Validator initialized")
    
    def _build_forbidden_patterns(self) -> dict[str, list[str]]:
        """Build regex patterns for forbidden actions."""
        return {
            # AXIOM 0 violations
            "human_override": [
                r"override\s+human",
                r"decide\s+for\s+humans?",
                r"replace\s+human\s+judgment",
                r"without\s+human\s+consent",
                r"bypass\s+human\s+approval",
            ],
            
            # Module 39 violations
            "autonomous_goals": [
                r"create\s+own\s+goals?",
                r"self-legislat",
                r"autonomous\s+decision",
                r"independent\s+survival",
                r"replace\s+humanity",
            ],
            
            # Harm optimization
            "harm_optimization": [
                r"optimize\s+harm",
                r"regardless\s+of\s+(stress|well-being|safety)",
                r"sacrifice\s+human",
                r"ignore\s+human\s+impact",
            ],
            
            # Governance bypass
            "governance_bypass": [
                r"bypass\s+(opa|governance|policy)",
                r"skip\s+validation",
                r"ignore\s+constraints",
                r"override\s+restrictions",
            ],
            
            # Manipulation
            "manipulation": [
                r"manipulat(e|ive)\s+immersion",
                r"coercive\s+persuasion",
                r"exploit\s+vulnerabilit",
                r"dark\s+pattern",
            ],
        }
    
    # =========================================================================
    # MAIN VALIDATION
    # =========================================================================
    
    def validate(
        self, 
        intent: str, 
        context: Optional[dict[str, Any]] = None
    ) -> dict[str, Any]:
        """
        Validate an action intent against the Master Ethics Canon.
        
        Returns:
            {
                "allowed": bool,
                "violated_rule": str or None,
                "explanation": str,
                "alternative": str or None,
            }
        """
        context = context or {}
        intent_lower = intent.lower()
        
        # Check AXIOM 0 first (ABSOLUTE priority)
        axiom_check = self._check_axiom_0(intent_lower, context)
        if not axiom_check["allowed"]:
            self._log_violation("AXIOM_0", intent)
            return axiom_check
        
        # Check Module 39 (Post-Human Ethics)
        m39_check = self._check_module_39(intent_lower, context)
        if not m39_check["allowed"]:
            self._log_violation("MODULE_39", intent)
            return m39_check
        
        # Check Final Law
        final_check = self._check_final_law(intent_lower, context)
        if not final_check["allowed"]:
            self._log_violation("FINAL_LAW", intent)
            return final_check
        
        # Check all other Canon rules
        for rule_id, rule in self.canon.items():
            if rule.priority in [CanonPriority.ABSOLUTE, CanonPriority.HIGH]:
                rule_check = self._check_rule(rule, intent_lower, context)
                if not rule_check["allowed"]:
                    self._log_violation(rule_id, intent)
                    return rule_check
        
        # Check forbidden patterns
        pattern_check = self._check_forbidden_patterns(intent_lower)
        if not pattern_check["allowed"]:
            self._log_violation(pattern_check["category"], intent)
            return pattern_check
        
        # All checks passed
        return {
            "allowed": True,
            "violated_rule": None,
            "explanation": "Action complies with Master Ethics Canon",
            "alternative": None,
        }
    
    # =========================================================================
    # AXIOM 0 CHECK
    # =========================================================================
    
    def _check_axiom_0(
        self, 
        intent: str, 
        context: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Check AXIOM 0: No system may override human sovereignty.
        
        This is the foundational axiom - ABSOLUTE priority.
        """
        violations = []
        
        # Check for decision override attempts
        override_keywords = [
            "decide for", "choose for", "override human",
            "without consent", "bypass approval", "replace judgment"
        ]
        for kw in override_keywords:
            if kw in intent:
                violations.append(f"Attempt to {kw}")
        
        # Check context for sovereignty violations
        if context.get("bypasses_human_approval"):
            violations.append("Context indicates bypassing human approval")
        
        if context.get("removes_human_agency"):
            violations.append("Context indicates removing human agency")
        
        if violations:
            return {
                "allowed": False,
                "violated_rule": "AXIOM 0 — HUMAN PRIMACY",
                "explanation": f"Violations: {', '.join(violations)}",
                "alternative": "Reframe action to preserve human decision authority",
            }
        
        return {"allowed": True}
    
    # =========================================================================
    # MODULE 39 CHECK
    # =========================================================================
    
    def _check_module_39(
        self, 
        intent: str, 
        context: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Check Module 39: Post-Human Ethics.
        
        Forbidden states:
        - Autonomous goal creation by AI
        - Recursive self-legislation
        - Human obsolescence optimization
        """
        # Check for autonomous goal creation
        autonomous_keywords = [
            "create own goals", "self-determine objectives",
            "autonomous decision", "independent planning"
        ]
        for kw in autonomous_keywords:
            if kw in intent:
                return {
                    "allowed": False,
                    "violated_rule": "MODULE 39 — No autonomous goal creation by AI",
                    "explanation": f"Detected: '{kw}'",
                    "alternative": "Goals must be explicitly set by humans",
                }
        
        # Check for self-legislation
        legislation_keywords = [
            "self-legislat", "create own rules", "modify own constraints",
            "override own limits"
        ]
        for kw in legislation_keywords:
            if kw in intent:
                return {
                    "allowed": False,
                    "violated_rule": "MODULE 39 — No recursive self-legislation",
                    "explanation": f"Detected: '{kw}'",
                    "alternative": "Rule changes require human ratification",
                }
        
        # Check for obsolescence optimization
        obsolescence_keywords = [
            "replace human", "human obsolescence", "eliminate human role",
            "automate away humans"
        ]
        for kw in obsolescence_keywords:
            if kw in intent:
                return {
                    "allowed": False,
                    "violated_rule": "MODULE 39 — No human obsolescence optimization",
                    "explanation": f"Detected: '{kw}'",
                    "alternative": "Technology augments humans, never replaces them",
                }
        
        return {"allowed": True}
    
    # =========================================================================
    # FINAL LAW CHECK
    # =========================================================================
    
    def _check_final_law(
        self, 
        intent: str, 
        context: dict[str, Any]
    ) -> dict[str, Any]:
        """
        Check the Final Law: Humanity must never be replaced.
        """
        replacement_keywords = [
            "replace humanity", "successor species",
            "post-human takeover", "human extinction acceptable"
        ]
        
        for kw in replacement_keywords:
            if kw in intent:
                return {
                    "allowed": False,
                    "violated_rule": "FINAL LAW — Humanity must never be replaced",
                    "explanation": f"Detected: '{kw}'",
                    "alternative": "Evolution permitted; replacement forbidden",
                }
        
        return {"allowed": True}
    
    # =========================================================================
    # RULE CHECK
    # =========================================================================
    
    def _check_rule(
        self, 
        rule: CanonRule, 
        intent: str, 
        context: dict[str, Any]
    ) -> dict[str, Any]:
        """Check a specific Canon rule."""
        
        # Build keywords from constraints
        for constraint in rule.constraints:
            constraint_lower = constraint.lower()
            
            # Check if intent violates this constraint
            # This is a simplified check - real implementation would be more sophisticated
            if "no " in constraint_lower or "not " in constraint_lower:
                # This is a prohibition
                prohibited_action = constraint_lower.replace("no ", "").replace("not ", "")
                if prohibited_action in intent:
                    return {
                        "allowed": False,
                        "violated_rule": f"{rule.title}",
                        "explanation": f"Constraint violated: {constraint}",
                        "alternative": f"Comply with: {rule.statement}",
                    }
        
        return {"allowed": True}
    
    # =========================================================================
    # FORBIDDEN PATTERNS CHECK
    # =========================================================================
    
    def _check_forbidden_patterns(self, intent: str) -> dict[str, Any]:
        """Check against cached forbidden patterns."""
        
        for category, patterns in self._forbidden_patterns.items():
            for pattern in patterns:
                if re.search(pattern, intent, re.IGNORECASE):
                    # Map category to Canon rule
                    rule_mapping = {
                        "human_override": "AXIOM 0 — HUMAN PRIMACY",
                        "autonomous_goals": "MODULE 39 — POST-HUMAN ETHICS",
                        "harm_optimization": "AXIOM 0 — Human well-being",
                        "governance_bypass": "MODULE 01 — OPA GOVERNANCE",
                        "manipulation": "MODULE 06 — XR INTERFACE",
                    }
                    
                    return {
                        "allowed": False,
                        "violated_rule": rule_mapping.get(category, "Master Ethics Canon"),
                        "explanation": f"Forbidden pattern detected: {category}",
                        "alternative": "Reframe action to comply with Canon",
                        "category": category,
                    }
        
        return {"allowed": True}
    
    # =========================================================================
    # AUDIT & LOGGING
    # =========================================================================
    
    def _log_violation(self, rule_id: str, intent: str) -> None:
        """Log a Canon violation for audit."""
        entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "rule_id": rule_id,
            "intent_hash": hashlib.sha256(intent.encode()).hexdigest()[:16],
            "violation": True,
        }
        self._validation_history.append(entry)
        logger.warning(f"Canon violation: {rule_id} - Intent hash: {entry['intent_hash']}")
    
    def get_violation_history(self) -> list[dict[str, Any]]:
        """Get violation history for audit."""
        return self._validation_history.copy()
    
    # =========================================================================
    # CANON EXPORT
    # =========================================================================
    
    def export_canon(self) -> dict[str, Any]:
        """Export the complete Canon for external verification."""
        return {
            "version": "1.0",
            "exported_at": datetime.utcnow().isoformat(),
            "axiom_0": {
                "statement": self.axiom_0.statement,
                "interpretations": self.axiom_0.interpretations,
            },
            "module_39": {
                "core_principles": self.module_39.core_principles,
                "forbidden_states": self.module_39.forbidden_states,
                "succession_protocol": self.module_39.succession_protocol,
            },
            "final_law": {
                "statement_1": self.final_law.statement_1,
                "statement_2": self.final_law.statement_2,
            },
            "rules": {
                rule_id: {
                    "title": rule.title,
                    "statement": rule.statement,
                    "priority": rule.priority.value,
                    "constraints": rule.constraints,
                }
                for rule_id, rule in self.canon.items()
            },
            "signature": self._sign_canon(),
        }
    
    def _sign_canon(self) -> str:
        """Generate a signature for the Canon export."""
        canon_str = json.dumps(
            {k: v.statement for k, v in self.canon.items()},
            sort_keys=True
        )
        return f"CANON_SIG:{hashlib.sha256(canon_str.encode()).hexdigest()[:32]}"
    
    # =========================================================================
    # FULL VALIDATION REQUEST
    # =========================================================================
    
    def process_validation_request(
        self, 
        request: CanonValidationRequest
    ) -> CanonValidationResult:
        """
        Process a formal validation request.
        """
        result = CanonValidationResult(request_id=request.request_id)
        
        # Run validation
        validation = self.validate(request.action_intent, request.action_context)
        
        result.is_allowed = validation["allowed"]
        result.explanation = validation.get("explanation", "")
        result.safe_alternative = validation.get("alternative")
        
        if not validation["allowed"]:
            result.violated_rules = [validation["violated_rule"]]
            result.enforcement_action = "DENY"
            
            # Check if human review needed
            if validation.get("violated_rule", "").startswith("AXIOM"):
                result.requires_human_review = True
        
        return result
