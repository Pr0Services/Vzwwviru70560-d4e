"""
EVENT BROADCASTING SERVICE
===========================

Service for broadcasting real-time events from CHE·NU services
to WebSocket clients.

Integrates with:
- Thread Service (Thread events)
- Checkpoint Service (Governance events)
- Agent Service (Agent execution events)
- Nova Pipeline (Pipeline events)

R&D COMPLIANCE:
- Rule #1: Checkpoint broadcasts notify but require explicit action
- Rule #3: Only broadcast to identity with access rights
- Rule #6: All broadcasts logged for traceability

VERSION: 1.0.0
"""

from typing import Dict, Any, Optional, List
from uuid import UUID
from datetime import datetime
import logging

from .connection_manager import (
    ConnectionManager, 
    get_connection_manager,
    EventType,
    SubscriptionType
)

logger = logging.getLogger(__name__)


class EventBroadcaster:
    """
    Service for broadcasting events to WebSocket subscribers.
    
    This service acts as a bridge between backend services
    and the WebSocket connection manager.
    """
    
    def __init__(self, connection_manager: Optional[ConnectionManager] = None):
        self._manager = connection_manager or get_connection_manager()
        self._broadcast_count = 0
        logger.info("EventBroadcaster initialized")
    
    # -------------------------------------------------------------------------
    # THREAD EVENTS
    # -------------------------------------------------------------------------
    
    async def broadcast_thread_created(
        self,
        identity_id: str,
        thread_id: str,
        sphere_id: str,
        thread_data: Dict[str, Any]
    ):
        """
        Broadcast when a new Thread is created.
        
        Notifies:
        - Identity owner (always)
        - Sphere subscribers
        """
        # Notify identity owner
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.THREAD_CREATED,
            {
                "thread_id": thread_id,
                "sphere_id": sphere_id,
                "founding_intent": thread_data.get("founding_intent"),
                "created_at": datetime.utcnow().isoformat()
            }
        )
        
        # Notify sphere subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.SPHERE,
            sphere_id,
            EventType.SPHERE_ITEM_ADDED,
            {
                "item_type": "thread",
                "item_id": thread_id,
                "item_data": thread_data
            }
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast thread_created: {thread_id}")
    
    async def broadcast_thread_updated(
        self,
        thread_id: str,
        identity_id: str,
        changes: Dict[str, Any]
    ):
        """
        Broadcast when a Thread is updated.
        
        Notifies:
        - Thread subscribers
        - Identity owner
        """
        event_data = {
            "thread_id": thread_id,
            "changes": changes,
            "updated_at": datetime.utcnow().isoformat()
        }
        
        # Notify thread subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.THREAD,
            thread_id,
            EventType.THREAD_UPDATED,
            event_data
        )
        
        # Notify identity owner
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.THREAD_UPDATED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast thread_updated: {thread_id}")
    
    async def broadcast_thread_event_added(
        self,
        thread_id: str,
        identity_id: str,
        event: Dict[str, Any]
    ):
        """
        Broadcast when an event is added to a Thread.
        
        Core Thread V2 event - append-only log updated.
        """
        event_data = {
            "thread_id": thread_id,
            "event": event,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Notify thread subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.THREAD,
            thread_id,
            EventType.THREAD_EVENT_ADDED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast thread_event_added: {thread_id} - {event.get('event_type')}")
    
    async def broadcast_thread_archived(
        self,
        thread_id: str,
        identity_id: str,
        sphere_id: str
    ):
        """Broadcast when a Thread is archived"""
        event_data = {
            "thread_id": thread_id,
            "sphere_id": sphere_id,
            "archived_at": datetime.utcnow().isoformat()
        }
        
        # Notify thread subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.THREAD,
            thread_id,
            EventType.THREAD_ARCHIVED,
            event_data
        )
        
        # Notify identity owner
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.THREAD_ARCHIVED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast thread_archived: {thread_id}")
    
    # -------------------------------------------------------------------------
    # CHECKPOINT EVENTS (Rule #1 - Human Sovereignty)
    # -------------------------------------------------------------------------
    
    async def broadcast_checkpoint_created(
        self,
        identity_id: str,
        checkpoint_id: str,
        checkpoint_type: str,
        thread_id: Optional[str],
        reason: str,
        options: List[str],
        preview: Optional[Dict[str, Any]] = None
    ):
        """
        Broadcast when a checkpoint is created requiring human approval.
        
        Rule #1: This notification allows human to see and act on checkpoint.
        The checkpoint blocks execution until approved.
        """
        event_data = {
            "checkpoint_id": checkpoint_id,
            "checkpoint_type": checkpoint_type,
            "thread_id": thread_id,
            "reason": reason,
            "options": options,
            "preview": preview,
            "status": "pending",
            "requires_action": True,
            "created_at": datetime.utcnow().isoformat()
        }
        
        # Notify identity owner - CRITICAL for human oversight
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.CHECKPOINT_CREATED,
            event_data
        )
        
        # Also broadcast to checkpoint subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.CHECKPOINT,
            identity_id,  # Using identity as target for checkpoint subscription
            EventType.CHECKPOINT_PENDING,
            event_data
        )
        
        # If thread-specific, notify thread subscribers too
        if thread_id:
            await self._manager.broadcast_to_subscription(
                SubscriptionType.THREAD,
                thread_id,
                EventType.CHECKPOINT_PENDING,
                event_data
            )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast checkpoint_created: {checkpoint_id} for identity {identity_id}")
    
    async def broadcast_checkpoint_approved(
        self,
        identity_id: str,
        checkpoint_id: str,
        approved_by: str,
        thread_id: Optional[str] = None
    ):
        """Broadcast when a checkpoint is approved"""
        event_data = {
            "checkpoint_id": checkpoint_id,
            "thread_id": thread_id,
            "approved_by": approved_by,
            "status": "approved",
            "approved_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.CHECKPOINT_APPROVED,
            event_data
        )
        
        if thread_id:
            await self._manager.broadcast_to_subscription(
                SubscriptionType.THREAD,
                thread_id,
                EventType.CHECKPOINT_APPROVED,
                event_data
            )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast checkpoint_approved: {checkpoint_id}")
    
    async def broadcast_checkpoint_rejected(
        self,
        identity_id: str,
        checkpoint_id: str,
        rejected_by: str,
        reason: Optional[str] = None,
        thread_id: Optional[str] = None
    ):
        """Broadcast when a checkpoint is rejected"""
        event_data = {
            "checkpoint_id": checkpoint_id,
            "thread_id": thread_id,
            "rejected_by": rejected_by,
            "reason": reason,
            "status": "rejected",
            "rejected_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.CHECKPOINT_REJECTED,
            event_data
        )
        
        if thread_id:
            await self._manager.broadcast_to_subscription(
                SubscriptionType.THREAD,
                thread_id,
                EventType.CHECKPOINT_REJECTED,
                event_data
            )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast checkpoint_rejected: {checkpoint_id}")
    
    # -------------------------------------------------------------------------
    # AGENT EVENTS
    # -------------------------------------------------------------------------
    
    async def broadcast_agent_execution_started(
        self,
        identity_id: str,
        execution_id: str,
        agent_id: str,
        agent_name: str,
        thread_id: Optional[str] = None
    ):
        """Broadcast when an agent starts execution"""
        event_data = {
            "execution_id": execution_id,
            "agent_id": agent_id,
            "agent_name": agent_name,
            "thread_id": thread_id,
            "status": "started",
            "started_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.AGENT_EXECUTION_STARTED,
            event_data
        )
        
        # Notify agent subscribers
        await self._manager.broadcast_to_subscription(
            SubscriptionType.AGENT,
            agent_id,
            EventType.AGENT_EXECUTION_STARTED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast agent_execution_started: {execution_id}")
    
    async def broadcast_agent_execution_progress(
        self,
        identity_id: str,
        execution_id: str,
        agent_id: str,
        progress: int,
        message: str
    ):
        """Broadcast agent execution progress update"""
        event_data = {
            "execution_id": execution_id,
            "agent_id": agent_id,
            "progress": progress,
            "message": message,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.AGENT_EXECUTION_PROGRESS,
            event_data
        )
        
        self._broadcast_count += 1
    
    async def broadcast_agent_execution_completed(
        self,
        identity_id: str,
        execution_id: str,
        agent_id: str,
        result_type: str,
        result_summary: str,
        has_draft: bool = False,
        thread_id: Optional[str] = None
    ):
        """Broadcast when agent execution completes"""
        event_data = {
            "execution_id": execution_id,
            "agent_id": agent_id,
            "thread_id": thread_id,
            "status": "completed",
            "result_type": result_type,
            "result_summary": result_summary,
            "has_draft": has_draft,  # If True, draft needs approval (Rule #1)
            "completed_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.AGENT_EXECUTION_COMPLETED,
            event_data
        )
        
        await self._manager.broadcast_to_subscription(
            SubscriptionType.AGENT,
            agent_id,
            EventType.AGENT_EXECUTION_COMPLETED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast agent_execution_completed: {execution_id}")
    
    async def broadcast_agent_draft_ready(
        self,
        identity_id: str,
        execution_id: str,
        agent_id: str,
        draft_type: str,
        draft_preview: str,
        thread_id: Optional[str] = None
    ):
        """
        Broadcast when an agent has a draft ready for approval.
        
        Rule #1: Drafts require human approval before execution.
        """
        event_data = {
            "execution_id": execution_id,
            "agent_id": agent_id,
            "thread_id": thread_id,
            "draft_type": draft_type,
            "draft_preview": draft_preview,
            "requires_approval": True,
            "created_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.AGENT_DRAFT_READY,
            event_data
        )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast agent_draft_ready: {execution_id} - awaiting approval")
    
    # -------------------------------------------------------------------------
    # NOVA PIPELINE EVENTS
    # -------------------------------------------------------------------------
    
    async def broadcast_nova_pipeline_started(
        self,
        identity_id: str,
        request_id: str,
        intent_type: str,
        thread_id: Optional[str] = None
    ):
        """Broadcast when Nova pipeline starts processing"""
        event_data = {
            "request_id": request_id,
            "thread_id": thread_id,
            "intent_type": intent_type,
            "status": "started",
            "started_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.NOVA_PIPELINE_STARTED,
            event_data
        )
        
        await self._manager.broadcast_to_subscription(
            SubscriptionType.NOVA,
            identity_id,
            EventType.NOVA_PIPELINE_STARTED,
            event_data
        )
        
        self._broadcast_count += 1
    
    async def broadcast_nova_lane_completed(
        self,
        identity_id: str,
        request_id: str,
        lane: str,
        lane_index: int,
        total_lanes: int = 7
    ):
        """Broadcast when a Nova pipeline lane completes"""
        event_data = {
            "request_id": request_id,
            "lane": lane,
            "lane_index": lane_index,
            "total_lanes": total_lanes,
            "progress": int((lane_index / total_lanes) * 100),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.NOVA_LANE_COMPLETED,
            event_data
        )
        
        self._broadcast_count += 1
    
    async def broadcast_nova_checkpoint_triggered(
        self,
        identity_id: str,
        request_id: str,
        checkpoint_id: str,
        reason: str,
        action_preview: str
    ):
        """
        Broadcast when Nova pipeline triggers a checkpoint.
        
        This is the real-time equivalent of HTTP 423.
        Rule #1: Checkpoint notification for human decision.
        """
        event_data = {
            "request_id": request_id,
            "checkpoint_id": checkpoint_id,
            "reason": reason,
            "action_preview": action_preview,
            "requires_approval": True,
            "options": ["approve", "reject"],
            "triggered_at": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_identity(
            identity_id,
            EventType.NOVA_CHECKPOINT_TRIGGERED,
            event_data
        )
        
        await self._manager.broadcast_to_subscription(
            SubscriptionType.CHECKPOINT,
            identity_id,
            EventType.NOVA_CHECKPOINT_TRIGGERED,
            event_data
        )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast nova_checkpoint_triggered: {checkpoint_id}")
    
    async def broadcast_nova_pipeline_completed(
        self,
        identity_id: str,
        request_id: str,
        success: bool,
        result_summary: Optional[str] = None,
        tokens_used: int = 0,
        duration_ms: int = 0
    ):
        """Broadcast when Nova pipeline completes"""
        event_data = {
            "request_id": request_id,
            "success": success,
            "result_summary": result_summary,
            "tokens_used": tokens_used,
            "duration_ms": duration_ms,
            "completed_at": datetime.utcnow().isoformat()
        }
        
        event_type = EventType.NOVA_PIPELINE_COMPLETED if success else EventType.NOVA_PIPELINE_FAILED
        
        await self._manager.broadcast_to_identity(
            identity_id,
            event_type,
            event_data
        )
        
        await self._manager.broadcast_to_subscription(
            SubscriptionType.NOVA,
            identity_id,
            event_type,
            event_data
        )
        
        self._broadcast_count += 1
        logger.debug(f"Broadcast nova_pipeline_completed: {request_id} success={success}")
    
    # -------------------------------------------------------------------------
    # PRESENCE EVENTS
    # -------------------------------------------------------------------------
    
    async def broadcast_presence_update(
        self,
        room_id: str,
        identity_id: str,
        status: str,  # "online", "away", "busy", "offline"
        activity: Optional[str] = None
    ):
        """Broadcast presence status update"""
        event_data = {
            "room_id": room_id,
            "identity_id": identity_id,
            "status": status,
            "activity": activity,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_subscription(
            SubscriptionType.THREAD,
            room_id,
            EventType.PRESENCE_UPDATED,
            event_data
        )
        
        self._broadcast_count += 1
    
    # -------------------------------------------------------------------------
    # SYSTEM EVENTS
    # -------------------------------------------------------------------------
    
    async def broadcast_system_notification(
        self,
        title: str,
        message: str,
        level: str = "info",  # info, warning, error
        identity_id: Optional[str] = None
    ):
        """
        Broadcast system notification.
        
        If identity_id provided, only that identity receives it.
        Otherwise, broadcast to all.
        """
        event_data = {
            "title": title,
            "message": message,
            "level": level,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        if identity_id:
            await self._manager.broadcast_to_identity(
                identity_id,
                EventType.SYSTEM_NOTIFICATION,
                event_data
            )
        else:
            await self._manager.broadcast_to_all(
                EventType.SYSTEM_NOTIFICATION,
                event_data
            )
        
        self._broadcast_count += 1
    
    async def broadcast_system_maintenance(
        self,
        message: str,
        scheduled_at: datetime,
        duration_minutes: int
    ):
        """Broadcast upcoming system maintenance"""
        event_data = {
            "message": message,
            "scheduled_at": scheduled_at.isoformat(),
            "duration_minutes": duration_minutes,
            "announcement_time": datetime.utcnow().isoformat()
        }
        
        await self._manager.broadcast_to_all(
            EventType.SYSTEM_MAINTENANCE,
            event_data
        )
        
        self._broadcast_count += 1
        logger.info(f"Broadcast system_maintenance: scheduled for {scheduled_at}")
    
    # -------------------------------------------------------------------------
    # UTILITY
    # -------------------------------------------------------------------------
    
    def get_broadcast_count(self) -> int:
        """Get total number of broadcasts sent"""
        return self._broadcast_count


# =============================================================================
# SINGLETON INSTANCE
# =============================================================================

_event_broadcaster: Optional[EventBroadcaster] = None


def get_event_broadcaster() -> EventBroadcaster:
    """Get or create the event broadcaster singleton"""
    global _event_broadcaster
    if _event_broadcaster is None:
        _event_broadcaster = EventBroadcaster()
    return _event_broadcaster


def init_event_broadcaster(connection_manager: ConnectionManager) -> EventBroadcaster:
    """Initialize event broadcaster with specific connection manager"""
    global _event_broadcaster
    _event_broadcaster = EventBroadcaster(connection_manager)
    return _event_broadcaster
