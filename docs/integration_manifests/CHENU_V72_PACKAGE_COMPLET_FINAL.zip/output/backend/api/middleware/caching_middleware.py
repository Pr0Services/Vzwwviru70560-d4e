"""
MIDDLEWARE: caching_middleware.py
SPHERE: Core
VERSION: 1.0.0
INTENT: HTTP response caching with ETag, conditional requests, and cache headers

CHE·NU™ Response Caching:
- Automatic response caching for GET requests
- ETag generation for conditional requests
- Cache-Control header management
- Vary header support
- Per-route cache policies

R&D COMPLIANCE: ✅
- Rule #1: Respects checkpoint responses (HTTP 423 never cached)
- Rule #6: Full traceability with request IDs
"""

from typing import Any, Callable, Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import hashlib
import json
import time
import logging
from uuid import uuid4

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from fastapi import FastAPI

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════════════
# CACHE POLICIES
# ═══════════════════════════════════════════════════════════════════════════════

class CacheScope(str, Enum):
    """Cache scope for responses"""
    PRIVATE = "private"    # Only user's browser
    PUBLIC = "public"      # CDN and browsers
    NO_CACHE = "no-cache"  # Must revalidate
    NO_STORE = "no-store"  # Never cache

@dataclass
class CachePolicy:
    """Cache policy for a route pattern"""
    
    pattern: str                          # URL pattern (e.g., "/api/v2/threads/*")
    scope: CacheScope = CacheScope.PRIVATE
    max_age: int = 60                     # Seconds
    s_maxage: Optional[int] = None        # CDN max-age
    stale_while_revalidate: Optional[int] = None
    stale_if_error: Optional[int] = None
    vary: List[str] = field(default_factory=lambda: ["Authorization"])
    etag: bool = True
    cacheable_statuses: Set[int] = field(default_factory=lambda: {200, 304})
    
    def to_cache_control(self) -> str:
        """Generate Cache-Control header value"""
        parts = [self.scope.value]
        
        parts.append(f"max-age={self.max_age}")
        
        if self.s_maxage is not None:
            parts.append(f"s-maxage={self.s_maxage}")
        
        if self.stale_while_revalidate is not None:
            parts.append(f"stale-while-revalidate={self.stale_while_revalidate}")
        
        if self.stale_if_error is not None:
            parts.append(f"stale-if-error={self.stale_if_error}")
        
        return ", ".join(parts)

# ═══════════════════════════════════════════════════════════════════════════════
# DEFAULT POLICIES
# ═══════════════════════════════════════════════════════════════════════════════

DEFAULT_POLICIES: List[CachePolicy] = [
    # Thread endpoints - moderate caching (data changes)
    CachePolicy(
        pattern="/api/v2/threads",
        max_age=30,
        scope=CacheScope.PRIVATE,
        etag=True
    ),
    
    # Sphere endpoints - longer cache (rarely changes)
    CachePolicy(
        pattern="/api/v2/spheres",
        max_age=300,
        scope=CacheScope.PRIVATE,
        etag=True
    ),
    
    # Agent registry - long cache (static config)
    CachePolicy(
        pattern="/api/v2/agents",
        max_age=600,
        scope=CacheScope.PUBLIC,
        s_maxage=3600,
        etag=True
    ),
    
    # Nova pipeline - no cache (real-time AI)
    CachePolicy(
        pattern="/api/v2/nova",
        scope=CacheScope.NO_STORE,
        max_age=0,
        etag=False
    ),
    
    # Checkpoints - no cache (governance)
    CachePolicy(
        pattern="/api/v2/checkpoints",
        scope=CacheScope.NO_STORE,
        max_age=0,
        etag=False
    ),
    
    # XR blueprints - moderate cache
    CachePolicy(
        pattern="/api/v2/xr",
        max_age=120,
        scope=CacheScope.PRIVATE,
        etag=True
    ),
    
    # Health endpoints - short cache
    CachePolicy(
        pattern="/health",
        max_age=5,
        scope=CacheScope.NO_CACHE,
        etag=False
    ),
    
    # Static documentation - long cache
    CachePolicy(
        pattern="/docs",
        max_age=3600,
        scope=CacheScope.PUBLIC,
        etag=True
    ),
]

# Never cache these status codes
NEVER_CACHE_STATUSES = {
    401,  # Unauthorized
    403,  # Forbidden
    423,  # Locked (checkpoint required!)
    500,  # Internal Server Error
    502,  # Bad Gateway
    503,  # Service Unavailable
}

# Never cache these methods
CACHEABLE_METHODS = {"GET", "HEAD"}

# ═══════════════════════════════════════════════════════════════════════════════
# ETAG UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════

class ETagGenerator:
    """Generate ETags for response content"""
    
    @staticmethod
    def generate(content: bytes) -> str:
        """Generate ETag from content"""
        content_hash = hashlib.sha256(content).hexdigest()[:16]
        return f'"{content_hash}"'
    
    @staticmethod
    def generate_weak(content: bytes, timestamp: Optional[float] = None) -> str:
        """Generate weak ETag (allows semantic equivalence)"""
        content_hash = hashlib.sha256(content).hexdigest()[:12]
        ts = int(timestamp or time.time())
        return f'W/"{content_hash}-{ts}"'
    
    @staticmethod
    def matches(etag: str, if_none_match: str) -> bool:
        """Check if ETag matches If-None-Match header"""
        # Handle multiple ETags in If-None-Match
        etags = [e.strip() for e in if_none_match.split(",")]
        
        # Check for wildcard
        if "*" in etags:
            return True
        
        # Strip weak indicator for comparison
        clean_etag = etag.replace('W/', '')
        
        for candidate in etags:
            clean_candidate = candidate.replace('W/', '')
            if clean_etag == clean_candidate:
                return True
        
        return False

# ═══════════════════════════════════════════════════════════════════════════════
# RESPONSE CACHE STORAGE
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class CachedResponse:
    """Cached HTTP response"""
    
    status_code: int
    headers: Dict[str, str]
    body: bytes
    etag: str
    created_at: float
    expires_at: float
    request_id: str

class ResponseCache:
    """In-memory response cache (L1)"""
    
    def __init__(self, max_size: int = 1000):
        self._cache: Dict[str, CachedResponse] = {}
        self.max_size = max_size
        
        # Metrics
        self.hits = 0
        self.misses = 0
        self.conditionals = 0
    
    def _make_key(self, request: Request) -> str:
        """Create cache key from request"""
        parts = [
            request.method,
            str(request.url.path),
            str(sorted(request.query_params.items())),
        ]
        
        # Include user ID if authenticated
        user_id = request.state.__dict__.get("user_id", "anonymous")
        parts.append(str(user_id))
        
        key_string = "|".join(parts)
        return hashlib.sha256(key_string.encode()).hexdigest()[:32]
    
    def get(self, request: Request) -> Optional[CachedResponse]:
        """Get cached response"""
        key = self._make_key(request)
        
        cached = self._cache.get(key)
        if cached is None:
            self.misses += 1
            return None
        
        # Check expiration
        if time.time() > cached.expires_at:
            del self._cache[key]
            self.misses += 1
            return None
        
        self.hits += 1
        return cached
    
    def set(
        self,
        request: Request,
        response: Response,
        body: bytes,
        etag: str,
        max_age: int
    ) -> None:
        """Store response in cache"""
        # Evict if at capacity
        while len(self._cache) >= self.max_size:
            # Remove oldest
            oldest_key = min(
                self._cache.keys(),
                key=lambda k: self._cache[k].created_at
            )
            del self._cache[oldest_key]
        
        key = self._make_key(request)
        now = time.time()
        
        self._cache[key] = CachedResponse(
            status_code=response.status_code,
            headers=dict(response.headers),
            body=body,
            etag=etag,
            created_at=now,
            expires_at=now + max_age,
            request_id=response.headers.get("X-Request-ID", str(uuid4()))
        )
    
    def invalidate_pattern(self, pattern: str) -> int:
        """Invalidate cache entries matching pattern"""
        # Simple prefix matching
        keys_to_remove = [
            k for k in self._cache.keys()
            if pattern.replace("*", "") in k
        ]
        
        for key in keys_to_remove:
            del self._cache[key]
        
        return len(keys_to_remove)
    
    def clear(self) -> None:
        """Clear all cache"""
        self._cache.clear()
        self.hits = 0
        self.misses = 0
        self.conditionals = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total = self.hits + self.misses
        hit_rate = (self.hits / total * 100) if total > 0 else 0
        
        return {
            "size": len(self._cache),
            "max_size": self.max_size,
            "hits": self.hits,
            "misses": self.misses,
            "conditionals": self.conditionals,
            "hit_rate": round(hit_rate, 2)
        }

# ═══════════════════════════════════════════════════════════════════════════════
# CACHING MIDDLEWARE
# ═══════════════════════════════════════════════════════════════════════════════

class CachingMiddleware(BaseHTTPMiddleware):
    """
    HTTP response caching middleware.
    
    Features:
    - Automatic ETag generation
    - Conditional request handling (304 Not Modified)
    - Per-route cache policies
    - Cache-Control header management
    - Respects governance (never caches HTTP 423)
    """
    
    def __init__(
        self,
        app: FastAPI,
        policies: Optional[List[CachePolicy]] = None,
        enable_response_cache: bool = True,
        response_cache_size: int = 1000
    ):
        super().__init__(app)
        self._policies = policies or DEFAULT_POLICIES
        self._policy_map: Dict[str, CachePolicy] = {}
        self._build_policy_map()
        
        # Response cache (L1)
        self._response_cache: Optional[ResponseCache] = None
        if enable_response_cache:
            self._response_cache = ResponseCache(max_size=response_cache_size)
    
    def _build_policy_map(self) -> None:
        """Build lookup map for policies"""
        for policy in self._policies:
            self._policy_map[policy.pattern] = policy
    
    def _find_policy(self, path: str) -> Optional[CachePolicy]:
        """Find cache policy for path"""
        # Exact match
        if path in self._policy_map:
            return self._policy_map[path]
        
        # Pattern match
        for pattern, policy in self._policy_map.items():
            if pattern.endswith("*"):
                prefix = pattern[:-1]
                if path.startswith(prefix):
                    return policy
            elif pattern.endswith("/*"):
                prefix = pattern[:-2]
                if path.startswith(prefix):
                    return policy
        
        return None
    
    async def dispatch(
        self,
        request: Request,
        call_next: Callable
    ) -> Response:
        """Process request with caching"""
        start_time = time.time()
        
        # Skip non-cacheable methods
        if request.method not in CACHEABLE_METHODS:
            return await call_next(request)
        
        # Find policy
        policy = self._find_policy(request.url.path)
        
        # Check for cached response
        if self._response_cache and policy and policy.scope != CacheScope.NO_STORE:
            cached = self._response_cache.get(request)
            
            if cached:
                # Check conditional request
                if_none_match = request.headers.get("If-None-Match")
                if if_none_match and ETagGenerator.matches(cached.etag, if_none_match):
                    self._response_cache.conditionals += 1
                    
                    return Response(
                        status_code=304,
                        headers={
                            "ETag": cached.etag,
                            "X-Cache": "HIT-CONDITIONAL",
                            "X-Response-Time": f"{(time.time() - start_time) * 1000:.2f}ms"
                        }
                    )
                
                # Return cached response
                response = Response(
                    content=cached.body,
                    status_code=cached.status_code,
                    media_type="application/json"
                )
                
                for key, value in cached.headers.items():
                    if key.lower() not in ("content-length", "content-encoding"):
                        response.headers[key] = value
                
                response.headers["X-Cache"] = "HIT"
                response.headers["X-Response-Time"] = f"{(time.time() - start_time) * 1000:.2f}ms"
                
                return response
        
        # Process request
        response = await call_next(request)
        
        # Add timing
        response.headers["X-Response-Time"] = f"{(time.time() - start_time) * 1000:.2f}ms"
        
        # Skip if not cacheable status
        if response.status_code in NEVER_CACHE_STATUSES:
            response.headers["Cache-Control"] = "no-store"
            return response
        
        # Apply cache policy
        if policy:
            # Set Cache-Control
            response.headers["Cache-Control"] = policy.to_cache_control()
            
            # Set Vary
            if policy.vary:
                response.headers["Vary"] = ", ".join(policy.vary)
            
            # Generate and set ETag
            if policy.etag and response.status_code in policy.cacheable_statuses:
                # Read body for ETag
                body = b""
                async for chunk in response.body_iterator:
                    body += chunk
                
                etag = ETagGenerator.generate(body)
                response.headers["ETag"] = etag
                response.headers["X-Cache"] = "MISS"
                
                # Store in response cache
                if (
                    self._response_cache and
                    policy.scope not in (CacheScope.NO_STORE, CacheScope.NO_CACHE) and
                    len(body) < 1024 * 1024  # Don't cache >1MB
                ):
                    self._response_cache.set(
                        request,
                        response,
                        body,
                        etag,
                        policy.max_age
                    )
                
                # Return new response with body
                return Response(
                    content=body,
                    status_code=response.status_code,
                    headers=dict(response.headers),
                    media_type=response.media_type
                )
        else:
            # Default: private, short cache
            response.headers["Cache-Control"] = "private, max-age=0, must-revalidate"
            response.headers["X-Cache"] = "BYPASS"
        
        return response
    
    def add_policy(self, policy: CachePolicy) -> None:
        """Add a cache policy"""
        self._policies.append(policy)
        self._policy_map[policy.pattern] = policy
    
    def remove_policy(self, pattern: str) -> bool:
        """Remove a cache policy"""
        if pattern in self._policy_map:
            del self._policy_map[pattern]
            self._policies = [p for p in self._policies if p.pattern != pattern]
            return True
        return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get middleware statistics"""
        stats = {
            "policies_count": len(self._policies),
            "response_cache": None
        }
        
        if self._response_cache:
            stats["response_cache"] = self._response_cache.get_stats()
        
        return stats
    
    def invalidate(self, pattern: str) -> int:
        """Invalidate cached responses matching pattern"""
        if self._response_cache:
            return self._response_cache.invalidate_pattern(pattern)
        return 0
    
    def clear_cache(self) -> None:
        """Clear response cache"""
        if self._response_cache:
            self._response_cache.clear()

# ═══════════════════════════════════════════════════════════════════════════════
# ROUTE DECORATORS
# ═══════════════════════════════════════════════════════════════════════════════

def cache_response(
    max_age: int = 60,
    scope: CacheScope = CacheScope.PRIVATE,
    vary: Optional[List[str]] = None,
    etag: bool = True
):
    """
    Decorator to apply cache policy to route.
    
    Usage:
        @app.get("/api/v2/items")
        @cache_response(max_age=300, scope=CacheScope.PUBLIC)
        async def list_items():
            ...
    """
    def decorator(func: Callable) -> Callable:
        # Store policy metadata on function
        func._cache_policy = CachePolicy(
            pattern=func.__name__,  # Will be updated by middleware
            max_age=max_age,
            scope=scope,
            vary=vary or ["Authorization"],
            etag=etag
        )
        return func
    return decorator

def no_cache():
    """
    Decorator to disable caching for route.
    
    Usage:
        @app.post("/api/v2/nova/process")
        @no_cache()
        async def process_nova():
            ...
    """
    def decorator(func: Callable) -> Callable:
        func._cache_policy = CachePolicy(
            pattern=func.__name__,
            scope=CacheScope.NO_STORE,
            max_age=0,
            etag=False
        )
        return func
    return decorator

# ═══════════════════════════════════════════════════════════════════════════════
# SETUP HELPER
# ═══════════════════════════════════════════════════════════════════════════════

def setup_caching(
    app: FastAPI,
    policies: Optional[List[CachePolicy]] = None,
    enable_response_cache: bool = True,
    response_cache_size: int = 1000
) -> CachingMiddleware:
    """
    Setup caching middleware for FastAPI app.
    
    Usage:
        from fastapi import FastAPI
        from api.middleware.caching_middleware import setup_caching
        
        app = FastAPI()
        caching = setup_caching(app)
    """
    middleware = CachingMiddleware(
        app,
        policies=policies,
        enable_response_cache=enable_response_cache,
        response_cache_size=response_cache_size
    )
    
    # Add middleware
    app.add_middleware(CachingMiddleware, **{
        "policies": policies,
        "enable_response_cache": enable_response_cache,
        "response_cache_size": response_cache_size
    })
    
    # Add stats endpoint
    @app.get("/api/v2/cache/stats", tags=["Cache"])
    async def get_cache_stats():
        """Get caching statistics"""
        return middleware.get_stats()
    
    @app.post("/api/v2/cache/invalidate", tags=["Cache"])
    async def invalidate_cache(pattern: str):
        """Invalidate cache by pattern"""
        count = middleware.invalidate(pattern)
        return {"invalidated": count, "pattern": pattern}
    
    @app.post("/api/v2/cache/clear", tags=["Cache"])
    async def clear_cache():
        """Clear all response cache"""
        middleware.clear_cache()
        return {"status": "cleared"}
    
    logger.info(f"Caching middleware configured with {len(policies or DEFAULT_POLICIES)} policies")
    
    return middleware

# ═══════════════════════════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════════════════════════

__all__ = [
    "CachingMiddleware",
    "CachePolicy",
    "CacheScope",
    "ETagGenerator",
    "ResponseCache",
    "CachedResponse",
    "cache_response",
    "no_cache",
    "setup_caching",
    "DEFAULT_POLICIES",
    "NEVER_CACHE_STATUSES",
    "CACHEABLE_METHODS",
]
