"""
CHE·NU™ V70 — MEETING SYSTEM
============================
Complete meeting lifecycle management system.

Based on: MEETING_SYSTEM_CHAPTER.md (Chapters 71-80)

In CHE·NU's philosophy, meetings are not mere video calls—
they are knowledge events that generate structured, actionable,
and replayable artifacts.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.meeting")


# =============================================================================
# ENUMS
# =============================================================================

class MeetingType(str, Enum):
    """Types of meetings."""
    REALTIME = "realtime"
    ASYNCHRONOUS = "asynchronous"
    HYBRID = "hybrid"
    XR_SPATIAL = "xr_spatial"
    CROSS_DOMAIN = "cross_domain"


class MeetingStatus(str, Enum):
    """Meeting status."""
    SCHEDULED = "scheduled"
    IN_PROGRESS = "in_progress"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class ParticipantRole(str, Enum):
    """Participant roles."""
    ORGANIZER = "organizer"
    PRESENTER = "presenter"
    PARTICIPANT = "participant"
    OBSERVER = "observer"
    AGENT = "agent"


class DecisionStatus(str, Enum):
    """Decision status."""
    PROPOSED = "proposed"
    DISCUSSED = "discussed"
    APPROVED = "approved"
    REJECTED = "rejected"
    DEFERRED = "deferred"


# =============================================================================
# PARTICIPANT MODEL
# =============================================================================

@dataclass
class Participant:
    """Meeting participant."""
    participant_id: str = field(default_factory=lambda: f"PART_{uuid4().hex[:8]}")
    user_id: str = ""
    name: str = ""
    email: str = ""
    
    # Role
    role: ParticipantRole = ParticipantRole.PARTICIPANT
    
    # Presence
    joined_at: Optional[datetime] = None
    left_at: Optional[datetime] = None
    is_present: bool = False
    
    # Contribution
    speaking_time_seconds: int = 0
    contributions: List[str] = field(default_factory=list)
    
    # Consent
    recording_consent: bool = False
    
    # Type
    is_agent: bool = False
    agent_type: Optional[str] = None


# =============================================================================
# AGENDA MODEL
# =============================================================================

@dataclass
class AgendaItem:
    """Meeting agenda item."""
    item_id: str = field(default_factory=lambda: f"AGI_{uuid4().hex[:8]}")
    
    # Content
    title: str = ""
    description: str = ""
    
    # Time
    planned_duration_minutes: int = 15
    actual_duration_minutes: int = 0
    
    # Presenter
    presenter_id: Optional[str] = None
    
    # Order
    order: int = 0
    
    # Status
    status: str = "pending"  # pending, active, completed, skipped
    
    # Outcomes
    notes: str = ""
    decisions: List[str] = field(default_factory=list)
    tasks: List[str] = field(default_factory=list)


@dataclass
class MeetingAgenda:
    """Complete meeting agenda."""
    agenda_id: str = field(default_factory=lambda: f"AGD_{uuid4().hex[:8]}")
    
    # Items
    items: List[AgendaItem] = field(default_factory=list)
    
    # Goals
    meeting_goals: List[str] = field(default_factory=list)
    
    # Pre-meeting
    pre_read_documents: List[str] = field(default_factory=list)
    
    # Timing
    total_planned_minutes: int = 60


# =============================================================================
# NOTES MODEL
# =============================================================================

@dataclass
class MeetingNote:
    """Individual meeting note."""
    note_id: str = field(default_factory=lambda: f"NOTE_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    content: str = ""
    
    # Attribution
    speaker_id: Optional[str] = None
    topic: Optional[str] = None
    
    # AI
    ai_generated: bool = False
    ai_summary: Optional[str] = None


@dataclass
class MeetingNotes:
    """Collection of meeting notes."""
    notes_id: str = field(default_factory=lambda: f"NOTES_{uuid4().hex[:8]}")
    
    # Raw
    raw_transcript: str = ""
    
    # Structured
    notes: List[MeetingNote] = field(default_factory=list)
    
    # Summaries
    topic_summaries: Dict[str, str] = field(default_factory=dict)
    executive_summary: str = ""
    
    # AI-generated
    ai_structured_notes: str = ""


# =============================================================================
# TASK MODEL
# =============================================================================

@dataclass
class MeetingTask:
    """Task extracted from meeting."""
    task_id: str = field(default_factory=lambda: f"MTASK_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    description: str = ""
    
    # Assignment
    assignee_id: Optional[str] = None
    assignee_name: str = ""
    
    # Deadline
    due_date: Optional[datetime] = None
    
    # Priority
    priority: str = "medium"
    
    # Status
    status: str = "pending"
    
    # Source
    extracted_from_note: Optional[str] = None
    ai_extracted: bool = False
    
    # HITL
    confirmed_by_human: bool = False  # GOVERNANCE


# =============================================================================
# DECISION MODEL
# =============================================================================

@dataclass
class MeetingDecision:
    """Decision made during meeting."""
    decision_id: str = field(default_factory=lambda: f"MDEC_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    description: str = ""
    context: str = ""
    rationale: str = ""
    
    # Options
    options_discussed: List[Dict[str, Any]] = field(default_factory=list)
    selected_option: Optional[str] = None
    
    # Status
    status: DecisionStatus = DecisionStatus.PROPOSED
    
    # Participants
    proposed_by: str = ""
    approved_by: List[str] = field(default_factory=list)
    
    # HITL
    requires_hitl: bool = True  # GOVERNANCE
    hitl_approved: bool = False
    
    # Synthetic
    synthetic: bool = True


# =============================================================================
# RECORDING MODEL
# =============================================================================

@dataclass
class MeetingRecording:
    """Meeting recording (requires consent)."""
    recording_id: str = field(default_factory=lambda: f"REC_{uuid4().hex[:8]}")
    
    # Files
    audio_path: Optional[str] = None
    video_path: Optional[str] = None
    transcript_path: Optional[str] = None
    
    # Duration
    duration_seconds: int = 0
    
    # Transcript
    transcript_text: str = ""
    transcript_timecoded: List[Dict[str, Any]] = field(default_factory=list)
    
    # Consent
    all_consents_obtained: bool = False
    consent_records: Dict[str, bool] = field(default_factory=dict)
    
    # XR
    xr_session_capture: Optional[str] = None


# =============================================================================
# XR SESSION MODEL
# =============================================================================

@dataclass
class XRMeetingSession:
    """XR spatial meeting session (READ ONLY outputs)."""
    session_id: str = field(default_factory=lambda: f"XRSESS_{uuid4().hex[:8]}")
    
    # Environment
    environment_type: str = ""
    environment_url: Optional[str] = None
    
    # Objects
    spatial_annotations: List[Dict[str, Any]] = field(default_factory=list)
    models_used: List[str] = field(default_factory=list)
    scene_snapshots: List[str] = field(default_factory=list)
    
    # Manipulation log
    manipulation_log: List[Dict[str, Any]] = field(default_factory=list)
    
    # CRITICAL: XR is READ ONLY
    read_only: bool = True  # GOVERNANCE


# =============================================================================
# MEETING MODEL
# =============================================================================

@dataclass
class Meeting:
    """Complete meeting entity."""
    meeting_id: str = field(default_factory=lambda: f"MTG_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Basic info
    title: str = ""
    description: str = ""
    
    # Type and status
    meeting_type: MeetingType = MeetingType.REALTIME
    status: MeetingStatus = MeetingStatus.SCHEDULED
    
    # Timing
    scheduled_start: Optional[datetime] = None
    scheduled_end: Optional[datetime] = None
    actual_start: Optional[datetime] = None
    actual_end: Optional[datetime] = None
    
    # Participants
    organizer_id: str = ""
    participants: List[Participant] = field(default_factory=list)
    
    # Agenda
    agenda: MeetingAgenda = field(default_factory=MeetingAgenda)
    
    # Notes
    notes: MeetingNotes = field(default_factory=MeetingNotes)
    
    # Tasks
    tasks: List[MeetingTask] = field(default_factory=list)
    
    # Decisions
    decisions: List[MeetingDecision] = field(default_factory=list)
    
    # Recordings
    recording: Optional[MeetingRecording] = None
    
    # XR
    xr_session: Optional[XRMeetingSession] = None
    
    # Context
    sphere: str = "enterprise"
    domain: str = "general"
    project_id: Optional[str] = None
    thread_id: Optional[str] = None
    
    # DataSpace
    dataspace_id: Optional[str] = None
    related_dataspace_ids: List[str] = field(default_factory=list)
    
    # Attachments
    shared_files: List[str] = field(default_factory=list)
    generated_artifacts: List[str] = field(default_factory=list)
    
    # Follow-up
    followup_meeting_id: Optional[str] = None
    triggered_workflows: List[str] = field(default_factory=list)
    
    # Governance
    governance_level: str = "strict"
    audit_trail: List[Dict[str, Any]] = field(default_factory=list)
    synthetic: bool = True


# =============================================================================
# MEETING ENGINE
# =============================================================================

class MeetingEngine:
    """
    CHE·NU Meeting Engine.
    
    Manages complete meeting lifecycle from scheduling to follow-up.
    
    Features:
    - Meeting CRUD
    - Participant management
    - Real-time note taking
    - Task extraction
    - Decision capture
    - Recording management (with consent)
    - XR session support (READ ONLY)
    - DataSpace integration
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        self._meetings: Dict[str, Meeting] = {}
        logger.info("MeetingEngine initialized")
    
    # =========================================================================
    # MEETING CRUD
    # =========================================================================
    
    def create_meeting(
        self,
        title: str,
        organizer_id: str,
        scheduled_start: datetime,
        duration_minutes: int = 60,
        meeting_type: MeetingType = MeetingType.REALTIME,
        sphere: str = "enterprise",
        domain: str = "general",
    ) -> Meeting:
        """Create a new meeting."""
        meeting = Meeting(
            title=title,
            organizer_id=organizer_id,
            meeting_type=meeting_type,
            scheduled_start=scheduled_start,
            scheduled_end=scheduled_start + timedelta(minutes=duration_minutes),
            sphere=sphere,
            domain=domain,
            synthetic=True,  # GOVERNANCE
        )
        
        # Add organizer as participant
        meeting.participants.append(Participant(
            user_id=organizer_id,
            role=ParticipantRole.ORGANIZER,
        ))
        
        self._meetings[meeting.meeting_id] = meeting
        
        logger.info(f"Created meeting: {meeting.meeting_id}")
        
        return meeting
    
    def get_meeting(self, meeting_id: str) -> Optional[Meeting]:
        """Get meeting by ID."""
        return self._meetings.get(meeting_id)
    
    def start_meeting(self, meeting_id: str) -> bool:
        """Start a meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        meeting.status = MeetingStatus.IN_PROGRESS
        meeting.actual_start = datetime.utcnow()
        
        meeting.audit_trail.append({
            "action": "meeting_started",
            "timestamp": datetime.utcnow().isoformat(),
        })
        
        logger.info(f"Started meeting: {meeting_id}")
        
        return True
    
    def end_meeting(self, meeting_id: str) -> bool:
        """End a meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        meeting.status = MeetingStatus.COMPLETED
        meeting.actual_end = datetime.utcnow()
        
        meeting.audit_trail.append({
            "action": "meeting_ended",
            "timestamp": datetime.utcnow().isoformat(),
        })
        
        logger.info(f"Ended meeting: {meeting_id}")
        
        return True
    
    # =========================================================================
    # PARTICIPANTS
    # =========================================================================
    
    def add_participant(
        self,
        meeting_id: str,
        user_id: str,
        name: str = "",
        role: ParticipantRole = ParticipantRole.PARTICIPANT,
        recording_consent: bool = False,
    ) -> Optional[Participant]:
        """Add participant to meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return None
        
        participant = Participant(
            user_id=user_id,
            name=name,
            role=role,
            recording_consent=recording_consent,
        )
        
        meeting.participants.append(participant)
        
        return participant
    
    def participant_join(self, meeting_id: str, user_id: str) -> bool:
        """Mark participant as joined."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        for p in meeting.participants:
            if p.user_id == user_id:
                p.joined_at = datetime.utcnow()
                p.is_present = True
                return True
        
        return False
    
    def participant_leave(self, meeting_id: str, user_id: str) -> bool:
        """Mark participant as left."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        for p in meeting.participants:
            if p.user_id == user_id:
                p.left_at = datetime.utcnow()
                p.is_present = False
                return True
        
        return False
    
    # =========================================================================
    # AGENDA
    # =========================================================================
    
    def set_agenda(
        self,
        meeting_id: str,
        items: List[Dict[str, Any]],
    ) -> bool:
        """Set meeting agenda."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        meeting.agenda.items = [
            AgendaItem(
                title=item.get("title", ""),
                description=item.get("description", ""),
                planned_duration_minutes=item.get("duration", 15),
                presenter_id=item.get("presenter_id"),
                order=idx,
            )
            for idx, item in enumerate(items)
        ]
        
        meeting.agenda.total_planned_minutes = sum(
            i.planned_duration_minutes for i in meeting.agenda.items
        )
        
        return True
    
    # =========================================================================
    # NOTES
    # =========================================================================
    
    def add_note(
        self,
        meeting_id: str,
        content: str,
        speaker_id: Optional[str] = None,
        topic: Optional[str] = None,
    ) -> Optional[MeetingNote]:
        """Add note to meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return None
        
        note = MeetingNote(
            content=content,
            speaker_id=speaker_id,
            topic=topic,
        )
        
        meeting.notes.notes.append(note)
        
        return note
    
    def generate_summary(self, meeting_id: str) -> str:
        """Generate AI summary of meeting (requires HITL review)."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return ""
        
        # Mock AI summary
        notes_text = "\n".join(n.content for n in meeting.notes.notes)
        summary = f"Meeting Summary for {meeting.title}:\n\n"
        summary += f"Participants: {len(meeting.participants)}\n"
        summary += f"Notes captured: {len(meeting.notes.notes)}\n"
        summary += f"Tasks: {len(meeting.tasks)}\n"
        summary += f"Decisions: {len(meeting.decisions)}\n"
        
        meeting.notes.executive_summary = summary
        meeting.notes.ai_structured_notes = "[AI Summary - Requires HITL Review]"
        
        return summary
    
    # =========================================================================
    # TASKS
    # =========================================================================
    
    def add_task(
        self,
        meeting_id: str,
        title: str,
        assignee_id: Optional[str] = None,
        due_date: Optional[datetime] = None,
        ai_extracted: bool = False,
    ) -> Optional[MeetingTask]:
        """Add task extracted from meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return None
        
        task = MeetingTask(
            title=title,
            assignee_id=assignee_id,
            due_date=due_date,
            ai_extracted=ai_extracted,
            confirmed_by_human=not ai_extracted,  # GOVERNANCE
        )
        
        meeting.tasks.append(task)
        
        return task
    
    def confirm_task(self, meeting_id: str, task_id: str) -> bool:
        """Confirm AI-extracted task (HITL)."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        for task in meeting.tasks:
            if task.task_id == task_id:
                task.confirmed_by_human = True
                return True
        
        return False
    
    # =========================================================================
    # DECISIONS
    # =========================================================================
    
    def add_decision(
        self,
        meeting_id: str,
        title: str,
        description: str,
        proposed_by: str,
    ) -> Optional[MeetingDecision]:
        """Add decision to meeting."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return None
        
        decision = MeetingDecision(
            title=title,
            description=description,
            proposed_by=proposed_by,
            requires_hitl=True,  # GOVERNANCE
            synthetic=True,
        )
        
        meeting.decisions.append(decision)
        
        return decision
    
    def approve_decision(
        self,
        meeting_id: str,
        decision_id: str,
        approver_id: str,
    ) -> bool:
        """Approve a decision (HITL)."""
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        for decision in meeting.decisions:
            if decision.decision_id == decision_id:
                decision.status = DecisionStatus.APPROVED
                decision.approved_by.append(approver_id)
                decision.hitl_approved = True
                return True
        
        return False
    
    # =========================================================================
    # RECORDING (CONSENT REQUIRED)
    # =========================================================================
    
    def start_recording(self, meeting_id: str) -> bool:
        """
        Start meeting recording.
        
        GOVERNANCE: Requires consent from all participants.
        """
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return False
        
        # Check all consents
        all_consent = all(p.recording_consent for p in meeting.participants)
        if not all_consent:
            logger.warning(f"Cannot start recording - missing consents for {meeting_id}")
            return False
        
        meeting.recording = MeetingRecording(
            all_consents_obtained=True,
            consent_records={p.user_id: p.recording_consent for p in meeting.participants},
        )
        
        logger.info(f"Started recording for meeting: {meeting_id}")
        
        return True
    
    # =========================================================================
    # XR SESSION (READ ONLY)
    # =========================================================================
    
    def start_xr_session(
        self,
        meeting_id: str,
        environment_type: str,
    ) -> Optional[XRMeetingSession]:
        """
        Start XR spatial meeting session.
        
        CRITICAL: XR is READ ONLY.
        """
        meeting = self.get_meeting(meeting_id)
        if not meeting:
            return None
        
        session = XRMeetingSession(
            environment_type=environment_type,
            read_only=True,  # GOVERNANCE
        )
        
        meeting.xr_session = session
        meeting.meeting_type = MeetingType.XR_SPATIAL
        
        logger.info(f"Started XR session for meeting: {meeting_id} (READ ONLY)")
        
        return session
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get meeting statistics."""
        total = len(self._meetings)
        completed = sum(
            1 for m in self._meetings.values()
            if m.status == MeetingStatus.COMPLETED
        )
        
        return {
            "total_meetings": total,
            "completed_meetings": completed,
            "in_progress": sum(
                1 for m in self._meetings.values()
                if m.status == MeetingStatus.IN_PROGRESS
            ),
            "governance": {
                "consent_required": True,
                "hitl_for_tasks": True,
                "hitl_for_decisions": True,
                "xr_read_only": True,
                "synthetic_only": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_meeting_engine: Optional[MeetingEngine] = None


def get_meeting_engine() -> MeetingEngine:
    """Get the meeting engine singleton."""
    global _meeting_engine
    if _meeting_engine is None:
        _meeting_engine = MeetingEngine()
    return _meeting_engine
