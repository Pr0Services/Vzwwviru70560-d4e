#!/bin/bash
# ============================================================================
# CHE·NU Health Check Script
# 
# Verifies all services are healthy and R&D compliance is maintained
# 
# R&D COMPLIANCE: ✅
# - Rule #1: Verifies human gates are active
# - Rule #6: Logs all health check results
# ============================================================================

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
BACKEND_URL="${BACKEND_URL:-http://localhost:8000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
POSTGRES_HOST="${POSTGRES_HOST:-localhost}"
POSTGRES_PORT="${POSTGRES_PORT:-5432}"
REDIS_HOST="${REDIS_HOST:-localhost}"
REDIS_PORT="${REDIS_PORT:-6379}"

# Counters
PASSED=0
FAILED=0
WARNINGS=0

# Logging
LOG_FILE="/var/log/chenu/healthcheck-$(date +%Y%m%d-%H%M%S).log"
mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || LOG_FILE="/tmp/healthcheck-$(date +%Y%m%d-%H%M%S).log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

check_pass() {
    echo -e "${GREEN}✓ $1${NC}"
    log "PASS: $1"
    ((PASSED++))
}

check_fail() {
    echo -e "${RED}✗ $1${NC}"
    log "FAIL: $1"
    ((FAILED++))
}

check_warn() {
    echo -e "${YELLOW}⚠ $1${NC}"
    log "WARN: $1"
    ((WARNINGS++))
}

header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}\n"
}

# ============================================================================
# Service Checks
# ============================================================================

check_backend_health() {
    header "Backend Health Check"
    
    # Basic health endpoint
    if curl -sf "${BACKEND_URL}/health" > /dev/null 2>&1; then
        check_pass "Backend health endpoint responding"
    else
        check_fail "Backend health endpoint not responding"
        return 1
    fi
    
    # Get detailed health info
    HEALTH_RESPONSE=$(curl -sf "${BACKEND_URL}/health" 2>/dev/null || echo '{}')
    
    # Check database connection
    if echo "$HEALTH_RESPONSE" | grep -q '"database":\s*"healthy"'; then
        check_pass "Backend database connection healthy"
    else
        check_fail "Backend database connection unhealthy"
    fi
    
    # Check Redis connection
    if echo "$HEALTH_RESPONSE" | grep -q '"redis":\s*"healthy"'; then
        check_pass "Backend Redis connection healthy"
    else
        check_warn "Backend Redis connection unhealthy (non-critical)"
    fi
    
    # Check API version
    API_VERSION=$(echo "$HEALTH_RESPONSE" | grep -o '"version":\s*"[^"]*"' | sed 's/.*"version":\s*"\([^"]*\)".*/\1/' || echo "unknown")
    log "API Version: $API_VERSION"
    check_pass "Backend API version: $API_VERSION"
}

check_backend_api() {
    header "Backend API Endpoints"
    
    # Auth endpoints
    if curl -sf -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v2/auth/health" | grep -q "200\|401"; then
        check_pass "Auth endpoint responding"
    else
        check_fail "Auth endpoint not responding"
    fi
    
    # Thread endpoints
    if curl -sf -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v2/threads" | grep -q "200\|401"; then
        check_pass "Thread endpoint responding"
    else
        check_fail "Thread endpoint not responding"
    fi
    
    # Sphere endpoints
    if curl -sf -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v2/spheres" | grep -q "200\|401"; then
        check_pass "Sphere endpoint responding"
    else
        check_fail "Sphere endpoint not responding"
    fi
    
    # Nova endpoints
    if curl -sf -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v2/nova/health" | grep -q "200\|401"; then
        check_pass "Nova endpoint responding"
    else
        check_warn "Nova endpoint not responding (may be disabled)"
    fi
    
    # Governance endpoints (critical for R&D compliance)
    if curl -sf -o /dev/null -w "%{http_code}" "${BACKEND_URL}/api/v2/governance/health" | grep -q "200\|401"; then
        check_pass "Governance endpoint responding (R&D Rule #1)"
    else
        check_fail "Governance endpoint not responding - R&D VIOLATION"
    fi
}

check_database() {
    header "Database Health Check"
    
    # Check PostgreSQL connectivity
    if pg_isready -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" > /dev/null 2>&1; then
        check_pass "PostgreSQL is accepting connections"
    else
        # Try with docker
        if docker exec chenu-postgres pg_isready > /dev/null 2>&1; then
            check_pass "PostgreSQL (Docker) is accepting connections"
        else
            check_fail "PostgreSQL is not accepting connections"
            return 1
        fi
    fi
    
    # Check migrations are current
    if command -v alembic &> /dev/null; then
        CURRENT=$(alembic current 2>/dev/null | grep -o '[a-f0-9]\{12\}' | head -1 || echo "unknown")
        HEAD=$(alembic heads 2>/dev/null | grep -o '[a-f0-9]\{12\}' | head -1 || echo "unknown")
        
        if [ "$CURRENT" = "$HEAD" ] && [ "$CURRENT" != "unknown" ]; then
            check_pass "Database migrations are current ($CURRENT)"
        else
            check_warn "Database migrations may be outdated (current: $CURRENT, head: $HEAD)"
        fi
    else
        log "Alembic not available, skipping migration check"
    fi
}

check_redis() {
    header "Redis Health Check"
    
    # Check Redis connectivity
    if redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" ping > /dev/null 2>&1; then
        check_pass "Redis is responding to PING"
    else
        # Try with docker
        if docker exec chenu-redis redis-cli ping > /dev/null 2>&1; then
            check_pass "Redis (Docker) is responding to PING"
        else
            check_warn "Redis is not responding (caching disabled)"
        fi
    fi
    
    # Check Redis memory
    REDIS_INFO=$(redis-cli -h "$REDIS_HOST" -p "$REDIS_PORT" info memory 2>/dev/null || echo "")
    if [ -n "$REDIS_INFO" ]; then
        USED_MEMORY=$(echo "$REDIS_INFO" | grep "used_memory_human" | cut -d: -f2 | tr -d '\r')
        MAX_MEMORY=$(echo "$REDIS_INFO" | grep "maxmemory_human" | cut -d: -f2 | tr -d '\r')
        log "Redis memory: $USED_MEMORY / $MAX_MEMORY"
        check_pass "Redis memory usage: $USED_MEMORY"
    fi
}

check_frontend() {
    header "Frontend Health Check"
    
    if curl -sf "${FRONTEND_URL}" > /dev/null 2>&1; then
        check_pass "Frontend is responding"
    else
        check_warn "Frontend is not responding (may be intentional)"
    fi
}

# ============================================================================
# R&D Compliance Checks
# ============================================================================

check_rnd_compliance() {
    header "R&D Compliance Verification"
    
    # Rule #1: Human Sovereignty - Check governance endpoints
    log "Checking Rule #1: Human Sovereignty..."
    GOVERNANCE_STATUS=$(curl -sf "${BACKEND_URL}/api/v2/governance/status" 2>/dev/null || echo '{}')
    
    if echo "$GOVERNANCE_STATUS" | grep -q '"human_gates_enabled":\s*true'; then
        check_pass "Rule #1: Human gates are ENABLED"
    else
        check_fail "Rule #1: Human gates may be DISABLED - R&D VIOLATION"
    fi
    
    # Rule #5: Social Restrictions - No ranking
    log "Checking Rule #5: Social Restrictions..."
    if echo "$GOVERNANCE_STATUS" | grep -q '"ranking_disabled":\s*true'; then
        check_pass "Rule #5: Ranking algorithms are DISABLED"
    else
        check_warn "Rule #5: Cannot verify ranking status"
    fi
    
    # Rule #6: Traceability - Check audit logging
    log "Checking Rule #6: Module Traceability..."
    if echo "$GOVERNANCE_STATUS" | grep -q '"audit_enabled":\s*true'; then
        check_pass "Rule #6: Audit logging is ENABLED"
    else
        check_fail "Rule #6: Audit logging may be DISABLED - R&D VIOLATION"
    fi
    
    # Check checkpoint system
    CHECKPOINT_HEALTH=$(curl -sf "${BACKEND_URL}/api/v2/governance/checkpoints/health" 2>/dev/null || echo '{}')
    if echo "$CHECKPOINT_HEALTH" | grep -q '"active":\s*true\|"status":\s*"healthy"'; then
        check_pass "Checkpoint system (HTTP 423) is active"
    else
        check_warn "Checkpoint system status unknown"
    fi
}

# ============================================================================
# Performance Checks
# ============================================================================

check_performance() {
    header "Performance Metrics"
    
    # Backend response time
    RESPONSE_TIME=$(curl -sf -o /dev/null -w "%{time_total}" "${BACKEND_URL}/health" 2>/dev/null || echo "timeout")
    
    if [ "$RESPONSE_TIME" != "timeout" ]; then
        RESPONSE_MS=$(echo "$RESPONSE_TIME * 1000" | bc 2>/dev/null || echo "$RESPONSE_TIME")
        
        if (( $(echo "$RESPONSE_TIME < 0.5" | bc -l 2>/dev/null || echo 0) )); then
            check_pass "Backend response time: ${RESPONSE_MS}ms (excellent)"
        elif (( $(echo "$RESPONSE_TIME < 1.0" | bc -l 2>/dev/null || echo 0) )); then
            check_pass "Backend response time: ${RESPONSE_MS}ms (good)"
        else
            check_warn "Backend response time: ${RESPONSE_MS}ms (slow)"
        fi
    else
        check_fail "Backend response timeout"
    fi
    
    # Check performance monitor endpoint
    PERF_SUMMARY=$(curl -sf "${BACKEND_URL}/api/v2/performance/summary" 2>/dev/null || echo '{}')
    
    if echo "$PERF_SUMMARY" | grep -q '"health_score"'; then
        HEALTH_SCORE=$(echo "$PERF_SUMMARY" | grep -o '"health_score":\s*[0-9.]*' | grep -o '[0-9.]*' | head -1)
        
        if [ -n "$HEALTH_SCORE" ]; then
            if (( $(echo "$HEALTH_SCORE >= 80" | bc -l 2>/dev/null || echo 0) )); then
                check_pass "System health score: $HEALTH_SCORE/100 (healthy)"
            elif (( $(echo "$HEALTH_SCORE >= 60" | bc -l 2>/dev/null || echo 0) )); then
                check_warn "System health score: $HEALTH_SCORE/100 (degraded)"
            else
                check_fail "System health score: $HEALTH_SCORE/100 (unhealthy)"
            fi
        fi
    fi
    
    # Check active alerts
    ALERTS=$(curl -sf "${BACKEND_URL}/api/v2/performance/alerts" 2>/dev/null || echo '[]')
    ALERT_COUNT=$(echo "$ALERTS" | grep -c '"severity"' 2>/dev/null || echo "0")
    
    if [ "$ALERT_COUNT" -eq 0 ]; then
        check_pass "No active performance alerts"
    else
        check_warn "$ALERT_COUNT active performance alert(s)"
    fi
}

# ============================================================================
# Summary
# ============================================================================

print_summary() {
    header "Health Check Summary"
    
    echo -e "Checks passed:  ${GREEN}$PASSED${NC}"
    echo -e "Checks failed:  ${RED}$FAILED${NC}"
    echo -e "Warnings:       ${YELLOW}$WARNINGS${NC}"
    echo ""
    
    if [ $FAILED -gt 0 ]; then
        echo -e "${RED}⚠️  HEALTH CHECK FAILED${NC}"
        echo -e "   See log file: $LOG_FILE"
        exit 1
    elif [ $WARNINGS -gt 0 ]; then
        echo -e "${YELLOW}✓ Health check passed with warnings${NC}"
        exit 0
    else
        echo -e "${GREEN}✓ All health checks passed${NC}"
        exit 0
    fi
}

# ============================================================================
# Main
# ============================================================================

main() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                  ║"
    echo "║              CHE·NU™ Health Check                               ║"
    echo "║                                                                  ║"
    echo "║              Governed Intelligence Operating System             ║"
    echo "║                                                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log "Starting health check..."
    
    # Run all checks
    check_backend_health
    check_backend_api
    check_database
    check_redis
    check_frontend
    check_rnd_compliance
    check_performance
    
    # Print summary
    print_summary
}

# Run main function
main "$@"
