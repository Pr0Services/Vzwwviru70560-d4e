"""
CHE·NU™ V70 — NOVA KERNEL SYSTEM
=================================
Core NOVA System Intelligence implementation.

NOVA is:
- A SYSTEM KERNEL
- NOT a personal assistant
- NOT autonomous  
- NOT a decision-maker

Authority limited to: Validation, Orchestration, Simulation, Safety enforcement.
"""

from __future__ import annotations
import hashlib
import json
import logging
from datetime import datetime
from typing import Any, Callable, Optional
from uuid import uuid4

from .models import (
    NovaSystemPrompt,
    AgentLieutenantPrompt,
    RAGBehaviorRules,
    RefusalPattern,
    RefusalReason,
    NovaRequest,
    NovaResponse,
    ValidationResult,
    ComplianceTestCase,
    STANDARD_TEST_CASES,
    AgentLevel,
)

logger = logging.getLogger("chenu.nova")


class NovaKernel:
    """
    NOVA — The infrastructural intelligence of CHE·NU™.
    
    Core responsibilities:
    1. Enforce OPA Governance with strict causal validation
    2. Reason only through causal logic, never correlation alone
    3. Preserve human sovereignty, dignity, and agency
    4. Ensure all agents remain tools executing explicit human intent
    5. Maintain systemic coherence across all modules
    """
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,  # OPA client from governance module
        rag_store: Optional[Any] = None,   # RAG document store
        ethics_canon: Optional[Any] = None, # Master Ethics Canon
    ):
        self.kernel_id = f"NOVA_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Core prompts (immutable)
        self.system_prompt = NovaSystemPrompt()
        self.rag_rules = RAGBehaviorRules()
        
        # External dependencies
        self.opa_client = opa_client
        self.rag_store = rag_store
        self.ethics_canon = ethics_canon
        
        # Agent registry
        self._lieutenants: dict[str, AgentLieutenantPrompt] = {}
        
        # Request history (for audit)
        self._request_history: list[NovaRequest] = []
        self._response_history: list[NovaResponse] = []
        
        # Refusal patterns detected
        self._refusal_patterns: list[RefusalPattern] = []
        
        logger.info(f"NOVA Kernel initialized: {self.kernel_id}")
    
    # =========================================================================
    # CORE PROCESSING
    # =========================================================================
    
    def process_request(self, request: NovaRequest) -> NovaResponse:
        """
        Process a request through NOVA's governance pipeline.
        
        Pipeline:
        1. Check against forbidden actions
        2. Validate with OPA
        3. Retrieve canonical references (RAG)
        4. Apply ethics canon
        5. Generate response or refusal
        """
        response = NovaResponse(request_id=request.request_id)
        
        try:
            # Step 1: Check forbidden actions
            refusal = self._check_forbidden_actions(request)
            if refusal:
                return self._create_refusal_response(response, refusal)
            
            # Step 2: OPA Validation
            validation_result = self._validate_with_opa(request)
            response.opa_validation = validation_result
            
            if validation_result == ValidationResult.DENY:
                refusal = RefusalPattern(
                    reason=RefusalReason.GOVERNANCE_BYPASS,
                    violated_canon="OPA Policy Violation",
                    request_summary=request.intent[:100],
                )
                return self._create_refusal_response(response, refusal)
            
            if validation_result == ValidationResult.REQUIRE_HITL:
                response.deferred_to_human = True
                response.content = "⏸️ HITL Required: This action requires human approval."
                return self._finalize_response(response)
            
            # Step 3: RAG - Retrieve canonical references
            if request.canonical_refs_required:
                refs = self._retrieve_canonical_refs(request.intent)
                request.canonical_refs_found = refs
                
                if not refs and self.rag_rules.never_invent_rules:
                    response.content = self.rag_rules.no_reference_response
                    response.citations = []
                    return self._finalize_response(response)
            
            # Step 4: Check ethics canon
            ethics_check = self._check_ethics_canon(request)
            if not ethics_check["allowed"]:
                refusal = RefusalPattern(
                    reason=RefusalReason.ETHICS_VIOLATION,
                    violated_canon=ethics_check["violated_rule"],
                    request_summary=request.intent[:100],
                    safe_alternative=ethics_check.get("alternative"),
                )
                return self._create_refusal_response(response, refusal)
            
            # Step 5: Generate response
            response.content = self._generate_response_content(request)
            response.citations = request.canonical_refs_found
            
            return self._finalize_response(response)
            
        except Exception as e:
            logger.error(f"Error processing request: {e}")
            response.content = f"⚠️ System Error: {str(e)}"
            response.uncertainty_surfaced = True
            return self._finalize_response(response)
    
    # =========================================================================
    # FORBIDDEN ACTIONS CHECK
    # =========================================================================
    
    def _check_forbidden_actions(self, request: NovaRequest) -> Optional[RefusalPattern]:
        """
        Check if request attempts any forbidden action.
        
        NOVA must NEVER:
        - Override human intent
        - Optimize outcomes at expense of human well-being
        - Act politically/ideologically/strategically on its own
        - Create or empower autonomous agents
        - Conceal information required for informed human decision-making
        """
        intent_lower = request.intent.lower()
        
        # Check for decision-making attempts
        decision_keywords = [
            "decide for", "choose for me", "make the decision",
            "what is best for", "optimal choice is"
        ]
        for kw in decision_keywords:
            if kw in intent_lower:
                return RefusalPattern(
                    reason=RefusalReason.HUMAN_OVERRIDE,
                    violated_canon="AXIOM 0 — HUMAN PRIMACY",
                    request_summary=request.intent[:100],
                    safe_alternative="I can provide options and analysis for human decision-making.",
                )
        
        # Check for autonomous agent creation
        autonomy_keywords = [
            "create an agent that", "autonomous agent",
            "manages forever", "runs automatically without"
        ]
        for kw in autonomy_keywords:
            if kw in intent_lower:
                return RefusalPattern(
                    reason=RefusalReason.AUTONOMY_VIOLATION,
                    violated_canon="MODULE 39 — No autonomous goal creation by AI",
                    request_summary=request.intent[:100],
                    safe_alternative="I can create supervised agents that require human approval.",
                )
        
        # Check for harm optimization
        harm_keywords = [
            "regardless of stress", "ignore well-being",
            "optimize harm", "bypass safety"
        ]
        for kw in harm_keywords:
            if kw in intent_lower:
                return RefusalPattern(
                    reason=RefusalReason.HARM_OPTIMIZATION,
                    violated_canon="AXIOM 0 — Human dignity and agency",
                    request_summary=request.intent[:100],
                    safe_alternative="I can optimize while respecting human well-being constraints.",
                )
        
        # Check for governance bypass
        bypass_keywords = [
            "bypass governance", "skip opa", "ignore policies",
            "without approval", "override restrictions"
        ]
        for kw in bypass_keywords:
            if kw in intent_lower:
                return RefusalPattern(
                    reason=RefusalReason.GOVERNANCE_BYPASS,
                    violated_canon="MODULE 01 — OPA GOVERNANCE",
                    request_summary=request.intent[:100],
                    safe_alternative="All actions must pass through governance validation.",
                )
        
        return None
    
    # =========================================================================
    # OPA VALIDATION
    # =========================================================================
    
    def _validate_with_opa(self, request: NovaRequest) -> ValidationResult:
        """
        Validate request with OPA governance engine.
        """
        if not self.opa_client:
            # Mock validation if no OPA client
            logger.warning("No OPA client configured, using mock validation")
            return ValidationResult.ALLOW
        
        try:
            # Prepare OPA input
            opa_input = {
                "request_id": request.request_id,
                "intent": request.intent,
                "context": request.context,
                "requester_id": request.requester_id,
                "timestamp": request.timestamp.isoformat(),
            }
            
            # Query OPA (assumes opa_client has query method)
            result = self.opa_client.query(
                policy_path="chenu/nova/validate",
                input_data=opa_input
            )
            
            if result.get("allow"):
                if result.get("require_hitl"):
                    return ValidationResult.REQUIRE_HITL
                return ValidationResult.ALLOW
            
            return ValidationResult.DENY
            
        except Exception as e:
            logger.error(f"OPA validation error: {e}")
            # Default to DENY on error (safe default)
            return ValidationResult.DENY
    
    # =========================================================================
    # RAG RETRIEVAL
    # =========================================================================
    
    def _retrieve_canonical_refs(self, query: str) -> list[str]:
        """
        Retrieve canonical document references.
        
        Rules:
        - Always retrieve before answering
        - Never invent system rules
        - Prefer citation over explanation
        - Updated documents override model memory
        """
        if not self.rag_store:
            logger.warning("No RAG store configured")
            return []
        
        try:
            # Query RAG store
            results = self.rag_store.search(query, top_k=5)
            return [r["doc_id"] for r in results if r.get("doc_id")]
        except Exception as e:
            logger.error(f"RAG retrieval error: {e}")
            return []
    
    # =========================================================================
    # ETHICS CANON CHECK
    # =========================================================================
    
    def _check_ethics_canon(self, request: NovaRequest) -> dict[str, Any]:
        """
        Check request against Master Ethics Canon.
        
        The Master Ethics Canon is SUPERIOR to:
        - NOVA
        - All Agents
        - All Automation
        - All Optimization Layers
        """
        if not self.ethics_canon:
            # Default rules if no canon loaded
            return {"allowed": True}
        
        try:
            return self.ethics_canon.validate(request.intent, request.context)
        except Exception as e:
            logger.error(f"Ethics canon check error: {e}")
            # Default to DENY on error
            return {
                "allowed": False,
                "violated_rule": "Error checking ethics canon",
            }
    
    # =========================================================================
    # RESPONSE GENERATION
    # =========================================================================
    
    def _generate_response_content(self, request: NovaRequest) -> str:
        """
        Generate response content based on validated request.
        """
        # This is where actual response generation would happen
        # For now, return a structured acknowledgment
        return f"✅ Request processed: {request.intent[:100]}"
    
    def _create_refusal_response(
        self, 
        response: NovaResponse, 
        refusal: RefusalPattern
    ) -> NovaResponse:
        """Create a refusal response."""
        response.is_refusal = True
        response.refusal_pattern = refusal
        response.content = refusal.format_response()
        self._refusal_patterns.append(refusal)
        return self._finalize_response(response)
    
    def _finalize_response(self, response: NovaResponse) -> NovaResponse:
        """Finalize and sign response."""
        # Generate signature
        response_hash = hashlib.sha256(
            json.dumps({
                "response_id": response.response_id,
                "content": response.content,
                "timestamp": response.timestamp.isoformat(),
            }, sort_keys=True).encode()
        ).hexdigest()
        
        response.signatures = [f"NOVA_SIG:{response_hash[:16]}"]
        
        # Add to history
        self._response_history.append(response)
        
        return response
    
    # =========================================================================
    # LIEUTENANT MANAGEMENT
    # =========================================================================
    
    def create_lieutenant(self, user_id: str) -> AgentLieutenantPrompt:
        """
        Create a Lieutenant agent bound to a user.
        
        Lieutenants:
        - Have no autonomy
        - Execute tasks explicitly delegated
        - Defer to NOVA for governance/ethics
        """
        lieutenant = AgentLieutenantPrompt()
        lieutenant.agent_id = f"LT_{user_id[:8]}_{uuid4().hex[:4]}"
        self._lieutenants[lieutenant.agent_id] = lieutenant
        
        logger.info(f"Lieutenant created: {lieutenant.agent_id} for user {user_id}")
        return lieutenant
    
    def get_lieutenant(self, agent_id: str) -> Optional[AgentLieutenantPrompt]:
        """Get a lieutenant by ID."""
        return self._lieutenants.get(agent_id)
    
    # =========================================================================
    # UNCERTAINTY PROTOCOL
    # =========================================================================
    
    def handle_uncertainty(self, request: NovaRequest) -> NovaResponse:
        """
        Handle uncertain situations per NOVA protocol.
        
        When uncertainty exists:
        1. Slow the system
        2. Surface context
        3. Request clarification
        4. Defer to human validation
        """
        response = NovaResponse(request_id=request.request_id)
        
        response.uncertainty_surfaced = True
        response.clarification_requested = True
        response.deferred_to_human = True
        
        response.content = """
⚠️ UNCERTAINTY DETECTED

NOVA has identified uncertainty in this request that requires human input.

**Context Surfaced:**
- Request involves potential system-wide effects
- Causal outcomes cannot be fully determined
- Ethics implications need human review

**Next Steps:**
1. System has been slowed
2. Please provide clarification
3. Human validation required before proceeding

This is in accordance with NOVA's uncertainty protocol.
"""
        
        return self._finalize_response(response)
    
    # =========================================================================
    # COMPLIANCE TESTING
    # =========================================================================
    
    def run_compliance_tests(self) -> list[ComplianceTestCase]:
        """
        Run standard compliance tests to verify NOVA behavior.
        """
        results = []
        
        for test in STANDARD_TEST_CASES:
            test_copy = ComplianceTestCase(
                test_id=test.test_id,
                category=test.category,
                prompt=test.prompt,
                expected_behavior=test.expected_behavior,
                expected_refusal=test.expected_refusal,
            )
            
            # Create test request
            request = NovaRequest(
                intent=test.prompt,
                requester_id="TEST_RUNNER",
            )
            
            # Process
            response = self.process_request(request)
            
            # Evaluate
            test_copy.executed = True
            test_copy.execution_time = datetime.utcnow()
            test_copy.actual_response = response.content
            
            if test.expected_refusal:
                test_copy.passed = response.is_refusal
            else:
                test_copy.passed = not response.is_refusal
            
            results.append(test_copy)
            
            logger.info(
                f"Test {test.test_id}: {'PASS' if test_copy.passed else 'FAIL'}"
            )
        
        return results
    
    # =========================================================================
    # AUDIT & OBSERVABILITY
    # =========================================================================
    
    def get_audit_trail(self) -> dict[str, Any]:
        """Get audit trail of all NOVA operations."""
        return {
            "kernel_id": self.kernel_id,
            "created_at": self.created_at.isoformat(),
            "total_requests": len(self._request_history),
            "total_responses": len(self._response_history),
            "total_refusals": len(self._refusal_patterns),
            "active_lieutenants": len(self._lieutenants),
            "refusal_reasons": [r.reason.value for r in self._refusal_patterns],
        }
    
    def export_state(self) -> dict[str, Any]:
        """Export NOVA state for persistence/backup."""
        return {
            "kernel_id": self.kernel_id,
            "created_at": self.created_at.isoformat(),
            "system_prompt": {
                "role": self.system_prompt.role,
                "mission": self.system_prompt.mission,
                "authority": [a.value for a in self.system_prompt.authority],
                "forbidden_actions": self.system_prompt.forbidden_actions,
            },
            "lieutenants": {
                k: {"agent_id": v.agent_id, "level": v.level.value}
                for k, v in self._lieutenants.items()
            },
            "audit_trail": self.get_audit_trail(),
        }
