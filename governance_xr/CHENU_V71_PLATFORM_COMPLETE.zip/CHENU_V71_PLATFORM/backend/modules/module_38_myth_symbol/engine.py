"""
CHE·NU™ V70 — MODULE 38: MYTH · SYMBOL · MEANING ENGINE
=======================================================
Maintient la cohérence symbolique et le sens dans une 
civilisation technologique avancée.

Problème Résolu:
Une société peut fonctionner techniquement tout en 
s'effondrant symboliquement.

Interdits:
- Aucun dogme
- Aucun culte
- Aucun récit imposé

CHE·NU™ ne remplace pas le sens. Elle l'empêche de disparaître.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.module_38")


class MythType(str, Enum):
    """Types de mythes."""
    FOUNDATIONAL = "foundational"
    HEROIC = "heroic"
    EXPLANATORY = "explanatory"
    CAUTIONARY = "cautionary"
    ASPIRATIONAL = "aspirational"


class SymbolCategory(str, Enum):
    """Catégories de symboles."""
    COMMUNITY = "community"
    VALUE = "value"
    ACHIEVEMENT = "achievement"
    MEMORY = "memory"
    HOPE = "hope"


class MeaningVoidType(str, Enum):
    """Types de vide de sens."""
    PURPOSE_VOID = "purpose_void"
    NARRATIVE_VOID = "narrative_void"
    SYMBOL_VOID = "symbol_void"
    RITUAL_VOID = "ritual_void"


@dataclass
class LocalMyth:
    """Mythe local d'une communauté."""
    myth_id: str = field(default_factory=lambda: f"MYTH_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    myth_type: MythType = MythType.FOUNDATIONAL
    title: str = ""
    narrative: str = ""
    
    # Sources
    historical_basis: Optional[str] = None
    verified: bool = False
    
    # Impact
    meaning_contribution: float = 0.0  # How much meaning it provides


@dataclass
class EmergentSymbol:
    """Symbole émergent de la communauté."""
    symbol_id: str = field(default_factory=lambda: f"SYM_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    category: SymbolCategory = SymbolCategory.COMMUNITY
    name: str = ""
    visual_representation: str = ""
    meaning: str = ""
    
    # Emergence
    origin_context: str = ""
    adoption_rate: float = 0.0  # How widely adopted


@dataclass
class MeaningVoid:
    """Vide de sens détecté."""
    void_id: str = field(default_factory=lambda: f"VOID_{uuid4().hex[:8]}")
    detected_at: datetime = field(default_factory=datetime.utcnow)
    
    # Detection
    community_id: str = ""
    void_type: MeaningVoidType = MeaningVoidType.PURPOSE_VOID
    severity: float = 0.0  # 0-1
    
    # Context
    context: str = ""
    
    # Resolution
    resolved: bool = False
    resolution_approach: Optional[str] = None


@dataclass
class CivicRitual:
    """Rituel civique généré."""
    ritual_id: str = field(default_factory=lambda: f"RITUAL_{uuid4().hex[:8]}")
    community_id: str = ""
    
    # Content
    name: str = ""
    purpose: str = ""
    frequency: str = ""  # daily, weekly, monthly, yearly
    
    # Elements
    symbols_used: list[str] = field(default_factory=list)
    narratives_referenced: list[str] = field(default_factory=list)
    
    # Status
    active: bool = True
    participation_rate: float = 0.0


@dataclass
class CollectiveNarrative:
    """Récit collectif généré."""
    narrative_id: str = field(default_factory=lambda: f"NARR_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    story: str = ""
    moral: str = ""
    
    # Sources
    myths_integrated: list[str] = field(default_factory=list)
    symbols_featured: list[str] = field(default_factory=list)
    
    # Constraints
    no_dogma: bool = True
    no_cult: bool = True
    no_imposition: bool = True
    
    # Impact
    meaning_impact: float = 0.0


class MythSymbolMeaningEngine:
    """
    Module 38 — Myth · Symbol · Meaning Engine
    
    Maintient la cohérence symbolique et le sens.
    
    Fonctions:
    - Cartographie des mythes locaux
    - Analyse des symboles émergents
    - Détection de vide de sens
    - Génération de récits collectifs
    
    Sources:
    - Littérature (Module 20)
    - Histoire (Module 19)
    - Agora (Module 18)
    - Créations citoyennes
    
    Sorties:
    - Rituels civiques
    - Narrations XR
    - Recontextualisation des projets
    - Stabilisation identitaire
    
    INTERDITS:
    - Aucun dogme
    - Aucun culte
    - Aucun récit imposé
    
    CHE·NU™ ne remplace pas le sens. Elle l'empêche de disparaître.
    """
    
    # Forbidden content (HARD BANS)
    FORBIDDEN_PATTERNS = [
        "dogma",
        "worship",
        "cult",
        "mandatory belief",
        "forced participation",
        "ideological supremacy",
    ]
    
    def __init__(
        self,
        library_engine: Optional[Any] = None,  # Module 20
        history_engine: Optional[Any] = None,  # Module 19
        agora_engine: Optional[Any] = None,  # Module 18
    ):
        self.engine_id = f"MSM_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies
        self.library_engine = library_engine
        self.history_engine = history_engine
        self.agora_engine = agora_engine
        
        # Storage
        self._myths: dict[str, LocalMyth] = {}
        self._symbols: dict[str, EmergentSymbol] = {}
        self._voids: dict[str, MeaningVoid] = {}
        self._rituals: dict[str, CivicRitual] = {}
        self._narratives: dict[str, CollectiveNarrative] = {}
        
        logger.info(f"Myth Symbol Meaning Engine initialized: {self.engine_id}")
    
    # =========================================================================
    # MYTH MAPPING
    # =========================================================================
    
    def map_local_myth(
        self,
        community_id: str,
        myth_type: MythType,
        title: str,
        narrative: str,
        historical_basis: Optional[str] = None,
    ) -> LocalMyth:
        """
        Map a local myth.
        """
        # Check for forbidden patterns
        if self._contains_forbidden(narrative):
            raise ValueError("Narrative contains forbidden patterns")
        
        myth = LocalMyth(
            community_id=community_id,
            myth_type=myth_type,
            title=title,
            narrative=narrative,
            historical_basis=historical_basis,
        )
        
        # Verify if historical basis provided
        if historical_basis:
            myth.verified = True
        
        # Calculate meaning contribution
        myth.meaning_contribution = self._calculate_meaning_contribution(myth)
        
        self._myths[myth.myth_id] = myth
        logger.info(f"Myth mapped: {myth.myth_id}")
        
        return myth
    
    def _contains_forbidden(self, text: str) -> bool:
        """Check if text contains forbidden patterns."""
        text_lower = text.lower()
        for pattern in self.FORBIDDEN_PATTERNS:
            if pattern in text_lower:
                return True
        return False
    
    def _calculate_meaning_contribution(self, myth: LocalMyth) -> float:
        """Calculate how much meaning a myth contributes."""
        score = 0.0
        
        # Type contribution
        type_scores = {
            MythType.FOUNDATIONAL: 0.4,
            MythType.HEROIC: 0.3,
            MythType.EXPLANATORY: 0.3,
            MythType.CAUTIONARY: 0.2,
            MythType.ASPIRATIONAL: 0.35,
        }
        score += type_scores.get(myth.myth_type, 0.2)
        
        # Verification bonus
        if myth.verified:
            score += 0.2
        
        # Narrative depth
        if len(myth.narrative) > 500:
            score += 0.2
        elif len(myth.narrative) > 200:
            score += 0.1
        
        return min(score, 1.0)
    
    # =========================================================================
    # SYMBOL ANALYSIS
    # =========================================================================
    
    def analyze_emergent_symbol(
        self,
        community_id: str,
        category: SymbolCategory,
        name: str,
        meaning: str,
        origin_context: str,
    ) -> EmergentSymbol:
        """
        Analyze and register an emergent symbol.
        """
        symbol = EmergentSymbol(
            community_id=community_id,
            category=category,
            name=name,
            meaning=meaning,
            origin_context=origin_context,
        )
        
        self._symbols[symbol.symbol_id] = symbol
        logger.info(f"Symbol analyzed: {symbol.symbol_id}")
        
        return symbol
    
    def track_symbol_adoption(
        self,
        symbol_id: str,
        adoption_delta: float,
    ) -> EmergentSymbol:
        """Track symbol adoption rate."""
        symbol = self._symbols.get(symbol_id)
        if not symbol:
            raise ValueError(f"Symbol not found: {symbol_id}")
        
        symbol.adoption_rate = min(symbol.adoption_rate + adoption_delta, 1.0)
        return symbol
    
    # =========================================================================
    # MEANING VOID DETECTION
    # =========================================================================
    
    def detect_meaning_void(
        self,
        community_id: str,
        purpose_score: float,
        narrative_score: float,
        symbol_score: float,
        ritual_score: float,
    ) -> list[MeaningVoid]:
        """
        Detect meaning voids in a community.
        """
        voids = []
        threshold = 0.3
        
        if purpose_score < threshold:
            void = MeaningVoid(
                community_id=community_id,
                void_type=MeaningVoidType.PURPOSE_VOID,
                severity=1 - purpose_score,
                context="Low sense of purpose detected",
            )
            voids.append(void)
            self._voids[void.void_id] = void
        
        if narrative_score < threshold:
            void = MeaningVoid(
                community_id=community_id,
                void_type=MeaningVoidType.NARRATIVE_VOID,
                severity=1 - narrative_score,
                context="Lack of shared narratives",
            )
            voids.append(void)
            self._voids[void.void_id] = void
        
        if symbol_score < threshold:
            void = MeaningVoid(
                community_id=community_id,
                void_type=MeaningVoidType.SYMBOL_VOID,
                severity=1 - symbol_score,
                context="Insufficient symbolic representation",
            )
            voids.append(void)
            self._voids[void.void_id] = void
        
        if ritual_score < threshold:
            void = MeaningVoid(
                community_id=community_id,
                void_type=MeaningVoidType.RITUAL_VOID,
                severity=1 - ritual_score,
                context="Lack of civic rituals",
            )
            voids.append(void)
            self._voids[void.void_id] = void
        
        if voids:
            logger.warning(f"Meaning voids detected: {len(voids)} for {community_id}")
        
        return voids
    
    # =========================================================================
    # NARRATIVE GENERATION
    # =========================================================================
    
    def generate_collective_narrative(
        self,
        community_id: str,
        title: str,
        theme: str,
        myth_ids: list[str] = None,
        symbol_ids: list[str] = None,
    ) -> CollectiveNarrative:
        """
        Generate a collective narrative.
        
        CONSTRAINTS:
        - No dogma
        - No cult
        - No imposition
        """
        narrative = CollectiveNarrative(
            community_id=community_id,
            title=title,
            myths_integrated=myth_ids or [],
            symbols_featured=symbol_ids or [],
        )
        
        # Generate story (simplified)
        narrative.story = f"A collective story about {theme} for community {community_id}"
        narrative.moral = f"The shared wisdom of {theme}"
        
        # Enforce constraints
        narrative.no_dogma = True
        narrative.no_cult = True
        narrative.no_imposition = True
        
        # Calculate impact
        narrative.meaning_impact = 0.3
        if myth_ids:
            narrative.meaning_impact += 0.2 * min(len(myth_ids), 3) / 3
        if symbol_ids:
            narrative.meaning_impact += 0.2 * min(len(symbol_ids), 3) / 3
        
        self._narratives[narrative.narrative_id] = narrative
        logger.info(f"Collective narrative generated: {narrative.narrative_id}")
        
        return narrative
    
    # =========================================================================
    # CIVIC RITUALS
    # =========================================================================
    
    def create_civic_ritual(
        self,
        community_id: str,
        name: str,
        purpose: str,
        frequency: str,
        symbol_ids: list[str] = None,
    ) -> CivicRitual:
        """
        Create a civic ritual.
        
        NEVER forced - always voluntary participation.
        """
        ritual = CivicRitual(
            community_id=community_id,
            name=name,
            purpose=purpose,
            frequency=frequency,
            symbols_used=symbol_ids or [],
        )
        
        self._rituals[ritual.ritual_id] = ritual
        logger.info(f"Civic ritual created: {ritual.ritual_id}")
        
        return ritual
    
    # =========================================================================
    # XR NARRATIVES
    # =========================================================================
    
    def get_xr_narrative_config(
        self,
        community_id: str,
    ) -> dict[str, Any]:
        """
        Get XR configuration for narrative visualization.
        """
        community_myths = [
            m for m in self._myths.values()
            if m.community_id == community_id
        ]
        community_symbols = [
            s for s in self._symbols.values()
            if s.community_id == community_id
        ]
        
        return {
            "scene_type": "NARRATIVE_SPACE",
            "read_only": True,  # XR = READ ONLY
            "community_id": community_id,
            "components": [
                {
                    "type": "myth_gallery",
                    "myths": [m.myth_id for m in community_myths],
                    "visualization": "immersive_stories",
                },
                {
                    "type": "symbol_constellation",
                    "symbols": [s.symbol_id for s in community_symbols],
                    "visualization": "3d_network",
                },
                {
                    "type": "meaning_meter",
                    "visualization": "ambient_indicator",
                },
            ],
            "governance": {
                "no_dogma": True,
                "no_cult": True,
                "no_imposition": True,
            },
        }
    
    # =========================================================================
    # PROJECT RECONTEXTUALIZATION
    # =========================================================================
    
    def recontextualize_project(
        self,
        project_id: str,
        community_id: str,
    ) -> dict[str, Any]:
        """
        Recontextualize a project within community meaning framework.
        """
        # Get community symbols
        symbols = [
            s for s in self._symbols.values()
            if s.community_id == community_id
        ]
        
        # Get community myths
        myths = [
            m for m in self._myths.values()
            if m.community_id == community_id
        ]
        
        return {
            "project_id": project_id,
            "community_id": community_id,
            "relevant_symbols": [s.name for s in symbols[:3]],
            "relevant_myths": [m.title for m in myths[:2]],
            "meaning_alignment": 0.7 if symbols and myths else 0.3,
            "stabilization_effect": "positive" if symbols else "neutral",
        }
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        return {
            "engine_id": self.engine_id,
            "myths_mapped": len(self._myths),
            "symbols_tracked": len(self._symbols),
            "voids_detected": len(self._voids),
            "active_voids": sum(1 for v in self._voids.values() if not v.resolved),
            "rituals_created": len(self._rituals),
            "narratives_generated": len(self._narratives),
        }
