"""
============================================================================
CHE·NU™ V71 — PROJECT MANAGEMENT API ROUTES
============================================================================
Version: 1.0.0
Vertical: PROJECT_MGMT_V68

CANON COMPLIANCE:
- HTTP 423 for checkpoint blocking
- HTTP 403 for unauthorized access
- Full audit trail on all operations
- Chronological listing (NO ranking)

"GOVERNANCE > EXECUTION"
============================================================================
"""

from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Query, Path, Body
from pydantic import BaseModel, Field

from .agents.project_manager_agent import (
    ProjectManagerAgent,
    Project,
    Task,
    Milestone,
    Checkpoint,
    ProjectAnalysis,
    ProjectStatus,
    TaskStatus,
    TaskPriority,
    MilestoneStatus,
)

router = APIRouter(prefix="/api/v2/projects", tags=["Project Management"])

# Singleton agent instance
_agent: Optional[ProjectManagerAgent] = None


def get_agent() -> ProjectManagerAgent:
    """Get or create agent instance"""
    global _agent
    if _agent is None:
        _agent = ProjectManagerAgent()
    return _agent


# ============================================================================
# REQUEST/RESPONSE MODELS
# ============================================================================

class CreateProjectRequest(BaseModel):
    """Request to create a project draft"""
    name: str = Field(..., min_length=1, max_length=200)
    description: str = Field(default="")
    owner_id: str = Field(...)
    start_date: Optional[datetime] = None
    target_end_date: Optional[datetime] = None
    budget: Decimal = Field(default=Decimal("0"), ge=0)


class ApproveCheckpointRequest(BaseModel):
    """Request to approve a checkpoint"""
    approved_by: str = Field(...)
    reason: str = Field(default="")


class RejectCheckpointRequest(BaseModel):
    """Request to reject a checkpoint"""
    rejected_by: str = Field(...)
    reason: str = Field(..., min_length=1)


class CreateTaskRequest(BaseModel):
    """Request to create a task"""
    title: str = Field(..., min_length=1, max_length=500)
    description: str = Field(default="")
    priority: TaskPriority = Field(default=TaskPriority.MEDIUM)
    assignee_id: Optional[str] = None
    due_date: Optional[datetime] = None
    estimated_hours: Optional[float] = Field(default=None, ge=0)


class UpdateTaskStatusRequest(BaseModel):
    """Request to update task status"""
    new_status: TaskStatus
    updated_by: str


class CreateMilestoneRequest(BaseModel):
    """Request to create a milestone"""
    name: str = Field(..., min_length=1, max_length=200)
    description: str = Field(default="")
    target_date: datetime


class ProjectResponse(BaseModel):
    """Project response"""
    id: str
    name: str
    description: str
    status: str
    owner_id: str
    created_by: str
    created_at: datetime
    budget: str
    spent: str
    
    class Config:
        from_attributes = True


class CheckpointResponse(BaseModel):
    """Checkpoint response for HTTP 423"""
    checkpoint_id: str
    checkpoint_type: str
    action_description: str
    status: str
    message: str = "Approval required - GOVERNANCE > EXECUTION"


class TaskResponse(BaseModel):
    """Task response"""
    id: str
    project_id: str
    title: str
    description: str
    status: str
    priority: str
    assignee_id: Optional[str]
    created_by: str
    created_at: datetime
    due_date: Optional[datetime]
    
    class Config:
        from_attributes = True


# ============================================================================
# PROJECT ENDPOINTS
# ============================================================================

@router.post(
    "/",
    response_model=dict,
    status_code=201,
    summary="Create project draft",
    description="Creates a project in DRAFT status. Returns checkpoint for approval.",
)
async def create_project(
    request: CreateProjectRequest,
    created_by: str = Query(..., description="User creating the project"),
):
    """
    Create a project draft.
    
    CANON: Project starts in DRAFT, requires checkpoint approval to activate.
    Returns HTTP 201 with checkpoint_id for approval flow.
    """
    agent = get_agent()
    
    project, checkpoint = agent.create_project_draft(
        name=request.name,
        description=request.description,
        owner_id=request.owner_id,
        created_by=created_by,
        start_date=request.start_date,
        target_end_date=request.target_end_date,
        budget=request.budget,
    )
    
    return {
        "project_id": project.id,
        "status": project.status.value,
        "checkpoint_id": checkpoint.id,
        "checkpoint_status": checkpoint.status,
        "message": "Project created in DRAFT. Approval required to activate.",
        "next_action": f"POST /api/v2/projects/checkpoints/{checkpoint.id}/approve",
    }


@router.get(
    "/",
    response_model=List[dict],
    summary="List projects (chronological)",
    description="List projects in CHRONOLOGICAL order (NO ranking algorithms)",
)
async def list_projects(
    owner_id: Optional[str] = Query(None, description="Filter by owner"),
    status: Optional[ProjectStatus] = Query(None, description="Filter by status"),
):
    """
    List projects - CHRONOLOGICAL order.
    
    CANON Rule #5: NO algorithmic ranking. Newest first.
    """
    agent = get_agent()
    projects = agent.list_projects(owner_id=owner_id, status=status)
    
    return [
        {
            "id": p.id,
            "name": p.name,
            "status": p.status.value,
            "owner_id": p.owner_id,
            "created_at": p.created_at.isoformat(),
            "budget": str(p.budget),
        }
        for p in projects
    ]


@router.get(
    "/{project_id}",
    response_model=dict,
    summary="Get project details",
)
async def get_project(
    project_id: str = Path(..., description="Project ID"),
):
    """Get project by ID"""
    agent = get_agent()
    project = agent.projects.get(project_id)
    
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return {
        "id": project.id,
        "name": project.name,
        "description": project.description,
        "status": project.status.value,
        "owner_id": project.owner_id,
        "created_by": project.created_by,
        "created_at": project.created_at.isoformat(),
        "modified_by": project.modified_by,
        "modified_at": project.modified_at.isoformat() if project.modified_at else None,
        "start_date": project.start_date.isoformat() if project.start_date else None,
        "target_end_date": project.target_end_date.isoformat() if project.target_end_date else None,
        "budget": str(project.budget),
        "spent": str(project.spent),
        "team_member_ids": project.team_member_ids,
        "tags": project.tags,
    }


# ============================================================================
# CHECKPOINT ENDPOINTS (Governance)
# ============================================================================

@router.get(
    "/checkpoints/pending",
    response_model=List[dict],
    summary="List pending checkpoints",
    description="List checkpoints awaiting human approval",
)
async def list_pending_checkpoints(
    project_id: Optional[str] = Query(None, description="Filter by project"),
):
    """
    List pending checkpoints requiring human approval.
    
    CANON Rule #1: Human Sovereignty - all sensitive actions need approval
    """
    agent = get_agent()
    checkpoints = agent.get_pending_checkpoints(project_id=project_id)
    
    return [
        {
            "checkpoint_id": c.id,
            "checkpoint_type": c.checkpoint_type.value,
            "project_id": c.project_id,
            "action_description": c.action_description,
            "status": c.status,
            "requested_by": c.requested_by,
            "requested_at": c.requested_at.isoformat(),
        }
        for c in checkpoints
    ]


@router.post(
    "/checkpoints/{checkpoint_id}/approve",
    response_model=dict,
    summary="Approve checkpoint",
    description="Approve a pending checkpoint - activates the blocked action",
)
async def approve_checkpoint(
    checkpoint_id: str = Path(..., description="Checkpoint ID"),
    request: ApproveCheckpointRequest = Body(...),
):
    """
    Approve checkpoint - human decision to proceed.
    
    CANON: This is the governance gate - human explicitly approves.
    """
    agent = get_agent()
    
    try:
        project = agent.approve_project_creation(
            checkpoint_id=checkpoint_id,
            approved_by=request.approved_by,
            reason=request.reason,
        )
        
        return {
            "status": "approved",
            "project_id": project.id,
            "project_status": project.status.value,
            "approved_by": request.approved_by,
            "message": "Checkpoint approved - action executed",
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post(
    "/checkpoints/{checkpoint_id}/reject",
    response_model=dict,
    summary="Reject checkpoint",
    description="Reject a pending checkpoint - blocks the action",
)
async def reject_checkpoint(
    checkpoint_id: str = Path(..., description="Checkpoint ID"),
    request: RejectCheckpointRequest = Body(...),
):
    """
    Reject checkpoint - human decision to block action.
    
    CANON: Human can reject any action requiring approval.
    """
    agent = get_agent()
    
    try:
        agent.reject_project_creation(
            checkpoint_id=checkpoint_id,
            rejected_by=request.rejected_by,
            reason=request.reason,
        )
        
        return {
            "status": "rejected",
            "checkpoint_id": checkpoint_id,
            "rejected_by": request.rejected_by,
            "reason": request.reason,
            "message": "Checkpoint rejected - action blocked",
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# ============================================================================
# TASK ENDPOINTS
# ============================================================================

@router.post(
    "/{project_id}/tasks",
    response_model=dict,
    status_code=201,
    summary="Create task",
    description="Create a task with USER-DEFINED priority (no algorithmic ranking)",
)
async def create_task(
    project_id: str = Path(..., description="Project ID"),
    request: CreateTaskRequest = Body(...),
    created_by: str = Query(..., description="User creating the task"),
):
    """
    Create task with user-defined priority.
    
    CANON Rule #5: Priority is USER input, NOT algorithmic ranking.
    """
    agent = get_agent()
    
    try:
        task = agent.create_task(
            project_id=project_id,
            title=request.title,
            description=request.description,
            created_by=created_by,
            priority=request.priority,
            assignee_id=request.assignee_id,
            due_date=request.due_date,
            estimated_hours=request.estimated_hours,
        )
        
        return {
            "task_id": task.id,
            "project_id": task.project_id,
            "title": task.title,
            "status": task.status.value,
            "priority": task.priority.value,
            "created_by": task.created_by,
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get(
    "/{project_id}/tasks",
    response_model=List[dict],
    summary="List tasks (chronological)",
    description="List tasks in CHRONOLOGICAL order (NO engagement ranking)",
)
async def list_tasks(
    project_id: str = Path(..., description="Project ID"),
    status: Optional[TaskStatus] = Query(None, description="Filter by status"),
    assignee_id: Optional[str] = Query(None, description="Filter by assignee"),
):
    """
    List tasks - CHRONOLOGICAL order.
    
    CANON Rule #5: NO engagement/ranking algorithms. Created_at order.
    """
    agent = get_agent()
    tasks = agent.list_tasks(
        project_id=project_id,
        status=status,
        assignee_id=assignee_id,
    )
    
    return [
        {
            "id": t.id,
            "title": t.title,
            "status": t.status.value,
            "priority": t.priority.value,
            "assignee_id": t.assignee_id,
            "due_date": t.due_date.isoformat() if t.due_date else None,
            "created_at": t.created_at.isoformat(),
        }
        for t in tasks
    ]


@router.patch(
    "/{project_id}/tasks/{task_id}/status",
    response_model=dict,
    summary="Update task status",
)
async def update_task_status(
    project_id: str = Path(..., description="Project ID"),
    task_id: str = Path(..., description="Task ID"),
    request: UpdateTaskStatusRequest = Body(...),
):
    """Update task status with audit trail"""
    agent = get_agent()
    
    try:
        task = agent.update_task_status(
            task_id=task_id,
            new_status=request.new_status,
            updated_by=request.updated_by,
        )
        
        return {
            "task_id": task.id,
            "status": task.status.value,
            "modified_by": task.modified_by,
            "modified_at": task.modified_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ============================================================================
# MILESTONE ENDPOINTS
# ============================================================================

@router.post(
    "/{project_id}/milestones",
    response_model=dict,
    status_code=201,
    summary="Create milestone",
)
async def create_milestone(
    project_id: str = Path(..., description="Project ID"),
    request: CreateMilestoneRequest = Body(...),
    created_by: str = Query(..., description="User creating the milestone"),
):
    """Create project milestone"""
    agent = get_agent()
    
    try:
        milestone = agent.create_milestone(
            project_id=project_id,
            name=request.name,
            description=request.description,
            target_date=request.target_date,
            created_by=created_by,
        )
        
        return {
            "milestone_id": milestone.id,
            "name": milestone.name,
            "status": milestone.status.value,
            "target_date": milestone.target_date.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ============================================================================
# ANALYSIS ENDPOINT (Sandbox mode)
# ============================================================================

@router.get(
    "/{project_id}/analysis",
    response_model=dict,
    summary="Analyze project (read-only)",
    description="Analyze project in SANDBOX mode - does NOT modify data",
)
async def analyze_project(
    project_id: str = Path(..., description="Project ID"),
    analyzed_by: str = Query(..., description="User requesting analysis"),
):
    """
    Analyze project in sandbox mode.
    
    CANON Rule #2: Analysis is READ-ONLY, doesn't modify any data.
    Returns suggestions - HUMAN decides whether to act.
    """
    agent = get_agent()
    
    try:
        analysis = agent.analyze_project(
            project_id=project_id,
            analyzed_by=analyzed_by,
        )
        
        return {
            "project_id": analysis.project_id,
            "analyzed_at": analysis.analyzed_at.isoformat(),
            "analyzed_by": analysis.analyzed_by,
            "metrics": {
                "total_tasks": analysis.total_tasks,
                "completed_tasks": analysis.completed_tasks,
                "overdue_tasks": analysis.overdue_tasks,
                "blocked_tasks": analysis.blocked_tasks,
            },
            "timeline": {
                "days_remaining": analysis.days_remaining,
                "is_on_track": analysis.is_on_track,
            },
            "budget": {
                "used_percent": analysis.budget_used_percent,
            },
            "suggestions": analysis.suggestions,
            "note": "Analysis is READ-ONLY. Human decides which suggestions to act on.",
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ============================================================================
# HEALTH CHECK
# ============================================================================

@router.get("/health", summary="Health check")
async def health_check():
    """Health check endpoint"""
    agent = get_agent()
    return {
        "status": "healthy",
        "vertical": "PROJECT_MGMT_V68",
        "projects_count": len(agent.projects),
        "tasks_count": len(agent.tasks),
        "pending_checkpoints": len(agent.get_pending_checkpoints()),
        "canon_compliant": True,
    }
