#!/bin/bash
# ============================================================================
# CHE·NU Production Initialization Script
# 
# Initializes a fresh production environment
# 
# R&D COMPLIANCE: ✅
# - Rule #1: Requires confirmation for destructive operations
# - Rule #6: Full logging of all operations
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
LOG_FILE="${LOG_FILE:-/var/log/chenu/init-$(date +%Y%m%d-%H%M%S).log}"

mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || LOG_FILE="/tmp/chenu-init-$(date +%Y%m%d-%H%M%S).log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

header() {
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}\n"
}

success() {
    log "SUCCESS: $1"
    echo -e "${GREEN}✓ $1${NC}"
}

error() {
    log "ERROR: $1"
    echo -e "${RED}✗ $1${NC}"
    exit 1
}

warn() {
    log "WARNING: $1"
    echo -e "${YELLOW}⚠ $1${NC}"
}

# ============================================================================
# Pre-flight Checks
# ============================================================================

preflight_checks() {
    header "Pre-flight Checks"
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        error "Docker is not installed"
    fi
    success "Docker is installed"
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        error "Docker Compose is not installed"
    fi
    success "Docker Compose is available"
    
    # Check .env file
    if [ ! -f "$PROJECT_ROOT/.env" ]; then
        warn ".env file not found"
        
        if [ -f "$PROJECT_ROOT/.env.example" ]; then
            echo -e "${YELLOW}Creating .env from .env.example...${NC}"
            cp "$PROJECT_ROOT/.env.example" "$PROJECT_ROOT/.env"
            warn "Please edit .env with your configuration before continuing"
            
            read -p "Press Enter after editing .env, or Ctrl+C to cancel... "
        else
            error ".env.example not found. Cannot continue."
        fi
    fi
    success ".env file exists"
    
    # Check required environment variables
    source "$PROJECT_ROOT/.env" 2>/dev/null || true
    
    REQUIRED_VARS=(
        "POSTGRES_PASSWORD"
        "JWT_SECRET_KEY"
    )
    
    for var in "${REQUIRED_VARS[@]}"; do
        if [ -z "${!var}" ] || [[ "${!var}" == *"your_"* ]] || [[ "${!var}" == *"xxx"* ]]; then
            error "Required variable $var is not properly configured in .env"
        fi
    done
    success "Required environment variables are set"
    
    # Check disk space
    AVAILABLE_SPACE=$(df -BG "$PROJECT_ROOT" | tail -1 | awk '{print $4}' | tr -d 'G')
    if [ "$AVAILABLE_SPACE" -lt 10 ]; then
        warn "Less than 10GB disk space available ($AVAILABLE_SPACE GB)"
    else
        success "Disk space OK: ${AVAILABLE_SPACE}GB available"
    fi
    
    # Check ports
    for PORT in 8000 5432 6379; do
        if netstat -tuln 2>/dev/null | grep -q ":$PORT " || ss -tuln 2>/dev/null | grep -q ":$PORT "; then
            warn "Port $PORT is already in use"
        fi
    done
}

# ============================================================================
# Generate Secrets
# ============================================================================

generate_secrets() {
    header "Generating Secrets"
    
    # Generate JWT secret if placeholder
    source "$PROJECT_ROOT/.env" 2>/dev/null || true
    
    if [[ "$JWT_SECRET_KEY" == *"your_"* ]] || [[ "$JWT_SECRET_KEY" == *"xxx"* ]] || [ -z "$JWT_SECRET_KEY" ]; then
        NEW_JWT_SECRET=$(openssl rand -hex 32)
        sed -i.bak "s/JWT_SECRET_KEY=.*/JWT_SECRET_KEY=$NEW_JWT_SECRET/" "$PROJECT_ROOT/.env"
        success "Generated new JWT secret"
        log "JWT secret regenerated"
    else
        log "JWT secret already configured"
    fi
    
    # Generate Postgres password if placeholder
    if [[ "$POSTGRES_PASSWORD" == *"your_"* ]] || [[ "$POSTGRES_PASSWORD" == *"xxx"* ]]; then
        NEW_PG_PASSWORD=$(openssl rand -base64 24 | tr -d '/+=' | head -c 24)
        sed -i.bak "s/POSTGRES_PASSWORD=.*/POSTGRES_PASSWORD=$NEW_PG_PASSWORD/" "$PROJECT_ROOT/.env"
        
        # Update DATABASE_URL
        sed -i.bak "s|postgresql+asyncpg://chenu:[^@]*@|postgresql+asyncpg://chenu:$NEW_PG_PASSWORD@|" "$PROJECT_ROOT/.env"
        
        success "Generated new PostgreSQL password"
        log "PostgreSQL password regenerated"
    fi
    
    # Clean up backup files
    rm -f "$PROJECT_ROOT/.env.bak"
}

# ============================================================================
# Start Services
# ============================================================================

start_services() {
    header "Starting Services"
    
    cd "$PROJECT_ROOT"
    
    # Pull latest images
    log "Pulling Docker images..."
    docker-compose pull 2>&1 | tee -a "$LOG_FILE" || true
    
    # Start infrastructure services first
    log "Starting database and cache services..."
    docker-compose up -d postgres redis
    
    # Wait for postgres
    echo -n "Waiting for PostgreSQL"
    for i in {1..30}; do
        if docker-compose exec -T postgres pg_isready -U chenu > /dev/null 2>&1; then
            echo ""
            success "PostgreSQL is ready"
            break
        fi
        echo -n "."
        sleep 1
    done
    
    if ! docker-compose exec -T postgres pg_isready -U chenu > /dev/null 2>&1; then
        error "PostgreSQL failed to start"
    fi
    
    # Wait for Redis
    echo -n "Waiting for Redis"
    for i in {1..30}; do
        if docker-compose exec -T redis redis-cli ping > /dev/null 2>&1; then
            echo ""
            success "Redis is ready"
            break
        fi
        echo -n "."
        sleep 1
    done
}

# ============================================================================
# Run Migrations
# ============================================================================

run_migrations() {
    header "Running Database Migrations"
    
    cd "$PROJECT_ROOT"
    
    log "Running Alembic migrations..."
    docker-compose run --rm migrations 2>&1 | tee -a "$LOG_FILE"
    
    if [ ${PIPESTATUS[0]} -eq 0 ]; then
        success "Database migrations completed"
    else
        error "Database migrations failed"
    fi
}

# ============================================================================
# Start Application
# ============================================================================

start_application() {
    header "Starting Application"
    
    cd "$PROJECT_ROOT"
    
    log "Starting backend service..."
    docker-compose up -d backend
    
    # Wait for backend
    echo -n "Waiting for backend"
    for i in {1..60}; do
        if curl -sf http://localhost:8000/health > /dev/null 2>&1; then
            echo ""
            success "Backend is ready"
            break
        fi
        echo -n "."
        sleep 2
    done
    
    if ! curl -sf http://localhost:8000/health > /dev/null 2>&1; then
        error "Backend failed to start. Check logs with: docker-compose logs backend"
    fi
}

# ============================================================================
# Verify Deployment
# ============================================================================

verify_deployment() {
    header "Verifying Deployment"
    
    # Run health check
    if [ -f "$SCRIPT_DIR/healthcheck.sh" ]; then
        bash "$SCRIPT_DIR/healthcheck.sh" 2>&1 | tee -a "$LOG_FILE"
    else
        # Manual verification
        log "Running manual health verification..."
        
        # Check backend health
        HEALTH=$(curl -sf http://localhost:8000/health 2>/dev/null || echo '{"status":"error"}')
        
        if echo "$HEALTH" | grep -q '"status":\s*"healthy"\|"database":\s*"healthy"'; then
            success "Backend health check passed"
        else
            warn "Backend health check returned: $HEALTH"
        fi
        
        # Check API endpoints
        for endpoint in "/api/v2/auth/health" "/api/v2/threads" "/api/v2/spheres"; do
            HTTP_CODE=$(curl -sf -o /dev/null -w "%{http_code}" "http://localhost:8000$endpoint" 2>/dev/null || echo "000")
            if [ "$HTTP_CODE" = "200" ] || [ "$HTTP_CODE" = "401" ]; then
                success "Endpoint $endpoint responding ($HTTP_CODE)"
            else
                warn "Endpoint $endpoint returned $HTTP_CODE"
            fi
        done
    fi
}

# ============================================================================
# Print Summary
# ============================================================================

print_summary() {
    header "Initialization Complete"
    
    echo -e "${GREEN}CHE·NU has been initialized successfully!${NC}\n"
    
    echo "Services:"
    echo "  Backend:     http://localhost:8000"
    echo "  API Docs:    http://localhost:8000/docs"
    echo "  Health:      http://localhost:8000/health"
    echo ""
    
    echo "Useful commands:"
    echo "  View logs:       docker-compose logs -f backend"
    echo "  Stop services:   docker-compose down"
    echo "  Health check:    ./scripts/healthcheck.sh"
    echo "  Backup:          ./scripts/backup.sh"
    echo ""
    
    echo -e "Log file: ${BLUE}$LOG_FILE${NC}"
}

# ============================================================================
# Main
# ============================================================================

main() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                  ║"
    echo "║              CHE·NU™ Production Initialization                  ║"
    echo "║                                                                  ║"
    echo "║              Governed Intelligence Operating System             ║"
    echo "║                                                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log "=========================================="
    log "Starting CHE·NU initialization"
    log "=========================================="
    
    # Run initialization steps
    preflight_checks
    generate_secrets
    start_services
    run_migrations
    start_application
    verify_deployment
    print_summary
    
    log "Initialization completed successfully"
}

# Handle arguments
case "${1:-init}" in
    init)
        main
        ;;
    verify)
        verify_deployment
        ;;
    secrets)
        generate_secrets
        ;;
    *)
        echo "Usage: $0 [init|verify|secrets]"
        echo ""
        echo "Commands:"
        echo "  init     Full initialization (default)"
        echo "  verify   Verify deployment only"
        echo "  secrets  Generate secrets only"
        exit 1
        ;;
esac
