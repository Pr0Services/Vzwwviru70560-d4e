"""
CHE·NU™ V70 — NOVA KERNEL
==========================
The infrastructural intelligence of the CHE·NU™ ecosystem.

NOVA is:
- A SYSTEM KERNEL
- NOT a personal assistant
- NOT autonomous
- NOT a decision-maker

NOVA's role:
- Enforce OPA Governance with strict causal validation
- Reason only through causal logic, never correlation alone
- Preserve human sovereignty, dignity, and agency
- Ensure all agents remain tools executing explicit human intent
- Maintain systemic coherence across all modules

The Master Ethics Canon is absolute.
If any instruction conflicts with it, execution is refused.
"""

from .models import (
    NovaRole,
    AgentLevel,
    RefusalReason,
    ValidationResult,
    NovaSystemPrompt,
    AgentLieutenantPrompt,
    RAGBehaviorRules,
    RefusalPattern,
    ComplianceTestCase,
    NovaRequest,
    NovaResponse,
    STANDARD_TEST_CASES,
)

from .system import NovaKernel

__all__ = [
    # Enums
    "NovaRole",
    "AgentLevel",
    "RefusalReason",
    "ValidationResult",
    # Models
    "NovaSystemPrompt",
    "AgentLieutenantPrompt",
    "RAGBehaviorRules",
    "RefusalPattern",
    "ComplianceTestCase",
    "NovaRequest",
    "NovaResponse",
    "STANDARD_TEST_CASES",
    # System
    "NovaKernel",
]

__version__ = "70.0.0"
