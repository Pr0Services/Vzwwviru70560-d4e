# MANIFEST — Module Professeur
# CHE·NU™ Integration Package
# Date: 2026-01-07
# Version: V1.0

## 📦 MODULE OVERVIEW

| Propriété | Valeur |
|-----------|--------|
| Module ID | `agents.professeur` |
| Nom | Agent Professeur |
| Version | 1.0.0 |
| Status | BETA |
| Risque | LOW |
| Dépendances | `agents.stagiaire` |

## 🎯 MISSION

Le professeur n'aide pas le système à aller plus vite.
Il l'aide à ne pas se perdre.

- Observer le système (pas les conversations)
- Marquer les échecs significatifs
- Empêcher la reconfirmation inutile
- Ramener le contexte quand le fil est perdu
- Stabiliser ce qui a déjà été compris

## 📁 STRUCTURE DES FICHIERS

```
professeur/
├── backend/
│   ├── agent_professeur.py      # 450+ lignes - Core implementation
│   └── api_routes.py            # Routes FastAPI (partagé)
├── frontend/
│   └── ProfesseurComponents.tsx # 400+ lignes - React components
└── docs/
    ├── 00_README.md
    ├── 01_CHARTE_AGENT_PROFESSEUR.md
    ├── 02_TYPES_ECHECS_MARQUABLES.md
    ├── 03_FICHIER_RECADRAGE.md
    ├── 04_RELATION_STAGIAIRE_PROFESSEUR.md
    └── 05_GUIDE_IMPLEMENTATION.md
```

## 📊 STATISTIQUES

| Type | Fichiers | Lignes |
|------|----------|--------|
| Backend Python | 2 | ~900 |
| Frontend TSX | 1 | ~400 |
| Documentation | 6 | ~150 |
| **TOTAL** | **9** | **~1,450** |

## 🔌 API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/professeur/session/start` | Démarrer session de revue |
| POST | `/professeur/session/end` | Terminer session |
| POST | `/professeur/analyze/intention` | Analyser échec intention |
| POST | `/professeur/analyze/stability` | Analyser échec stabilité |
| POST | `/professeur/recadrage` | Ajouter entrée recadrage |
| GET | `/professeur/recadrage/export` | Export pour orchestreur |
| GET | `/professeur/stats` | Statistiques |

## 🧪 TESTS

```bash
cd backend
python -m agent_professeur
# Exécute test_professeur() avec 6 tests
```

Tests couverts:
- ✓ Pas de réponse directe à l'utilisateur
- ✓ Session requise pour analyser
- ✓ Marquage d'échec fonctionne
- ✓ Fichier de recadrage fonctionne
- ✓ Session termine correctement
- ✓ Stats correctes

## 🔗 INTÉGRATION

### Backend (FastAPI)
```python
from professeur.backend.agent_professeur import AgentProfesseur
from professeur.backend.api_routes import router_professeur

app.include_router(router_professeur, prefix="/api/v1")
```

### Frontend (React)
```tsx
import { ProfesseurDashboard, EchecCard } from './professeur/frontend/ProfesseurComponents';
```

## ⚠️ CE QUI RESTE MOCK/PLACEHOLDER

- Persistance en base de données (in-memory seulement)
- Intégration avec orchestreur réel
- Notifications temps réel

## 🔐 GOUVERNANCE

- Le professeur n'est JAMAIS activé en temps réel
- Activation par cycle (humain ou gouvernance)
- Aucune action sans session active
- Fichier de recadrage jamais exposé à l'utilisateur

## 📋 CHECKLIST D'INTÉGRATION

- [ ] Copier `backend/` vers `app/modules/professeur/`
- [ ] Copier `frontend/` vers `src/modules/professeur/`
- [ ] Ajouter routes à FastAPI main
- [ ] Configurer base de données pour persistance
- [ ] Intégrer avec système d'orchestration
- [ ] Tests E2E
