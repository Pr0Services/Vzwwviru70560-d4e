"""
CHE·NU™ V70 — DATASPACE ENGINE MODELS
=====================================
Data models for the intelligent governed storage system.

Based on: DATASPACE_ENGINE_CHAPTER.md

A DataSpace is CHE·NU's fundamental unit of intelligent, governed storage.
Unlike traditional folders, a DataSpace is a structured, intelligent,
governed container that serves as a self-contained micro-environment.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4


# =============================================================================
# ENUMS
# =============================================================================

class DataSpaceType(str, Enum):
    """Types of DataSpaces."""
    PROJECT = "project"
    MEETING = "meeting"
    PROPERTY_PERSONAL = "property_personal"
    BUILDING_ENTERPRISE = "building_enterprise"
    DOCUMENT = "document"
    CREATIVE_ASSET = "creative_asset"
    CONSTRUCTION_SITE = "construction_site"
    ARCHITECTURAL_PLAN = "architectural_plan"
    UNIT = "unit"
    TENANT = "tenant"
    GENERIC = "generic"


class DataSpaceStatus(str, Enum):
    """Status of a DataSpace."""
    ACTIVE = "active"
    ARCHIVED = "archived"
    DELETED = "deleted"
    LOCKED = "locked"


class ContentType(str, Enum):
    """Content types in a DataSpace."""
    DOCUMENT = "document"
    TASK = "task"
    MEDIA = "media"
    DIAGRAM = "diagram"
    XR_SCENE = "xr_scene"
    TIMELINE = "timeline"
    AGENT_MEMORY = "agent_memory"
    DECISION = "decision"
    WORKFLOW = "workflow"
    RELATIONSHIP = "relationship"


class DocumentType(str, Enum):
    """Document types."""
    REPORT = "report"
    NOTE = "note"
    CONTRACT = "contract"
    SPECIFICATION = "specification"
    CREATIVE_SCRIPT = "creative_script"
    PLAN = "plan"
    BLUEPRINT = "blueprint"
    PERMIT = "permit"
    INVOICE = "invoice"
    LEASE = "lease"


class MediaType(str, Enum):
    """Media types."""
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    PDF = "pdf"
    BLUEPRINT = "blueprint"
    MODEL_3D = "model_3d"


class TaskStatus(str, Enum):
    """Task status."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class TaskPriority(str, Enum):
    """Task priority."""
    URGENT = "urgent"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class DiagramType(str, Enum):
    """Diagram types."""
    MERMAID = "mermaid"
    ARCHITECTURE = "architecture"
    WORKFLOW = "workflow"
    MINDMAP = "mindmap"
    ORG_CHART = "org_chart"
    ER_DIAGRAM = "er_diagram"
    GANTT = "gantt"


class HierarchyLevel(int, Enum):
    """DataSpace hierarchy levels."""
    SPHERE = 1
    DOMAIN = 2
    DATASPACE = 3
    SUB_DATASPACE = 4
    ENTITY = 5


# =============================================================================
# CONTENT MODELS
# =============================================================================

@dataclass
class DataSpaceDocument:
    """Document within a DataSpace."""
    document_id: str = field(default_factory=lambda: f"DOC_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    document_type: DocumentType = DocumentType.NOTE
    title: str = ""
    content: str = ""
    
    # Versioning
    version: int = 1
    version_history: List[Dict[str, Any]] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    author_id: str = ""
    
    # Collaboration
    collaborators: List[str] = field(default_factory=list)
    comments: List[Dict[str, Any]] = field(default_factory=list)
    
    # Export
    export_formats: List[str] = field(default_factory=lambda: ["pdf", "docx", "md"])
    
    # Governance
    synthetic: bool = True


@dataclass
class DataSpaceTask:
    """Task within a DataSpace."""
    task_id: str = field(default_factory=lambda: f"TASK_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    description: str = ""
    
    # Status
    status: TaskStatus = TaskStatus.PENDING
    priority: TaskPriority = TaskPriority.MEDIUM
    
    # Dates
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Hierarchy
    parent_task_id: Optional[str] = None
    subtasks: List[str] = field(default_factory=list)
    
    # Dependencies
    dependencies: List[str] = field(default_factory=list)
    blockers: List[str] = field(default_factory=list)
    
    # Assignment
    assignee_id: Optional[str] = None
    assignee_type: str = "user"  # user or agent
    
    # Domain
    domain_tags: List[str] = field(default_factory=list)
    
    # Time tracking
    estimated_hours: Optional[float] = None
    actual_hours: float = 0.0
    
    # Governance
    synthetic: bool = True


@dataclass
class DataSpaceMedia:
    """Media asset within a DataSpace."""
    media_id: str = field(default_factory=lambda: f"MEDIA_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    media_type: MediaType = MediaType.IMAGE
    filename: str = ""
    file_path: str = ""
    file_size: int = 0
    mime_type: str = ""
    
    # Metadata
    title: str = ""
    description: str = ""
    tags: List[str] = field(default_factory=list)
    
    # Processing
    thumbnail_path: Optional[str] = None
    transcription: Optional[str] = None  # For audio/video
    ocr_text: Optional[str] = None  # For PDFs/images
    
    # AI analysis
    ai_tags: List[str] = field(default_factory=list)
    ai_description: Optional[str] = None
    
    # XR
    xr_compatible: bool = False
    xr_placement: Optional[Dict[str, Any]] = None
    
    # Governance
    synthetic: bool = True


@dataclass
class DataSpaceDiagram:
    """Diagram within a DataSpace."""
    diagram_id: str = field(default_factory=lambda: f"DIAG_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    diagram_type: DiagramType = DiagramType.MERMAID
    title: str = ""
    source_code: str = ""  # Mermaid or other notation
    
    # Rendered
    rendered_svg: Optional[str] = None
    rendered_png: Optional[str] = None
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    
    # XR
    xr_spatial_data: Optional[Dict[str, Any]] = None
    
    # Governance
    synthetic: bool = True


@dataclass
class DataSpaceXRScene:
    """XR Scene within a DataSpace (READ ONLY)."""
    scene_id: str = field(default_factory=lambda: f"XRS_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    scene_type: str = ""  # meeting_room, property_walkthrough, etc.
    title: str = ""
    
    # 3D Data
    objects: List[Dict[str, Any]] = field(default_factory=list)
    environment: Dict[str, Any] = field(default_factory=dict)
    
    # Annotations
    annotations: List[Dict[str, Any]] = field(default_factory=list)
    
    # Multi-user
    max_participants: int = 10
    
    # CRITICAL: Always read-only
    read_only: bool = True  # GOVERNANCE


@dataclass
class DataSpaceTimeline:
    """Timeline data within a DataSpace."""
    timeline_id: str = field(default_factory=lambda: f"TL_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    
    # Events
    milestones: List[Dict[str, Any]] = field(default_factory=list)
    schedules: List[Dict[str, Any]] = field(default_factory=list)
    deadlines: List[Dict[str, Any]] = field(default_factory=list)
    logs: List[Dict[str, Any]] = field(default_factory=list)
    
    # Governance
    synthetic: bool = True


@dataclass
class AgentMemory:
    """
    Agent memory scoped to DataSpace (GOVERNED).
    
    Rules:
    - NO personal data
    - Scoped to DataSpace only
    - User can view/delete
    - Cannot cross identity boundaries
    """
    memory_id: str = field(default_factory=lambda: f"MEM_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    memory_type: str = ""  # rules, templates, structured_knowledge, preferences
    key: str = ""
    value: Any = None
    
    # Scope
    dataspace_id: str = ""
    agent_id: str = ""
    
    # Governance
    admin_approved: bool = False  # For rules
    user_deletable: bool = True
    synthetic: bool = True
    
    # Expiry
    expires_at: Optional[datetime] = None


@dataclass
class DataSpaceDecision:
    """Recorded decision within a DataSpace."""
    decision_id: str = field(default_factory=lambda: f"DEC_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    title: str = ""
    description: str = ""
    context: str = ""
    rationale: str = ""
    
    # Options
    options_considered: List[Dict[str, Any]] = field(default_factory=list)
    selected_option: Optional[str] = None
    
    # Participants
    decision_maker: str = ""
    stakeholders: List[str] = field(default_factory=list)
    
    # Audit
    audit_trail: List[Dict[str, Any]] = field(default_factory=list)
    
    # Governance
    hitl_approved: bool = False  # GOVERNANCE
    synthetic: bool = True


@dataclass
class DataSpaceRelationship:
    """Relationship between DataSpaces."""
    relationship_id: str = field(default_factory=lambda: f"REL_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Endpoints
    source_dataspace_id: str = ""
    target_dataspace_id: str = ""
    
    # Type
    relationship_type: str = ""  # parent, reference, depends_on, related_to
    
    # Metadata
    description: str = ""
    bidirectional: bool = False
    
    # Governance
    same_identity: bool = True  # MUST be same identity
    synthetic: bool = True


# =============================================================================
# DATASPACE MODEL
# =============================================================================

@dataclass
class DataSpaceMetadata:
    """Comprehensive metadata for a DataSpace."""
    # Identity
    identity_id: str = ""
    sphere: str = ""  # Personal, Enterprise, Creative, etc.
    domain: str = ""
    
    # Classification
    dataspace_type: DataSpaceType = DataSpaceType.GENERIC
    status: DataSpaceStatus = DataSpaceStatus.ACTIVE
    
    # Permissions
    owner_id: str = ""
    permissions: Dict[str, List[str]] = field(default_factory=dict)
    
    # Tags
    user_tags: List[str] = field(default_factory=list)
    ai_tags: List[str] = field(default_factory=list)
    
    # Timestamps
    created_at: datetime = field(default_factory=datetime.utcnow)
    created_by: str = ""
    modified_at: datetime = field(default_factory=datetime.utcnow)
    modified_by: str = ""
    
    # Versioning
    version: int = 1


@dataclass
class DataSpace:
    """
    CHE·NU DataSpace - Intelligent Governed Storage Unit.
    
    A DataSpace is NOT a folder. It is a self-contained micro-environment
    that understands its contents, maintains its history, respects its
    governance rules, and serves its designated purpose.
    """
    dataspace_id: str = field(default_factory=lambda: f"DS_{uuid4().hex[:8]}")
    
    # Identity
    title: str = ""
    description: str = ""
    
    # Metadata
    metadata: DataSpaceMetadata = field(default_factory=DataSpaceMetadata)
    
    # Hierarchy
    level: HierarchyLevel = HierarchyLevel.DATASPACE
    parent_id: Optional[str] = None
    children_ids: List[str] = field(default_factory=list)
    
    # Content
    documents: List[DataSpaceDocument] = field(default_factory=list)
    tasks: List[DataSpaceTask] = field(default_factory=list)
    media: List[DataSpaceMedia] = field(default_factory=list)
    diagrams: List[DataSpaceDiagram] = field(default_factory=list)
    xr_scenes: List[DataSpaceXRScene] = field(default_factory=list)
    timelines: List[DataSpaceTimeline] = field(default_factory=list)
    agent_memories: List[AgentMemory] = field(default_factory=list)
    decisions: List[DataSpaceDecision] = field(default_factory=list)
    
    # Relationships
    relationships: List[DataSpaceRelationship] = field(default_factory=list)
    
    # Governance
    synthetic: bool = True
    governance_level: str = "strict"


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_dataspace(
    title: str,
    dataspace_type: DataSpaceType,
    owner_id: str,
    sphere: str = "personal",
    domain: str = "general",
    parent_id: Optional[str] = None,
) -> DataSpace:
    """Create a new DataSpace."""
    metadata = DataSpaceMetadata(
        identity_id=owner_id,
        sphere=sphere,
        domain=domain,
        dataspace_type=dataspace_type,
        owner_id=owner_id,
        created_by=owner_id,
    )
    
    return DataSpace(
        title=title,
        metadata=metadata,
        parent_id=parent_id,
        level=HierarchyLevel.SUB_DATASPACE if parent_id else HierarchyLevel.DATASPACE,
        synthetic=True,  # GOVERNANCE
    )


def create_project_dataspace(
    title: str,
    owner_id: str,
    domain: str = "general",
) -> DataSpace:
    """Create a Project DataSpace with recommended structure."""
    ds = create_dataspace(
        title=title,
        dataspace_type=DataSpaceType.PROJECT,
        owner_id=owner_id,
        sphere="enterprise",
        domain=domain,
    )
    
    # Add recommended sub-DataSpaces
    ds.children_ids = [
        f"DS_{uuid4().hex[:8]}",  # Planning
        f"DS_{uuid4().hex[:8]}",  # Resources
        f"DS_{uuid4().hex[:8]}",  # Deliverables
    ]
    
    return ds


def create_building_dataspace(
    title: str,
    owner_id: str,
    address: str = "",
) -> DataSpace:
    """Create a Building DataSpace (Immobilier Enterprise)."""
    ds = create_dataspace(
        title=title,
        dataspace_type=DataSpaceType.BUILDING_ENTERPRISE,
        owner_id=owner_id,
        sphere="enterprise",
        domain="immobilier",
    )
    
    ds.description = address
    
    return ds


def create_meeting_dataspace(
    title: str,
    owner_id: str,
    participants: List[str] = None,
) -> DataSpace:
    """Create a Meeting DataSpace."""
    ds = create_dataspace(
        title=title,
        dataspace_type=DataSpaceType.MEETING,
        owner_id=owner_id,
        sphere="enterprise",
        domain="general",
    )
    
    # Add agenda document
    ds.documents.append(DataSpaceDocument(
        document_type=DocumentType.NOTE,
        title="Meeting Agenda",
        content="",
        author_id=owner_id,
    ))
    
    return ds
