"""
CHE·NU™ Agents Module

Exports all agent implementations.
"""

from .stagiaire.agent import (
    AgentStagiaire,
    StagiaireNote,
    PromotionCandidate,
    CooldownState,
    UserSignal,
    LearningValue,
    RecurrenceEstimate,
    Priority,
    PromotionStatus,
    StagiaireState,
)

from .professeur.agent import (
    AgentProfesseur,
    FailureMarker,
    RecenteringFile,
    FailureType,
    FailureSeverity,
    RecenteringStatus,
)

__all__ = [
    # Stagiaire
    "AgentStagiaire",
    "StagiaireNote",
    "PromotionCandidate",
    "CooldownState",
    "UserSignal",
    "LearningValue",
    "RecurrenceEstimate",
    "Priority",
    "PromotionStatus",
    "StagiaireState",
    
    # Professeur
    "AgentProfesseur",
    "FailureMarker",
    "RecenteringFile",
    "FailureType",
    "FailureSeverity",
    "RecenteringStatus",
]
