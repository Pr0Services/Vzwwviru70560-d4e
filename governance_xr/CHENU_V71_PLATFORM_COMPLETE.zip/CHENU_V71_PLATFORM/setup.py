"""
CHE·NU™ V70 — GP2 Package Setup
"""

from setuptools import setup, find_packages

setup(
    name="chenu-gp2",
    version="70.0.0",
    description="CHE·NU™ Governed Intelligence Operating System - GP2 Modules",
    author="CHE·NU Team",
    author_email="contact@chenu.io",
    url="https://github.com/chenu/chenu-v70-gp2",
    packages=find_packages(),
    python_requires=">=3.10",
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn>=0.27.0",
        "pydantic>=2.5.0",
        "httpx>=0.26.0",
        "python-multipart>=0.0.6",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "pytest-asyncio>=0.23.0",
            "pytest-cov>=4.1.0",
            "black>=24.1.0",
            "ruff>=0.1.0",
            "mypy>=1.8.0",
        ],
        "database": [
            "asyncpg>=0.29.0",
            "sqlalchemy>=2.0.0",
            "alembic>=1.13.0",
        ],
        "cache": [
            "redis>=5.0.0",
        ],
        "monitoring": [
            "prometheus-client>=0.19.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "chenu-gp2=cli.gp2_cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="chenu governance ai simulation decision-support",
    project_urls={
        "Documentation": "https://docs.chenu.io",
        "Source": "https://github.com/chenu/chenu-v70-gp2",
    },
)
