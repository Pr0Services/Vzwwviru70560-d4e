# CRM Routes
from .crm_routes import router
