# Antenne de Lecher

Notation & hypothèses testables. Si non répétable → classer en inspiration, pas en vérité.
