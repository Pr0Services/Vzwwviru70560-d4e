"""
CHE·NU WebSocket Module
=======================

Real-time communication layer for CHE·NU.

Components:
- ConnectionManager: Manages WebSocket connections and subscriptions
- EventBroadcaster: Broadcasts events to subscribers
- WebSocket Routes: FastAPI WebSocket endpoints

Usage:
    from api.websocket import (
        get_connection_manager,
        get_event_broadcaster,
        EventType,
        SubscriptionType
    )
    
    # Broadcast a Thread event
    broadcaster = get_event_broadcaster()
    await broadcaster.broadcast_thread_created(
        identity_id="user-uuid",
        thread_id="thread-uuid",
        sphere_id="sphere-uuid",
        thread_data={...}
    )

R&D COMPLIANCE:
- Rule #1: All checkpoint broadcasts require explicit human action
- Rule #3: Identity boundary enforced in all broadcasts
- Rule #6: All connections and broadcasts logged

VERSION: 1.0.0
"""

from .connection_manager import (
    ConnectionManager,
    get_connection_manager,
    WebSocketConnection,
    WebSocketMessage,
    Subscription,
    ConnectionState,
    SubscriptionType,
    EventType
)

from .event_broadcaster import (
    EventBroadcaster,
    get_event_broadcaster,
    init_event_broadcaster
)

from .websocket_routes import router as websocket_router


__all__ = [
    # Connection Manager
    "ConnectionManager",
    "get_connection_manager",
    "WebSocketConnection",
    "WebSocketMessage",
    "Subscription",
    "ConnectionState",
    "SubscriptionType",
    "EventType",
    
    # Event Broadcaster
    "EventBroadcaster",
    "get_event_broadcaster",
    "init_event_broadcaster",
    
    # Routes
    "websocket_router"
]
