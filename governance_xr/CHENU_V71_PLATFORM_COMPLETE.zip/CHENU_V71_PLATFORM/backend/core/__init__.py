"""
CHE·NU™ V70 — CORE PACKAGE
==========================
Core utilities for GP2 system.
"""

from .config import (
    GP2SystemConfig,
    GovernanceConfig,
    ConfigLoader,
    get_config,
    reload_config,
)
from .events import (
    ModuleEventType,
    ModuleEvent,
    EventBus,
    get_event_bus,
)
from .cache import (
    CacheManager,
    InMemoryCache,
    RedisCache,
    get_cache_manager,
    cached,
)

__all__ = [
    # Config
    "GP2SystemConfig",
    "GovernanceConfig",
    "ConfigLoader",
    "get_config",
    "reload_config",
    # Events
    "ModuleEventType",
    "ModuleEvent",
    "EventBus",
    "get_event_bus",
    # Cache
    "CacheManager",
    "InMemoryCache",
    "RedisCache",
    "get_cache_manager",
    "cached",
]

__version__ = "70.0.0"
