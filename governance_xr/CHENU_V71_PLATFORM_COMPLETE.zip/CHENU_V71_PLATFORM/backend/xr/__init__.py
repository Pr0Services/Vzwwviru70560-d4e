"""
CHE·NU™ V70 — XR PACKAGE
========================
XR visualization for GP2 modules.

CRITICAL: XR = READ ONLY
"""

from .scenes import (
    SceneType,
    RenderMode,
    XRVector3,
    XRColor,
    XRNode,
    XREdge,
    XRScene,
    XRSceneBuilder,
    XRSceneManager,
    COLORS,
)

__all__ = [
    "SceneType",
    "RenderMode",
    "XRVector3",
    "XRColor",
    "XRNode",
    "XREdge",
    "XRScene",
    "XRSceneBuilder",
    "XRSceneManager",
    "COLORS",
]

__version__ = "70.0.0"
