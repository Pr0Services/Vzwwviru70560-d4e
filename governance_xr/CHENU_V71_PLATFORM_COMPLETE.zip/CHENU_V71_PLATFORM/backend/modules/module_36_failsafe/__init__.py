"""
CHE·NU™ V70 — MODULE 36: CIVILIZATIONAL FAIL-SAFE & COLLAPSE PROTOCOL
CHE·NU™ ne s'arrête jamais brutalement. Elle ralentit pour survivre.
"""

from .engine import (
    CrisisType,
    ResponseLevel,
    WorldSnapshot,
    DNALedger,
    LocalSurvivalMap,
    FailsafeActivation,
    CivilizationalFailsafeEngine,
)

__all__ = [
    "CrisisType",
    "ResponseLevel",
    "WorldSnapshot",
    "DNALedger",
    "LocalSurvivalMap",
    "FailsafeActivation",
    "CivilizationalFailsafeEngine",
]

__version__ = "70.0.0"
