# Suggested commits

1) feat(governance): add shared governance types (signals, patch instructions)
2) feat(governance): add CEA interface + sample guards
3) feat(governance): add orchestrator skeleton with QCT/SES/RDC hooks
4) feat(api): add governance routes + event logging integration points
5) feat(client): add TS helpers to post signals/events/backlog items
6) test(governance): add wiring acceptance tests
