"""
CHE·NU™ V70 — LOAD TESTING
==========================
Performance and load testing with Locust.

Usage:
    locust -f tests/load_test.py --host=http://localhost:8000

GOUVERNANCE > EXÉCUTION
"""

from locust import HttpUser, task, between, events
import json
import random
import logging

logger = logging.getLogger("chenu.loadtest")


class ChenuGP2User(HttpUser):
    """
    Simulated user for CHE·NU GP2 load testing.
    """
    
    wait_time = between(1, 3)
    
    def on_start(self):
        """Setup before tests."""
        self.token = None
        self.package_ids = []
        
        # Login to get token
        response = self.client.post("/api/v1/auth/login", json={
            "username": "loadtest",
            "password": "loadtest123",
        })
        
        if response.status_code == 200:
            data = response.json()
            self.token = data.get("access_token")
    
    @property
    def headers(self):
        """Get auth headers."""
        if self.token:
            return {"Authorization": f"Bearer {self.token}"}
        return {}
    
    # =========================================================================
    # HEALTH CHECKS
    # =========================================================================
    
    @task(10)
    def health_check(self):
        """Test health endpoint."""
        self.client.get("/health")
    
    @task(5)
    def health_ready(self):
        """Test readiness endpoint."""
        self.client.get("/health/ready")
    
    # =========================================================================
    # NOVA VALIDATION
    # =========================================================================
    
    @task(20)
    def nova_validate_simple(self):
        """Test simple NOVA validation."""
        intents = [
            "Optimize resource allocation",
            "Simulate market scenario",
            "Analyze workflow efficiency",
            "Predict budget outcomes",
            "Model team dynamics",
        ]
        
        self.client.post(
            "/api/v1/nova/validate",
            headers=self.headers,
            json={
                "intent": random.choice(intents),
                "context": {"test": True},
            }
        )
    
    @task(5)
    def nova_validate_complex(self):
        """Test complex NOVA validation."""
        self.client.post(
            "/api/v1/nova/validate",
            headers=self.headers,
            json={
                "intent": "Simulate multi-year budget projection with risk factors",
                "context": {
                    "years": 5,
                    "risk_factors": ["inflation", "market_volatility"],
                    "synthetic": True,
                },
            }
        )
    
    # =========================================================================
    # ETHICS VALIDATION
    # =========================================================================
    
    @task(15)
    def ethics_validate(self):
        """Test ethics validation."""
        actions = [
            "Analyze data patterns",
            "Generate report summary",
            "Simulate decision tree",
            "Evaluate risk factors",
            "Process simulation results",
        ]
        
        self.client.post(
            "/api/v1/ethics/validate",
            headers=self.headers,
            json={
                "action_description": random.choice(actions),
                "actor_type": "system_intelligence",
            }
        )
    
    # =========================================================================
    # DECISION LOOP
    # =========================================================================
    
    @task(10)
    def decision_loop(self):
        """Test decision loop creation."""
        response = self.client.post(
            "/api/v1/civilization/decision-loop",
            headers=self.headers,
            json={
                "user_intent": f"Test decision {random.randint(1, 1000)}",
                "initial_state": {"test": True},
                "simulation_cycles": random.randint(5, 20),
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            package_id = data.get("package_id")
            if package_id:
                self.package_ids.append(package_id)
    
    @task(5)
    def get_decision_package(self):
        """Test getting decision package."""
        if self.package_ids:
            package_id = random.choice(self.package_ids)
            self.client.get(
                f"/api/v1/civilization/packages/{package_id}",
                headers=self.headers,
            )
    
    # =========================================================================
    # FAILSAFE
    # =========================================================================
    
    @task(3)
    def failsafe_status(self):
        """Test failsafe status."""
        self.client.get(
            "/api/v1/failsafe/status",
            headers=self.headers,
        )
    
    @task(2)
    def failsafe_check(self):
        """Test crisis check."""
        self.client.post(
            "/api/v1/failsafe/check",
            headers=self.headers,
            json={
                "indicators": {
                    "network_health": random.uniform(0.7, 1.0),
                    "social_cohesion": random.uniform(0.7, 1.0),
                    "supply_chain": random.uniform(0.8, 1.0),
                }
            }
        )
    
    # =========================================================================
    # GRAPHQL
    # =========================================================================
    
    @task(8)
    def graphql_health(self):
        """Test GraphQL health query."""
        query = """
        query {
            health {
                status
                version
                governance {
                    level
                    syntheticOnly
                }
            }
        }
        """
        self.client.post(
            "/graphql",
            headers=self.headers,
            json={"query": query}
        )
    
    @task(5)
    def graphql_nova_validate(self):
        """Test GraphQL NOVA mutation."""
        mutation = """
        mutation($intent: String!) {
            novaValidate(input: {intent: $intent}) {
                requestId
                validated
                isRefusal
            }
        }
        """
        self.client.post(
            "/graphql",
            headers=self.headers,
            json={
                "query": mutation,
                "variables": {"intent": f"Test intent {random.randint(1, 1000)}"}
            }
        )


class ChenuAdminUser(HttpUser):
    """
    Simulated admin user for heavy operations.
    """
    
    wait_time = between(5, 10)
    weight = 1  # Less frequent than regular users
    
    @task(1)
    def get_metrics(self):
        """Get Prometheus metrics."""
        self.client.get("/metrics")
    
    @task(1)
    def get_full_health(self):
        """Get full health status."""
        self.client.get("/health")


# =============================================================================
# EVENT HOOKS
# =============================================================================

@events.test_start.add_listener
def on_test_start(environment, **kwargs):
    """Log test start."""
    logger.info("=" * 60)
    logger.info("CHE·NU™ V70 GP2 — LOAD TEST STARTED")
    logger.info("GOUVERNANCE > EXÉCUTION")
    logger.info("=" * 60)


@events.test_stop.add_listener
def on_test_stop(environment, **kwargs):
    """Log test stop."""
    logger.info("=" * 60)
    logger.info("CHE·NU™ V70 GP2 — LOAD TEST COMPLETED")
    logger.info("=" * 60)


@events.request.add_listener
def on_request(request_type, name, response_time, response_length, exception, **kwargs):
    """Log failed requests."""
    if exception:
        logger.warning(f"Request failed: {name} - {exception}")
