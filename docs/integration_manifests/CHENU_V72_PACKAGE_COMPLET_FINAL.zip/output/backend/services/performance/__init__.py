"""
CHE·NU™ Performance Module

High-performance optimization services including:
- Query optimization with prepared statements
- N+1 detection
- Request performance monitoring
- Health scoring
- Alert management
"""

from services.performance.query_optimizer import (
    QueryOptimizer,
    QueryMetrics,
    QueryPlan,
    PreparedStatementCache,
    BatchQueryExecutor,
    NPlusOneDetector,
    EagerLoadingOptimizer,
    optimized_query,
    get_query_optimizer,
    configure_optimizer,
)

from services.performance.performance_monitor import (
    PerformanceMonitor,
    Histogram,
    RateCalculator,
    MetricType,
    MetricPoint,
    Alert,
    AlertSeverity,
    HealthScore,
    track_performance,
    get_performance_monitor,
    configure_monitor,
)

__all__ = [
    # Query Optimizer
    "QueryOptimizer",
    "QueryMetrics",
    "QueryPlan",
    "PreparedStatementCache",
    "BatchQueryExecutor",
    "NPlusOneDetector",
    "EagerLoadingOptimizer",
    "optimized_query",
    "get_query_optimizer",
    "configure_optimizer",
    
    # Performance Monitor
    "PerformanceMonitor",
    "Histogram",
    "RateCalculator",
    "MetricType",
    "MetricPoint",
    "Alert",
    "AlertSeverity",
    "HealthScore",
    "track_performance",
    "get_performance_monitor",
    "configure_monitor",
]
