"""
CHE·NU™ V70 — OCW ENGINE (OneClick Workspace)
=============================================
Instant workspace creation and configuration.

Based on: OCW_CHAPTER.md

OCW enables rapid workspace instantiation with pre-configured
templates, tools, and agent assignments.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.ocw")


# =============================================================================
# ENUMS
# =============================================================================

class WorkspaceTemplate(str, Enum):
    """Pre-defined workspace templates."""
    BLANK = "blank"
    PROJECT = "project"
    MEETING = "meeting"
    DOCUMENT = "document"
    IMMOBILIER_PROPERTY = "immobilier_property"
    CONSTRUCTION_SITE = "construction_site"
    CREATIVE_PROJECT = "creative_project"
    RESEARCH = "research"
    FINANCIAL_ANALYSIS = "financial_analysis"


class OCWStatus(str, Enum):
    """OCW creation status."""
    CREATING = "creating"
    READY = "ready"
    FAILED = "failed"


# =============================================================================
# MODELS
# =============================================================================

@dataclass
class OCWTemplate:
    """OneClick Workspace template definition."""
    template_id: str = field(default_factory=lambda: f"OCWT_{uuid4().hex[:8]}")
    
    # Definition
    name: str = ""
    description: str = ""
    template_type: WorkspaceTemplate = WorkspaceTemplate.BLANK
    
    # Structure
    initial_mode: str = "document"
    initial_layout: Dict[str, Any] = field(default_factory=dict)
    
    # Content
    default_documents: List[Dict[str, Any]] = field(default_factory=list)
    default_folders: List[str] = field(default_factory=list)
    
    # Agents
    activated_agents: List[str] = field(default_factory=list)
    
    # Context
    sphere: str = ""
    domain: str = ""
    
    # UI
    icon: str = "🚀"
    color: str = "#3F7249"


@dataclass
class OCWInstance:
    """Created OCW instance."""
    instance_id: str = field(default_factory=lambda: f"OCWI_{uuid4().hex[:8]}")
    template_id: str = ""
    
    # Creation
    created_at: datetime = field(default_factory=datetime.utcnow)
    created_by: str = ""
    
    # IDs
    workspace_id: str = ""
    dataspace_id: str = ""
    
    # Status
    status: OCWStatus = OCWStatus.CREATING
    
    # Context
    sphere: str = ""
    domain: str = ""
    identity_id: str = ""
    
    # Customization
    title: str = ""
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    # Governance
    synthetic: bool = True


# =============================================================================
# OCW ENGINE
# =============================================================================

class OCWEngine:
    """
    CHE·NU OCW Engine (OneClick Workspace).
    
    Enables rapid workspace instantiation with pre-configured
    templates, tools, and agent assignments.
    
    Features:
    - Template management
    - Instant workspace creation
    - Automatic configuration
    - Agent activation
    - DataSpace linking
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        self._templates: Dict[str, OCWTemplate] = {}
        self._instances: Dict[str, OCWInstance] = {}
        self._register_default_templates()
        logger.info("OCWEngine initialized")
    
    def _register_default_templates(self):
        """Register default OCW templates."""
        defaults = [
            OCWTemplate(
                name="Quick Project",
                description="Start a new project with board and timeline",
                template_type=WorkspaceTemplate.PROJECT,
                initial_mode="board",
                activated_agents=["organizer", "domain"],
                default_folders=["Documents", "Tasks", "Resources"],
                sphere="enterprise",
                icon="📊",
            ),
            OCWTemplate(
                name="Meeting Space",
                description="Prepare for a meeting with notes and agenda",
                template_type=WorkspaceTemplate.MEETING,
                initial_mode="document",
                activated_agents=["meeting", "notes"],
                default_documents=[
                    {"title": "Agenda", "template": "meeting_agenda"},
                    {"title": "Notes", "template": "meeting_notes"},
                ],
                sphere="enterprise",
                icon="📅",
            ),
            OCWTemplate(
                name="Property Workspace",
                description="Manage an immobilier property",
                template_type=WorkspaceTemplate.IMMOBILIER_PROPERTY,
                initial_mode="dashboard",
                activated_agents=["immobilier", "financial"],
                default_folders=["Documents", "Tenants", "Maintenance", "Finance"],
                sphere="enterprise",
                domain="immobilier",
                icon="🏠",
            ),
            OCWTemplate(
                name="Construction Site",
                description="Manage a construction project",
                template_type=WorkspaceTemplate.CONSTRUCTION_SITE,
                initial_mode="board",
                activated_agents=["construction", "safety", "timeline"],
                default_folders=["Blueprints", "Permits", "Daily Logs", "Photos"],
                sphere="enterprise",
                domain="construction",
                icon="🏗️",
            ),
            OCWTemplate(
                name="Creative Project",
                description="Start a creative project with whiteboard",
                template_type=WorkspaceTemplate.CREATIVE_PROJECT,
                initial_mode="whiteboard",
                activated_agents=["creative", "content"],
                default_folders=["Concepts", "Assets", "Drafts", "Final"],
                sphere="creative",
                icon="🎨",
            ),
            OCWTemplate(
                name="Research Space",
                description="Research and analysis workspace",
                template_type=WorkspaceTemplate.RESEARCH,
                initial_mode="document",
                activated_agents=["research", "analyst"],
                default_folders=["Sources", "Notes", "Analysis", "Reports"],
                sphere="scholar",
                icon="🔬",
            ),
            OCWTemplate(
                name="Financial Analysis",
                description="Financial analysis with spreadsheets",
                template_type=WorkspaceTemplate.FINANCIAL_ANALYSIS,
                initial_mode="spreadsheet",
                activated_agents=["financial", "analyst"],
                default_documents=[
                    {"title": "Budget", "template": "budget_template"},
                ],
                sphere="enterprise",
                domain="finance",
                icon="💰",
            ),
        ]
        
        for template in defaults:
            self._templates[template.template_id] = template
    
    # =========================================================================
    # TEMPLATE MANAGEMENT
    # =========================================================================
    
    def register_template(self, template: OCWTemplate) -> str:
        """Register a new template."""
        self._templates[template.template_id] = template
        logger.info(f"Registered template: {template.name}")
        return template.template_id
    
    def get_template(self, template_id: str) -> Optional[OCWTemplate]:
        """Get template by ID."""
        return self._templates.get(template_id)
    
    def list_templates(
        self,
        sphere: Optional[str] = None,
        domain: Optional[str] = None,
    ) -> List[OCWTemplate]:
        """List available templates."""
        templates = list(self._templates.values())
        
        if sphere:
            templates = [t for t in templates if not t.sphere or t.sphere == sphere]
        
        if domain:
            templates = [t for t in templates if not t.domain or t.domain == domain]
        
        return templates
    
    # =========================================================================
    # WORKSPACE CREATION
    # =========================================================================
    
    def create_workspace(
        self,
        template_id: str,
        user_id: str,
        identity_id: str,
        title: str = "",
        parameters: Dict[str, Any] = None,
    ) -> OCWInstance:
        """
        Create workspace from template (OneClick).
        
        GOUVERNANCE: Respects governance rules.
        """
        template = self.get_template(template_id)
        if not template:
            raise ValueError(f"Template not found: {template_id}")
        
        # Create instance
        instance = OCWInstance(
            template_id=template_id,
            created_by=user_id,
            identity_id=identity_id,
            title=title or f"New {template.name}",
            parameters=parameters or {},
            sphere=template.sphere,
            domain=template.domain,
            synthetic=True,  # GOVERNANCE
        )
        
        # Generate IDs
        instance.workspace_id = f"WS_{uuid4().hex[:8]}"
        instance.dataspace_id = f"DS_{uuid4().hex[:8]}"
        
        # Mark as ready (in production, would actually create)
        instance.status = OCWStatus.READY
        
        self._instances[instance.instance_id] = instance
        
        logger.info(f"Created workspace from template {template.name}: {instance.workspace_id}")
        
        return instance
    
    def create_from_type(
        self,
        template_type: WorkspaceTemplate,
        user_id: str,
        identity_id: str,
        title: str = "",
    ) -> OCWInstance:
        """Create workspace by template type."""
        # Find template by type
        template = next(
            (t for t in self._templates.values() if t.template_type == template_type),
            None
        )
        
        if not template:
            raise ValueError(f"No template for type: {template_type}")
        
        return self.create_workspace(
            template.template_id,
            user_id,
            identity_id,
            title,
        )
    
    # =========================================================================
    # INSTANCE MANAGEMENT
    # =========================================================================
    
    def get_instance(self, instance_id: str) -> Optional[OCWInstance]:
        """Get instance by ID."""
        return self._instances.get(instance_id)
    
    def list_instances(
        self,
        user_id: Optional[str] = None,
        identity_id: Optional[str] = None,
    ) -> List[OCWInstance]:
        """List created instances."""
        instances = list(self._instances.values())
        
        if user_id:
            instances = [i for i in instances if i.created_by == user_id]
        
        if identity_id:
            instances = [i for i in instances if i.identity_id == identity_id]
        
        return instances
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        return {
            "templates": len(self._templates),
            "instances_created": len(self._instances),
            "by_type": {
                t.value: sum(
                    1 for i in self._instances.values()
                    if self.get_template(i.template_id) and
                    self.get_template(i.template_id).template_type == t
                )
                for t in WorkspaceTemplate
            },
            "governance": {
                "synthetic_only": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_ocw_engine: Optional[OCWEngine] = None


def get_ocw_engine() -> OCWEngine:
    """Get the OCW engine singleton."""
    global _ocw_engine
    if _ocw_engine is None:
        _ocw_engine = OCWEngine()
    return _ocw_engine
