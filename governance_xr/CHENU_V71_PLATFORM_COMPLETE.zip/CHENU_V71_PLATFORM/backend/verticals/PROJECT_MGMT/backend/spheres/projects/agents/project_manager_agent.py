"""
============================================================================
CHE·NU™ V71 — PROJECT MANAGEMENT AGENT
============================================================================
Version: 1.0.0
Vertical: PROJECT_MGMT_V68
Sphere: Projects

CANON COMPLIANCE:
- Rule #1: Human Sovereignty ✓ (all actions require approval)
- Rule #2: Autonomy Isolation ✓ (sandbox mode for analysis)
- Rule #3: Sphere Integrity ✓ (projects sphere only)
- Rule #4: No AI orchestrating AI ✓ (human coordinates)
- Rule #5: No ranking algorithms ✓ (chronological/priority only)
- Rule #6: Traceability ✓ (created_by, created_at on all objects)
- Rule #7: Continuity ✓ (builds on V68 patterns)

"GOVERNANCE > EXECUTION"
============================================================================
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4
import logging

logger = logging.getLogger(__name__)


# ============================================================================
# ENUMS
# ============================================================================

class ProjectStatus(str, Enum):
    """Project lifecycle status"""
    DRAFT = "draft"
    PLANNING = "planning"
    ACTIVE = "active"
    ON_HOLD = "on_hold"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class TaskStatus(str, Enum):
    """Task status - NO ranking, user-defined priority only"""
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    BLOCKED = "blocked"
    DONE = "done"


class TaskPriority(str, Enum):
    """User-defined priority - NOT algorithmic ranking"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"


class MilestoneStatus(str, Enum):
    """Milestone status"""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    MISSED = "missed"


class CheckpointType(str, Enum):
    """Governance checkpoint types"""
    PROJECT_CREATE = "project_create"
    PROJECT_DELETE = "project_delete"
    MILESTONE_COMPLETE = "milestone_complete"
    BUDGET_CHANGE = "budget_change"
    TEAM_CHANGE = "team_change"
    STATUS_CHANGE = "status_change"


# ============================================================================
# MODELS - All with full traceability
# ============================================================================

@dataclass
class Project:
    """
    Project entity with full traceability.
    
    CANON: All objects have created_by, created_at, id
    """
    id: str
    name: str
    description: str
    status: ProjectStatus
    
    # Ownership & traceability
    owner_id: str
    created_by: str
    created_at: datetime
    modified_by: Optional[str] = None
    modified_at: Optional[datetime] = None
    
    # Planning
    start_date: Optional[datetime] = None
    target_end_date: Optional[datetime] = None
    actual_end_date: Optional[datetime] = None
    
    # Budget (user-defined, not AI-calculated)
    budget: Decimal = Decimal("0")
    spent: Decimal = Decimal("0")
    currency: str = "CAD"
    
    # Team
    team_member_ids: List[str] = field(default_factory=list)
    
    # Metadata
    tags: List[str] = field(default_factory=list)
    sphere_id: str = "projects"


@dataclass
class Task:
    """
    Task entity with user-defined priority (NOT algorithmic ranking).
    
    CANON Rule #5: NO ranking algorithms
    """
    id: str
    project_id: str
    title: str
    description: str
    status: TaskStatus
    priority: TaskPriority  # User-defined, not AI-ranked
    
    # Assignment
    assignee_id: Optional[str] = None
    
    # Traceability
    created_by: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    modified_by: Optional[str] = None
    modified_at: Optional[datetime] = None
    
    # Dates
    due_date: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Estimation (user input, not AI)
    estimated_hours: Optional[float] = None
    actual_hours: Optional[float] = None
    
    # Dependencies
    depends_on: List[str] = field(default_factory=list)
    blocks: List[str] = field(default_factory=list)


@dataclass
class Milestone:
    """Project milestone"""
    id: str
    project_id: str
    name: str
    description: str
    status: MilestoneStatus
    target_date: datetime
    
    # Traceability
    created_by: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None
    
    # Linked tasks
    task_ids: List[str] = field(default_factory=list)


@dataclass
class Checkpoint:
    """
    Governance checkpoint - BLOCKS execution until approved.
    
    CANON Rule #1: Human Sovereignty
    """
    id: str
    checkpoint_type: CheckpointType
    project_id: str
    
    # What requires approval
    action_description: str
    action_data: Dict[str, Any]
    
    # Status
    status: str = "pending"  # pending, approved, rejected
    
    # Traceability
    requested_by: str = ""
    requested_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    resolved_by: Optional[str] = None
    resolved_at: Optional[datetime] = None
    resolution_reason: Optional[str] = None


@dataclass
class ProjectAnalysis:
    """
    Read-only project analysis (sandbox mode).
    
    CANON Rule #2: Autonomy Isolation - Analysis doesn't modify data
    """
    project_id: str
    analyzed_at: datetime
    analyzed_by: str
    
    # Metrics (read-only observations)
    total_tasks: int = 0
    completed_tasks: int = 0
    overdue_tasks: int = 0
    blocked_tasks: int = 0
    
    # Timeline analysis
    days_remaining: Optional[int] = None
    is_on_track: Optional[bool] = None
    
    # Budget analysis
    budget_used_percent: float = 0.0
    
    # Suggestions (human decides whether to act)
    suggestions: List[str] = field(default_factory=list)


# ============================================================================
# PROJECT MANAGER AGENT
# ============================================================================

class ProjectManagerAgent:
    """
    Project Management Agent with full CANON compliance.
    
    PRINCIPLES:
    - GOVERNANCE > EXECUTION
    - All modifications require human approval
    - Analysis mode is read-only
    - No ranking algorithms (chronological + user priority)
    - Full audit trail
    """
    
    def __init__(self) -> None:
        self.projects: Dict[str, Project] = {}
        self.tasks: Dict[str, Task] = {}
        self.milestones: Dict[str, Milestone] = {}
        self.checkpoints: Dict[str, Checkpoint] = {}
        
        logger.info("ProjectManagerAgent initialized - GOVERNANCE > EXECUTION")
    
    # ========================================================================
    # PROJECT OPERATIONS (with checkpoints)
    # ========================================================================
    
    def create_project_draft(
        self,
        name: str,
        description: str,
        owner_id: str,
        created_by: str,
        start_date: Optional[datetime] = None,
        target_end_date: Optional[datetime] = None,
        budget: Decimal = Decimal("0"),
    ) -> Tuple[Project, Checkpoint]:
        """
        Create project DRAFT - requires approval to activate.
        
        CANON: Human Sovereignty - draft until approved
        """
        project_id = str(uuid4())
        
        project = Project(
            id=project_id,
            name=name,
            description=description,
            status=ProjectStatus.DRAFT,
            owner_id=owner_id,
            created_by=created_by,
            created_at=datetime.now(timezone.utc),
            start_date=start_date,
            target_end_date=target_end_date,
            budget=budget,
        )
        
        # Create approval checkpoint
        checkpoint = Checkpoint(
            id=str(uuid4()),
            checkpoint_type=CheckpointType.PROJECT_CREATE,
            project_id=project_id,
            action_description=f"Create project: {name}",
            action_data={
                "name": name,
                "description": description,
                "budget": str(budget),
            },
            requested_by=created_by,
        )
        
        self.projects[project_id] = project
        self.checkpoints[checkpoint.id] = checkpoint
        
        logger.info(
            f"Project draft created: {project_id} | "
            f"Checkpoint: {checkpoint.id} | "
            f"Awaiting approval"
        )
        
        return project, checkpoint
    
    def approve_project_creation(
        self,
        checkpoint_id: str,
        approved_by: str,
        reason: str = "",
    ) -> Project:
        """
        Approve project creation - activates the project.
        
        CANON: Human must explicitly approve
        """
        checkpoint = self.checkpoints.get(checkpoint_id)
        if not checkpoint:
            raise ValueError(f"Checkpoint not found: {checkpoint_id}")
        
        if checkpoint.status != "pending":
            raise ValueError(f"Checkpoint already resolved: {checkpoint.status}")
        
        project = self.projects.get(checkpoint.project_id)
        if not project:
            raise ValueError(f"Project not found: {checkpoint.project_id}")
        
        # Update checkpoint
        checkpoint.status = "approved"
        checkpoint.resolved_by = approved_by
        checkpoint.resolved_at = datetime.now(timezone.utc)
        checkpoint.resolution_reason = reason
        
        # Activate project
        project.status = ProjectStatus.PLANNING
        project.modified_by = approved_by
        project.modified_at = datetime.now(timezone.utc)
        
        logger.info(
            f"Project approved: {project.id} | "
            f"By: {approved_by} | "
            f"Status: {project.status.value}"
        )
        
        return project
    
    def reject_project_creation(
        self,
        checkpoint_id: str,
        rejected_by: str,
        reason: str,
    ) -> None:
        """Reject project creation - project stays in draft"""
        checkpoint = self.checkpoints.get(checkpoint_id)
        if not checkpoint:
            raise ValueError(f"Checkpoint not found: {checkpoint_id}")
        
        checkpoint.status = "rejected"
        checkpoint.resolved_by = rejected_by
        checkpoint.resolved_at = datetime.now(timezone.utc)
        checkpoint.resolution_reason = reason
        
        logger.info(
            f"Project rejected: {checkpoint.project_id} | "
            f"By: {rejected_by} | "
            f"Reason: {reason}"
        )
    
    # ========================================================================
    # TASK OPERATIONS
    # ========================================================================
    
    def create_task(
        self,
        project_id: str,
        title: str,
        description: str,
        created_by: str,
        priority: TaskPriority = TaskPriority.MEDIUM,
        assignee_id: Optional[str] = None,
        due_date: Optional[datetime] = None,
        estimated_hours: Optional[float] = None,
    ) -> Task:
        """
        Create task with user-defined priority.
        
        CANON Rule #5: Priority is USER-DEFINED, not algorithmic
        """
        if project_id not in self.projects:
            raise ValueError(f"Project not found: {project_id}")
        
        task = Task(
            id=str(uuid4()),
            project_id=project_id,
            title=title,
            description=description,
            status=TaskStatus.TODO,
            priority=priority,
            assignee_id=assignee_id,
            created_by=created_by,
            created_at=datetime.now(timezone.utc),
            due_date=due_date,
            estimated_hours=estimated_hours,
        )
        
        self.tasks[task.id] = task
        
        logger.info(
            f"Task created: {task.id} | "
            f"Project: {project_id} | "
            f"Priority: {priority.value} (user-defined)"
        )
        
        return task
    
    def update_task_status(
        self,
        task_id: str,
        new_status: TaskStatus,
        updated_by: str,
    ) -> Task:
        """Update task status with audit trail"""
        task = self.tasks.get(task_id)
        if not task:
            raise ValueError(f"Task not found: {task_id}")
        
        old_status = task.status
        task.status = new_status
        task.modified_by = updated_by
        task.modified_at = datetime.now(timezone.utc)
        
        if new_status == TaskStatus.DONE:
            task.completed_at = datetime.now(timezone.utc)
        
        logger.info(
            f"Task status updated: {task_id} | "
            f"{old_status.value} -> {new_status.value} | "
            f"By: {updated_by}"
        )
        
        return task
    
    def list_tasks(
        self,
        project_id: str,
        status: Optional[TaskStatus] = None,
        assignee_id: Optional[str] = None,
    ) -> List[Task]:
        """
        List tasks - CHRONOLOGICAL order, then by user priority.
        
        CANON Rule #5: NO algorithmic ranking
        """
        tasks = [t for t in self.tasks.values() if t.project_id == project_id]
        
        if status:
            tasks = [t for t in tasks if t.status == status]
        
        if assignee_id:
            tasks = [t for t in tasks if t.assignee_id == assignee_id]
        
        # Sort by created_at (chronological), NOT by engagement/ranking
        tasks.sort(key=lambda t: t.created_at)
        
        return tasks
    
    # ========================================================================
    # MILESTONE OPERATIONS
    # ========================================================================
    
    def create_milestone(
        self,
        project_id: str,
        name: str,
        description: str,
        target_date: datetime,
        created_by: str,
    ) -> Milestone:
        """Create project milestone"""
        if project_id not in self.projects:
            raise ValueError(f"Project not found: {project_id}")
        
        milestone = Milestone(
            id=str(uuid4()),
            project_id=project_id,
            name=name,
            description=description,
            status=MilestoneStatus.PENDING,
            target_date=target_date,
            created_by=created_by,
        )
        
        self.milestones[milestone.id] = milestone
        
        logger.info(f"Milestone created: {milestone.id} | Project: {project_id}")
        
        return milestone
    
    def complete_milestone(
        self,
        milestone_id: str,
        completed_by: str,
    ) -> Tuple[Milestone, Checkpoint]:
        """
        Complete milestone - requires approval checkpoint.
        
        CANON: Milestone completion is a governance event
        """
        milestone = self.milestones.get(milestone_id)
        if not milestone:
            raise ValueError(f"Milestone not found: {milestone_id}")
        
        # Create checkpoint for approval
        checkpoint = Checkpoint(
            id=str(uuid4()),
            checkpoint_type=CheckpointType.MILESTONE_COMPLETE,
            project_id=milestone.project_id,
            action_description=f"Complete milestone: {milestone.name}",
            action_data={"milestone_id": milestone_id},
            requested_by=completed_by,
        )
        
        self.checkpoints[checkpoint.id] = checkpoint
        
        logger.info(
            f"Milestone completion requested: {milestone_id} | "
            f"Checkpoint: {checkpoint.id}"
        )
        
        return milestone, checkpoint
    
    # ========================================================================
    # ANALYSIS (Read-only sandbox mode)
    # ========================================================================
    
    def analyze_project(
        self,
        project_id: str,
        analyzed_by: str,
    ) -> ProjectAnalysis:
        """
        Analyze project in SANDBOX MODE.
        
        CANON Rule #2: Analysis is read-only, doesn't modify data
        """
        project = self.projects.get(project_id)
        if not project:
            raise ValueError(f"Project not found: {project_id}")
        
        tasks = self.list_tasks(project_id)
        now = datetime.now(timezone.utc)
        
        # Calculate metrics (read-only observations)
        total_tasks = len(tasks)
        completed_tasks = len([t for t in tasks if t.status == TaskStatus.DONE])
        overdue_tasks = len([
            t for t in tasks 
            if t.due_date and t.due_date < now and t.status != TaskStatus.DONE
        ])
        blocked_tasks = len([t for t in tasks if t.status == TaskStatus.BLOCKED])
        
        # Timeline analysis
        days_remaining = None
        is_on_track = None
        if project.target_end_date:
            days_remaining = (project.target_end_date - now).days
            progress = completed_tasks / total_tasks if total_tasks > 0 else 0
            expected_progress = 1 - (days_remaining / 30) if days_remaining < 30 else 0.5
            is_on_track = progress >= expected_progress * 0.8
        
        # Budget analysis
        budget_used_percent = 0.0
        if project.budget > 0:
            budget_used_percent = float(project.spent / project.budget * 100)
        
        # Generate suggestions (human decides whether to act)
        suggestions = []
        if blocked_tasks > 0:
            suggestions.append(f"{blocked_tasks} tasks are blocked - review blockers")
        if overdue_tasks > 0:
            suggestions.append(f"{overdue_tasks} tasks are overdue - reassess deadlines")
        if budget_used_percent > 80:
            suggestions.append(f"Budget {budget_used_percent:.0f}% used - review spending")
        
        analysis = ProjectAnalysis(
            project_id=project_id,
            analyzed_at=now,
            analyzed_by=analyzed_by,
            total_tasks=total_tasks,
            completed_tasks=completed_tasks,
            overdue_tasks=overdue_tasks,
            blocked_tasks=blocked_tasks,
            days_remaining=days_remaining,
            is_on_track=is_on_track,
            budget_used_percent=budget_used_percent,
            suggestions=suggestions,
        )
        
        logger.info(
            f"Project analyzed (sandbox): {project_id} | "
            f"Tasks: {completed_tasks}/{total_tasks} | "
            f"Suggestions: {len(suggestions)}"
        )
        
        return analysis
    
    # ========================================================================
    # LISTING (Chronological, NO ranking)
    # ========================================================================
    
    def list_projects(
        self,
        owner_id: Optional[str] = None,
        status: Optional[ProjectStatus] = None,
    ) -> List[Project]:
        """
        List projects - CHRONOLOGICAL order.
        
        CANON Rule #5: NO algorithmic ranking
        """
        projects = list(self.projects.values())
        
        if owner_id:
            projects = [p for p in projects if p.owner_id == owner_id]
        
        if status:
            projects = [p for p in projects if p.status == status]
        
        # Sort CHRONOLOGICALLY by created_at
        projects.sort(key=lambda p: p.created_at, reverse=True)
        
        return projects
    
    def get_pending_checkpoints(
        self,
        project_id: Optional[str] = None,
    ) -> List[Checkpoint]:
        """List pending checkpoints requiring human approval"""
        checkpoints = [
            c for c in self.checkpoints.values()
            if c.status == "pending"
        ]
        
        if project_id:
            checkpoints = [c for c in checkpoints if c.project_id == project_id]
        
        # Chronological order
        checkpoints.sort(key=lambda c: c.requested_at)
        
        return checkpoints


# ============================================================================
# FACTORY
# ============================================================================

def create_project_manager_agent() -> ProjectManagerAgent:
    """Factory function to create agent"""
    return ProjectManagerAgent()


# ============================================================================
# MODULE INFO
# ============================================================================

__all__ = [
    "ProjectManagerAgent",
    "Project",
    "Task",
    "Milestone",
    "Checkpoint",
    "ProjectAnalysis",
    "ProjectStatus",
    "TaskStatus",
    "TaskPriority",
    "MilestoneStatus",
    "CheckpointType",
    "create_project_manager_agent",
]

MODULE_VERSION = "1.0.0"
MODULE_STATUS = "INTEGRATED"
SPHERE = "projects"
CANON_COMPLIANT = True
