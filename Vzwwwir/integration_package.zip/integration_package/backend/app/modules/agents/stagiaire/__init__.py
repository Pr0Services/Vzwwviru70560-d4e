"""
Agent Stagiaire - Qualitative Learning Agent
"""
from .agent import *
