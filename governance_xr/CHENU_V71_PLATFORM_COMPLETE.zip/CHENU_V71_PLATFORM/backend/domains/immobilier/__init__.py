"""
CHE·NU™ V70 — IMMOBILIER DOMAIN PACKAGE
=======================================
Real estate domain specialization.
"""

from .engine import (
    PropertyType, OwnershipType, LeaseStatus,
    MaintenanceStatus, MaintenancePriority,
    Address, Property, Unit, Tenant, Lease,
    MaintenanceRequest, RentPayment,
    ImmobilierEngine, get_immobilier_engine,
)

__all__ = [
    "PropertyType", "OwnershipType", "LeaseStatus",
    "MaintenanceStatus", "MaintenancePriority",
    "Address", "Property", "Unit", "Tenant", "Lease",
    "MaintenanceRequest", "RentPayment",
    "ImmobilierEngine", "get_immobilier_engine",
]

__version__ = "70.0.0"
