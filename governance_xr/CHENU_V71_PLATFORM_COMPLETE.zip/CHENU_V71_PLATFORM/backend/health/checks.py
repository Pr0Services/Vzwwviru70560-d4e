"""
CHE·NU™ V70 — HEALTH CHECKS & DIAGNOSTICS
=========================================
System health monitoring for GP2.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Optional
from uuid import uuid4
import asyncio
import logging
import time
import platform
import psutil

logger = logging.getLogger("chenu.health")


class HealthStatus(str, Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


@dataclass
class ComponentHealth:
    """Health of a single component."""
    name: str
    status: HealthStatus = HealthStatus.UNKNOWN
    message: Optional[str] = None
    latency_ms: Optional[float] = None
    last_check: datetime = field(default_factory=datetime.utcnow)
    details: dict = field(default_factory=dict)
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "latency_ms": self.latency_ms,
            "last_check": self.last_check.isoformat(),
            "details": self.details,
        }


@dataclass
class SystemHealth:
    """Overall system health."""
    status: HealthStatus = HealthStatus.UNKNOWN
    version: str = "70.0.0"
    uptime_seconds: float = 0
    components: list[ComponentHealth] = field(default_factory=list)
    
    # Governance
    governance_level: str = "strict"
    synthetic_only: bool = True
    xr_read_only: bool = True
    
    # Diagnostics
    diagnostics: dict = field(default_factory=dict)
    
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "version": self.version,
            "uptime_seconds": self.uptime_seconds,
            "components": [c.to_dict() for c in self.components],
            "governance": {
                "level": self.governance_level,
                "synthetic_only": self.synthetic_only,
                "xr_read_only": self.xr_read_only,
            },
            "diagnostics": self.diagnostics,
            "timestamp": self.timestamp.isoformat(),
        }


class HealthChecker:
    """
    Health checker for GP2 system.
    
    Monitors:
    - Database connectivity
    - Redis connectivity
    - OPA availability
    - Worker pool status
    - System resources
    """
    
    def __init__(self):
        self.checker_id = f"HEALTH_{uuid4().hex[:8]}"
        self._start_time = datetime.utcnow()
        self._checks: dict[str, Callable] = {}
        self._last_results: dict[str, ComponentHealth] = {}
        
        # Register default checks
        self._register_default_checks()
        
        logger.info(f"Health Checker initialized: {self.checker_id}")
    
    def _register_default_checks(self):
        """Register default health checks."""
        self.register_check("system", self._check_system)
        self.register_check("governance", self._check_governance)
    
    def register_check(self, name: str, check_fn: Callable):
        """Register a health check."""
        self._checks[name] = check_fn
    
    # =========================================================================
    # HEALTH CHECKS
    # =========================================================================
    
    async def check_all(self) -> SystemHealth:
        """Run all health checks."""
        components = []
        
        for name, check_fn in self._checks.items():
            start = time.time()
            try:
                if asyncio.iscoroutinefunction(check_fn):
                    result = await check_fn()
                else:
                    result = check_fn()
                
                latency = (time.time() - start) * 1000
                
                component = ComponentHealth(
                    name=name,
                    status=result.get("status", HealthStatus.HEALTHY),
                    message=result.get("message"),
                    latency_ms=latency,
                    details=result.get("details", {}),
                )
            except Exception as e:
                component = ComponentHealth(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=str(e),
                )
            
            components.append(component)
            self._last_results[name] = component
        
        # Calculate overall status
        overall_status = self._calculate_overall_status(components)
        
        # Get system diagnostics
        diagnostics = await self._get_diagnostics()
        
        return SystemHealth(
            status=overall_status,
            uptime_seconds=(datetime.utcnow() - self._start_time).total_seconds(),
            components=components,
            diagnostics=diagnostics,
        )
    
    def _calculate_overall_status(
        self,
        components: list[ComponentHealth],
    ) -> HealthStatus:
        """Calculate overall status from components."""
        statuses = [c.status for c in components]
        
        if all(s == HealthStatus.HEALTHY for s in statuses):
            return HealthStatus.HEALTHY
        
        if any(s == HealthStatus.UNHEALTHY for s in statuses):
            return HealthStatus.UNHEALTHY
        
        if any(s == HealthStatus.DEGRADED for s in statuses):
            return HealthStatus.DEGRADED
        
        return HealthStatus.UNKNOWN
    
    # =========================================================================
    # DEFAULT CHECKS
    # =========================================================================
    
    def _check_system(self) -> dict:
        """Check system resources."""
        try:
            cpu_percent = psutil.cpu_percent(interval=0.1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            # Determine status
            if cpu_percent > 90 or memory.percent > 90 or disk.percent > 90:
                status = HealthStatus.UNHEALTHY
                message = "Critical resource usage"
            elif cpu_percent > 70 or memory.percent > 70 or disk.percent > 80:
                status = HealthStatus.DEGRADED
                message = "High resource usage"
            else:
                status = HealthStatus.HEALTHY
                message = "Resources OK"
            
            return {
                "status": status,
                "message": message,
                "details": {
                    "cpu_percent": cpu_percent,
                    "memory_percent": memory.percent,
                    "memory_available_gb": round(memory.available / (1024**3), 2),
                    "disk_percent": disk.percent,
                    "disk_free_gb": round(disk.free / (1024**3), 2),
                },
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNKNOWN,
                "message": f"Could not check system: {e}",
            }
    
    def _check_governance(self) -> dict:
        """Check governance configuration."""
        # These should ALWAYS be true
        synthetic_only = True
        xr_read_only = True
        governance_level = "strict"
        
        if not synthetic_only or not xr_read_only:
            return {
                "status": HealthStatus.UNHEALTHY,
                "message": "CRITICAL: Governance misconfigured",
                "details": {
                    "synthetic_only": synthetic_only,
                    "xr_read_only": xr_read_only,
                    "governance_level": governance_level,
                },
            }
        
        return {
            "status": HealthStatus.HEALTHY,
            "message": "Governance OK",
            "details": {
                "synthetic_only": synthetic_only,
                "xr_read_only": xr_read_only,
                "governance_level": governance_level,
            },
        }
    
    # =========================================================================
    # COMPONENT CHECKS
    # =========================================================================
    
    async def check_database(self, db_url: str) -> dict:
        """Check database connectivity."""
        try:
            import asyncpg
            
            start = time.time()
            conn = await asyncpg.connect(db_url, timeout=5)
            await conn.execute("SELECT 1")
            await conn.close()
            latency = (time.time() - start) * 1000
            
            return {
                "status": HealthStatus.HEALTHY,
                "message": f"Connected ({latency:.2f}ms)",
                "details": {"latency_ms": latency},
            }
        except ImportError:
            return {
                "status": HealthStatus.UNKNOWN,
                "message": "asyncpg not installed",
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNHEALTHY,
                "message": f"Connection failed: {e}",
            }
    
    async def check_redis(self, redis_url: str) -> dict:
        """Check Redis connectivity."""
        try:
            import redis.asyncio as redis
            
            start = time.time()
            client = redis.from_url(redis_url)
            await client.ping()
            await client.close()
            latency = (time.time() - start) * 1000
            
            return {
                "status": HealthStatus.HEALTHY,
                "message": f"Connected ({latency:.2f}ms)",
                "details": {"latency_ms": latency},
            }
        except ImportError:
            return {
                "status": HealthStatus.UNKNOWN,
                "message": "redis not installed",
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNHEALTHY,
                "message": f"Connection failed: {e}",
            }
    
    async def check_opa(self, opa_url: str) -> dict:
        """Check OPA availability."""
        try:
            import httpx
            
            start = time.time()
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{opa_url}/health",
                    timeout=5,
                )
            latency = (time.time() - start) * 1000
            
            if response.status_code == 200:
                return {
                    "status": HealthStatus.HEALTHY,
                    "message": f"OPA available ({latency:.2f}ms)",
                    "details": {"latency_ms": latency},
                }
            else:
                return {
                    "status": HealthStatus.DEGRADED,
                    "message": f"OPA returned {response.status_code}",
                }
        except ImportError:
            return {
                "status": HealthStatus.UNKNOWN,
                "message": "httpx not installed",
            }
        except Exception as e:
            return {
                "status": HealthStatus.UNHEALTHY,
                "message": f"OPA unavailable: {e}",
            }
    
    # =========================================================================
    # DIAGNOSTICS
    # =========================================================================
    
    async def _get_diagnostics(self) -> dict:
        """Get system diagnostics."""
        return {
            "python_version": platform.python_version(),
            "platform": platform.platform(),
            "processor": platform.processor(),
            "hostname": platform.node(),
            "process_id": psutil.Process().pid,
            "process_memory_mb": round(
                psutil.Process().memory_info().rss / (1024**2), 2
            ),
            "process_threads": psutil.Process().num_threads(),
        }
    
    # =========================================================================
    # LIVENESS & READINESS
    # =========================================================================
    
    async def liveness_check(self) -> bool:
        """
        Kubernetes liveness probe.
        
        Returns True if the application is running.
        """
        return True
    
    async def readiness_check(self) -> bool:
        """
        Kubernetes readiness probe.
        
        Returns True if the application is ready to serve traffic.
        """
        # Check critical components
        governance = self._check_governance()
        if governance["status"] == HealthStatus.UNHEALTHY:
            return False
        
        return True


# =============================================================================
# FASTAPI INTEGRATION
# =============================================================================

def create_health_routes(checker: HealthChecker):
    """Create FastAPI health check routes."""
    from fastapi import APIRouter
    from fastapi.responses import JSONResponse
    
    router = APIRouter()
    
    @router.get("/health")
    async def health():
        """Comprehensive health check."""
        health = await checker.check_all()
        
        status_code = 200
        if health.status == HealthStatus.DEGRADED:
            status_code = 200  # Still serving
        elif health.status == HealthStatus.UNHEALTHY:
            status_code = 503
        
        return JSONResponse(
            status_code=status_code,
            content=health.to_dict(),
        )
    
    @router.get("/health/live")
    async def liveness():
        """Kubernetes liveness probe."""
        alive = await checker.liveness_check()
        
        if alive:
            return {"status": "alive"}
        else:
            return JSONResponse(
                status_code=503,
                content={"status": "dead"},
            )
    
    @router.get("/health/ready")
    async def readiness():
        """Kubernetes readiness probe."""
        ready = await checker.readiness_check()
        
        if ready:
            return {"status": "ready"}
        else:
            return JSONResponse(
                status_code=503,
                content={"status": "not_ready"},
            )
    
    @router.get("/health/components/{component}")
    async def component_health(component: str):
        """Get specific component health."""
        if component not in checker._last_results:
            return JSONResponse(
                status_code=404,
                content={"error": f"Unknown component: {component}"},
            )
        
        result = checker._last_results[component]
        return result.to_dict()
    
    return router


# =============================================================================
# SINGLETON
# =============================================================================

_health_checker: Optional[HealthChecker] = None


def get_health_checker() -> HealthChecker:
    """Get the health checker singleton."""
    global _health_checker
    if _health_checker is None:
        _health_checker = HealthChecker()
    return _health_checker
