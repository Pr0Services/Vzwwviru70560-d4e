# CHE-NU — Kit Agent Professeur (Canon)
Version: v1.0

Ce package complète le **Kit Stagiaire**.
Il formalise le rôle du **Professeur** : apprentissage intentionnel, stabilité cognitive, anti-dérive.

Le professeur n’optimise pas la performance.
Il protège la compréhension.

Contenu :
- 01_CHARTE_AGENT_PROFESSEUR.md
- 02_TYPES_ECHECS_MARQUABLES.md
- 03_FICHIER_RECADRAGE.md
- 04_RELATION_STAGIAIRE_PROFESSEUR.md
- 05_GUIDE_IMPLEMENTATION.md
