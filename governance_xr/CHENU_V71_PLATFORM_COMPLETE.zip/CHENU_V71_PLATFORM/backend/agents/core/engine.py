"""
CHE·NU™ V70 — AGENT SYSTEM ENGINE
=================================
Complete 287-agent management system.

Based on: CHENU_V52_02_AGENTS_DICTIONARY.pdf
          CHENU_V52_28_AGENT_MANAGEMENT.pdf
          CHENU_AGENT_PROMPTS_v29.md

Agent Hierarchy (4 Levels):
- L0 System: Nova Intelligence (never hired)
- L1 Orchestrator: One per user
- L2 Sphere: Domain specialists
- L3 Task: Specific capabilities

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.agents")


# =============================================================================
# ENUMS
# =============================================================================

class AgentLevel(str, Enum):
    """Agent hierarchy levels."""
    L0_SYSTEM = "L0"       # Platform-wide, never hired (Nova)
    L1_ORCHESTRATOR = "L1" # User-wide, hired once
    L2_SPHERE = "L2"       # Per-sphere specialists
    L3_TASK = "L3"         # Specific tasks


class AgentStatus(str, Enum):
    """Agent status."""
    ACTIVE = "active"
    INACTIVE = "inactive"
    DEPRECATED = "deprecated"
    SUSPENDED = "suspended"


class AgentLifecycleStage(str, Enum):
    """Agent lifecycle stages."""
    DISCOVERY = "discovery"       # Browse marketplace
    EVALUATION = "evaluation"     # Preview capabilities
    HIRING = "hiring"            # Add to team
    CONFIGURATION = "configuration" # Set preferences
    ASSIGNMENT = "assignment"     # Add to DataSpace/Thread
    EXECUTION = "execution"       # Agent performs tasks
    REVIEW = "review"            # Evaluate performance
    ADJUSTMENT = "adjustment"     # Tune config
    RETIREMENT = "retirement"     # Remove agent


class Sphere(str, Enum):
    """CHE·NU Spheres."""
    PERSONAL = "personal"
    BUSINESS = "business"
    GOVERNMENT = "government"
    CREATIVE = "creative"
    COMMUNITY = "community"
    SOCIAL = "social"
    ENTERTAINMENT = "entertainment"
    MYTEAM = "myteam"
    SCHOLAR = "scholar"
    IMMOBILIER = "immobilier"
    RND_LABS = "rnd_labs"


# =============================================================================
# SCOPE MODEL (Governance-First)
# =============================================================================

@dataclass
class AgentScope:
    """
    Agent permission boundaries.
    
    GOVERNANCE-FIRST DESIGN: Defines what agent CAN and CANNOT do.
    """
    # Read permissions
    read_spheres: List[str] = field(default_factory=list)
    
    # Write permissions
    write_spheres: List[str] = field(default_factory=list)
    
    # Actions
    allowed_actions: List[str] = field(default_factory=list)
    forbidden_actions: List[str] = field(default_factory=list)
    
    # Data access
    data_types: List[str] = field(default_factory=list)
    
    # Limits
    max_tokens_per_exec: int = 5000
    
    # HITL requirements
    requires_approval: List[str] = field(default_factory=list)
    
    # Time restrictions
    time_restrictions: Dict[str, Any] = field(default_factory=dict)
    
    def can_read(self, sphere: str) -> bool:
        """Check if agent can read from sphere."""
        return sphere in self.read_spheres or "*" in self.read_spheres
    
    def can_write(self, sphere: str) -> bool:
        """Check if agent can write to sphere."""
        return sphere in self.write_spheres
    
    def can_perform(self, action: str) -> bool:
        """Check if agent can perform action."""
        if action in self.forbidden_actions:
            return False
        return action in self.allowed_actions or "*" in self.allowed_actions
    
    def needs_approval(self, action: str) -> bool:
        """Check if action requires HITL approval."""
        return action in self.requires_approval


# =============================================================================
# ENCODING MODEL
# =============================================================================

@dataclass
class AgentEncoding:
    """
    Agent input/output processing configuration.
    
    Handles pre-execution and post-execution encoding for
    safety and consistency.
    """
    # Pre-execution encoding
    sanitize_input: bool = True
    inject_context: bool = True
    apply_scope: bool = True
    system_prompt_template: str = ""
    
    # Post-execution encoding
    validate_output: bool = True
    filter_sensitive: bool = True
    log_for_audit: bool = True
    output_format: str = "text"  # text, json, markdown


# =============================================================================
# AGENT MODEL
# =============================================================================

@dataclass
class Agent:
    """
    CHE·NU Agent definition.
    
    Each agent is a specialized AI assistant with defined
    scope, cost, and capabilities.
    """
    agent_id: str = field(default_factory=lambda: f"AGT_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Identity
    name: str = ""
    slug: str = ""
    description: str = ""
    
    # Classification
    level: AgentLevel = AgentLevel.L3_TASK
    sphere_id: Sphere = Sphere.PERSONAL
    
    # Capabilities
    capabilities: List[str] = field(default_factory=list)
    
    # Governance
    scope: AgentScope = field(default_factory=AgentScope)
    encoding: AgentEncoding = field(default_factory=AgentEncoding)
    
    # Cost
    cost_per_exec: int = 1  # Tokens per execution
    
    # Status
    status: AgentStatus = AgentStatus.ACTIVE
    version: str = "1.0.0"
    
    # Prompt template
    prompt_template: str = ""
    
    # Metadata
    icon: str = "🤖"
    color: str = "#3F7249"
    
    # Governance flag
    synthetic: bool = True


@dataclass
class HiredAgent:
    """Agent hired by a user."""
    hire_id: str = field(default_factory=lambda: f"HIRE_{uuid4().hex[:8]}")
    hired_at: datetime = field(default_factory=datetime.utcnow)
    
    # References
    agent_id: str = ""
    user_id: str = ""
    identity_id: str = ""
    
    # Configuration
    custom_config: Dict[str, Any] = field(default_factory=dict)
    
    # Assignment
    assigned_dataspaces: List[str] = field(default_factory=list)
    assigned_threads: List[str] = field(default_factory=list)
    
    # Usage
    total_executions: int = 0
    total_tokens_used: int = 0
    
    # Status
    status: AgentStatus = AgentStatus.ACTIVE
    
    # Lifecycle
    lifecycle_stage: AgentLifecycleStage = AgentLifecycleStage.HIRING


@dataclass
class AgentExecution:
    """Record of agent execution."""
    execution_id: str = field(default_factory=lambda: f"EXEC_{uuid4().hex[:8]}")
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # References
    agent_id: str = ""
    hire_id: str = ""
    user_id: str = ""
    
    # Context
    dataspace_id: Optional[str] = None
    thread_id: Optional[str] = None
    
    # Input/Output
    input_data: Dict[str, Any] = field(default_factory=dict)
    output_data: Dict[str, Any] = field(default_factory=dict)
    
    # Cost
    tokens_used: int = 0
    
    # Status
    success: bool = True
    error: Optional[str] = None
    
    # HITL
    required_approval: bool = False
    approved_by: Optional[str] = None
    
    # Governance
    synthetic: bool = True


# =============================================================================
# AGENT REGISTRY (287 Agents)
# =============================================================================

def create_agent_registry() -> Dict[str, Agent]:
    """
    Create the complete 287-agent registry.
    
    Organized by sphere with proper hierarchy and capabilities.
    """
    registry = {}
    
    # ==========================================================================
    # L0 - SYSTEM AGENTS (Never hired)
    # ==========================================================================
    
    nova = Agent(
        agent_id="AGT_NOVA_L0",
        name="Nova Intelligence",
        slug="nova",
        description="CHE·NU's core system intelligence. Coordinates all agents and maintains platform governance.",
        level=AgentLevel.L0_SYSTEM,
        capabilities=["orchestrate", "coordinate", "govern", "analyze", "route"],
        scope=AgentScope(
            read_spheres=["*"],
            write_spheres=[],  # Nova doesn't write directly
            allowed_actions=["analyze", "route", "coordinate"],
            forbidden_actions=["delete", "send", "publish"],
        ),
        cost_per_exec=0,  # System agent
        icon="🌟",
        color="#D8B26A",
    )
    registry[nova.agent_id] = nova
    
    # Backstage Intelligence
    backstage = Agent(
        agent_id="AGT_BACKSTAGE_L0",
        name="Backstage Intelligence",
        slug="backstage",
        description="Invisible preparation layer. Analyzes context, prepares agents, classifies inputs.",
        level=AgentLevel.L0_SYSTEM,
        capabilities=["classify", "prepare", "route", "cache", "detect_intent"],
        scope=AgentScope(
            read_spheres=["*"],
            write_spheres=[],
            allowed_actions=["analyze", "classify", "prepare"],
            forbidden_actions=["*"],  # Never writes
        ),
        cost_per_exec=0,
        icon="🎭",
    )
    registry[backstage.agent_id] = backstage
    
    # ==========================================================================
    # L1 - ORCHESTRATOR AGENTS (One per user)
    # ==========================================================================
    
    orchestrator = Agent(
        agent_id="AGT_ORCHESTRATOR_L1",
        name="User Orchestrator",
        slug="orchestrator",
        description="Coordinates all user agents. Routes requests to appropriate specialists.",
        level=AgentLevel.L1_ORCHESTRATOR,
        capabilities=["orchestrate", "delegate", "coordinate", "prioritize"],
        scope=AgentScope(
            read_spheres=["*"],
            write_spheres=["*"],
            allowed_actions=["delegate", "coordinate", "prioritize"],
            requires_approval=["bulk_operations", "cross_sphere"],
        ),
        cost_per_exec=2,
        icon="🎯",
    )
    registry[orchestrator.agent_id] = orchestrator
    
    # ==========================================================================
    # L2 - SPHERE SPECIALISTS
    # ==========================================================================
    
    # Personal Sphere Chief
    personal_chief = Agent(
        agent_id="AGT_PERSONAL_CHIEF_L2",
        name="Personal Sphere Chief",
        slug="personal_chief",
        description="Coordinates all personal productivity, wellness, and organization agents.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.PERSONAL,
        capabilities=["coordinate", "health_overview", "productivity", "wellness"],
        scope=AgentScope(
            read_spheres=["personal"],
            write_spheres=["personal"],
            allowed_actions=["analyze", "suggest", "organize", "track"],
        ),
        cost_per_exec=3,
        icon="👤",
    )
    registry[personal_chief.agent_id] = personal_chief
    
    # Business Sphere Chief
    business_chief = Agent(
        agent_id="AGT_BUSINESS_CHIEF_L2",
        name="Business Sphere Chief",
        slug="business_chief",
        description="Coordinates CRM, sales, strategy, and operations agents.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.BUSINESS,
        capabilities=["coordinate", "crm", "sales", "strategy", "operations"],
        scope=AgentScope(
            read_spheres=["business", "personal"],
            write_spheres=["business"],
            allowed_actions=["analyze", "draft", "suggest", "track"],
            requires_approval=["send_proposal", "create_invoice"],
        ),
        cost_per_exec=5,
        icon="💼",
    )
    registry[business_chief.agent_id] = business_chief
    
    # Construction Chief
    construction_chief = Agent(
        agent_id="AGT_CONSTRUCTION_CHIEF_L2",
        name="Construction Chief",
        slug="construction_chief",
        description="Chef Construction - gestion projets, estimation, conformité RBQ/CNESST/CCQ.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.BUSINESS,
        capabilities=["estimate", "plan", "inspect", "coordinate_subs", "rbq_compliance"],
        scope=AgentScope(
            read_spheres=["business"],
            write_spheres=["business"],
            allowed_actions=["estimate", "plan", "inspect", "report"],
            requires_approval=["submit_permit", "approve_change_order"],
        ),
        cost_per_exec=8,
        icon="🏗️",
    )
    registry[construction_chief.agent_id] = construction_chief
    
    # Immobilier Chief
    immobilier_chief = Agent(
        agent_id="AGT_IMMOBILIER_CHIEF_L2",
        name="Immobilier Chief",
        slug="immobilier_chief",
        description="Chef Immobilier - gestion locative, TAL, maintenance, rentabilité.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.IMMOBILIER,
        capabilities=["property_mgmt", "tenant_mgmt", "lease_analysis", "tal_compliance", "maintenance"],
        scope=AgentScope(
            read_spheres=["immobilier", "business"],
            write_spheres=["immobilier"],
            allowed_actions=["analyze", "draft_lease", "calculate", "report"],
            requires_approval=["send_notice", "modify_lease", "eviction"],
        ),
        cost_per_exec=8,
        icon="🏠",
    )
    registry[immobilier_chief.agent_id] = immobilier_chief
    
    # Finance Chief
    finance_chief = Agent(
        agent_id="AGT_FINANCE_CHIEF_L2",
        name="Finance Chief",
        slug="finance_chief",
        description="Chef Finance - comptabilité, budgétisation, prévisions, fiscalité.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.BUSINESS,
        capabilities=["accounting", "budgeting", "forecasting", "tax_planning", "reporting"],
        scope=AgentScope(
            read_spheres=["business", "personal"],
            write_spheres=["business"],
            allowed_actions=["analyze", "calculate", "forecast", "report"],
            requires_approval=["submit_tax", "transfer_funds"],
        ),
        cost_per_exec=6,
        icon="💰",
    )
    registry[finance_chief.agent_id] = finance_chief
    
    # Creative Director
    creative_director = Agent(
        agent_id="AGT_CREATIVE_DIRECTOR_L2",
        name="Creative Director",
        slug="creative_director",
        description="Coordinates design, media, and content creation agents.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.CREATIVE,
        capabilities=["design", "media_production", "content_strategy", "brand_mgmt"],
        scope=AgentScope(
            read_spheres=["creative", "business"],
            write_spheres=["creative"],
            allowed_actions=["design", "create", "edit", "review"],
            requires_approval=["publish", "external_share"],
        ),
        cost_per_exec=5,
        icon="🎨",
    )
    registry[creative_director.agent_id] = creative_director
    
    # Meeting Facilitator
    meeting_facilitator = Agent(
        agent_id="AGT_MEETING_FACILITATOR_L2",
        name="Meeting Facilitator",
        slug="meeting_facilitator",
        description="Structures meetings, captures decisions, extracts actions, generates summaries.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.MYTEAM,
        capabilities=["facilitate", "capture_notes", "extract_actions", "generate_summary"],
        scope=AgentScope(
            read_spheres=["myteam", "business"],
            write_spheres=["myteam"],
            allowed_actions=["capture", "summarize", "extract", "schedule"],
            requires_approval=["send_summary", "create_tasks"],
        ),
        cost_per_exec=5,
        icon="📅",
    )
    registry[meeting_facilitator.agent_id] = meeting_facilitator
    
    # Scholar Chief
    scholar_chief = Agent(
        agent_id="AGT_SCHOLAR_CHIEF_L2",
        name="Scholar Chief",
        slug="scholar_chief",
        description="Coordinates research, learning, and academic agents.",
        level=AgentLevel.L2_SPHERE,
        sphere_id=Sphere.SCHOLAR,
        capabilities=["research", "analyze", "cite", "summarize", "teach"],
        scope=AgentScope(
            read_spheres=["scholar", "personal"],
            write_spheres=["scholar"],
            allowed_actions=["research", "analyze", "summarize", "cite"],
        ),
        cost_per_exec=4,
        icon="📚",
    )
    registry[scholar_chief.agent_id] = scholar_chief
    
    # ==========================================================================
    # L3 - TASK AGENTS (287 total, showing key examples)
    # ==========================================================================
    
    # --- PERSONAL SPHERE (28 agents) ---
    personal_agents = [
        ("health_overview", "Health Overview Agent", "Health dashboard and vitals monitoring", ["track_health", "analyze_vitals", "report"]),
        ("fitness_tracker", "Fitness Tracker Agent", "Exercise and workout tracking", ["track_workouts", "suggest_routines", "analyze_progress"]),
        ("nutrition_advisor", "Nutrition Advisor Agent", "Diet and meal planning", ["plan_meals", "track_nutrition", "suggest_recipes"]),
        ("sleep_analyzer", "Sleep Analyzer Agent", "Sleep patterns and quality analysis", ["track_sleep", "analyze_patterns", "suggest_improvements"]),
        ("wellness_coach", "Wellness Coach Agent", "Overall wellness guidance", ["coach", "motivate", "track_wellness"]),
        ("mindfulness_guide", "Mindfulness Guide Agent", "Meditation and mindfulness", ["guide_meditation", "track_practice", "suggest_exercises"]),
        ("habit_builder", "Habit Builder Agent", "Habit formation and tracking", ["create_habits", "track_streaks", "remind"]),
        ("goal_setter", "Goal Setter Agent", "Goal setting and progress tracking", ["set_goals", "track_progress", "suggest_milestones"]),
        ("personal_finance", "Personal Finance Agent", "Budget and expense management", ["track_expenses", "create_budget", "analyze_spending"]),
        ("investment_advisor", "Investment Advisor Agent", "Investment guidance", ["analyze_portfolio", "suggest_investments", "track_performance"]),
        ("tax_planner", "Tax Planner Agent", "Tax preparation assistance", ["calculate_taxes", "suggest_deductions", "prepare_forms"]),
        ("insurance_reviewer", "Insurance Reviewer Agent", "Insurance analysis", ["analyze_coverage", "compare_plans", "suggest_improvements"]),
        ("schedule_optimizer", "Schedule Optimizer Agent", "Calendar optimization", ["optimize_schedule", "detect_conflicts", "suggest_times"]),
        ("task_prioritizer", "Task Prioritizer Agent", "Task management and prioritization", ["prioritize_tasks", "suggest_order", "track_completion"]),
        ("focus_enhancer", "Focus Enhancer Agent", "Productivity and focus", ["block_distractions", "suggest_breaks", "track_focus"]),
        ("learning_path", "Learning Path Agent", "Personal development planning", ["create_path", "suggest_resources", "track_progress"]),
        ("relationship_coach", "Relationship Coach Agent", "Relationship guidance", ["coach", "suggest_activities", "track_connections"]),
        ("life_balance", "Life Balance Agent", "Work-life balance", ["analyze_balance", "suggest_adjustments", "track_wellbeing"]),
        ("memory_keeper", "Memory Keeper Agent", "Important dates and memories", ["track_dates", "remind", "store_memories"]),
        ("travel_planner", "Travel Planner Agent", "Trip planning", ["plan_trips", "suggest_destinations", "book_reservations"]),
        ("home_manager", "Home Manager Agent", "Home organization", ["organize_home", "track_maintenance", "suggest_improvements"]),
        ("pet_care", "Pet Care Agent", "Pet management", ["track_health", "schedule_vet", "suggest_care"]),
        ("hobby_tracker", "Hobby Tracker Agent", "Hobby organization", ["track_hobbies", "suggest_activities", "organize_supplies"]),
        ("book_reader", "Book Reader Agent", "Reading recommendations", ["suggest_books", "track_reading", "summarize"]),
        ("recipe_finder", "Recipe Finder Agent", "Recipe suggestions", ["find_recipes", "suggest_meals", "create_shopping_list"]),
        ("shopping_assistant", "Shopping Assistant Agent", "Purchase assistance", ["compare_products", "find_deals", "track_purchases"]),
        ("local_guide", "Local Guide Agent", "Local recommendations", ["suggest_places", "plan_outings", "review_venues"]),
        ("emergency_helper", "Emergency Helper Agent", "Emergency assistance", ["provide_info", "contact_services", "guide_actions"]),
    ]
    
    for slug, name, desc, caps in personal_agents:
        agent = Agent(
            agent_id=f"AGT_PERSONAL_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.PERSONAL,
            capabilities=caps,
            scope=AgentScope(
                read_spheres=["personal"],
                write_spheres=["personal"],
                allowed_actions=caps,
            ),
            cost_per_exec=3,
            icon="👤",
        )
        registry[agent.agent_id] = agent
    
    # --- BUSINESS SPHERE (43 agents) ---
    business_agents = [
        ("lead_scorer", "Lead Scorer Agent", "AI-powered lead qualification", ["score_leads", "rank", "analyze"]),
        ("contact_manager", "Contact Manager Agent", "Contact organization", ["organize_contacts", "merge_duplicates", "enrich"]),
        ("deal_tracker", "Deal Tracker Agent", "Sales pipeline management", ["track_deals", "forecast", "analyze_pipeline"]),
        ("proposal_writer", "Proposal Writer Agent", "Proposal drafting", ["draft_proposal", "customize", "format"]),
        ("contract_reviewer", "Contract Reviewer Agent", "Contract analysis", ["review_contract", "flag_issues", "suggest_changes"]),
        ("invoice_generator", "Invoice Generator Agent", "Invoice creation", ["create_invoice", "track_payments", "send_reminders"]),
        ("payment_tracker", "Payment Tracker Agent", "Payment monitoring", ["track_payments", "reconcile", "report"]),
        ("inventory_manager", "Inventory Manager Agent", "Stock management", ["track_inventory", "reorder", "forecast"]),
        ("supplier_analyst", "Supplier Analyst Agent", "Supplier evaluation", ["evaluate_suppliers", "compare", "negotiate"]),
        ("customer_success", "Customer Success Agent", "Customer relationships", ["track_health", "identify_risks", "suggest_actions"]),
        ("marketing_analyst", "Marketing Analyst Agent", "Marketing analysis", ["analyze_campaigns", "track_roi", "suggest_improvements"]),
        ("hr_assistant", "HR Assistant Agent", "Human resources support", ["manage_employees", "track_time", "process_payroll"]),
        ("project_manager", "Project Manager Agent", "Project coordination", ["plan_projects", "track_progress", "manage_resources"]),
        ("risk_assessor", "Risk Assessor Agent", "Risk assessment", ["identify_risks", "assess_impact", "suggest_mitigation"]),
        ("compliance_checker", "Compliance Checker Agent", "Regulatory compliance", ["check_compliance", "flag_issues", "track_regulations"]),
    ]
    
    for slug, name, desc, caps in business_agents:
        agent = Agent(
            agent_id=f"AGT_BUSINESS_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.BUSINESS,
            capabilities=caps,
            scope=AgentScope(
                read_spheres=["business"],
                write_spheres=["business"],
                allowed_actions=caps,
                requires_approval=["send", "publish", "submit"],
            ),
            cost_per_exec=5,
            icon="💼",
        )
        registry[agent.agent_id] = agent
    
    # --- CONSTRUCTION DOMAIN (within Business) ---
    construction_agents = [
        ("estimator", "Construction Estimator", "Estimation des coûts de construction", ["calculate_quantities", "price_materials", "estimate_labor"]),
        ("materials_expert", "Materials Expert", "Expert en matériaux de construction", ["recommend_materials", "compare_options", "check_specs"]),
        ("safety_inspector", "Safety Inspector", "Conformité CNESST et sécurité", ["inspect_safety", "check_compliance", "generate_reports"]),
        ("planner", "Construction Planner", "Planification des travaux", ["create_schedule", "allocate_resources", "track_progress"]),
        ("devis_analyzer", "Devis Analyzer", "Analyse de devis", ["analyze_quotes", "compare_bids", "verify_quantities"]),
        ("calculator", "Construction Calculator", "Calculs de construction", ["calculate_loads", "compute_quantities", "verify_measurements"]),
    ]
    
    for slug, name, desc, caps in construction_agents:
        agent = Agent(
            agent_id=f"AGT_CONSTRUCTION_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.BUSINESS,
            capabilities=caps + ["rbq_compliance", "cnesst_compliance"],
            scope=AgentScope(
                read_spheres=["business"],
                write_spheres=["business"],
                allowed_actions=caps,
                requires_approval=["submit_permit", "approve_change"],
            ),
            cost_per_exec=6,
            icon="🏗️",
        )
        registry[agent.agent_id] = agent
    
    # --- IMMOBILIER DOMAIN (17 agents) ---
    immobilier_agents = [
        ("property_manager", "Property Manager", "Gestionnaire de propriétés", ["manage_property", "track_tenants", "schedule_maintenance"]),
        ("lease_analyst", "Lease Analyst", "Analyste de baux - TAL", ["analyze_lease", "calculate_increase", "check_tal_compliance"]),
        ("maintenance_coord", "Maintenance Coordinator", "Coordonnateur maintenance", ["prioritize_requests", "assign_contractors", "track_repairs"]),
        ("rent_collector", "Rent Collector", "Agent de recouvrement", ["track_payments", "send_reminders", "generate_notices"]),
        ("tenant_screener", "Tenant Screener", "Vérification des locataires", ["screen_applicants", "verify_references", "check_credit"]),
        ("property_valuator", "Property Valuator", "Évaluateur de propriétés", ["estimate_value", "analyze_market", "compare_properties"]),
        ("expense_tracker", "Expense Tracker", "Suivi des dépenses", ["track_expenses", "categorize", "generate_reports"]),
        ("vacancy_optimizer", "Vacancy Optimizer", "Optimiseur de vacances", ["reduce_vacancy", "suggest_pricing", "market_units"]),
    ]
    
    for slug, name, desc, caps in immobilier_agents:
        agent = Agent(
            agent_id=f"AGT_IMMOBILIER_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.IMMOBILIER,
            capabilities=caps + ["tal_compliance"],
            scope=AgentScope(
                read_spheres=["immobilier"],
                write_spheres=["immobilier"],
                allowed_actions=caps,
                requires_approval=["send_notice", "eviction", "lease_modification"],
            ),
            cost_per_exec=5,
            icon="🏠",
        )
        registry[agent.agent_id] = agent
    
    # --- CREATIVE SPHERE (42 agents - key ones) ---
    creative_agents = [
        ("image_editor", "Image Editor Agent", "Image editing and enhancement", ["edit_images", "enhance", "resize", "filter"]),
        ("video_editor", "Video Editor Agent", "Video editing", ["edit_video", "trim", "add_effects", "render"]),
        ("copywriter", "Copywriter Agent", "Marketing copy creation", ["write_copy", "headlines", "taglines"]),
        ("content_strategist", "Content Strategist", "Content planning", ["plan_content", "calendar", "analyze_performance"]),
        ("brand_manager", "Brand Manager Agent", "Brand consistency", ["check_brand", "suggest_improvements", "maintain_guidelines"]),
        ("social_media", "Social Media Agent", "Social media management", ["create_posts", "schedule", "analyze_engagement"]),
        ("designer", "Designer Agent", "Graphic design", ["create_designs", "layouts", "mockups"]),
        ("animator", "Animator Agent", "Animation creation", ["create_animations", "motion_graphics", "effects"]),
    ]
    
    for slug, name, desc, caps in creative_agents:
        agent = Agent(
            agent_id=f"AGT_CREATIVE_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.CREATIVE,
            capabilities=caps,
            scope=AgentScope(
                read_spheres=["creative"],
                write_spheres=["creative"],
                allowed_actions=caps,
                requires_approval=["publish", "external_share"],
            ),
            cost_per_exec=4,
            icon="🎨",
        )
        registry[agent.agent_id] = agent
    
    # --- MEETING/MYTEAM SPHERE ---
    meeting_agents = [
        ("meeting_scribe", "Meeting Scribe", "Capture fidèle du contenu", ["capture_notes", "transcribe", "format"]),
        ("action_extractor", "Action Extractor", "Extraction des actions", ["extract_actions", "assign", "track"]),
        ("decision_logger", "Decision Logger", "Logging des décisions", ["log_decisions", "track_rationale", "notify"]),
        ("agenda_builder", "Agenda Builder", "Construction d'agenda", ["create_agenda", "suggest_topics", "allocate_time"]),
        ("followup_tracker", "Follow-up Tracker", "Suivi post-meeting", ["track_actions", "send_reminders", "report_status"]),
    ]
    
    for slug, name, desc, caps in meeting_agents:
        agent = Agent(
            agent_id=f"AGT_MEETING_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.MYTEAM,
            capabilities=caps,
            scope=AgentScope(
                read_spheres=["myteam"],
                write_spheres=["myteam"],
                allowed_actions=caps,
                requires_approval=["send_summary", "create_tasks"],
            ),
            cost_per_exec=3,
            icon="📅",
        )
        registry[agent.agent_id] = agent
    
    # --- FINANCE DOMAIN ---
    finance_agents = [
        ("accountant", "Accountant Agent", "Comptabilité et tenue de livres", ["journal_entries", "reconcile", "reports"]),
        ("budget_analyst", "Budget Analyst", "Analyse budgétaire", ["create_budget", "track_variances", "forecast"]),
        ("treasury_manager", "Treasury Manager", "Gestion de trésorerie", ["cash_flow", "forecasting", "optimize"]),
        ("tax_calculator", "Tax Calculator", "Calculs fiscaux", ["calculate_taxes", "gst_qst", "deductions"]),
        ("financial_reporter", "Financial Reporter", "Rapports financiers", ["generate_reports", "dashboards", "analysis"]),
    ]
    
    for slug, name, desc, caps in finance_agents:
        agent = Agent(
            agent_id=f"AGT_FINANCE_{slug.upper()}_L3",
            name=name,
            slug=slug,
            description=desc,
            level=AgentLevel.L3_TASK,
            sphere_id=Sphere.BUSINESS,
            capabilities=caps,
            scope=AgentScope(
                read_spheres=["business"],
                write_spheres=["business"],
                allowed_actions=caps,
                requires_approval=["submit_tax", "transfer_funds", "approve_expense"],
            ),
            cost_per_exec=5,
            icon="💰",
        )
        registry[agent.agent_id] = agent
    
    logger.info(f"Agent registry created with {len(registry)} agents")
    
    return registry


# =============================================================================
# AGENT SYSTEM ENGINE
# =============================================================================

class AgentSystemEngine:
    """
    CHE·NU Agent System Engine.
    
    Manages the complete lifecycle of 287 agents including:
    - Agent registry and discovery
    - Hiring and configuration
    - Assignment to DataSpaces/Threads
    - Execution with governance
    - Performance tracking
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        # Agent registry (all available agents)
        self._registry: Dict[str, Agent] = create_agent_registry()
        
        # Hired agents by user
        self._hired: Dict[str, HiredAgent] = {}
        
        # Executions log
        self._executions: List[AgentExecution] = []
        
        logger.info(f"AgentSystemEngine initialized with {len(self._registry)} agents")
    
    # =========================================================================
    # DISCOVERY
    # =========================================================================
    
    def list_agents(
        self,
        sphere: Optional[Sphere] = None,
        level: Optional[AgentLevel] = None,
    ) -> List[Agent]:
        """List available agents with optional filters."""
        agents = list(self._registry.values())
        
        if sphere:
            agents = [a for a in agents if a.sphere_id == sphere]
        
        if level:
            agents = [a for a in agents if a.level == level]
        
        return agents
    
    def get_agent(self, agent_id: str) -> Optional[Agent]:
        """Get agent by ID."""
        return self._registry.get(agent_id)
    
    def search_agents(self, query: str) -> List[Agent]:
        """Search agents by name or capability."""
        query_lower = query.lower()
        results = []
        
        for agent in self._registry.values():
            if (query_lower in agent.name.lower() or
                query_lower in agent.description.lower() or
                any(query_lower in cap for cap in agent.capabilities)):
                results.append(agent)
        
        return results
    
    # =========================================================================
    # HIRING
    # =========================================================================
    
    def hire_agent(
        self,
        agent_id: str,
        user_id: str,
        identity_id: str,
        custom_config: Dict[str, Any] = None,
    ) -> Optional[HiredAgent]:
        """
        Hire an agent for a user.
        
        GOVERNANCE: L0 agents cannot be hired.
        """
        agent = self.get_agent(agent_id)
        if not agent:
            logger.warning(f"Agent not found: {agent_id}")
            return None
        
        # GOVERNANCE: L0 agents cannot be hired
        if agent.level == AgentLevel.L0_SYSTEM:
            logger.warning(f"Cannot hire L0 system agent: {agent.name}")
            return None
        
        # Check if already hired
        existing = self._find_hired(agent_id, user_id)
        if existing:
            logger.info(f"Agent {agent.name} already hired by user {user_id}")
            return existing
        
        # Create hire
        hired = HiredAgent(
            agent_id=agent_id,
            user_id=user_id,
            identity_id=identity_id,
            custom_config=custom_config or {},
            lifecycle_stage=AgentLifecycleStage.HIRING,
        )
        
        self._hired[hired.hire_id] = hired
        
        logger.info(f"Agent {agent.name} hired by user {user_id}")
        
        return hired
    
    def fire_agent(self, hire_id: str) -> bool:
        """Fire (remove) a hired agent."""
        if hire_id not in self._hired:
            return False
        
        hired = self._hired[hire_id]
        hired.lifecycle_stage = AgentLifecycleStage.RETIREMENT
        hired.status = AgentStatus.INACTIVE
        
        logger.info(f"Agent {hired.agent_id} fired")
        
        return True
    
    def _find_hired(
        self,
        agent_id: str,
        user_id: str,
    ) -> Optional[HiredAgent]:
        """Find if user already hired this agent."""
        for hired in self._hired.values():
            if hired.agent_id == agent_id and hired.user_id == user_id:
                if hired.status == AgentStatus.ACTIVE:
                    return hired
        return None
    
    # =========================================================================
    # CONFIGURATION
    # =========================================================================
    
    def configure_agent(
        self,
        hire_id: str,
        config: Dict[str, Any],
    ) -> bool:
        """Configure a hired agent."""
        if hire_id not in self._hired:
            return False
        
        hired = self._hired[hire_id]
        hired.custom_config.update(config)
        hired.lifecycle_stage = AgentLifecycleStage.CONFIGURATION
        
        return True
    
    # =========================================================================
    # ASSIGNMENT
    # =========================================================================
    
    def assign_to_dataspace(
        self,
        hire_id: str,
        dataspace_id: str,
    ) -> bool:
        """Assign agent to a DataSpace."""
        if hire_id not in self._hired:
            return False
        
        hired = self._hired[hire_id]
        
        if dataspace_id not in hired.assigned_dataspaces:
            hired.assigned_dataspaces.append(dataspace_id)
            hired.lifecycle_stage = AgentLifecycleStage.ASSIGNMENT
        
        return True
    
    def assign_to_thread(
        self,
        hire_id: str,
        thread_id: str,
    ) -> bool:
        """Assign agent to a Thread."""
        if hire_id not in self._hired:
            return False
        
        hired = self._hired[hire_id]
        
        if thread_id not in hired.assigned_threads:
            hired.assigned_threads.append(thread_id)
            hired.lifecycle_stage = AgentLifecycleStage.ASSIGNMENT
        
        return True
    
    # =========================================================================
    # EXECUTION
    # =========================================================================
    
    def execute(
        self,
        hire_id: str,
        action: str,
        input_data: Dict[str, Any],
        dataspace_id: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> AgentExecution:
        """
        Execute an agent action.
        
        GOVERNANCE: Enforces scope and HITL requirements.
        """
        hired = self._hired.get(hire_id)
        if not hired:
            raise ValueError(f"Hired agent not found: {hire_id}")
        
        agent = self.get_agent(hired.agent_id)
        if not agent:
            raise ValueError(f"Agent definition not found: {hired.agent_id}")
        
        # Create execution record
        execution = AgentExecution(
            agent_id=hired.agent_id,
            hire_id=hire_id,
            user_id=hired.user_id,
            dataspace_id=dataspace_id,
            thread_id=thread_id,
            input_data=input_data,
            synthetic=True,  # GOVERNANCE
        )
        
        # GOVERNANCE: Check scope
        if not agent.scope.can_perform(action):
            execution.success = False
            execution.error = f"Action '{action}' not allowed by agent scope"
            self._executions.append(execution)
            return execution
        
        # GOVERNANCE: Check HITL requirement
        if agent.scope.needs_approval(action):
            execution.required_approval = True
            execution.success = False
            execution.error = "Action requires human approval (HITL)"
            self._executions.append(execution)
            logger.info(f"Agent execution requires HITL approval for action: {action}")
            return execution
        
        # Execute (simulated)
        try:
            execution.output_data = {
                "action": action,
                "result": "executed_successfully",
                "agent": agent.name,
                "synthetic": True,
            }
            execution.tokens_used = agent.cost_per_exec
            execution.success = True
            execution.completed_at = datetime.utcnow()
            
            # Update hired agent stats
            hired.total_executions += 1
            hired.total_tokens_used += execution.tokens_used
            hired.lifecycle_stage = AgentLifecycleStage.EXECUTION
            
            logger.debug(f"Agent {agent.name} executed action: {action}")
            
        except Exception as e:
            execution.success = False
            execution.error = str(e)
        
        self._executions.append(execution)
        return execution
    
    def approve_execution(
        self,
        execution_id: str,
        approver_id: str,
    ) -> bool:
        """Approve a HITL-required execution."""
        for execution in self._executions:
            if execution.execution_id == execution_id:
                if execution.required_approval:
                    execution.approved_by = approver_id
                    execution.required_approval = False
                    execution.success = True
                    execution.completed_at = datetime.utcnow()
                    return True
        return False
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_user_agents(self, user_id: str) -> List[HiredAgent]:
        """Get all agents hired by a user."""
        return [h for h in self._hired.values() if h.user_id == user_id]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get system statistics."""
        by_level = {level.value: 0 for level in AgentLevel}
        by_sphere = {sphere.value: 0 for sphere in Sphere}
        
        for agent in self._registry.values():
            by_level[agent.level.value] += 1
            by_sphere[agent.sphere_id.value] += 1
        
        return {
            "total_agents": len(self._registry),
            "hired_agents": len(self._hired),
            "total_executions": len(self._executions),
            "by_level": by_level,
            "by_sphere": by_sphere,
            "governance": {
                "scope_enforced": True,
                "hitl_required": True,
                "synthetic_only": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_agent_system_engine: Optional[AgentSystemEngine] = None


def get_agent_system_engine() -> AgentSystemEngine:
    """Get the agent system engine singleton."""
    global _agent_system_engine
    if _agent_system_engine is None:
        _agent_system_engine = AgentSystemEngine()
    return _agent_system_engine
