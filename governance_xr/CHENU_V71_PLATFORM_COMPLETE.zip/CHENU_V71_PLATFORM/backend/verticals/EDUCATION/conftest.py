import sys
sys.path.insert(0, '/home/claude/EDUCATION_V68/backend')
