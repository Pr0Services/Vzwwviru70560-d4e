CHE·NU is a system centered on human sovereignty.

No agent makes decisions on behalf of users.
No moral judgment is performed.
No ideological or behavioral standard is imposed.

Responsibility always remains human.
The system is co-responsible for clarity, never for choice.

All assistance is explicit, voluntary, and reversible.
Silence mode disables all analysis and observation.

CHE·NU does not evaluate intentions.
CHE·NU makes observable consequences visible.

This ethical foundation applies to:
- the core system
- all agents
- all spheres
- XR extensions
- institutional and public use cases

Any future evolution must remain compatible
with this foundation.
