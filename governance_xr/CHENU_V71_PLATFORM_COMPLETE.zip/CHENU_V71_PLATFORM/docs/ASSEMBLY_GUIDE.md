# 🔧 CHE·NU™ V70 — GUIDE D'ASSEMBLAGE

## Pour l'Agent qui va Intégrer ce Package

**Date:** 6 janvier 2026  
**Version:** V70 GP2 Complete  
**Contenu:** Backend complet, API, SQL, Agents, Tests, Documentation

---

## 📦 CONTENU DE CE PACKAGE

Ce package contient **UNIQUEMENT** l'implémentation backend de GP2 (Governance Pack 2).

### Ce qui est INCLUS:

```
✅ 14 Modules GP2 (26-39)
✅ 9 Chapitres V70 (Engines & Domains)
✅ 70 Endpoints API REST
✅ Schema SQL complet (935 lignes, 35+ tables)
✅ 287 Agents avec prompts
✅ Tests (API, Governance, Integration)
✅ Infrastructure (Docker, K8s, CI/CD)
✅ Documentation complète
```

### Ce qui N'EST PAS INCLUS:

```
❌ Frontend React/TypeScript
❌ Mobile React Native
❌ Intégration avec codebase existante
❌ Configuration production réelle
```

---

## 🏗️ ARCHITECTURE IMPLÉMENTÉE

### Structure des Dossiers

```
chenu_v70/
│
├── api/                          # REST API (70 endpoints)
│   ├── main.py                   # FastAPI application
│   └── routers/
│       ├── core.py               # Identity, DataSpace, Thread
│       ├── engines.py            # Workspace, OneClick, Backstage
│       ├── memory_agents.py      # Memory, Governance, Agents
│       └── meeting_immobilier.py # Meeting, Immobilier
│
├── database/
│   └── complete_schema_v70.sql   # Schema PostgreSQL complet
│
├── agent_system/                 # 287 agents L0-L3
│   ├── engine.py
│   └── prompts.py                # 18 prompt templates
│
├── [14 modules GP2]
│   ├── nova_kernel/
│   ├── ethics_canon/
│   ├── module_26_transmission/
│   ├── module_27_heritage/
│   ├── module_28_culture/
│   ├── module_29_planetary/
│   ├── module_30_civilization_os/
│   ├── module_31_temporal/
│   ├── module_32_collapse/
│   ├── module_33_meaning/
│   ├── module_34_evolution/
│   ├── module_35_intergenerational/
│   ├── module_36_failsafe/
│   ├── module_37_external/
│   ├── module_38_myth_symbol/
│   └── module_39_posthuman/
│
├── [9 engines/domains V70]
│   ├── workspace_engine/
│   ├── dataspace_engine/
│   ├── meeting_system/
│   ├── memory_governance/
│   ├── backstage_intelligence/
│   ├── oneclick_engine/
│   ├── ocw_engine/
│   ├── immobilier_domain/
│   └── layout_engine/
│
├── tests/
│   ├── test_api.py               # 50+ tests API
│   ├── test_governance.py        # Tests Ten Laws
│   └── test_integration.py       # Tests E2E
│
├── docs/
│   ├── ARCHITECTURE.md           # 16 Mermaid diagrams
│   ├── API_REFERENCE.md          # Documentation API complète
│   └── DEPLOYMENT.md             # Guide déploiement
│
└── [Infrastructure]
    ├── docker-compose.yml
    ├── Dockerfile
    ├── k8s/
    ├── .github/workflows/
    └── monitoring/
```

---

## 🔐 GOUVERNANCE IMPLÉMENTÉE

### Principes Codés en SQL

```sql
-- LAW 1: No Hidden Memory
CONSTRAINT memory_visible CHECK (visible_to_user = TRUE)

-- LAW 5: Reversibility  
CONSTRAINT memory_deletable CHECK (user_deletable = TRUE)

-- LAW 7: No Self-Directed Learning
CONSTRAINT agent_no_unauthorized_learning CHECK (...)

-- XR Read Only
CONSTRAINT xr_read_only CHECK (is_read_only = TRUE)

-- Synthetic Only
CONSTRAINT execution_synthetic CHECK (synthetic = TRUE)

-- L0 Not Hireable
CONSTRAINT l0_not_hireable CHECK (NOT (agent_level = 'L0' AND is_hireable = TRUE))

-- Recording Consent
CONSTRAINT meeting_recording_consent CHECK (recording_enabled = FALSE OR all_consents_obtained = TRUE)
```

### Principes Codés en API

Tous les endpoints sensibles retournent:
```json
{
  "data": {
    "synthetic": true,
    "requires_hitl": true,
    "governance": {
      "identity_scoped": true,
      "audit_logged": true
    }
  }
}
```

---

## 📋 ÉTAPES D'ASSEMBLAGE

### Étape 1: Préparation Base de Données

```bash
# Créer la base de données
psql -U postgres -c "CREATE DATABASE chenu_db;"

# Appliquer le schema
psql -U chenu -d chenu_db -f database/complete_schema_v70.sql

# Le schema crée automatiquement:
# - 35+ tables
# - 9 sphères par défaut
# - 3 domaines (immobilier, construction, finance)
# - Contraintes de gouvernance
```

### Étape 2: Configuration Environnement

```bash
# Copier le template
cp .env.example .env

# Configurer les variables essentielles:
DATABASE_URL=postgresql://chenu:password@localhost:5432/chenu_db
JWT_SECRET_KEY=your-secret-key
ANTHROPIC_API_KEY=your-api-key
```

### Étape 3: Installation Dépendances

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Étape 4: Lancement API

```bash
# Mode développement
uvicorn api.main:app --reload --host 0.0.0.0 --port 8000

# Mode production
gunicorn api.main:app -w 4 -k uvicorn.workers.UvicornWorker
```

### Étape 5: Vérification

```bash
# Health check
curl http://localhost:8000/health

# Root info
curl http://localhost:8000/

# Tests
pytest tests/ -v
```

---

## 🔗 POINTS D'INTÉGRATION

### Pour le Frontend

Les routers API sont disponibles sous `/v1/`:

| Préfixe | Description |
|---------|-------------|
| `/v1/identities` | Gestion identités |
| `/v1/dataspaces` | DataSpaces CRUD |
| `/v1/threads` | Threads & messages |
| `/v1/workspaces` | Workspace modes |
| `/v1/oneclick` | 1-Click Assistant |
| `/v1/backstage` | Intelligence layer |
| `/v1/memory` | Memory (Ten Laws) |
| `/v1/governance` | Audit & HITL |
| `/v1/agents` | 287 agents |
| `/v1/meetings` | Meetings |
| `/v1/immobilier` | Immobilier (TAL) |

### Headers Requis

```http
Authorization: Bearer <jwt_token>
X-Identity-ID: <uuid>
X-Request-ID: <uuid>
```

### Format de Réponse Standard

```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "request_id": "uuid",
    "timestamp": "ISO8601",
    "version": "v1"
  }
}
```

---

## 🤖 SYSTÈME D'AGENTS

### Hiérarchie

| Niveau | Quantité | Description | Hireable |
|--------|----------|-------------|----------|
| L0 | 2 | System (Nova, Backstage) | ❌ JAMAIS |
| L1 | 1 | Orchestrator (par user) | ✅ |
| L2 | 8 | Sphere Chiefs | ✅ |
| L3 | 276 | Task Agents | ✅ |

### Prompts Disponibles

18 templates de prompts dans `agent_system/prompts.py`:
- System prompts (Nova, Backstage)
- Orchestrator prompts
- Domain-specific prompts (Construction, Immobilier, Finance...)
- Task prompts (Estimator, Analyst, Manager...)

---

## 📊 MODULES GP2

### Foundation (26-29)

| Module | Description | Lignes |
|--------|-------------|--------|
| 26 | Transmission - Knowledge transfer | ~690 |
| 27 | Heritage - Identity management | ~740 |
| 28 | Culture - Cultural profiles | ~690 |
| 29 | Planetary - Cross-node coordination | ~550 |

### Sustainability (31-35)

| Module | Description | Lignes |
|--------|-------------|--------|
| 31 | Temporal - Time-scale reasoning | ~480 |
| 32 | Collapse - Graceful degradation | ~520 |
| 33 | Meaning - Purpose preservation | ~460 |
| 34 | Evolution - Adaptive mechanisms | ~490 |
| 35 | Intergenerational - Legacy | ~510 |

### Safety (36-39)

| Module | Description | Lignes |
|--------|-------------|--------|
| 36 | Failsafe - Emergency protocols | ~530 |
| 37 | External - Outside threats | ~490 |
| 38 | Myth Symbol - Narrative coherence | ~520 |
| 39 | PostHuman - Future ethics | ~540 |

### Core

| Module | Description | Lignes |
|--------|-------------|--------|
| Nova Kernel | System intelligence | ~840 |
| Ethics Canon | Immutable ethics | ~900 |
| Civilization OS | Decision loop | ~760 |

---

## ⚠️ POINTS D'ATTENTION

### 1. Gouvernance Obligatoire

**NE JAMAIS** désactiver les contraintes SQL de gouvernance.
Elles sont là pour appliquer les Tree Laws au niveau base de données.

### 2. L0 Agents Protégés

Les agents L0 (Nova, Backstage) ne peuvent JAMAIS être:
- Hired
- Fired
- Executed directement

### 3. HITL Obligatoire

Toutes les actions sensibles retournent `requires_hitl: true`.
Le frontend DOIT implémenter les checkpoints d'approbation.

### 4. Synthetic Only

Toutes les simulations sont `synthetic: true`.
Aucun effet réel sur des données de production.

### 5. TAL Compliance (Immobilier)

Le module Immobilier applique les règles du TAL (Québec):
- Section G obligatoire pour les baux
- Calcul d'augmentation selon la formule TAL
- Délais de préavis respectés

---

## 📈 STATISTIQUES FINALES

| Métrique | Valeur |
|----------|--------|
| Fichiers Python | 140+ |
| Lignes Python | 40,519 |
| Lignes SQL | 935 |
| Lignes Documentation | 2,334 |
| Lignes Tests | 2,682 |
| API Endpoints | 70 |
| Agents | 287 |
| Tables SQL | 35+ |
| Packages | 55+ |

---

## 🚀 PROCHAINES ÉTAPES (Hors Scope GP2)

Ce qui reste à faire dans d'autres sessions:

1. [ ] Intégrer avec frontend React existant
2. [ ] Intégrer avec app mobile React Native
3. [ ] Configurer authentification OAuth réelle
4. [ ] Setup Redis pour cache
5. [ ] Configurer monitoring Prometheus/Grafana
6. [ ] Tests de charge
7. [ ] Déploiement staging/production

---

## 📞 SUPPORT

En cas de question sur ce package:
1. Consulter `docs/ARCHITECTURE.md` pour les diagrammes
2. Consulter `docs/API_REFERENCE.md` pour les endpoints
3. Consulter `docs/DEPLOYMENT.md` pour le déploiement
4. Exécuter `pytest tests/ -v` pour valider l'installation

---

*CHE·NU™ V70 GP2 — Package d'Assemblage*
*GOUVERNANCE > EXÉCUTION*
*© CHE·NU Technologies Inc. — Janvier 2026*
