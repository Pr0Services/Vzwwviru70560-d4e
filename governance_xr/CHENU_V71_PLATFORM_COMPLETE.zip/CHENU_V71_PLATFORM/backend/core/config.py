"""
CHE·NU™ V70 — CONFIGURATION MANAGEMENT
======================================
Centralized configuration for GP2 system.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
from pathlib import Path
import os
import json
import logging

logger = logging.getLogger("chenu.config")


@dataclass
class GovernanceConfig:
    """Governance configuration - CRITICAL."""
    
    # Core governance (NON-NEGOTIABLE)
    level: str = "strict"
    synthetic_only: bool = True
    xr_read_only: bool = True
    hitl_required: bool = True
    
    # OPA
    opa_enabled: bool = True
    opa_endpoint: str = "http://localhost:8181"
    opa_policy_path: str = "chenu/gp2"
    
    # Audit
    audit_enabled: bool = True
    audit_retention_days: int = 90


@dataclass
class DatabaseConfig:
    """Database configuration."""
    
    driver: str = "postgresql"
    host: str = "localhost"
    port: int = 5432
    database: str = "chenu"
    username: str = "chenu"
    password: str = ""
    
    # Pool
    pool_size: int = 10
    max_overflow: int = 20
    pool_timeout: int = 30
    
    @property
    def url(self) -> str:
        return f"{self.driver}://{self.username}:{self.password}@{self.host}:{self.port}/{self.database}"


@dataclass
class RedisConfig:
    """Redis configuration."""
    
    host: str = "localhost"
    port: int = 6379
    db: int = 0
    password: str = ""
    
    # Pool
    max_connections: int = 50
    socket_timeout: int = 5
    
    @property
    def url(self) -> str:
        if self.password:
            return f"redis://:{self.password}@{self.host}:{self.port}/{self.db}"
        return f"redis://{self.host}:{self.port}/{self.db}"


@dataclass
class APIConfig:
    """API configuration."""
    
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    
    # CORS
    cors_origins: list[str] = field(default_factory=lambda: ["*"])
    cors_credentials: bool = True
    
    # Rate limiting
    rate_limit_enabled: bool = True
    rate_limit_requests: int = 100
    rate_limit_window: int = 60  # seconds
    
    # Timeouts
    request_timeout: int = 30
    websocket_timeout: int = 300


@dataclass
class SimulationConfig:
    """Simulation configuration."""
    
    mode: str = "deterministic"
    max_cycles: int = 1000
    default_cycles: int = 10
    
    # Constraints
    synthetic_only: bool = True  # CRITICAL
    max_concurrent: int = 5
    
    # WorldEngine
    worldengine_endpoint: str = "http://localhost:8001"


@dataclass
class XRConfig:
    """XR configuration."""
    
    # CRITICAL - READ ONLY
    read_only: bool = True
    
    # Rendering
    default_render_mode: str = "threejs"
    enable_webxr: bool = True
    
    # Assets
    asset_cdn_url: str = ""
    
    # Verification
    verify_signatures: bool = True
    wasm_verification: bool = True


@dataclass
class LoggingConfig:
    """Logging configuration."""
    
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    
    # File logging
    file_enabled: bool = True
    file_path: str = "logs/chenu-gp2.log"
    file_max_bytes: int = 10_485_760  # 10MB
    file_backup_count: int = 5
    
    # JSON logging
    json_enabled: bool = True


@dataclass
class GP2SystemConfig:
    """Complete GP2 system configuration."""
    
    # Environment
    environment: str = "development"
    version: str = "70.0.0"
    
    # Sub-configurations
    governance: GovernanceConfig = field(default_factory=GovernanceConfig)
    database: DatabaseConfig = field(default_factory=DatabaseConfig)
    redis: RedisConfig = field(default_factory=RedisConfig)
    api: APIConfig = field(default_factory=APIConfig)
    simulation: SimulationConfig = field(default_factory=SimulationConfig)
    xr: XRConfig = field(default_factory=XRConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    
    # Modules
    enable_nova_kernel: bool = True
    enable_ethics_canon: bool = True
    enable_civilization_os: bool = True
    enable_failsafe: bool = True
    
    def validate(self) -> list[str]:
        """Validate configuration."""
        errors = []
        
        # CRITICAL checks
        if not self.governance.synthetic_only:
            errors.append("CRITICAL: synthetic_only must be True")
        
        if not self.xr.read_only:
            errors.append("CRITICAL: XR read_only must be True")
        
        if self.governance.level not in ["strict", "standard"]:
            errors.append(f"Invalid governance level: {self.governance.level}")
        
        return errors
    
    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            "environment": self.environment,
            "version": self.version,
            "governance": {
                "level": self.governance.level,
                "synthetic_only": self.governance.synthetic_only,
                "xr_read_only": self.xr.read_only,
                "hitl_required": self.governance.hitl_required,
                "opa_enabled": self.governance.opa_enabled,
            },
            "api": {
                "host": self.api.host,
                "port": self.api.port,
            },
            "modules": {
                "nova_kernel": self.enable_nova_kernel,
                "ethics_canon": self.enable_ethics_canon,
                "civilization_os": self.enable_civilization_os,
                "failsafe": self.enable_failsafe,
            },
        }


class ConfigLoader:
    """Configuration loader from environment and files."""
    
    @staticmethod
    def from_env() -> GP2SystemConfig:
        """Load configuration from environment variables."""
        config = GP2SystemConfig()
        
        # Environment
        config.environment = os.getenv("CHENU_ENV", "development")
        
        # Governance
        config.governance.level = os.getenv("GOVERNANCE_LEVEL", "strict")
        config.governance.synthetic_only = os.getenv("SYNTHETIC_ONLY", "true").lower() == "true"
        config.governance.hitl_required = os.getenv("HITL_REQUIRED", "true").lower() == "true"
        config.governance.opa_endpoint = os.getenv("OPA_ENDPOINT", "http://localhost:8181")
        
        # XR (CRITICAL)
        config.xr.read_only = True  # ALWAYS TRUE
        
        # Database
        db_url = os.getenv("DATABASE_URL", "")
        if db_url:
            # Parse DATABASE_URL
            config.database.host = os.getenv("DB_HOST", "localhost")
            config.database.port = int(os.getenv("DB_PORT", "5432"))
            config.database.database = os.getenv("DB_NAME", "chenu")
            config.database.username = os.getenv("DB_USER", "chenu")
            config.database.password = os.getenv("DB_PASSWORD", "")
        
        # Redis
        redis_url = os.getenv("REDIS_URL", "")
        if redis_url:
            config.redis.host = os.getenv("REDIS_HOST", "localhost")
            config.redis.port = int(os.getenv("REDIS_PORT", "6379"))
        
        # API
        config.api.host = os.getenv("API_HOST", "0.0.0.0")
        config.api.port = int(os.getenv("API_PORT", "8000"))
        config.api.debug = os.getenv("API_DEBUG", "false").lower() == "true"
        
        # Logging
        config.logging.level = os.getenv("LOG_LEVEL", "INFO")
        
        return config
    
    @staticmethod
    def from_file(path: str) -> GP2SystemConfig:
        """Load configuration from JSON file."""
        config = GP2SystemConfig()
        
        file_path = Path(path)
        if not file_path.exists():
            logger.warning(f"Config file not found: {path}")
            return config
        
        with open(file_path) as f:
            data = json.load(f)
        
        # Apply loaded config
        if "environment" in data:
            config.environment = data["environment"]
        
        if "governance" in data:
            gov = data["governance"]
            config.governance.level = gov.get("level", config.governance.level)
            # Never load synthetic_only=False from file
            config.governance.synthetic_only = True
            config.governance.hitl_required = gov.get("hitl_required", True)
        
        if "database" in data:
            db = data["database"]
            config.database.host = db.get("host", config.database.host)
            config.database.port = db.get("port", config.database.port)
            config.database.database = db.get("database", config.database.database)
        
        # XR is ALWAYS read_only
        config.xr.read_only = True
        
        return config
    
    @staticmethod
    def load() -> GP2SystemConfig:
        """Load configuration with priority: env > file > defaults."""
        # Start with defaults
        config = GP2SystemConfig()
        
        # Try file
        config_path = os.getenv("CHENU_CONFIG", "config/gp2.json")
        if Path(config_path).exists():
            config = ConfigLoader.from_file(config_path)
        
        # Override with env
        env_config = ConfigLoader.from_env()
        
        # Merge (env takes precedence)
        config.environment = env_config.environment or config.environment
        config.governance.level = env_config.governance.level
        config.governance.opa_endpoint = env_config.governance.opa_endpoint
        config.database.host = env_config.database.host or config.database.host
        config.api.port = env_config.api.port
        config.logging.level = env_config.logging.level
        
        # CRITICAL - Force governance
        config.governance.synthetic_only = True
        config.xr.read_only = True
        
        # Validate
        errors = config.validate()
        if errors:
            for error in errors:
                logger.error(f"Config error: {error}")
            raise ValueError(f"Invalid configuration: {errors}")
        
        logger.info(f"Configuration loaded: {config.environment}")
        return config


# =============================================================================
# SINGLETON
# =============================================================================

_config: Optional[GP2SystemConfig] = None


def get_config() -> GP2SystemConfig:
    """Get the configuration singleton."""
    global _config
    if _config is None:
        _config = ConfigLoader.load()
    return _config


def reload_config():
    """Reload configuration."""
    global _config
    _config = ConfigLoader.load()
    return _config
