"""
CHE·NU™ V70 — CACHE LAYER
=========================
Caching for GP2 system with Redis support.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Optional, TypeVar, Generic
from uuid import uuid4
import json
import hashlib
import logging
from abc import ABC, abstractmethod

logger = logging.getLogger("chenu.cache")

T = TypeVar('T')


# =============================================================================
# CACHE INTERFACES
# =============================================================================

class CacheBackend(ABC):
    """Abstract cache backend."""
    
    @abstractmethod
    async def get(self, key: str) -> Optional[str]:
        pass
    
    @abstractmethod
    async def set(self, key: str, value: str, ttl: Optional[int] = None):
        pass
    
    @abstractmethod
    async def delete(self, key: str):
        pass
    
    @abstractmethod
    async def exists(self, key: str) -> bool:
        pass
    
    @abstractmethod
    async def clear_pattern(self, pattern: str):
        pass


# =============================================================================
# IN-MEMORY CACHE (for development)
# =============================================================================

@dataclass
class CacheEntry:
    """Cache entry with TTL."""
    value: str
    created_at: datetime = field(default_factory=datetime.utcnow)
    ttl: Optional[int] = None  # seconds
    
    def is_expired(self) -> bool:
        if self.ttl is None:
            return False
        expiry = self.created_at + timedelta(seconds=self.ttl)
        return datetime.utcnow() > expiry


class InMemoryCache(CacheBackend):
    """Simple in-memory cache."""
    
    def __init__(self, max_size: int = 10000):
        self._cache: dict[str, CacheEntry] = {}
        self._max_size = max_size
    
    async def get(self, key: str) -> Optional[str]:
        entry = self._cache.get(key)
        if entry is None:
            return None
        if entry.is_expired():
            del self._cache[key]
            return None
        return entry.value
    
    async def set(self, key: str, value: str, ttl: Optional[int] = None):
        # Evict if at max size
        if len(self._cache) >= self._max_size:
            self._evict_expired()
        
        self._cache[key] = CacheEntry(value=value, ttl=ttl)
    
    async def delete(self, key: str):
        self._cache.pop(key, None)
    
    async def exists(self, key: str) -> bool:
        entry = self._cache.get(key)
        if entry is None:
            return False
        if entry.is_expired():
            del self._cache[key]
            return False
        return True
    
    async def clear_pattern(self, pattern: str):
        pattern = pattern.replace("*", "")
        keys_to_delete = [k for k in self._cache.keys() if pattern in k]
        for key in keys_to_delete:
            del self._cache[key]
    
    def _evict_expired(self):
        expired = [k for k, v in self._cache.items() if v.is_expired()]
        for key in expired:
            del self._cache[key]


# =============================================================================
# REDIS CACHE
# =============================================================================

class RedisCache(CacheBackend):
    """Redis cache backend."""
    
    def __init__(self, redis_url: str = "redis://localhost:6379/0"):
        self._redis_url = redis_url
        self._client = None
    
    async def _get_client(self):
        if self._client is None:
            try:
                import redis.asyncio as redis
                self._client = redis.from_url(self._redis_url)
            except ImportError:
                logger.warning("redis package not installed, using in-memory cache")
                return None
        return self._client
    
    async def get(self, key: str) -> Optional[str]:
        client = await self._get_client()
        if client is None:
            return None
        try:
            value = await client.get(key)
            return value.decode() if value else None
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            return None
    
    async def set(self, key: str, value: str, ttl: Optional[int] = None):
        client = await self._get_client()
        if client is None:
            return
        try:
            if ttl:
                await client.setex(key, ttl, value)
            else:
                await client.set(key, value)
        except Exception as e:
            logger.error(f"Redis set error: {e}")
    
    async def delete(self, key: str):
        client = await self._get_client()
        if client is None:
            return
        try:
            await client.delete(key)
        except Exception as e:
            logger.error(f"Redis delete error: {e}")
    
    async def exists(self, key: str) -> bool:
        client = await self._get_client()
        if client is None:
            return False
        try:
            return await client.exists(key) > 0
        except Exception as e:
            logger.error(f"Redis exists error: {e}")
            return False
    
    async def clear_pattern(self, pattern: str):
        client = await self._get_client()
        if client is None:
            return
        try:
            cursor = 0
            while True:
                cursor, keys = await client.scan(cursor, match=pattern, count=100)
                if keys:
                    await client.delete(*keys)
                if cursor == 0:
                    break
        except Exception as e:
            logger.error(f"Redis clear_pattern error: {e}")


# =============================================================================
# CACHE MANAGER
# =============================================================================

class CacheManager:
    """
    Cache manager for GP2 system.
    
    Features:
    - Multiple cache namespaces
    - TTL support
    - Cache invalidation
    - Statistics
    """
    
    # Cache namespaces
    NS_OPA = "opa"
    NS_ETHICS = "ethics"
    NS_DECISIONS = "decisions"
    NS_SIMULATIONS = "simulations"
    NS_XR_SCENES = "xr_scenes"
    
    def __init__(self, backend: Optional[CacheBackend] = None):
        self.manager_id = f"CACHE_{uuid4().hex[:8]}"
        self._backend = backend or InMemoryCache()
        self._stats = {
            "hits": 0,
            "misses": 0,
            "sets": 0,
            "deletes": 0,
        }
        
        logger.info(f"Cache Manager initialized: {self.manager_id}")
    
    def _make_key(self, namespace: str, key: str) -> str:
        """Create namespaced cache key."""
        return f"chenu:gp2:{namespace}:{key}"
    
    # =========================================================================
    # BASIC OPERATIONS
    # =========================================================================
    
    async def get(
        self,
        namespace: str,
        key: str,
    ) -> Optional[Any]:
        """Get value from cache."""
        cache_key = self._make_key(namespace, key)
        value = await self._backend.get(cache_key)
        
        if value is None:
            self._stats["misses"] += 1
            return None
        
        self._stats["hits"] += 1
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    
    async def set(
        self,
        namespace: str,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
    ):
        """Set value in cache."""
        cache_key = self._make_key(namespace, key)
        
        if isinstance(value, (dict, list)):
            value = json.dumps(value)
        
        await self._backend.set(cache_key, value, ttl)
        self._stats["sets"] += 1
    
    async def delete(self, namespace: str, key: str):
        """Delete value from cache."""
        cache_key = self._make_key(namespace, key)
        await self._backend.delete(cache_key)
        self._stats["deletes"] += 1
    
    async def exists(self, namespace: str, key: str) -> bool:
        """Check if key exists."""
        cache_key = self._make_key(namespace, key)
        return await self._backend.exists(cache_key)
    
    async def invalidate_namespace(self, namespace: str):
        """Invalidate all keys in namespace."""
        pattern = self._make_key(namespace, "*")
        await self._backend.clear_pattern(pattern)
        logger.info(f"Invalidated namespace: {namespace}")
    
    # =========================================================================
    # SPECIALIZED CACHING
    # =========================================================================
    
    async def cache_opa_decision(
        self,
        policy_path: str,
        input_hash: str,
        decision: dict,
        ttl: int = 300,  # 5 minutes
    ):
        """Cache OPA decision."""
        key = f"{policy_path}:{input_hash}"
        await self.set(self.NS_OPA, key, decision, ttl)
    
    async def get_opa_decision(
        self,
        policy_path: str,
        input_hash: str,
    ) -> Optional[dict]:
        """Get cached OPA decision."""
        key = f"{policy_path}:{input_hash}"
        return await self.get(self.NS_OPA, key)
    
    async def cache_ethics_validation(
        self,
        action_hash: str,
        result: dict,
        ttl: int = 600,  # 10 minutes
    ):
        """Cache ethics validation result."""
        await self.set(self.NS_ETHICS, action_hash, result, ttl)
    
    async def get_ethics_validation(
        self,
        action_hash: str,
    ) -> Optional[dict]:
        """Get cached ethics validation."""
        return await self.get(self.NS_ETHICS, action_hash)
    
    async def cache_decision_package(
        self,
        package_id: str,
        package_data: dict,
        ttl: int = 3600,  # 1 hour
    ):
        """Cache decision package."""
        await self.set(self.NS_DECISIONS, package_id, package_data, ttl)
    
    async def get_decision_package(
        self,
        package_id: str,
    ) -> Optional[dict]:
        """Get cached decision package."""
        return await self.get(self.NS_DECISIONS, package_id)
    
    async def cache_xr_scene(
        self,
        scene_id: str,
        scene_data: dict,
        ttl: int = 1800,  # 30 minutes
    ):
        """Cache XR scene."""
        await self.set(self.NS_XR_SCENES, scene_id, scene_data, ttl)
    
    async def get_xr_scene(
        self,
        scene_id: str,
    ) -> Optional[dict]:
        """Get cached XR scene."""
        return await self.get(self.NS_XR_SCENES, scene_id)
    
    # =========================================================================
    # HELPERS
    # =========================================================================
    
    @staticmethod
    def hash_input(data: Any) -> str:
        """Create hash of input data for cache key."""
        if isinstance(data, dict):
            data = json.dumps(data, sort_keys=True)
        return hashlib.sha256(str(data).encode()).hexdigest()[:16]
    
    # =========================================================================
    # STATS
    # =========================================================================
    
    def get_stats(self) -> dict:
        """Get cache statistics."""
        total = self._stats["hits"] + self._stats["misses"]
        hit_rate = self._stats["hits"] / total if total > 0 else 0
        
        return {
            "manager_id": self.manager_id,
            "hits": self._stats["hits"],
            "misses": self._stats["misses"],
            "sets": self._stats["sets"],
            "deletes": self._stats["deletes"],
            "hit_rate": hit_rate,
        }


# =============================================================================
# DECORATOR
# =============================================================================

def cached(
    namespace: str,
    ttl: int = 300,
    key_fn: Optional[callable] = None,
):
    """
    Decorator to cache function results.
    
    Usage:
        @cached("opa", ttl=300)
        async def validate_action(action: str) -> dict:
            ...
    """
    def decorator(func):
        async def wrapper(*args, **kwargs):
            cache = get_cache_manager()
            
            # Generate cache key
            if key_fn:
                cache_key = key_fn(*args, **kwargs)
            else:
                cache_key = CacheManager.hash_input(str(args) + str(kwargs))
            
            # Check cache
            cached_result = await cache.get(namespace, cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function
            result = await func(*args, **kwargs)
            
            # Cache result
            await cache.set(namespace, cache_key, result, ttl)
            
            return result
        
        return wrapper
    return decorator


# =============================================================================
# SINGLETON
# =============================================================================

_cache_manager: Optional[CacheManager] = None


def get_cache_manager() -> CacheManager:
    """Get the cache manager singleton."""
    global _cache_manager
    if _cache_manager is None:
        # Try Redis first, fallback to in-memory
        import os
        redis_url = os.getenv("REDIS_URL", "")
        
        if redis_url:
            backend = RedisCache(redis_url)
        else:
            backend = InMemoryCache()
        
        _cache_manager = CacheManager(backend)
    
    return _cache_manager
