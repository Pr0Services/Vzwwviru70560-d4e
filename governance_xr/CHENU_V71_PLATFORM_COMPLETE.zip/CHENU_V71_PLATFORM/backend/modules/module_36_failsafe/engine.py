"""
CHE·NU™ V70 — MODULE 36: CIVILIZATIONAL FAIL-SAFE & COLLAPSE PROTOCOL
=====================================================================
Garantit la continuité de CHE·NU™ en cas d'effondrement.

Principes:
- Aucun agent ne décide seul
- Priorité absolue à la survie humaine
- Dégradation gracieuse
- Reconstructibilité déterministe

CHE·NU™ ne s'arrête jamais brutalement. Elle ralentit pour survivre.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import hashlib
import json
import logging

logger = logging.getLogger("chenu.module_36")


class CrisisType(str, Enum):
    """Types de crise."""
    DIGITAL_BLACKOUT = "digital_blackout"
    SOCIAL_FRAGMENTATION = "social_fragmentation"
    LOGISTIC_COLLAPSE = "logistic_collapse"
    POLITICAL_CAPTURE = "political_capture"
    MULTI_CRISIS = "multi_crisis"


class ResponseLevel(str, Enum):
    """Niveaux de réponse."""
    N0_MONITORING = "n0_monitoring"  # Monitoring passif
    N1_FREEZE_OPTIMIZATION = "n1_freeze_optimization"  # Gel des optimisations
    N2_VITAL_FOCUS = "n2_vital_focus"  # Recentrage besoins vitaux
    N3_LOCAL_AUTONOMY = "n3_local_autonomy"  # Autonomie locale totale
    N4_ARCHIVE = "n4_archive"  # Archivage civilisationnel


@dataclass
class WorldSnapshot:
    """Snapshot de l'état du monde pour reconstruction."""
    snapshot_id: str = field(default_factory=lambda: f"SNAP_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # State
    worldstate_hash: str = ""
    critical_data: dict[str, Any] = field(default_factory=dict)
    
    # Metadata
    crisis_context: Optional[str] = None
    response_level: ResponseLevel = ResponseLevel.N0_MONITORING
    
    # Verification
    integrity_hash: str = ""
    signatures: list[str] = field(default_factory=list)


@dataclass
class DNALedger:
    """
    Ledger ADN - registre des éléments essentiels pour reconstruction.
    """
    ledger_id: str = field(default_factory=lambda: f"DNA_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Essential elements
    core_values: list[str] = field(default_factory=list)
    critical_skills: list[str] = field(default_factory=list)
    governance_rules: list[str] = field(default_factory=list)
    survival_procedures: list[str] = field(default_factory=list)
    
    # Verification
    verified: bool = False
    signatures: list[str] = field(default_factory=list)


@dataclass
class LocalSurvivalMap:
    """Cartographie de survie locale."""
    map_id: str = field(default_factory=lambda: f"SURVIVAL_{uuid4().hex[:8]}")
    community_id: str = ""
    
    # Resources
    water_sources: list[dict[str, Any]] = field(default_factory=list)
    food_sources: list[dict[str, Any]] = field(default_factory=list)
    shelter_locations: list[dict[str, Any]] = field(default_factory=list)
    medical_resources: list[dict[str, Any]] = field(default_factory=list)
    
    # Human resources
    skilled_individuals: list[str] = field(default_factory=list)
    leadership_structure: dict[str, Any] = field(default_factory=dict)
    
    # Status
    last_verified: Optional[datetime] = None
    confidence_score: float = 0.0


@dataclass
class FailsafeActivation:
    """Activation du failsafe."""
    activation_id: str = field(default_factory=lambda: f"FAILSAFE_{uuid4().hex[:8]}")
    activated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Crisis
    crisis_type: CrisisType = CrisisType.DIGITAL_BLACKOUT
    response_level: ResponseLevel = ResponseLevel.N1_FREEZE_OPTIMIZATION
    
    # Actions taken
    actions: list[str] = field(default_factory=list)
    
    # Status
    is_active: bool = True
    deactivated_at: Optional[datetime] = None


class CivilizationalFailsafeEngine:
    """
    Module 36 — Civilizational Fail-Safe & Collapse Protocol
    
    Garantit la continuité de CHE·NU™ en cas d'effondrement.
    
    Modes de Crise:
    1. Blackout Numérique
    2. Fragmentation Sociale
    3. Effondrement Logistique
    4. Capture Politique Externe
    
    Niveaux de Réponse:
    - N0: Monitoring passif
    - N1: Gel des optimisations
    - N2: Recentrage sur besoins vitaux
    - N3: Autonomie locale totale
    - N4: Archivage civilisationnel
    
    CHE·NU™ ne s'arrête jamais brutalement. Elle ralentit pour survivre.
    """
    
    def __init__(
        self,
        worldengine: Optional[Any] = None,
        orchestration: Optional[Any] = None,
        transmission: Optional[Any] = None,
    ):
        self.engine_id = f"FAILSAFE_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies (Modules 04, 22, 35)
        self.worldengine = worldengine
        self.orchestration = orchestration
        self.transmission = transmission
        
        self._snapshots: dict[str, WorldSnapshot] = {}
        self._ledgers: dict[str, DNALedger] = {}
        self._survival_maps: dict[str, LocalSurvivalMap] = {}
        self._activations: dict[str, FailsafeActivation] = {}
        
        self.current_response_level = ResponseLevel.N0_MONITORING
        
        logger.info(f"Civilizational Failsafe Engine initialized: {self.engine_id}")
    
    # =========================================================================
    # CRISIS DETECTION
    # =========================================================================
    
    def detect_crisis(
        self,
        indicators: dict[str, float],
    ) -> Optional[CrisisType]:
        """
        Detect crisis type from indicators.
        """
        # Digital blackout indicators
        if indicators.get("network_availability", 1.0) < 0.3:
            return CrisisType.DIGITAL_BLACKOUT
        
        # Social fragmentation
        if indicators.get("social_cohesion", 1.0) < 0.4:
            return CrisisType.SOCIAL_FRAGMENTATION
        
        # Logistic collapse
        if indicators.get("supply_chain_health", 1.0) < 0.3:
            return CrisisType.LOGISTIC_COLLAPSE
        
        # Political capture
        if indicators.get("governance_integrity", 1.0) < 0.4:
            return CrisisType.POLITICAL_CAPTURE
        
        return None
    
    def determine_response_level(self, crisis_type: CrisisType) -> ResponseLevel:
        """Determine appropriate response level."""
        # Single crisis -> moderate response
        if crisis_type in [CrisisType.DIGITAL_BLACKOUT, CrisisType.SOCIAL_FRAGMENTATION]:
            return ResponseLevel.N2_VITAL_FOCUS
        
        if crisis_type == CrisisType.LOGISTIC_COLLAPSE:
            return ResponseLevel.N3_LOCAL_AUTONOMY
        
        if crisis_type == CrisisType.POLITICAL_CAPTURE:
            return ResponseLevel.N1_FREEZE_OPTIMIZATION
        
        return ResponseLevel.N1_FREEZE_OPTIMIZATION
    
    # =========================================================================
    # FAILSAFE ACTIVATION
    # =========================================================================
    
    def activate_failsafe(
        self,
        crisis_type: CrisisType,
        response_level: Optional[ResponseLevel] = None,
    ) -> FailsafeActivation:
        """
        Activate the failsafe protocol.
        """
        if response_level is None:
            response_level = self.determine_response_level(crisis_type)
        
        activation = FailsafeActivation(
            crisis_type=crisis_type,
            response_level=response_level,
        )
        
        # Take actions based on level
        actions = self._execute_response_level(response_level)
        activation.actions = actions
        
        # Update current level
        self.current_response_level = response_level
        
        # Create snapshot
        self._create_emergency_snapshot(crisis_type, response_level)
        
        self._activations[activation.activation_id] = activation
        logger.critical(f"FAILSAFE ACTIVATED: {activation.activation_id} - Level {response_level.value}")
        
        return activation
    
    def _execute_response_level(self, level: ResponseLevel) -> list[str]:
        """Execute actions for a response level."""
        actions = []
        
        if level == ResponseLevel.N0_MONITORING:
            actions.append("monitoring_enhanced")
        
        if level == ResponseLevel.N1_FREEZE_OPTIMIZATION:
            actions.append("optimization_frozen")
            actions.append("monitoring_enhanced")
        
        if level == ResponseLevel.N2_VITAL_FOCUS:
            actions.extend([
                "optimization_frozen",
                "non_essential_suspended",
                "vital_resources_prioritized",
            ])
        
        if level == ResponseLevel.N3_LOCAL_AUTONOMY:
            actions.extend([
                "optimization_frozen",
                "non_essential_suspended",
                "vital_resources_prioritized",
                "local_autonomy_enabled",
                "central_dependencies_removed",
            ])
        
        if level == ResponseLevel.N4_ARCHIVE:
            actions.extend([
                "all_operations_suspended",
                "civilizational_archive_activated",
                "dna_ledger_sealed",
            ])
        
        return actions
    
    def deactivate_failsafe(self, activation_id: str) -> FailsafeActivation:
        """Deactivate a failsafe protocol."""
        activation = self._activations.get(activation_id)
        if not activation:
            raise ValueError(f"Activation not found: {activation_id}")
        
        activation.is_active = False
        activation.deactivated_at = datetime.utcnow()
        
        # Return to normal monitoring
        self.current_response_level = ResponseLevel.N0_MONITORING
        
        logger.info(f"Failsafe deactivated: {activation_id}")
        return activation
    
    # =========================================================================
    # SNAPSHOTS
    # =========================================================================
    
    def create_snapshot(self) -> WorldSnapshot:
        """Create a world snapshot for potential reconstruction."""
        snapshot = WorldSnapshot()
        
        # Get worldstate if available
        if self.worldengine:
            try:
                state = self.worldengine.get_current_state()
                snapshot.critical_data = state
                snapshot.worldstate_hash = hashlib.sha256(
                    json.dumps(state, sort_keys=True).encode()
                ).hexdigest()
            except Exception as e:
                logger.error(f"Failed to get worldstate: {e}")
        
        # Generate integrity hash
        snapshot.integrity_hash = hashlib.sha256(
            f"{snapshot.snapshot_id}:{snapshot.worldstate_hash}".encode()
        ).hexdigest()
        
        # Sign
        snapshot.signatures.append(
            f"SNAP_SIG:{snapshot.integrity_hash[:16]}"
        )
        
        self._snapshots[snapshot.snapshot_id] = snapshot
        return snapshot
    
    def _create_emergency_snapshot(
        self, 
        crisis_type: CrisisType, 
        level: ResponseLevel
    ) -> WorldSnapshot:
        """Create an emergency snapshot during crisis."""
        snapshot = self.create_snapshot()
        snapshot.crisis_context = crisis_type.value
        snapshot.response_level = level
        return snapshot
    
    # =========================================================================
    # DNA LEDGER
    # =========================================================================
    
    def create_dna_ledger(
        self,
        core_values: list[str],
        critical_skills: list[str],
        governance_rules: list[str],
        survival_procedures: list[str],
    ) -> DNALedger:
        """
        Create a DNA Ledger - essential elements for civilization reconstruction.
        """
        ledger = DNALedger(
            core_values=core_values,
            critical_skills=critical_skills,
            governance_rules=governance_rules,
            survival_procedures=survival_procedures,
        )
        
        # Sign
        content = json.dumps({
            "values": core_values,
            "skills": critical_skills,
        }, sort_keys=True)
        ledger.signatures.append(
            f"DNA_SIG:{hashlib.sha256(content.encode()).hexdigest()[:16]}"
        )
        ledger.verified = True
        
        self._ledgers[ledger.ledger_id] = ledger
        logger.info(f"DNA Ledger created: {ledger.ledger_id}")
        
        return ledger
    
    # =========================================================================
    # SURVIVAL MAPS
    # =========================================================================
    
    def create_survival_map(
        self,
        community_id: str,
        water_sources: list[dict[str, Any]] = None,
        food_sources: list[dict[str, Any]] = None,
    ) -> LocalSurvivalMap:
        """Create a local survival map."""
        survival_map = LocalSurvivalMap(
            community_id=community_id,
            water_sources=water_sources or [],
            food_sources=food_sources or [],
        )
        
        # Calculate confidence
        resource_count = len(survival_map.water_sources) + len(survival_map.food_sources)
        survival_map.confidence_score = min(resource_count * 0.1, 1.0)
        survival_map.last_verified = datetime.utcnow()
        
        self._survival_maps[survival_map.map_id] = survival_map
        return survival_map
    
    # =========================================================================
    # GRACEFUL DEGRADATION
    # =========================================================================
    
    def get_degradation_path(self) -> list[ResponseLevel]:
        """
        Get the graceful degradation path.
        CHE·NU™ never stops abruptly - it slows down to survive.
        """
        return [
            ResponseLevel.N0_MONITORING,
            ResponseLevel.N1_FREEZE_OPTIMIZATION,
            ResponseLevel.N2_VITAL_FOCUS,
            ResponseLevel.N3_LOCAL_AUTONOMY,
            ResponseLevel.N4_ARCHIVE,
        ]
    
    def can_operate_at_level(self, level: ResponseLevel) -> dict[str, bool]:
        """Check what can operate at a given level."""
        capabilities = {
            "optimization": level == ResponseLevel.N0_MONITORING,
            "non_essential": level in [ResponseLevel.N0_MONITORING, ResponseLevel.N1_FREEZE_OPTIMIZATION],
            "vital_services": level != ResponseLevel.N4_ARCHIVE,
            "local_autonomy": True,  # Always available
            "archive_access": True,  # Always available
        }
        return capabilities
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        return {
            "engine_id": self.engine_id,
            "current_response_level": self.current_response_level.value,
            "snapshots": len(self._snapshots),
            "dna_ledgers": len(self._ledgers),
            "survival_maps": len(self._survival_maps),
            "active_activations": sum(
                1 for a in self._activations.values() if a.is_active
            ),
        }
