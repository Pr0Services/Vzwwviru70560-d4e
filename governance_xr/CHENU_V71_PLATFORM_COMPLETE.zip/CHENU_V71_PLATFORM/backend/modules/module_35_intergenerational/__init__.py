"""
CHE·NU™ V70 — MODULE 35: INTERGENERATIONAL TRANSMISSION ENGINE
Knowledge, values and structures must survive generations.
"""

from .engine import (
    TransmissionType,
    GenerationPhase,
    LegacyArtifact,
    MentorshipGraph,
    TemporalTrustAnchor,
    GenerationTransition,
    IntergenerationalTransmissionEngine,
)

__all__ = [
    "TransmissionType",
    "GenerationPhase",
    "LegacyArtifact",
    "MentorshipGraph",
    "TemporalTrustAnchor",
    "GenerationTransition",
    "IntergenerationalTransmissionEngine",
]

__version__ = "70.0.0"
