
# AT-OM — VIDEO & MANIFEST SCRIPT PACKAGE
Date: 2026-01-07

Contents:
- Script 1: Invisible overload (problem framing)
- Script 2: AI memory fragmentation
- Script 3: AT-OM paradigm shift
- Script 4: Urgency and invitation

Use:
- Voice-over video
- XR onboarding narration
- Manifest excerpts

Tone:
Calm, lucid, non-blaming, urgent.

Next:
- Storyboard
- XR entry room script
- Multilingual versions
