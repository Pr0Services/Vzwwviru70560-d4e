# Changelog — Thread v2 Canonical Package
Date: 2026-01-06

- Added canonical definition, technical spec, security invariants
- Added JSON schema + SQL migration
- Added checklist + acceptance tests
