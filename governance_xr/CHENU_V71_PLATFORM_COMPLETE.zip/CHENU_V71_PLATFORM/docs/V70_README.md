# CHE·NU™ V70 — GP2 MODULES

> **GOUVERNANCE > EXÉCUTION**

![Version](https://img.shields.io/badge/version-70.0.0-gold)
![Status](https://img.shields.io/badge/status-production--ready-green)
![Governance](https://img.shields.io/badge/governance-strict-blue)

## 🎯 Overview

GP2 (Governance Pack 2) is the complete implementation of CHE·NU™ advanced modules (26-39), providing:

- **NOVA Kernel** - System intelligence (NOT a decision-maker)
- **Master Ethics Canon** - Immutable ethical rules
- **Civilization OS** - Decision loop orchestration
- **Foundation Modules (26-29)** - Transmission, Heritage, Culture, Planetary
- **Sustainability Modules (31-35)** - Temporal, Collapse, Meaning, Evolution, Intergenerational
- **Safety Modules (36-39)** - Failsafe, External, Myth Symbol, Post-Human Ethics

## 🔐 Governance Principles

All GP2 modules enforce these **NON-NEGOTIABLE** principles:

| Principle | Description |
|-----------|-------------|
| **GOUVERNANCE > EXÉCUTION** | Governance always takes precedence over execution |
| **XR = READ ONLY** | XR interfaces can only read, never write |
| **SYNTHETIC ONLY** | All simulations are synthetic, no real-world effects |
| **HITL OBLIGATOIRE** | Human-in-the-loop required for high-impact decisions |
| **NO AUTONOMOUS AGENTS** | Agents are tools, not decision-makers |
| **HUMAN PRIMACY** | AXIOM 0 - No system may override human sovereignty |

## 📦 Modules

### Core

| Module | Description | Lines |
|--------|-------------|-------|
| `nova_kernel` | System intelligence kernel | ~840 |
| `ethics_canon` | Master Ethics Canon (IMMUTABLE) | ~900 |

### Foundation (26-29)

| Module | Description | Lines |
|--------|-------------|-------|
| `module_26_transmission` | Skill trace & knowledge transmission | ~690 |
| `module_27_heritage` | Identity & heritage management | ~740 |
| `module_28_culture` | Culture profiles & myth artifacts | ~690 |
| `module_29_planetary` | Cross-node planetary coordination | ~550 |

### Civilization Layer (30)

| Module | Description | Lines |
|--------|-------------|-------|
| `module_30_civilization_os` | Decision loop orchestration | ~780 |

### Sustainability (31-35)

| Module | Description | Lines |
|--------|-------------|-------|
| `module_31_temporal` | Temporal rhythm & fatigue detection | ~840 |
| `module_32_collapse` | Collapse prevention engine | ~940 |
| `module_33_meaning` | Meaning & purpose mapping | ~910 |
| `module_34_evolution` | Controlled evolution & mutation | ~1000 |
| `module_35_intergenerational` | Legacy & generational transmission | ~1030 |

### Safety (36-39)

| Module | Description | Lines |
|--------|-------------|-------|
| `module_36_failsafe` | Civilizational failsafe protocol | ~1100 |
| `module_37_external` | External world interface | ~1180 |
| `module_38_myth_symbol` | Myth, symbol & meaning engine | ~1230 |
| `module_39_posthuman` | Post-human ethics (IMMUTABLE) | ~1230 |

### Infrastructure

| Component | Description | Lines |
|-----------|-------------|-------|
| `nova_cloud` | Cloud deployment toolkit | ~630 |
| `opa_policies` | OPA governance policies | ~520 |
| `api` | FastAPI endpoints | ~650 |
| `cli` | Command-line interface | ~420 |
| `database` | SQL schemas | ~450 |
| `integration` | Unified system integration | ~450 |
| `tests` | Pytest test suite | ~700 |

**Total: ~16,500+ lines across 50+ files**

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone https://github.com/chenu/chenu-v70-gp2.git
cd chenu-v70-gp2

# Install dependencies
pip install -r requirements.txt

# Run tests
pytest tests/ -v
```

### Using the CLI

```bash
# Validate action through NOVA
python -m cli.gp2_cli nova validate "simulate market scenario"

# Check against Ethics Canon
python -m cli.gp2_cli ethics check "autonomous decision"

# Execute decision loop
python -m cli.gp2_cli civilization decision "optimize resource allocation"

# Check failsafe status
python -m cli.gp2_cli failsafe status

# Activate failsafe level
python -m cli.gp2_cli failsafe activate n2

# Show GP2 info
python -m cli.gp2_cli info
```

### Using the API

```bash
# Start the API server
uvicorn api.gp2_endpoints:app --host 0.0.0.0 --port 8000

# Health check
curl http://localhost:8000/health

# Validate through NOVA
curl -X POST http://localhost:8000/api/v1/nova/validate \
  -H "Content-Type: application/json" \
  -H "X-Governance-Token: your-token" \
  -H "X-User-ID: user123" \
  -d '{"intent": "simulate scenario", "context": {}}'
```

### Using the Integration Module

```python
from integration.gp2_system import create_gp2_system, GP2Config

# Create system with custom config
config = GP2Config(
    governance_level="strict",
    synthetic_only=True,
    hitl_required=True,
)

system = create_gp2_system(config)

# Execute decision loop
result = system.execute_decision_loop(
    user_intent="Optimize budget allocation",
    context={"budget": 100000}
)

# Check governance
gov_result = system.enforce_governance(
    action="simulate market",
    actor="user"
)

# Get status
status = system.get_status()
```

## 🐳 Docker Deployment

```bash
# Using Docker Compose
cd nova_cloud
docker-compose up -d

# Services:
# - nova-kernel: 8000
# - worldengine: 8001
# - causal-engine: 8002
# - opa: 8181
# - postgres: 5432
# - redis: 6379
# - prometheus: 9090
# - grafana: 3000
```

## 🗄️ Database Setup

```bash
# Create database
createdb chenu

# Apply schemas
psql chenu < database/gp2_schemas.sql
```

## ⚖️ OPA Policies

GP2 includes comprehensive OPA policies in `opa_policies/gp2_policies.rego`:

- NOVA kernel validation
- Ethics canon enforcement
- Module-specific rules
- Forbidden state detection
- Human primacy checks

```bash
# Load policies into OPA
opa run --server --bundle opa_policies/
```

## 📊 Monitoring

Prometheus metrics available at `/metrics`:

- `chenu_gp2_requests_total`
- `chenu_gp2_governance_checks_total`
- `chenu_gp2_hitl_pending`
- `chenu_gp2_crisis_level`

## 🧪 Testing

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=. --cov-report=html

# Run specific module tests
pytest tests/test_gp2_modules.py::TestNovaKernel -v
```

## 🏗️ Architecture

```
                    ┌─────────────────────┐
                    │   USER / INTERFACE  │
                    └──────────┬──────────┘
                               │
                    ┌──────────▼──────────┐
                    │     GP2 SYSTEM      │
                    │   (Integration)     │
                    └──────────┬──────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
┌───────▼───────┐    ┌────────▼────────┐    ┌───────▼───────┐
│  NOVA KERNEL  │    │  ETHICS CANON   │    │     OPA       │
│  (Validator)  │    │  (IMMUTABLE)    │    │ (Governance)  │
└───────┬───────┘    └────────┬────────┘    └───────┬───────┘
        │                     │                     │
        └──────────────────────┼─────────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │  CIVILIZATION OS    │
                    │  (Decision Loop)    │
                    └──────────┬──────────┘
                               │
     ┌─────────────────────────┼─────────────────────────┐
     │                         │                         │
┌────▼────┐    ┌───────────────▼───────────────┐    ┌────▼────┐
│ MOD 26- │    │        MOD 31-35              │    │ MOD 36- │
│   29    │    │   (Sustainability)            │    │   39    │
│Foundation│    │                               │    │ Safety  │
└─────────┘    └───────────────────────────────┘    └─────────┘
```

## 🔒 Security

- All actions validated through OPA
- Ethics canon checks on every operation
- Human-in-the-loop for high-impact decisions
- Audit logging for all operations
- Ed25519 signatures for artifacts
- WASM verification for XR artifacts

## 📜 License

Proprietary - CHE·NU™ © 2024-2025

## 🤝 Contributing

See CONTRIBUTING.md for guidelines.

---

**CHE·NU™ ne s'arrête jamais brutalement. Elle ralentit pour survivre.**

*GOUVERNANCE > EXÉCUTION*

---

## 🌐 V70 COMPLETE STACK

### API Layer (70 Endpoints)

| Router | Endpoints | Description |
|--------|-----------|-------------|
| `/v1/identities` | 4 | Identity management |
| `/v1/dataspaces` | 6 | DataSpace CRUD & links |
| `/v1/threads` | 5 | Threads & messages |
| `/v1/workspaces` | 8 | Workspace modes & states |
| `/v1/oneclick` | 6 | 1-Click Assistant |
| `/v1/backstage` | 3 | Intelligence layer |
| `/v1/memory` | 7 | Memory with Ten Laws |
| `/v1/governance` | 4 | Audit & elevation |
| `/v1/agents` | 8 | 287 agent system |
| `/v1/meetings` | 8 | Meeting system |
| `/v1/immobilier` | 11 | Real estate domain |

### Database Schema (35+ Tables)

- **Identity**: users, identities, permissions
- **Spheres**: 9 spheres, domains, access
- **DataSpace**: dataspaces, items, links
- **Threads**: threads, messages, decisions
- **Workspace**: workspaces, panels, states
- **Memory**: memory_items, audit_log (Ten Laws enforced)
- **Agents**: 287 agents, hires, executions
- **Meetings**: meetings, participants, tasks
- **Immobilier**: properties, units, leases, payments

### Agent System (287 Agents)

| Level | Count | Description |
|-------|-------|-------------|
| L0 | 2 | System (Nova, Backstage) - **NEVER HIRED** |
| L1 | 1 | Orchestrator (per user) |
| L2 | 8 | Sphere Chiefs |
| L3 | 276 | Task Agents |

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| `docs/ARCHITECTURE.md` | Complete system architecture with Mermaid diagrams |
| `docs/API_REFERENCE.md` | Full API documentation (70 endpoints) |
| `docs/DEPLOYMENT.md` | Deployment guide (Docker, K8s, SSL) |
| `CHAPTERS_README.md` | V70 chapters overview |

---

## 🚀 Quick Start

```bash
# Clone repository
git clone https://github.com/chenu/chenu-platform.git
cd chenu-platform

# Setup environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Run database migrations
alembic upgrade head

# Start API server
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Docker Quick Start

```bash
docker-compose up -d
```

---

## 🔒 Governance Enforcement

### SQL Constraints (Database Level)

```sql
-- Memory visible to user (Law 1)
CONSTRAINT memory_visible CHECK (visible_to_user = TRUE)

-- Memory deletable (Law 5)
CONSTRAINT memory_deletable CHECK (user_deletable = TRUE)

-- XR read only
CONSTRAINT xr_read_only CHECK (is_read_only = TRUE)

-- Synthetic only
CONSTRAINT execution_synthetic CHECK (synthetic = TRUE)

-- L0 not hireable
CONSTRAINT l0_not_hireable CHECK (NOT (agent_level = 'L0' AND is_hireable = TRUE))

-- Recording consent
CONSTRAINT meeting_recording_consent CHECK (recording_enabled = FALSE OR all_consents_obtained = TRUE)
```

### API Enforcement

All API responses include governance tracking:

```json
{
  "data": {
    "synthetic": true,
    "governance": {
      "hitl_required": true,
      "scope_checked": true
    }
  }
}
```

---

## 📊 Statistics

| Metric | Value |
|--------|-------|
| **Total Files** | 140+ |
| **Python Lines** | 42,000+ |
| **SQL Lines** | 935 |
| **API Endpoints** | 70 |
| **Agents** | 287 |
| **Tests** | 100+ |
| **Documentation Pages** | 15+ |

---

## 🧪 Testing

```bash
# Run all tests
pytest tests/ -v

# Run governance tests
pytest tests/test_governance.py -v

# Run API tests
pytest tests/test_api.py -v

# Run with coverage
pytest --cov=. --cov-report=html
```

---

## 📁 Project Structure

```
chenu_v70/
├── api/                    # REST API (70 endpoints)
│   ├── routers/
│   │   ├── core.py         # Identity, DataSpace, Thread
│   │   ├── engines.py      # Workspace, OneClick, Backstage
│   │   ├── memory_agents.py# Memory, Governance, Agents
│   │   └── meeting_immobilier.py
│   └── main.py
├── agent_system/           # 287 agents
│   ├── engine.py
│   └── prompts.py
├── backstage_intelligence/
├── dataspace_engine/
├── database/
│   └── complete_schema_v70.sql
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API_REFERENCE.md
│   └── DEPLOYMENT.md
├── immobilier_domain/
├── meeting_system/
├── memory_governance/
├── module_26_transmission/
├── ...
├── module_39_posthuman/
├── nova_kernel/
├── ocw_engine/
├── oneclick_engine/
├── tests/
│   ├── test_api.py
│   ├── test_governance.py
│   └── test_integration.py
├── workspace_engine/
├── docker-compose.yml
├── requirements.txt
└── README.md
```

---

## 🏛️ CHE·NU Philosophy

CHE·NU™ is not a game, not a dashboard, not an autonomous AI.

It is a **system of understanding, simulation, and decision support**, where technology **never replaces humans** but gives them a **clear, verifiable, and governed vision**.

### Core Principles

1. **GOUVERNANCE > EXÉCUTION** — Governance always precedes execution
2. **Human Primacy** — Humans make decisions, AI supports
3. **Transparency** — All memory visible, all actions logged
4. **Reversibility** — Every action can be undone
5. **Domain Awareness** — Context-aware intelligence
6. **Safety First** — Synthetic simulations, no real effects

---

*CHE·NU™ V70 — January 2026*
*© CHE·NU Technologies Inc.*
