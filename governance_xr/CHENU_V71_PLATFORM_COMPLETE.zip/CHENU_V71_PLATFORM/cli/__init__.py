"""CHE·NU™ V70 — GP2 CLI Package"""
__version__ = "70.0.0"
