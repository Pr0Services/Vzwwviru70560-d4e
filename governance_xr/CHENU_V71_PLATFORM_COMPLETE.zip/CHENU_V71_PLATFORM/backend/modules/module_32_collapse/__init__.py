"""
CHE·NU™ V70 — MODULE 32: COLLAPSE PREVENTION ENGINE
Canon Rule: Un système qui ignore le silence s'effondre déjà.
"""

from .engine import (
    CollapseType,
    CollapseStage,
    ActionType,
    CollapseIndicator,
    CollapseAlert,
    PreventiveAction,
    CollapsePreventionEngine,
)

__all__ = [
    "CollapseType",
    "CollapseStage",
    "ActionType",
    "CollapseIndicator",
    "CollapseAlert",
    "PreventiveAction",
    "CollapsePreventionEngine",
]

__version__ = "70.0.0"
