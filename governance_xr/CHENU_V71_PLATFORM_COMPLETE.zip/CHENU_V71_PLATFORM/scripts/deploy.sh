#!/bin/bash
# ============================================================================
# CHE·NU™ V70 — DEPLOYMENT SCRIPT
# ============================================================================
# Production deployment script
# GOUVERNANCE > EXÉCUTION
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
CYAN='\033[0;36m'
NC='\033[0m'

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
DEPLOY_ENV="${DEPLOY_ENV:-staging}"
DOCKER_REGISTRY="${DOCKER_REGISTRY:-}"
IMAGE_TAG="${IMAGE_TAG:-v70.0.0}"

# ============================================================================
# FUNCTIONS
# ============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "\n${CYAN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}═══════════════════════════════════════════════════════════${NC}\n"
}

check_prerequisites() {
    log_step "Checking Prerequisites"
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        log_error "Docker is not installed"
        exit 1
    fi
    log_info "Docker: $(docker --version)"
    
    # Check Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        log_error "Docker Compose is not installed"
        exit 1
    fi
    log_info "Docker Compose: $(docker-compose --version)"
    
    # Check environment file
    if [ ! -f "$PROJECT_DIR/.env" ]; then
        log_warn ".env file not found, using defaults"
    fi
}

verify_governance() {
    log_step "Verifying Governance Compliance"
    
    # Check synthetic_only
    if grep -r "synthetic.*=.*False" --include="*.py" "$PROJECT_DIR" 2>/dev/null | grep -v test; then
        log_error "GOVERNANCE VIOLATION: synthetic=False found!"
        exit 1
    fi
    log_info "✓ SYNTHETIC_ONLY verified"
    
    # Check XR read_only
    if grep -r "read_only.*=.*False" --include="*.py" "$PROJECT_DIR" 2>/dev/null | grep -i xr; then
        log_error "GOVERNANCE VIOLATION: XR read_only=False found!"
        exit 1
    fi
    log_info "✓ XR_READ_ONLY verified"
    
    log_info "✓ All governance checks passed"
}

run_tests() {
    log_step "Running Tests"
    
    cd "$PROJECT_DIR"
    
    # Run pytest if available
    if command -v pytest &> /dev/null; then
        pytest tests/ -v --tb=short || {
            log_error "Tests failed!"
            exit 1
        }
    else
        log_warn "pytest not available, skipping tests"
    fi
    
    log_info "✓ All tests passed"
}

build_image() {
    log_step "Building Docker Image"
    
    cd "$PROJECT_DIR"
    
    # Build image
    docker build -t chenu-gp2:${IMAGE_TAG} \
        --build-arg BUILD_DATE=$(date -u +'%Y-%m-%dT%H:%M:%SZ') \
        --build-arg VERSION=${IMAGE_TAG} \
        -f Dockerfile \
        .
    
    log_info "✓ Image built: chenu-gp2:${IMAGE_TAG}"
    
    # Tag for registry if specified
    if [ -n "$DOCKER_REGISTRY" ]; then
        docker tag chenu-gp2:${IMAGE_TAG} ${DOCKER_REGISTRY}/chenu-gp2:${IMAGE_TAG}
        log_info "✓ Tagged: ${DOCKER_REGISTRY}/chenu-gp2:${IMAGE_TAG}"
    fi
}

push_image() {
    log_step "Pushing Docker Image"
    
    if [ -z "$DOCKER_REGISTRY" ]; then
        log_warn "DOCKER_REGISTRY not set, skipping push"
        return
    fi
    
    docker push ${DOCKER_REGISTRY}/chenu-gp2:${IMAGE_TAG}
    log_info "✓ Image pushed: ${DOCKER_REGISTRY}/chenu-gp2:${IMAGE_TAG}"
}

deploy_staging() {
    log_step "Deploying to Staging"
    
    cd "$PROJECT_DIR"
    
    # Stop existing containers
    docker-compose -f docker-compose.yml down || true
    
    # Start new containers
    docker-compose -f docker-compose.yml up -d
    
    # Wait for health check
    log_info "Waiting for health check..."
    sleep 10
    
    if curl -s http://localhost:8000/health | grep -q "healthy"; then
        log_info "✓ Staging deployment successful"
    else
        log_error "Health check failed!"
        docker-compose logs
        exit 1
    fi
}

deploy_production() {
    log_step "Deploying to Production"
    
    log_warn "Production deployment requires manual approval"
    read -p "Are you sure you want to deploy to production? (yes/no): " confirm
    
    if [ "$confirm" != "yes" ]; then
        log_info "Deployment cancelled"
        exit 0
    fi
    
    # Production deployment steps
    log_info "Deploying to production..."
    
    # Add production-specific deployment commands here
    # e.g., kubectl apply, helm upgrade, etc.
    
    log_info "✓ Production deployment completed"
}

rollback() {
    log_step "Rolling Back Deployment"
    
    # Get previous image tag
    PREVIOUS_TAG="${1:-latest}"
    
    log_info "Rolling back to: chenu-gp2:${PREVIOUS_TAG}"
    
    cd "$PROJECT_DIR"
    
    # Stop current deployment
    docker-compose down || true
    
    # Start with previous tag
    IMAGE_TAG=$PREVIOUS_TAG docker-compose up -d
    
    log_info "✓ Rollback completed"
}

show_status() {
    log_step "Deployment Status"
    
    cd "$PROJECT_DIR"
    
    # Show container status
    docker-compose ps
    
    echo ""
    
    # Show health
    if curl -s http://localhost:8000/health; then
        echo ""
        log_info "✓ System is healthy"
    else
        log_error "System is unhealthy"
    fi
}

show_logs() {
    log_step "Application Logs"
    
    cd "$PROJECT_DIR"
    docker-compose logs -f --tail=100
}

# ============================================================================
# MAIN
# ============================================================================

show_banner() {
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════╗"
    echo "║                                                           ║"
    echo "║           CHE·NU™ V70 — GP2 DEPLOYMENT                   ║"
    echo "║        Governed Intelligence Operating System            ║"
    echo "║                                                           ║"
    echo "║           GOUVERNANCE > EXÉCUTION                        ║"
    echo "║                                                           ║"
    echo "╚═══════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

show_help() {
    show_banner
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  check       Check prerequisites and governance"
    echo "  test        Run tests"
    echo "  build       Build Docker image"
    echo "  push        Push image to registry"
    echo "  staging     Deploy to staging"
    echo "  production  Deploy to production"
    echo "  rollback    Rollback deployment"
    echo "  status      Show deployment status"
    echo "  logs        Show application logs"
    echo "  all         Run full deployment (check, test, build, staging)"
    echo ""
    echo "Environment Variables:"
    echo "  DEPLOY_ENV       Target environment (default: staging)"
    echo "  DOCKER_REGISTRY  Docker registry URL"
    echo "  IMAGE_TAG        Docker image tag (default: v70.0.0)"
}

main() {
    show_banner
    
    case "${1:-help}" in
        check)
            check_prerequisites
            verify_governance
            ;;
        test)
            run_tests
            ;;
        build)
            build_image
            ;;
        push)
            push_image
            ;;
        staging)
            deploy_staging
            ;;
        production)
            deploy_production
            ;;
        rollback)
            rollback "${2:-}"
            ;;
        status)
            show_status
            ;;
        logs)
            show_logs
            ;;
        all)
            check_prerequisites
            verify_governance
            run_tests
            build_image
            deploy_staging
            show_status
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
