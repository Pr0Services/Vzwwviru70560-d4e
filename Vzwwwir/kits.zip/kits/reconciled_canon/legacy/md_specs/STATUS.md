STATUS: LEGACY
Includes early markdown specifications.
