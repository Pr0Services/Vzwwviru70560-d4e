"""
CHE·NU™ V70 — MODULE 28: CULTURE & MYTH ENGINE
===============================================
Donne aux communautés une couche narrative partagée qui est GOUVERNÉE,
NON-MANIPULATRICE, et LIÉE À L'ACTION.

La culture devient un stabilisateur pour la coordination à long terme,
pas de la propagande.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import hashlib
import json
import logging

logger = logging.getLogger("chenu.module_28")


class StoryMode(str, Enum):
    """Modes de narration préférés."""
    CASE_STORY = "case_story"
    HERO_JOURNEY = "hero_journey"
    DOCUMENTARY = "documentary"
    INTERACTIVE = "interactive"
    PARABLE = "parable"


class MythReviewMode(str, Enum):
    """Modes de révision des mythes."""
    HITL_REQUIRED = "hitl_required"
    AUTO_APPROVED = "auto_approved"
    COMMUNITY_VOTE = "community_vote"


@dataclass
class CultureProfile:
    """
    Profil culturel d'une communauté.
    
    N'est PAS un stéréotype.
    C'est un ensemble CONSENTI et AGRÉGÉ de préférences et normes.
    """
    profile_id: str = field(default_factory=lambda: f"CULTURE_{uuid4().hex[:8]}")
    locale: str = "en-US"
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Core cultural elements
    values: list[str] = field(default_factory=list)
    taboos: list[str] = field(default_factory=list)
    rituals: list[dict[str, Any]] = field(default_factory=list)
    symbols: list[str] = field(default_factory=list)
    
    # Narrative preferences
    preferred_story_modes: list[StoryMode] = field(default_factory=list)
    
    # Consent
    consent: dict[str, Any] = field(default_factory=lambda: {
        "source": "community_opt_in",
        "privacy": "aggregated_only",
        "retention_days": 180,
    })


@dataclass
class MythArtifact:
    """
    Artifact mythique - wrapper narratif gouverné autour d'une simulation réelle.
    
    Chaque MythArtifact est:
    - Lié à un WorldState + trace causale
    - Soumis à des contraintes de vérité
    - Gouverné par OPA + HITL
    """
    artifact_type: str = "MYTH_ARTIFACT"
    myth_id: str = field(default_factory=lambda: f"MYTH_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Links to truth
    linked_worldstate: str = ""  # Hash
    linked_causal_trace: str = ""  # Hash
    
    # Narrative content
    narrative: dict[str, Any] = field(default_factory=lambda: {
        "title": "",
        "format": "interactive_story",
        "chapters": [],
    })
    
    # Truth constraints (CRITICAL)
    truth_constraints: dict[str, bool] = field(default_factory=lambda: {
        "no_false_claims": True,
        "citations_required": True,
        "counterfactuals_labeled": True,
    })
    
    # Governance
    governance: dict[str, Any] = field(default_factory=lambda: {
        "opa_policy_id": "OPA_CULTURE_SAFE_V1",
        "review_mode": "HITL_REQUIRED",
        "signatures": [],
    })


@dataclass
class CulturalFrictionPrediction:
    """
    Prédiction de friction culturelle.
    
    Utilise les graphes causaux pour prédire le risque de rejet:
    - "Policy X triggers taboo Y"
    - "Project Y contradicts ritual Z"
    """
    prediction_id: str = field(default_factory=lambda: f"FRICTION_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Subject
    policy_or_project: str = ""
    target_community: str = ""
    
    # Predictions
    triggered_taboos: list[str] = field(default_factory=list)
    contradicted_rituals: list[str] = field(default_factory=list)
    rejection_risk: float = 0.0  # 0-1
    
    # Mitigations
    suggested_mitigations: list[dict[str, str]] = field(default_factory=list)


class CultureSignalExtractor:
    """
    Culture Signal Extractor (CSE)
    
    Input: community interactions (opt-in), anonymized trends, completed tasks
    Output: CultureProfile updates + confidence intervals
    
    Rule: NEVER infer sensitive traits; only store what users explicitly opt-in to.
    """
    
    def __init__(self):
        self.extractor_id = f"CSE_{uuid4().hex[:8]}"
        self._profiles: dict[str, CultureProfile] = {}
    
    def extract_signals(
        self,
        community_id: str,
        interactions: list[dict[str, Any]],
        opt_in_scope: list[str],
    ) -> CultureProfile:
        """
        Extract cultural signals from interactions.
        
        Only processes data within opt_in_scope.
        """
        profile = self._profiles.get(community_id, CultureProfile())
        
        # Filter to only opted-in categories
        filtered_interactions = [
            i for i in interactions
            if i.get("category") in opt_in_scope
        ]
        
        # Extract values (simplified)
        for interaction in filtered_interactions:
            if interaction.get("type") == "value_expression":
                value = interaction.get("value")
                if value and value not in profile.values:
                    profile.values.append(value)
        
        self._profiles[community_id] = profile
        return profile
    
    def get_confidence_intervals(
        self, 
        community_id: str
    ) -> dict[str, tuple[float, float]]:
        """Get confidence intervals for cultural signals."""
        profile = self._profiles.get(community_id)
        if not profile:
            return {}
        
        # Simplified confidence calculation
        return {
            "values": (0.7, 0.9) if len(profile.values) > 3 else (0.4, 0.6),
            "symbols": (0.6, 0.8) if len(profile.symbols) > 2 else (0.3, 0.5),
        }


class NarrativeCompiler:
    """
    Narrative Compiler (NC)
    
    Converts WorldEngine scenarios into:
    - Micro-stories for onboarding
    - "Serious myths" for civic engagement
    - Training narratives for Skill-Lattice
    """
    
    def __init__(self):
        self.compiler_id = f"NC_{uuid4().hex[:8]}"
    
    def compile_myth(
        self,
        worldstate_hash: str,
        causal_trace_hash: str,
        culture_profile: CultureProfile,
        story_mode: StoryMode = StoryMode.CASE_STORY,
    ) -> MythArtifact:
        """
        Compile a myth artifact from WorldEngine scenario.
        """
        myth = MythArtifact(
            linked_worldstate=worldstate_hash,
            linked_causal_trace=causal_trace_hash,
        )
        
        # Generate narrative based on story mode
        myth.narrative = self._generate_narrative(
            story_mode, 
            culture_profile
        )
        
        # Set governance
        myth.governance["review_mode"] = MythReviewMode.HITL_REQUIRED.value
        
        return myth
    
    def _generate_narrative(
        self, 
        mode: StoryMode, 
        profile: CultureProfile
    ) -> dict[str, Any]:
        """Generate narrative structure based on mode and culture."""
        base_narrative = {
            "title": "",
            "format": mode.value,
            "chapters": [],
            "symbols_used": profile.symbols[:3] if profile.symbols else [],
            "respects_taboos": profile.taboos,
        }
        
        if mode == StoryMode.HERO_JOURNEY:
            base_narrative["chapters"] = [
                {"id": "C1", "stage": "ordinary_world"},
                {"id": "C2", "stage": "call_to_adventure"},
                {"id": "C3", "stage": "crossing_threshold"},
                {"id": "C4", "stage": "tests_and_allies"},
                {"id": "C5", "stage": "ordeal"},
                {"id": "C6", "stage": "return"},
            ]
        elif mode == StoryMode.CASE_STORY:
            base_narrative["chapters"] = [
                {"id": "C1", "stage": "situation"},
                {"id": "C2", "stage": "challenge"},
                {"id": "C3", "stage": "response"},
                {"id": "C4", "stage": "outcome"},
            ]
        
        return base_narrative


class CulturalFrictionPredictor:
    """
    Cultural Friction Predictor (CFP)
    
    Uses causal graphs to predict rejection risk and suggest mitigations.
    """
    
    def __init__(self, causal_engine: Optional[Any] = None):
        self.predictor_id = f"CFP_{uuid4().hex[:8]}"
        self.causal_engine = causal_engine
    
    def predict_friction(
        self,
        policy: str,
        culture_profile: CultureProfile,
    ) -> CulturalFrictionPrediction:
        """
        Predict cultural friction for a policy/project.
        """
        prediction = CulturalFrictionPrediction(
            policy_or_project=policy,
        )
        
        policy_lower = policy.lower()
        
        # Check against taboos
        for taboo in culture_profile.taboos:
            if taboo.lower() in policy_lower:
                prediction.triggered_taboos.append(taboo)
        
        # Check against rituals
        for ritual in culture_profile.rituals:
            ritual_name = ritual.get("name", "").lower()
            if any(
                conflict_word in policy_lower 
                for conflict_word in ["cancel", "replace", "remove"]
            ) and ritual_name in policy_lower:
                prediction.contradicted_rituals.append(ritual.get("name"))
        
        # Calculate risk
        risk_factors = len(prediction.triggered_taboos) + len(prediction.contradicted_rituals)
        prediction.rejection_risk = min(risk_factors * 0.2, 1.0)
        
        # Generate mitigations
        if prediction.rejection_risk > 0.3:
            prediction.suggested_mitigations = self._generate_mitigations(
                prediction
            )
        
        return prediction
    
    def _generate_mitigations(
        self, 
        prediction: CulturalFrictionPrediction
    ) -> list[dict[str, str]]:
        """Generate mitigation suggestions."""
        mitigations = []
        
        for taboo in prediction.triggered_taboos:
            mitigations.append({
                "type": "reframe",
                "description": f"Reframe policy to avoid triggering '{taboo}' taboo",
            })
        
        for ritual in prediction.contradicted_rituals:
            mitigations.append({
                "type": "schedule",
                "description": f"Schedule implementation to not conflict with '{ritual}'",
            })
        
        if prediction.rejection_risk > 0.5:
            mitigations.append({
                "type": "education",
                "description": "Add educational component explaining benefits",
            })
        
        return mitigations


class CultureMythEngine:
    """
    Module 28 — Culture & Myth Engine
    
    Crée une couche culturelle sur:
    - WorldEngine (simulations déterministes)
    - Causal Engine (preuves "pourquoi")
    - OPA Governance (garde-fous contre manipulation)
    - XR Pack (storytelling immersif)
    """
    
    # HARD BANS - These are FORBIDDEN
    HARD_BANS = [
        "coercive_persuasion",
        "targeting_vulnerabilities",
        "hate_or_dehumanization",
        "us_vs_them_amplification",
    ]
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,
        worldengine: Optional[Any] = None,
        causal_engine: Optional[Any] = None,
    ):
        self.engine_id = f"CULTURE_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies
        self.opa_client = opa_client
        self.worldengine = worldengine
        self.causal_engine = causal_engine
        
        # Sub-engines
        self.signal_extractor = CultureSignalExtractor()
        self.narrative_compiler = NarrativeCompiler()
        self.friction_predictor = CulturalFrictionPredictor(causal_engine)
        
        # Storage
        self._profiles: dict[str, CultureProfile] = {}
        self._myths: dict[str, MythArtifact] = {}
        self._predictions: dict[str, CulturalFrictionPrediction] = {}
        
        logger.info(f"Culture & Myth Engine initialized: {self.engine_id}")
    
    # =========================================================================
    # CULTURE PROFILE
    # =========================================================================
    
    def create_culture_profile(
        self,
        community_id: str,
        locale: str,
        values: list[str],
        taboos: list[str],
        preferred_modes: list[StoryMode] = None,
    ) -> CultureProfile:
        """
        Create a culture profile for a community.
        
        Requires explicit opt-in consent.
        """
        profile = CultureProfile(
            locale=locale,
            values=values,
            taboos=taboos,
            preferred_story_modes=preferred_modes or [StoryMode.CASE_STORY],
        )
        
        self._profiles[community_id] = profile
        logger.info(f"Culture profile created for: {community_id}")
        
        return profile
    
    def add_ritual(
        self,
        community_id: str,
        ritual_name: str,
        frequency: str,
        meaning: str,
    ) -> CultureProfile:
        """Add a ritual to community culture profile."""
        profile = self._profiles.get(community_id)
        if not profile:
            raise ValueError(f"No profile for community: {community_id}")
        
        ritual = {
            "id": f"RIT_{uuid4().hex[:4]}",
            "name": ritual_name,
            "frequency": frequency,
            "meaning": meaning,
        }
        profile.rituals.append(ritual)
        
        return profile
    
    def add_symbols(
        self, 
        community_id: str, 
        symbols: list[str]
    ) -> CultureProfile:
        """Add symbols to community culture profile."""
        profile = self._profiles.get(community_id)
        if not profile:
            raise ValueError(f"No profile for community: {community_id}")
        
        profile.symbols.extend(symbols)
        return profile
    
    # =========================================================================
    # MYTH GENERATION
    # =========================================================================
    
    def compile_myth_from_scenario(
        self,
        community_id: str,
        worldstate_hash: str,
        causal_trace_hash: str,
        title: str,
        story_mode: StoryMode = StoryMode.CASE_STORY,
    ) -> MythArtifact:
        """
        Compile a myth artifact from a WorldEngine scenario.
        
        The myth is:
        - Faithful to causal trace
        - Culturally adapted
        - Governed by OPA
        - Requires HITL approval
        """
        profile = self._profiles.get(community_id, CultureProfile())
        
        # Compile base myth
        myth = self.narrative_compiler.compile_myth(
            worldstate_hash,
            causal_trace_hash,
            profile,
            story_mode,
        )
        
        myth.narrative["title"] = title
        
        # OPA validation
        if not self._validate_myth_opa(myth):
            raise ValueError("Myth failed OPA validation")
        
        # Check against hard bans
        if not self._check_hard_bans(myth):
            raise ValueError("Myth contains banned content")
        
        self._myths[myth.myth_id] = myth
        logger.info(f"Myth compiled: {myth.myth_id}")
        
        return myth
    
    def _validate_myth_opa(self, myth: MythArtifact) -> bool:
        """
        OPA checks for myths:
        - Is the narrative faithful to causal trace?
        - Are counterfactuals labeled?
        - Is uncertainty shown?
        - Is user consent valid?
        """
        if not self.opa_client:
            return True  # Mock
        
        try:
            result = self.opa_client.query(
                policy_path="chenu/culture/myth",
                input_data={
                    "myth_id": myth.myth_id,
                    "linked_worldstate": myth.linked_worldstate,
                    "truth_constraints": myth.truth_constraints,
                },
            )
            return result.get("allow", False)
        except Exception as e:
            logger.error(f"OPA validation error: {e}")
            return False
    
    def _check_hard_bans(self, myth: MythArtifact) -> bool:
        """Check myth against hard bans."""
        narrative_text = json.dumps(myth.narrative).lower()
        
        for ban in self.HARD_BANS:
            if ban.replace("_", " ") in narrative_text:
                logger.warning(f"Hard ban triggered: {ban}")
                return False
        
        return True
    
    def approve_myth(
        self, 
        myth_id: str, 
        approver_id: str
    ) -> MythArtifact:
        """
        HITL approval for a myth.
        Required before publication.
        """
        myth = self._myths.get(myth_id)
        if not myth:
            raise ValueError(f"Myth not found: {myth_id}")
        
        # Add signature
        signature = f"APPROVED:{approver_id}:{datetime.utcnow().isoformat()}"
        myth.governance["signatures"].append(signature)
        myth.governance["review_mode"] = "APPROVED"
        
        logger.info(f"Myth approved: {myth_id} by {approver_id}")
        return myth
    
    # =========================================================================
    # FRICTION PREDICTION
    # =========================================================================
    
    def predict_cultural_friction(
        self,
        community_id: str,
        policy_description: str,
    ) -> CulturalFrictionPrediction:
        """
        Predict cultural friction for a policy/project.
        """
        profile = self._profiles.get(community_id, CultureProfile())
        
        prediction = self.friction_predictor.predict_friction(
            policy_description, 
            profile
        )
        prediction.target_community = community_id
        
        self._predictions[prediction.prediction_id] = prediction
        return prediction
    
    # =========================================================================
    # XR INTERFACE
    # =========================================================================
    
    def get_xr_story_dome_config(
        self, 
        community_id: str
    ) -> dict[str, Any]:
        """
        Get XR configuration for the Story Dome.
        
        Features:
        - User stands in dome of scenes
        - Each scene = causal branch
        - Walk the consequences on timeline ring
        """
        return {
            "scene_type": "STORY_DOME",
            "read_only": True,  # XR = READ ONLY
            "community_id": community_id,
            "components": [
                {
                    "type": "dome_projection",
                    "scenes_source": "myths",
                    "interactive": True,
                },
                {
                    "type": "timeline_ring",
                    "visualization": "causal_branches",
                    "walkable": True,
                },
                {
                    "type": "symbol_switch",
                    "description": "Same truth, multiple cultural renderings",
                },
                {
                    "type": "consent_lantern",
                    "description": "Always visible, shows data consent scope",
                    "clickable": True,
                },
            ],
            "interactions": [
                "walk_consequences",
                "switch_cultural_lens",
                "view_consent_scope",
            ],
            "governance": {
                "opa_policy_id": "OPA_CULTURE_SAFE_V1",
                "hitl_required": False,
            },
        }
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        return {
            "engine_id": self.engine_id,
            "culture_profiles": len(self._profiles),
            "myths_created": len(self._myths),
            "myths_approved": sum(
                1 for m in self._myths.values()
                if m.governance.get("review_mode") == "APPROVED"
            ),
            "friction_predictions": len(self._predictions),
        }
