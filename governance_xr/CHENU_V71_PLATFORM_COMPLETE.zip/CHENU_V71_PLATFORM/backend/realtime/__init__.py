"""
CHE·NU™ V70 — REALTIME PACKAGE
==============================
WebSocket and real-time communication.
"""

from .websocket import (
    EventType,
    WSEvent,
    WSClient,
    WSEventBus,
    create_websocket_router,
    get_event_bus,
)

__all__ = [
    "EventType",
    "WSEvent",
    "WSClient",
    "WSEventBus",
    "create_websocket_router",
    "get_event_bus",
]

__version__ = "70.0.0"
