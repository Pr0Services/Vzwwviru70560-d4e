"""
CHE·NU™ Performance Monitor — System Performance Monitoring
============================================================

Comprehensive performance monitoring including:
- Request timing and latency tracking
- Memory and resource monitoring
- Health check endpoints
- Performance metrics aggregation
- Alert thresholds and notifications
- Performance dashboard data

Author: CHE·NU Backend Team
Version: 1.0.0
"""

from typing import Optional, Dict, Any, List, Callable
from datetime import datetime, timedelta
from uuid import UUID
import time
import asyncio
import logging
import psutil
import functools
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from contextlib import asynccontextmanager

logger = logging.getLogger(__name__)


class HealthStatus(str, Enum):
    """System health status levels."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"


class MetricType(str, Enum):
    """Types of metrics."""
    COUNTER = "counter"      # Monotonically increasing
    GAUGE = "gauge"          # Point-in-time value
    HISTOGRAM = "histogram"  # Distribution
    TIMER = "timer"          # Duration measurements


@dataclass
class TimingMetric:
    """Timing metric for request/operation duration."""
    name: str
    start_time: float
    end_time: Optional[float] = None
    duration_ms: Optional[float] = None
    tags: Dict[str, str] = field(default_factory=dict)
    
    def stop(self) -> float:
        """Stop timing and return duration."""
        self.end_time = time.time()
        self.duration_ms = (self.end_time - self.start_time) * 1000
        return self.duration_ms


@dataclass
class HistogramBucket:
    """Bucket for histogram metrics."""
    le: float  # Less than or equal
    count: int = 0


@dataclass
class Histogram:
    """Histogram for distribution metrics."""
    name: str
    buckets: List[HistogramBucket]
    sum: float = 0.0
    count: int = 0
    
    # Default latency buckets (ms)
    DEFAULT_BUCKETS = [5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000]
    
    @classmethod
    def create(cls, name: str, buckets: Optional[List[float]] = None) -> "Histogram":
        """Create histogram with specified buckets."""
        bucket_values = buckets or cls.DEFAULT_BUCKETS
        return cls(
            name=name,
            buckets=[HistogramBucket(le=b) for b in bucket_values],
        )
    
    def observe(self, value: float) -> None:
        """Record an observation."""
        self.sum += value
        self.count += 1
        for bucket in self.buckets:
            if value <= bucket.le:
                bucket.count += 1
    
    def percentile(self, p: float) -> float:
        """Calculate approximate percentile."""
        if self.count == 0:
            return 0.0
        
        target = self.count * p
        for bucket in self.buckets:
            if bucket.count >= target:
                return bucket.le
        
        return self.buckets[-1].le if self.buckets else 0.0
    
    @property
    def avg(self) -> float:
        """Calculate average."""
        return self.sum / self.count if self.count > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "count": self.count,
            "sum": round(self.sum, 2),
            "avg": round(self.avg, 2),
            "p50": round(self.percentile(0.5), 2),
            "p90": round(self.percentile(0.9), 2),
            "p95": round(self.percentile(0.95), 2),
            "p99": round(self.percentile(0.99), 2),
        }


@dataclass
class Counter:
    """Counter metric."""
    name: str
    value: int = 0
    labels: Dict[str, str] = field(default_factory=dict)
    
    def inc(self, amount: int = 1) -> None:
        """Increment counter."""
        self.value += amount
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "labels": self.labels,
        }


@dataclass
class Gauge:
    """Gauge metric (point-in-time value)."""
    name: str
    value: float = 0.0
    labels: Dict[str, str] = field(default_factory=dict)
    
    def set(self, value: float) -> None:
        """Set gauge value."""
        self.value = value
    
    def inc(self, amount: float = 1.0) -> None:
        """Increment gauge."""
        self.value += amount
    
    def dec(self, amount: float = 1.0) -> None:
        """Decrement gauge."""
        self.value -= amount
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "value": self.value,
            "labels": self.labels,
        }


@dataclass
class HealthCheck:
    """Health check result."""
    name: str
    status: HealthStatus
    message: str
    latency_ms: Optional[float] = None
    details: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "message": self.message,
            "latency_ms": round(self.latency_ms, 2) if self.latency_ms else None,
            "details": self.details,
            "timestamp": self.timestamp.isoformat(),
        }


class PerformanceMonitor:
    """
    Central performance monitoring service.
    
    Features:
    - Request latency tracking
    - Resource usage monitoring
    - Health check management
    - Metrics aggregation
    - Alert detection
    """
    
    # Alert thresholds
    THRESHOLDS = {
        "request_latency_p95_ms": 500,
        "request_latency_p99_ms": 1000,
        "error_rate_percent": 5.0,
        "memory_usage_percent": 80.0,
        "cpu_usage_percent": 80.0,
        "database_latency_ms": 100,
        "cache_hit_rate_min": 50.0,
    }
    
    def __init__(
        self,
        window_size: int = 1000,
        health_check_interval: int = 30,
    ):
        """
        Initialize performance monitor.
        
        Args:
            window_size: Number of recent requests to track
            health_check_interval: Seconds between health checks
        """
        self.window_size = window_size
        self.health_check_interval = health_check_interval
        
        # Metrics storage
        self._histograms: Dict[str, Histogram] = {}
        self._counters: Dict[str, Counter] = {}
        self._gauges: Dict[str, Gauge] = {}
        
        # Recent request tracking (rolling window)
        self._recent_requests: deque = deque(maxlen=window_size)
        
        # Health checks
        self._health_checks: Dict[str, Callable] = {}
        self._last_health_results: Dict[str, HealthCheck] = {}
        
        # Initialize default metrics
        self._init_default_metrics()
        
        logger.info("PerformanceMonitor initialized")
    
    def _init_default_metrics(self) -> None:
        """Initialize default metrics."""
        # Request latency histogram
        self._histograms["http_request_duration_ms"] = Histogram.create(
            "http_request_duration_ms"
        )
        
        # Counters
        self._counters["http_requests_total"] = Counter("http_requests_total")
        self._counters["http_errors_total"] = Counter("http_errors_total")
        self._counters["checkpoints_triggered"] = Counter("checkpoints_triggered")
        self._counters["identity_violations"] = Counter("identity_violations")
        
        # Gauges
        self._gauges["active_connections"] = Gauge("active_connections")
        self._gauges["active_websockets"] = Gauge("active_websockets")
        self._gauges["cache_size_bytes"] = Gauge("cache_size_bytes")
    
    # ==========================================================================
    # Request Tracking
    # ==========================================================================
    
    @asynccontextmanager
    async def track_request(
        self,
        method: str,
        path: str,
        tags: Optional[Dict[str, str]] = None,
    ):
        """
        Context manager to track request performance.
        
        Usage:
            async with monitor.track_request("GET", "/api/threads") as timing:
                # Handle request
                pass
        """
        timing = TimingMetric(
            name=f"{method} {path}",
            start_time=time.time(),
            tags=tags or {},
        )
        
        try:
            yield timing
        finally:
            duration = timing.stop()
            
            # Record in histogram
            self._histograms["http_request_duration_ms"].observe(duration)
            
            # Increment counter
            self._counters["http_requests_total"].inc()
            
            # Track in recent requests
            self._recent_requests.append({
                "method": method,
                "path": path,
                "duration_ms": duration,
                "timestamp": datetime.utcnow().isoformat(),
                "tags": tags or {},
            })
    
    def record_error(
        self,
        method: str,
        path: str,
        status_code: int,
        error_type: str,
    ) -> None:
        """Record an error."""
        self._counters["http_errors_total"].inc()
        
        # Track specific error types
        counter_name = f"http_errors_{status_code}"
        if counter_name not in self._counters:
            self._counters[counter_name] = Counter(counter_name)
        self._counters[counter_name].inc()
    
    def record_checkpoint(self) -> None:
        """Record a checkpoint trigger."""
        self._counters["checkpoints_triggered"].inc()
    
    def record_identity_violation(self) -> None:
        """Record an identity boundary violation."""
        self._counters["identity_violations"].inc()
    
    # ==========================================================================
    # Metrics Access
    # ==========================================================================
    
    def histogram(self, name: str) -> Histogram:
        """Get or create a histogram."""
        if name not in self._histograms:
            self._histograms[name] = Histogram.create(name)
        return self._histograms[name]
    
    def counter(self, name: str, labels: Optional[Dict[str, str]] = None) -> Counter:
        """Get or create a counter."""
        if name not in self._counters:
            self._counters[name] = Counter(name, labels=labels or {})
        return self._counters[name]
    
    def gauge(self, name: str, labels: Optional[Dict[str, str]] = None) -> Gauge:
        """Get or create a gauge."""
        if name not in self._gauges:
            self._gauges[name] = Gauge(name, labels=labels or {})
        return self._gauges[name]
    
    # ==========================================================================
    # Health Checks
    # ==========================================================================
    
    def register_health_check(
        self,
        name: str,
        check_fn: Callable[[], HealthCheck],
    ) -> None:
        """Register a health check function."""
        self._health_checks[name] = check_fn
        logger.info(f"Registered health check: {name}")
    
    async def run_health_checks(self) -> Dict[str, HealthCheck]:
        """Run all registered health checks."""
        results = {}
        
        for name, check_fn in self._health_checks.items():
            try:
                start = time.time()
                
                if asyncio.iscoroutinefunction(check_fn):
                    result = await check_fn()
                else:
                    result = check_fn()
                
                result.latency_ms = (time.time() - start) * 1000
                results[name] = result
                
            except Exception as e:
                results[name] = HealthCheck(
                    name=name,
                    status=HealthStatus.UNHEALTHY,
                    message=str(e),
                )
        
        self._last_health_results = results
        return results
    
    async def get_overall_health(self) -> HealthStatus:
        """Get overall system health status."""
        results = await self.run_health_checks()
        
        if not results:
            return HealthStatus.UNKNOWN
        
        statuses = [r.status for r in results.values()]
        
        if HealthStatus.UNHEALTHY in statuses:
            return HealthStatus.UNHEALTHY
        elif HealthStatus.DEGRADED in statuses:
            return HealthStatus.DEGRADED
        else:
            return HealthStatus.HEALTHY
    
    # ==========================================================================
    # System Resources
    # ==========================================================================
    
    def get_system_resources(self) -> Dict[str, Any]:
        """Get current system resource usage."""
        try:
            # CPU
            cpu_percent = psutil.cpu_percent(interval=0.1)
            cpu_count = psutil.cpu_count()
            
            # Memory
            memory = psutil.virtual_memory()
            
            # Disk
            disk = psutil.disk_usage("/")
            
            # Network (if available)
            try:
                net = psutil.net_io_counters()
                network = {
                    "bytes_sent": net.bytes_sent,
                    "bytes_recv": net.bytes_recv,
                }
            except:
                network = None
            
            return {
                "cpu": {
                    "percent": cpu_percent,
                    "count": cpu_count,
                },
                "memory": {
                    "total_gb": round(memory.total / (1024**3), 2),
                    "available_gb": round(memory.available / (1024**3), 2),
                    "percent": memory.percent,
                },
                "disk": {
                    "total_gb": round(disk.total / (1024**3), 2),
                    "free_gb": round(disk.free / (1024**3), 2),
                    "percent": disk.percent,
                },
                "network": network,
            }
            
        except Exception as e:
            logger.error(f"Failed to get system resources: {e}")
            return {}
    
    # ==========================================================================
    # Alerts
    # ==========================================================================
    
    def check_alerts(self) -> List[Dict[str, Any]]:
        """Check for performance alerts."""
        alerts = []
        
        # Check request latency
        request_histogram = self._histograms.get("http_request_duration_ms")
        if request_histogram:
            p95 = request_histogram.percentile(0.95)
            p99 = request_histogram.percentile(0.99)
            
            if p95 > self.THRESHOLDS["request_latency_p95_ms"]:
                alerts.append({
                    "type": "latency_warning",
                    "metric": "request_latency_p95",
                    "value": p95,
                    "threshold": self.THRESHOLDS["request_latency_p95_ms"],
                    "severity": "warning",
                })
            
            if p99 > self.THRESHOLDS["request_latency_p99_ms"]:
                alerts.append({
                    "type": "latency_critical",
                    "metric": "request_latency_p99",
                    "value": p99,
                    "threshold": self.THRESHOLDS["request_latency_p99_ms"],
                    "severity": "critical",
                })
        
        # Check error rate
        total_requests = self._counters.get("http_requests_total", Counter("")).value
        total_errors = self._counters.get("http_errors_total", Counter("")).value
        
        if total_requests > 0:
            error_rate = (total_errors / total_requests) * 100
            if error_rate > self.THRESHOLDS["error_rate_percent"]:
                alerts.append({
                    "type": "error_rate_high",
                    "metric": "error_rate_percent",
                    "value": error_rate,
                    "threshold": self.THRESHOLDS["error_rate_percent"],
                    "severity": "critical",
                })
        
        # Check system resources
        resources = self.get_system_resources()
        
        if resources.get("memory", {}).get("percent", 0) > self.THRESHOLDS["memory_usage_percent"]:
            alerts.append({
                "type": "memory_high",
                "metric": "memory_usage_percent",
                "value": resources["memory"]["percent"],
                "threshold": self.THRESHOLDS["memory_usage_percent"],
                "severity": "warning",
            })
        
        if resources.get("cpu", {}).get("percent", 0) > self.THRESHOLDS["cpu_usage_percent"]:
            alerts.append({
                "type": "cpu_high",
                "metric": "cpu_usage_percent",
                "value": resources["cpu"]["percent"],
                "threshold": self.THRESHOLDS["cpu_usage_percent"],
                "severity": "warning",
            })
        
        return alerts
    
    # ==========================================================================
    # Dashboard Data
    # ==========================================================================
    
    def get_dashboard_data(self) -> Dict[str, Any]:
        """Get aggregated data for performance dashboard."""
        return {
            "timestamp": datetime.utcnow().isoformat(),
            "requests": {
                "total": self._counters.get("http_requests_total", Counter("")).value,
                "errors": self._counters.get("http_errors_total", Counter("")).value,
                "latency": self._histograms.get("http_request_duration_ms", Histogram.create("")).to_dict(),
            },
            "governance": {
                "checkpoints_triggered": self._counters.get("checkpoints_triggered", Counter("")).value,
                "identity_violations": self._counters.get("identity_violations", Counter("")).value,
            },
            "connections": {
                "active": self._gauges.get("active_connections", Gauge("")).value,
                "websockets": self._gauges.get("active_websockets", Gauge("")).value,
            },
            "resources": self.get_system_resources(),
            "health": {
                name: check.to_dict()
                for name, check in self._last_health_results.items()
            },
            "alerts": self.check_alerts(),
            "recent_requests": list(self._recent_requests)[-20:],  # Last 20
        }
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of all metrics."""
        return {
            "histograms": {
                name: hist.to_dict()
                for name, hist in self._histograms.items()
            },
            "counters": {
                name: counter.to_dict()
                for name, counter in self._counters.items()
            },
            "gauges": {
                name: gauge.to_dict()
                for name, gauge in self._gauges.items()
            },
        }
    
    def reset_metrics(self) -> None:
        """Reset all metrics (for testing)."""
        self._histograms.clear()
        self._counters.clear()
        self._gauges.clear()
        self._recent_requests.clear()
        self._init_default_metrics()


# Singleton instance
performance_monitor = PerformanceMonitor()


# ==========================================================================
# Default Health Checks
# ==========================================================================

def database_health_check(session_factory) -> Callable:
    """Create database health check function."""
    async def check() -> HealthCheck:
        try:
            async with session_factory() as session:
                await session.execute("SELECT 1")
                return HealthCheck(
                    name="database",
                    status=HealthStatus.HEALTHY,
                    message="Database connection OK",
                )
        except Exception as e:
            return HealthCheck(
                name="database",
                status=HealthStatus.UNHEALTHY,
                message=f"Database error: {str(e)}",
            )
    
    return check


def redis_health_check(redis_client) -> Callable:
    """Create Redis health check function."""
    async def check() -> HealthCheck:
        try:
            await redis_client.ping()
            info = await redis_client.info("memory")
            return HealthCheck(
                name="redis",
                status=HealthStatus.HEALTHY,
                message="Redis connection OK",
                details={
                    "used_memory": info.get("used_memory_human", "unknown"),
                },
            )
        except Exception as e:
            return HealthCheck(
                name="redis",
                status=HealthStatus.UNHEALTHY,
                message=f"Redis error: {str(e)}",
            )
    
    return check


def cache_health_check() -> HealthCheck:
    """Check cache health."""
    from .cache_service import cache_service
    
    stats = cache_service.get_stats()
    hit_rate = stats.get("hit_rate", 0)
    
    if hit_rate < 30:
        status = HealthStatus.DEGRADED
        message = f"Cache hit rate low: {hit_rate}%"
    else:
        status = HealthStatus.HEALTHY
        message = f"Cache healthy, hit rate: {hit_rate}%"
    
    return HealthCheck(
        name="cache",
        status=status,
        message=message,
        details=stats,
    )


# ==========================================================================
# Middleware Helper
# ==========================================================================

def create_performance_middleware(app):
    """
    Create FastAPI middleware for performance monitoring.
    
    Usage:
        app.middleware("http")(create_performance_middleware(app))
    """
    from fastapi import Request
    
    async def middleware(request: Request, call_next):
        async with performance_monitor.track_request(
            method=request.method,
            path=request.url.path,
        ):
            response = await call_next(request)
            
            # Record errors
            if response.status_code >= 400:
                performance_monitor.record_error(
                    method=request.method,
                    path=request.url.path,
                    status_code=response.status_code,
                    error_type="http_error",
                )
            
            # Track governance responses
            if response.status_code == 423:
                performance_monitor.record_checkpoint()
            elif response.status_code == 403:
                performance_monitor.record_identity_violation()
            
            return response
    
    return middleware


# ==========================================================================
# Exports
# ==========================================================================

__all__ = [
    "PerformanceMonitor",
    "HealthStatus",
    "HealthCheck",
    "MetricType",
    "TimingMetric",
    "Histogram",
    "Counter",
    "Gauge",
    "performance_monitor",
    "database_health_check",
    "redis_health_check",
    "cache_health_check",
    "create_performance_middleware",
]
