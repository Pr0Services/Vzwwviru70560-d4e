# 🎓 CHE·NU™ ONBOARDING & SPHERE PROFILES
## Wizard de Configuration Initiale + Profils par Sphère

---

# 📐 VUE D'ENSEMBLE DU FLUX

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                      ONBOARDING JOURNEY (7 ÉTAPES)                            ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║   ÉTAPE 1                ÉTAPE 2                ÉTAPE 3                      ║
║   ┌──────────┐          ┌──────────┐          ┌──────────┐                  ║
║   │ BIENVENUE│    →     │ UNIVERS  │    →     │ PIÈCES   │                  ║
║   │          │          │ (Thème)  │          │ (8 choix)│                  ║
║   └──────────┘          └──────────┘          └──────────┘                  ║
║                                                      │                        ║
║                                                      ▼                        ║
║   ÉTAPE 6                ÉTAPE 5                ÉTAPE 4                      ║
║   ┌──────────┐          ┌──────────┐          ┌──────────┐                  ║
║   │ RÉSUMÉ   │    ←     │CONNEXIONS│    ←     │ TUTORIAL │                  ║
║   │          │          │(Optionnel)│          │          │                  ║
║   └──────────┘          └──────────┘          └──────────┘                  ║
║         │                                                                     ║
║         ▼                                                                     ║
║   ÉTAPE 7                                                                    ║
║   ┌──────────┐                                                               ║
║   │ PROFILS  │  → Configuration détaillée de chaque sphère                  ║
║   │ SPHÈRES  │     (peut être fait plus tard)                               ║
║   └──────────┘                                                               ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

# 🎬 ÉTAPE 1: BIENVENUE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                              [LOGO CHE·NU]                                  │
│                                                                             │
│                                                                             │
│                     ╔═══════════════════════════════╗                      │
│                     ║                               ║                      │
│                     ║      Bienvenue dans          ║                      │
│                     ║         CHE·NU™              ║                      │
│                     ║                               ║                      │
│                     ║  Governed Intelligence        ║                      │
│                     ║    Operating System           ║                      │
│                     ║                               ║                      │
│                     ╚═══════════════════════════════╝                      │
│                                                                             │
│                                                                             │
│          CHE·NU n'est pas une application de productivité.                 │
│                                                                             │
│          C'est un système qui organise votre vie en 8 SPHÈRES             │
│          distinctes, chacune avec son propre espace, ses agents,          │
│          et sa gouvernance.                                                │
│                                                                             │
│          Dans les prochaines minutes, vous allez:                          │
│                                                                             │
│          ◇ Choisir votre univers visuel                                   │
│          ◇ Attribuer une pièce à chaque sphère                            │
│          ◇ Comprendre comment naviguer                                     │
│          ◇ Configurer vos profils (optionnel)                             │
│                                                                             │
│                                                                             │
│                     [ Commencer la configuration ]                         │
│                                                                             │
│                                                                             │
│                         ○ ○ ○ ○ ○ ○ ○   (1/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 🎨 ÉTAPE 2: CHOIX DE L'UNIVERS

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 2/7                              [ ← Retour ]                    │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                    Choisissez votre UNIVERS                                │
│                                                                             │
│          Votre univers définit l'ambiance visuelle de CHE·NU.             │
│          Vous pourrez le changer à tout moment dans les paramètres.        │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   ┌─────────────────────────────┐    ┌─────────────────────────────┐      │
│   │                             │    │                             │      │
│   │    [IMAGE NATURAL THEME]    │    │   [IMAGE ATLANTIS THEME]    │      │
│   │                             │    │                             │      │
│   │    🌿 NATURAL               │    │    🏛️ ATLANTIS              │      │
│   │                             │    │                             │      │
│   │    Tons terreux, bois,      │    │    Pierre dorée, colonnes,  │      │
│   │    végétation luxuriante.   │    │    lumière sous-marine.     │      │
│   │    Chaleur et sérénité.     │    │    Sagesse et mystère.      │      │
│   │                             │    │                             │      │
│   │    [ Sélectionner ]         │    │    [ Sélectionner ]         │      │
│   └─────────────────────────────┘    └─────────────────────────────┘      │
│                                                                             │
│   ┌─────────────────────────────┐    ┌─────────────────────────────┐      │
│   │                             │    │                             │      │
│   │  [IMAGE FUTURISTIC THEME]   │    │    [IMAGE ASTRAL THEME]     │      │
│   │                             │    │                             │      │
│   │    🚀 FUTURISTIC            │    │    ✨ ASTRAL                 │      │
│   │                             │    │                             │      │
│   │    Néons, hologrammes,      │    │    Étoiles, constellations, │      │
│   │    architecture high-tech.  │    │    cosmos infini.           │      │
│   │    Innovation et précision. │    │    Transcendance.           │      │
│   │                             │    │                             │      │
│   │    [ Sélectionner ]         │    │    [ Sélectionner ]         │      │
│   └─────────────────────────────┘    └─────────────────────────────┘      │
│                                                                             │
│                                                                             │
│                         ● ○ ○ ○ ○ ○ ○   (2/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 🏠 ÉTAPE 3: ATTRIBUTION DES PIÈCES

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 3/7                              [ ← Retour ]                    │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│              Attribuez une PIÈCE à chaque SPHÈRE                          │
│                                                                             │
│          Chaque sphère de votre vie a son propre espace visuel.           │
│          Choisissez la pièce qui représente le mieux chaque contexte.     │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   SPHÈRE ACTIVE:  ◇ PERSONAL (1/8)                                        │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │                      [ROOM PREVIEW LARGE]                          │  │
│   │                                                                     │  │
│   │                         Pièce sélectionnée:                        │  │
│   │                      "Salon Cosy avec Cheminée"                    │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   Autres options pour cette sphère:                                        │
│                                                                             │
│   ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐      │
│   │[thumb1]│ │[thumb2]│ │[thumb3]│ │[thumb4]│ │[thumb5]│ │[thumb6]│      │
│   │ Salon  │ │Chambre │ │ Bureau │ │Terrasse│ │ Biblio │ │Jardin  │      │
│   │  ✓     │ │        │ │        │ │ d'hiver│ │        │ │        │      │
│   └────────┘ └────────┘ └────────┘ └────────┘ └────────┘ └────────┘      │
│                                                                             │
│   ┌────────┐ ┌────────┐ ┌────────┐ ┌────────┐                             │
│   │[thumb7]│ │[thumb8]│ │[thumb9]│ │[thum10]│  ... [Voir plus]           │
│   │ Atelier│ │ Cuisine│ │ Grenier│ │ Cave   │                             │
│   │        │ │        │ │        │ │        │                             │
│   └────────┘ └────────┘ └────────┘ └────────┘                             │
│                                                                             │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   PROGRESSION:                                                             │
│   ◇ Personal    ✓    ⬡ Business   ○    ⏣ Government  ○    ✦ Creative  ○  │
│   ◉ Community   ○    ⊛ Social     ○    ▷ Entertainment○    ⎔ My Team   ○  │
│                                                                             │
│                                                                             │
│        [ Pièce précédente ]              [ Pièce suivante → ]             │
│                                                                             │
│                         ● ● ○ ○ ○ ○ ○   (3/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Flow d'Attribution des 8 Pièces

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   SPHÈRE 1: ◇ PERSONAL                    Suggestion: Salon, Chambre        │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Votre espace intime. Réflexions personnelles, journaux, objectifs."      │
│                                                                              │
│   SPHÈRE 2: ⬡ BUSINESS                    Suggestion: Bureau, Salle de conf│
│   ────────────────────────────────────────────────────────────────────────  │
│   "Vos activités professionnelles. Projets, clients, finances."             │
│                                                                              │
│   SPHÈRE 3: ⏣ GOVERNMENT                  Suggestion: Hall officiel, Archive│
│   ────────────────────────────────────────────────────────────────────────  │
│   "Relations avec institutions. Impôts, documents officiels, démarches."    │
│                                                                              │
│   SPHÈRE 4: ✦ CREATIVE                    Suggestion: Atelier, Studio       │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Votre créativité. Design, écriture, musique, art."                       │
│                                                                              │
│   SPHÈRE 5: ◉ COMMUNITY                   Suggestion: Place publique, Café  │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Vos communautés. Associations, groupes, événements locaux."              │
│                                                                              │
│   SPHÈRE 6: ⊛ SOCIAL                      Suggestion: Lounge, Terrasse      │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Réseaux sociaux et médias. Publications, contacts, influence."           │
│                                                                              │
│   SPHÈRE 7: ▷ ENTERTAINMENT               Suggestion: Salle média, Cinéma   │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Vos loisirs. Films, jeux, musique, sports."                              │
│                                                                              │
│   SPHÈRE 8: ⎔ MY TEAM                     Suggestion: War room, Hub         │
│   ────────────────────────────────────────────────────────────────────────  │
│   "Vos agents IA, outils, et laboratoire d'innovation."                     │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

# 📖 ÉTAPE 4: TUTORIAL INTERACTIF

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 4/7                              [ ← Retour ]  [ Passer → ]      │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                    Comment fonctionne CHE·NU                               │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │                    [ANIMATION / VIDÉO TUTORIAL]                     │  │
│   │                                                                     │  │
│   │    ┌─────────────────────────────────────────────────────────┐     │  │
│   │    │                                                         │     │  │
│   │    │    ◇───⬡───⏣───✦                                       │     │  │
│   │    │    │   │   │   │                                       │     │  │
│   │    │    ◉───⊛───▷───⎔        8 SPHÈRES                      │     │  │
│   │    │                         = 8 CONTEXTES                  │     │  │
│   │    │                         = 8 BUREAUX IDENTIQUES         │     │  │
│   │    │                                                         │     │  │
│   │    └─────────────────────────────────────────────────────────┘     │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│                                                                             │
│   CONCEPT 1/4: LES SPHÈRES                                                 │
│   ─────────────────────────────────────────────────────────────────────    │
│                                                                             │
│   Votre vie est organisée en 8 SPHÈRES distinctes.                         │
│                                                                             │
│   • Chaque sphère représente un CONTEXTE de votre vie                      │
│   • Les sphères sont SÉPARÉES - les données ne se mélangent pas            │
│   • Vous ne voyez qu'UNE sphère à la fois = clarté cognitive              │
│                                                                             │
│   Pourquoi? Parce que quand vous travaillez sur un projet pro,            │
│   vous n'avez pas besoin de voir vos photos de vacances.                   │
│   Et inversement.                                                          │
│                                                                             │
│                                                                             │
│                    [ Concept suivant → ]                                   │
│                                                                             │
│                         ● ● ● ○ ○ ○ ○   (4/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Tutorial Slides (4 concepts)

### Slide 1: Les Sphères
```
8 SPHÈRES = 8 CONTEXTES DE VIE

◇ Personal     - Vie privée, réflexions
⬡ Business     - Travail, clients, projets
⏣ Government   - Administration, institutions
✦ Creative     - Création, art, design
◉ Community    - Associations, groupes
⊛ Social       - Réseaux, médias, contacts
▷ Entertainment- Loisirs, détente
⎔ My Team      - Agents IA, outils

→ SÉPARATION CRÉE CLARTÉ
```

### Slide 2: Le Bureau Unifié
```
CHAQUE SPHÈRE = MÊME STRUCTURE

┌─────────────────────────────────────┐
│  BUREAU (10 sections identiques)    │
├─────────────────────────────────────┤
│  1. Dashboard      6. Meetings      │
│  2. Notes          7. Data          │
│  3. Tasks          8. Agents        │
│  4. Projects       9. Reports       │
│  5. Threads        10. Budget       │
└─────────────────────────────────────┘

→ Même interface, contenus différents
→ Pas besoin de réapprendre
```

### Slide 3: Navigation & Pièces
```
VOTRE REPRÉSENTATION VISUELLE

┌─────────────────────────────────────┐
│                                     │
│   [Image de la pièce choisie]       │
│                                     │
│        ◇ (symbole en overlay)       │
│                                     │
└─────────────────────────────────────┘

• La PIÈCE vous indique où vous êtes
• Le SYMBOLE confirme la sphère
• Le LOGO change selon le thème actif

→ Repère visuel instantané
```

### Slide 4: Gouvernance & Tokens
```
GOUVERNANCE = CONTRÔLE

┌─────────────────────────────────────┐
│                                     │
│   💰 TOKENS = Énergie IA            │
│                                     │
│   • Chaque action IA coûte          │
│   • Vous voyez les coûts            │
│   • Vous contrôlez les budgets      │
│                                     │
│   🤖 AGENTS = Assistants            │
│                                     │
│   • Nova = Intelligence système     │
│   • Orchestrateur = Votre assistant │
│   • Agents spécialisés              │
│                                     │
└─────────────────────────────────────┘

→ VOUS gardez le contrôle
→ Pas d'IA autonome non autorisée
```

---

# 🔌 ÉTAPE 5: CONNEXIONS (Optionnel)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 5/7                   [ ← Retour ]  [ Passer cette étape → ]     │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                 Connectez vos plateformes (Optionnel)                      │
│                                                                             │
│          Vous pouvez connecter des services externes maintenant            │
│          ou le faire plus tard dans les paramètres de chaque sphère.       │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   PRODUCTIVITÉ                                                             │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐        │
│   │ [Google] │ │[Outlook] │ │ [Notion] │ │ [Slack]  │ │ [Teams]  │        │
│   │ Calendar │ │ Calendar │ │          │ │          │ │          │        │
│   │ [Connecter]│ [Connecter]│ [Connecter]│ [Connecter]│ [Connecter]│       │
│   └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘        │
│                                                                             │
│   RÉSEAUX SOCIAUX                                                          │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐        │
│   │[LinkedIn]│ │ [Twitter]│ │[Instagram│ │[Facebook]│ │ [TikTok] │        │
│   │          │ │    /X    │ │          │ │          │ │          │        │
│   │ [Connecter]│ [Connecter]│ [Connecter]│ [Connecter]│ [Connecter]│       │
│   └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘        │
│                                                                             │
│   FINANCE & BUSINESS                                                       │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐                     │
│   │[QuickBook│ │ [Stripe] │ │ [Xero]   │ │[Hubspot] │                     │
│   │          │ │          │ │          │ │          │                     │
│   │ [Connecter]│ [Connecter]│ [Connecter]│ [Connecter]│                    │
│   └──────────┘ └──────────┘ └──────────┘ └──────────┘                     │
│                                                                             │
│   STOCKAGE                                                                 │
│   ┌──────────┐ ┌──────────┐ ┌──────────┐                                  │
│   │ [Google  │ │ [Dropbox]│ │[OneDrive]│                                  │
│   │  Drive]  │ │          │ │          │                                  │
│   │ [Connecter]│ [Connecter]│ [Connecter]│                                 │
│   └──────────┘ └──────────┘ └──────────┘                                  │
│                                                                             │
│                                                                             │
│                         ● ● ● ● ○ ○ ○   (5/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# ✅ ÉTAPE 6: RÉSUMÉ

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 6/7                              [ ← Retour ]                    │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                    Votre CHE·NU est prêt!                                  │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │   VOTRE UNIVERS: 🌿 NATURAL                                        │  │
│   │   ───────────────────────────────────────────────────────────────  │  │
│   │                                                                     │  │
│   │   VOS 8 PIÈCES:                                                    │  │
│   │                                                                     │  │
│   │   ◇ Personal      → Salon Cosy avec Cheminée                       │  │
│   │   ⬡ Business      → Bureau Moderne                                 │  │
│   │   ⏣ Government    → Hall aux Archives                              │  │
│   │   ✦ Creative      → Atelier d'Artiste                              │  │
│   │   ◉ Community     → Café Communautaire                             │  │
│   │   ⊛ Social        → Terrasse Lounge                                │  │
│   │   ▷ Entertainment → Salle Média                                    │  │
│   │   ⎔ My Team       → Centre de Commande                             │  │
│   │                                                                     │  │
│   │   CONNEXIONS: 3 plateformes connectées                             │  │
│   │   • Google Calendar                                                │  │
│   │   • Slack                                                          │  │
│   │   • Google Drive                                                   │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│                                                                             │
│   ℹ️ Vous pouvez modifier ces choix à tout moment dans les paramètres.     │
│                                                                             │
│                                                                             │
│        [ Modifier ]              [ Continuer vers les profils → ]         │
│                                                                             │
│                         ● ● ● ● ● ○ ○   (6/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 👤 ÉTAPE 7: CONFIGURATION DES PROFILS PAR SPHÈRE

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     Étape 7/7                              [ Terminer plus tard ]          │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│              Configurez vos PROFILS par sphère (Optionnel)                 │
│                                                                             │
│          Chaque sphère peut avoir ses propres profils, entités,            │
│          et configurations spécifiques.                                    │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   Sélectionnez une sphère pour configurer son profil:                      │
│                                                                             │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐        │
│   │ ◇ PERSONAL       │  │ ⬡ BUSINESS       │  │ ⏣ GOVERNMENT     │        │
│   │                  │  │                  │  │                  │        │
│   │ • Infos perso    │  │ • Entreprises    │  │ • Identité       │        │
│   │ • Objectifs      │  │ • Clients        │  │ • Documents      │        │
│   │ • Santé          │  │ • Partenaires    │  │ • Échéances      │        │
│   │                  │  │                  │  │                  │        │
│   │  [Configurer]    │  │  [Configurer]    │  │  [Configurer]    │        │
│   │  ○ Non configuré │  │  ○ Non configuré │  │  ○ Non configuré │        │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘        │
│                                                                             │
│   ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐        │
│   │ ✦ CREATIVE       │  │ ◉ COMMUNITY      │  │ ⊛ SOCIAL         │        │
│   │                  │  │                  │  │                  │        │
│   │ • Portfolio      │  │ • Associations   │  │ • Profils        │        │
│   │ • Projets        │  │ • Groupes        │  │ • Audiences      │        │
│   │ • Style          │  │ • Rôles          │  │ • Calendrier     │        │
│   │                  │  │                  │  │                  │        │
│   │  [Configurer]    │  │  [Configurer]    │  │  [Configurer]    │        │
│   │  ○ Non configuré │  │  ○ Non configuré │  │  ○ Non configuré │        │
│   └──────────────────┘  └──────────────────┘  └──────────────────┘        │
│                                                                             │
│   ┌──────────────────┐  ┌──────────────────┐                              │
│   │ ▷ ENTERTAINMENT  │  │ ⎔ MY TEAM        │                              │
│   │                  │  │                  │                              │
│   │ • Préférences    │  │ • Agents IA      │                              │
│   │ • Abonnements    │  │ • Outils         │                              │
│   │ • Historique     │  │ • Labs           │                              │
│   │                  │  │                  │                              │
│   │  [Configurer]    │  │  [Configurer]    │                              │
│   │  ○ Non configuré │  │  ○ Non configuré │                              │
│   └──────────────────┘  └──────────────────┘                              │
│                                                                             │
│                                                                             │
│                    [ Terminer et accéder à CHE·NU ]                        │
│                                                                             │
│                         ● ● ● ● ● ● ○   (7/7)                            │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📝 PROFILS DÉTAILLÉS PAR SPHÈRE

## ⬡ BUSINESS PROFILE (Exemple Détaillé)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│     ⬡ BUSINESS - Configuration du Profil                    [ × Fermer ]  │
│                                                                             │
│     ═══════════════════════════════════════════════════════════════════    │
│                                                                             │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │  📋 ONGLETS:  [Entreprises] [Branches] [Clients] [Partenaires]      │  │
│   │               [Finances] [Plateformes] [Équipe]                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   ═══════════════════════════════════════════════════════════════════      │
│   ENTREPRISES                                                              │
│   ═══════════════════════════════════════════════════════════════════      │
│                                                                             │
│   Ajoutez les entreprises avec lesquelles vous travaillez:                 │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │  🏢 MA PROPRE ENTREPRISE                                           │  │
│   │  ─────────────────────────────────────────────────────────────────  │  │
│   │                                                                     │  │
│   │  Nom: [PR0 Services Inc.________________________]                  │  │
│   │                                                                     │  │
│   │  Type: ○ Entreprise individuelle                                   │  │
│   │        ● Société (Inc, SARL, etc.)                                 │  │
│   │        ○ Freelance / Consultant                                    │  │
│   │        ○ Autre                                                     │  │
│   │                                                                     │  │
│   │  Secteur: [Technologies / SaaS_______________] ▼                   │  │
│   │                                                                     │  │
│   │  Numéro d'entreprise: [NEQ123456789__________]                     │  │
│   │                                                                     │  │
│   │  Logo: [📷 Ajouter logo]                                           │  │
│   │                                                                     │  │
│   │  [ Sauvegarder ]                                                   │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│   ┌─────────────────────────────────────────────────────────────────────┐  │
│   │                                                                     │  │
│   │  [+ Ajouter une autre entreprise]                                  │  │
│   │                                                                     │  │
│   │  Exemples:                                                         │  │
│   │  • Employeur actuel                                                │  │
│   │  • Entreprise personnelle secondaire                               │  │
│   │  • Holding ou structure mère                                       │  │
│   │                                                                     │  │
│   └─────────────────────────────────────────────────────────────────────┘  │
│                                                                             │
│                                                                             │
│   ═══════════════════════════════════════════════════════════════════      │
│   BRANCHES / DIVISIONS                                                     │
│   ═══════════════════════════════════════════════════════════════════      │
│                                                                             │
│   Créez des branches pour organiser vos activités:                         │
│                                                                             │
│   PR0 Services Inc.                                                        │
│   ├── 📁 CHE·NU Development                                               │
│   │   ├── Équipe: 5 membres                                               │
│   │   ├── Budget: $50,000/mois                                            │
│   │   └── [Modifier] [Supprimer]                                          │
│   │                                                                        │
│   ├── 📁 Consulting                                                        │
│   │   ├── Équipe: 2 membres                                               │
│   │   ├── Budget: $15,000/mois                                            │
│   │   └── [Modifier] [Supprimer]                                          │
│   │                                                                        │
│   └── [+ Nouvelle branche]                                                 │
│                                                                             │
│                                                                             │
│   ═══════════════════════════════════════════════════════════════════      │
│   PLATEFORMES CONNECTÉES                                                   │
│   ═══════════════════════════════════════════════════════════════════      │
│                                                                             │
│   ┌────────────────┐  ┌────────────────┐  ┌────────────────┐              │
│   │ [QuickBooks]   │  │ [Stripe]       │  │ [Hubspot]      │              │
│   │ ✓ Connecté     │  │ ✓ Connecté     │  │ ○ Non connecté │              │
│   │                │  │                │  │                │              │
│   │ Dernière sync: │  │ Dernière sync: │  │                │              │
│   │ Il y a 2h      │  │ Il y a 30min   │  │ [Connecter]    │              │
│   │                │  │                │  │                │              │
│   │ [Déconnecter]  │  │ [Déconnecter]  │  │                │              │
│   └────────────────┘  └────────────────┘  └────────────────┘              │
│                                                                             │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 🗃️ MODÈLE DE DONNÉES - PROFILS

## Schema SQL

```sql
-- ═══════════════════════════════════════════════════════════════════
-- ONBOARDING & SPHERE PROFILES
-- Extension au schema CHE·NU
-- ═══════════════════════════════════════════════════════════════════

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROGRESSION ONBOARDING
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE user_onboarding (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Progression
    current_step INTEGER DEFAULT 1,
    completed_steps INTEGER[] DEFAULT '{}',
    is_completed BOOLEAN DEFAULT FALSE,
    
    -- Choix faits
    selected_theme_id VARCHAR(50),
    room_assignments JSONB DEFAULT '{}',  -- {sphere_id: room_variant_index}
    
    -- Connexions faites pendant onboarding
    connected_platforms TEXT[] DEFAULT '{}',
    
    -- Timestamps
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    last_step_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Feedback
    skipped_steps INTEGER[] DEFAULT '{}',
    time_spent_seconds INTEGER DEFAULT 0,
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFILS DE SPHÈRES
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE sphere_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    sphere_id VARCHAR(20) NOT NULL,
    
    -- Configuration
    is_configured BOOLEAN DEFAULT FALSE,
    configuration_progress INTEGER DEFAULT 0,  -- 0-100%
    
    -- Données de profil (flexible selon sphère)
    profile_data JSONB DEFAULT '{}',
    
    -- Timestamps
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id, sphere_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: ENTITÉS (Entreprises, Organisations, etc.)
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE entities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Identification
    name VARCHAR(255) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,  -- 'company', 'organization', 'client', 'partner', 'association'
    
    -- Sphère d'appartenance principale
    primary_sphere_id VARCHAR(20) NOT NULL,
    
    -- Informations de base
    description TEXT,
    logo_url TEXT,
    website_url TEXT,
    
    -- Identifiants légaux (optionnel)
    legal_id VARCHAR(100),           -- NEQ, SIRET, etc.
    legal_id_type VARCHAR(50),       -- Type d'identifiant
    
    -- Secteur / Catégorie
    sector VARCHAR(100),
    category VARCHAR(100),
    tags TEXT[],
    
    -- Contact
    email VARCHAR(255),
    phone VARCHAR(50),
    address JSONB,                    -- {street, city, postal_code, country}
    
    -- Relation avec l'utilisateur
    relationship_type VARCHAR(50),    -- 'owner', 'employee', 'client', 'partner', 'member'
    role_in_entity VARCHAR(100),      -- Rôle de l'utilisateur
    
    -- Thème personnalisé (optionnel)
    custom_theme_id VARCHAR(50),
    custom_room_variant INTEGER,
    
    -- Métadonnées
    metadata JSONB DEFAULT '{}',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_entities_user ON entities(user_id);
CREATE INDEX idx_entities_sphere ON entities(user_id, primary_sphere_id);
CREATE INDEX idx_entities_type ON entities(entity_type);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: BRANCHES / DIVISIONS
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE entity_branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entity_id UUID NOT NULL REFERENCES entities(id) ON DELETE CASCADE,
    parent_branch_id UUID REFERENCES entity_branches(id),  -- Pour hiérarchie
    
    name VARCHAR(255) NOT NULL,
    branch_type VARCHAR(50),          -- 'division', 'department', 'team', 'project', 'location'
    
    description TEXT,
    
    -- Budget associé (optionnel)
    budget_monthly DECIMAL(15,2),
    budget_currency VARCHAR(3) DEFAULT 'USD',
    
    -- Équipe
    team_size INTEGER DEFAULT 0,
    team_members UUID[],              -- Références vers contacts
    
    -- Métadonnées
    metadata JSONB DEFAULT '{}',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX idx_branches_entity ON entity_branches(entity_id);
CREATE INDEX idx_branches_parent ON entity_branches(parent_branch_id);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: CONNEXIONS DE PLATEFORMES
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE platform_connections (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Plateforme
    platform_id VARCHAR(50) NOT NULL,  -- 'google_calendar', 'slack', 'stripe', etc.
    platform_name VARCHAR(100) NOT NULL,
    platform_category VARCHAR(50),     -- 'productivity', 'social', 'finance', 'storage'
    
    -- Sphère(s) associée(s)
    associated_sphere_ids TEXT[] DEFAULT '{}',
    
    -- Entité associée (optionnel)
    entity_id UUID REFERENCES entities(id),
    
    -- État de connexion
    is_connected BOOLEAN DEFAULT FALSE,
    connection_status VARCHAR(20) DEFAULT 'disconnected',  -- 'connected', 'disconnected', 'error', 'expired'
    
    -- Tokens et authentification (chiffrés en prod)
    access_token TEXT,
    refresh_token TEXT,
    token_expires_at TIMESTAMP WITH TIME ZONE,
    
    -- Synchronisation
    last_sync_at TIMESTAMP WITH TIME ZONE,
    sync_frequency VARCHAR(20) DEFAULT 'hourly',  -- 'realtime', 'hourly', 'daily', 'manual'
    sync_enabled BOOLEAN DEFAULT TRUE,
    
    -- Permissions accordées
    granted_scopes TEXT[],
    
    -- Métadonnées
    connection_metadata JSONB DEFAULT '{}',
    
    -- Audit
    connected_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_platform_user ON platform_connections(user_id);
CREATE INDEX idx_platform_status ON platform_connections(user_id, is_connected);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL PERSONAL (Données sensibles)
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE personal_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Informations de base
    full_name VARCHAR(255),
    date_of_birth DATE,
    nationality VARCHAR(100),
    
    -- Contact personnel
    personal_email VARCHAR(255),
    personal_phone VARCHAR(50),
    
    -- Adresse
    address JSONB,
    
    -- Santé (optionnel, chiffré en prod)
    health_info JSONB DEFAULT '{}',
    emergency_contacts JSONB DEFAULT '[]',
    
    -- Objectifs personnels
    life_goals JSONB DEFAULT '[]',
    
    -- Préférences
    preferences JSONB DEFAULT '{}',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL GOVERNMENT (Documents officiels)
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE government_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Identité
    legal_name VARCHAR(255),
    
    -- Documents (références, pas les documents eux-mêmes)
    identity_documents JSONB DEFAULT '[]',  -- [{type, number, expiry, country}]
    tax_identifiers JSONB DEFAULT '[]',     -- [{type, number, jurisdiction}]
    
    -- Institutions connues
    registered_institutions JSONB DEFAULT '[]',
    
    -- Échéances importantes
    important_deadlines JSONB DEFAULT '[]',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL CREATIVE
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE creative_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Portfolio
    portfolio_url TEXT,
    showcase_works JSONB DEFAULT '[]',
    
    -- Style et préférences
    creative_style TEXT,
    preferred_tools TEXT[],
    inspirations TEXT[],
    
    -- Compétences
    skills JSONB DEFAULT '[]',
    
    -- Projets en cours
    active_projects JSONB DEFAULT '[]',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL COMMUNITY
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE community_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Associations et groupes
    memberships JSONB DEFAULT '[]',  -- [{name, role, since, type}]
    
    -- Rôles communautaires
    community_roles JSONB DEFAULT '[]',
    
    -- Intérêts communautaires
    community_interests TEXT[],
    
    -- Événements
    upcoming_events JSONB DEFAULT '[]',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL SOCIAL
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE social_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Profils sociaux
    social_handles JSONB DEFAULT '{}',  -- {platform: handle}
    
    -- Audiences
    audience_metrics JSONB DEFAULT '{}',
    
    -- Calendrier de publication
    posting_schedule JSONB DEFAULT '{}',
    
    -- Contenu
    content_pillars TEXT[],
    brand_voice TEXT,
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL ENTERTAINMENT
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE entertainment_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Préférences
    favorite_genres JSONB DEFAULT '{}',  -- {movies: [], music: [], games: []}
    
    -- Abonnements
    subscriptions JSONB DEFAULT '[]',  -- [{service, status, price}]
    
    -- Listes
    watchlist JSONB DEFAULT '[]',
    played_games JSONB DEFAULT '[]',
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);

-- ═══════════════════════════════════════════════════════════════════
-- TABLE: PROFIL MY TEAM
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE team_profile (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Agents actifs
    active_agents JSONB DEFAULT '[]',
    
    -- Outils préférés
    preferred_tools JSONB DEFAULT '[]',
    
    -- Labs / Expérimentations
    active_experiments JSONB DEFAULT '[]',
    
    -- Budget tokens
    monthly_token_budget INTEGER DEFAULT 0,
    current_token_usage INTEGER DEFAULT 0,
    
    -- Audit
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    UNIQUE(user_id)
);
```

---

# 🔌 API ENDPOINTS - ONBOARDING & PROFILES

```python
# api/routes/onboarding.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
from uuid import UUID
from pydantic import BaseModel

router = APIRouter(prefix="/api/onboarding", tags=["Onboarding"])

# ═══════════════════════════════════════════════════════════════════
# SCHEMAS
# ═══════════════════════════════════════════════════════════════════

class OnboardingProgress(BaseModel):
    current_step: int
    completed_steps: List[int]
    is_completed: bool
    selected_theme_id: Optional[str]
    room_assignments: dict

class RoomAssignment(BaseModel):
    sphere_id: str
    room_variant_index: int

class PlatformConnection(BaseModel):
    platform_id: str
    auth_code: Optional[str]

# ═══════════════════════════════════════════════════════════════════
# ONBOARDING ENDPOINTS
# ═══════════════════════════════════════════════════════════════════

@router.get("/progress/{user_id}", response_model=OnboardingProgress)
async def get_onboarding_progress(
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Récupère la progression de l'onboarding de l'utilisateur.
    """
    progress = await get_user_onboarding(db, user_id)
    if not progress:
        # Créer un nouvel onboarding
        progress = await create_onboarding(db, user_id)
    return progress

@router.put("/progress/{user_id}/step/{step}")
async def complete_onboarding_step(
    user_id: UUID,
    step: int,
    db: AsyncSession = Depends(get_db)
):
    """
    Marque une étape de l'onboarding comme complétée.
    """
    await mark_step_completed(db, user_id, step)
    return {"status": "ok", "step": step}

@router.put("/progress/{user_id}/theme")
async def set_selected_theme(
    user_id: UUID,
    theme_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Enregistre le thème sélectionné pendant l'onboarding.
    """
    await save_selected_theme(db, user_id, theme_id)
    return {"status": "ok", "theme_id": theme_id}

@router.put("/progress/{user_id}/rooms")
async def set_room_assignments(
    user_id: UUID,
    assignments: List[RoomAssignment],
    db: AsyncSession = Depends(get_db)
):
    """
    Enregistre les attributions de pièces aux sphères.
    """
    assignments_dict = {a.sphere_id: a.room_variant_index for a in assignments}
    await save_room_assignments(db, user_id, assignments_dict)
    return {"status": "ok", "assignments": assignments_dict}

@router.post("/progress/{user_id}/complete")
async def complete_onboarding(
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Finalise l'onboarding et applique les configurations.
    """
    # Appliquer le thème
    progress = await get_user_onboarding(db, user_id)
    if progress.selected_theme_id:
        await apply_theme_selection(db, user_id, progress.selected_theme_id)
    
    # Appliquer les pièces
    if progress.room_assignments:
        await apply_room_assignments(db, user_id, progress.room_assignments)
    
    # Marquer comme complété
    await mark_onboarding_completed(db, user_id)
    
    return {"status": "completed", "redirect": "/dashboard"}

@router.post("/progress/{user_id}/skip")
async def skip_onboarding(
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Permet de passer l'onboarding avec les valeurs par défaut.
    """
    await apply_default_configuration(db, user_id)
    await mark_onboarding_completed(db, user_id)
    return {"status": "skipped", "redirect": "/dashboard"}

# ═══════════════════════════════════════════════════════════════════
# ROOM SELECTION
# ═══════════════════════════════════════════════════════════════════

@router.get("/rooms/{theme_id}")
async def get_available_rooms(
    theme_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Récupère toutes les pièces disponibles pour un thème.
    """
    rooms = await get_theme_rooms(db, theme_id)
    
    # Grouper par suggestions de sphère
    suggestions = {
        'personal': ['salon', 'chambre', 'bureau_perso'],
        'business': ['bureau', 'salle_conf', 'open_space'],
        'government': ['hall', 'archives', 'bureau_officiel'],
        'creative': ['atelier', 'studio', 'loft'],
        'community': ['cafe', 'place', 'centre'],
        'social': ['terrasse', 'lounge', 'rooftop'],
        'entertainment': ['media_room', 'cinema', 'gaming'],
        'team': ['command_center', 'hub', 'lab']
    }
    
    return {
        "theme_id": theme_id,
        "rooms": rooms,
        "suggestions": suggestions
    }

@router.get("/rooms/{theme_id}/preview/{variant_index}")
async def preview_room(
    theme_id: str,
    variant_index: int,
    quality: str = "medium"
):
    """
    Récupère l'image de preview d'une pièce.
    """
    room_url = f"/assets/rooms/{theme_id}/room_{variant_index:02d}_{quality}.jpg"
    room_info = await get_room_info(theme_id, variant_index)
    
    return {
        "theme_id": theme_id,
        "variant_index": variant_index,
        "preview_url": room_url,
        "name": room_info.name,
        "description": room_info.description,
        "suggested_spheres": room_info.suggested_spheres
    }


# api/routes/profiles.py

router_profiles = APIRouter(prefix="/api/profiles", tags=["Sphere Profiles"])

# ═══════════════════════════════════════════════════════════════════
# ENTITY MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

@router_profiles.post("/entities")
async def create_entity(
    user_id: UUID,
    name: str,
    entity_type: str,
    primary_sphere_id: str,
    description: Optional[str] = None,
    sector: Optional[str] = None,
    relationship_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Crée une nouvelle entité (entreprise, organisation, client, etc.)
    """
    entity = await create_new_entity(
        db, user_id, name, entity_type, primary_sphere_id,
        description=description,
        sector=sector,
        relationship_type=relationship_type
    )
    return entity

@router_profiles.get("/entities")
async def list_entities(
    user_id: UUID,
    sphere_id: Optional[str] = None,
    entity_type: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Liste les entités de l'utilisateur.
    """
    entities = await get_user_entities(
        db, user_id, sphere_id=sphere_id, entity_type=entity_type
    )
    return {"entities": entities, "total": len(entities)}

@router_profiles.get("/entities/{entity_id}")
async def get_entity(
    entity_id: UUID,
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Récupère les détails d'une entité.
    """
    entity = await get_entity_by_id(db, entity_id, user_id)
    if not entity:
        raise HTTPException(status_code=404, detail="Entity not found")
    return entity

@router_profiles.put("/entities/{entity_id}")
async def update_entity(
    entity_id: UUID,
    user_id: UUID,
    update_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """
    Met à jour une entité.
    """
    entity = await update_entity_data(db, entity_id, user_id, update_data)
    return entity

@router_profiles.delete("/entities/{entity_id}")
async def delete_entity(
    entity_id: UUID,
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Supprime une entité (soft delete).
    """
    await soft_delete_entity(db, entity_id, user_id)
    return {"status": "deleted"}

# ═══════════════════════════════════════════════════════════════════
# BRANCH MANAGEMENT
# ═══════════════════════════════════════════════════════════════════

@router_profiles.post("/entities/{entity_id}/branches")
async def create_branch(
    entity_id: UUID,
    user_id: UUID,
    name: str,
    branch_type: str = "division",
    parent_branch_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Crée une nouvelle branche pour une entité.
    """
    branch = await create_entity_branch(
        db, entity_id, name, branch_type, parent_branch_id
    )
    return branch

@router_profiles.get("/entities/{entity_id}/branches")
async def list_branches(
    entity_id: UUID,
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Liste les branches d'une entité.
    """
    branches = await get_entity_branches(db, entity_id)
    return {"branches": branches, "total": len(branches)}

# ═══════════════════════════════════════════════════════════════════
# PLATFORM CONNECTIONS
# ═══════════════════════════════════════════════════════════════════

@router_profiles.get("/platforms")
async def list_available_platforms():
    """
    Liste toutes les plateformes connectables.
    """
    return {
        "platforms": [
            {
                "id": "google_calendar",
                "name": "Google Calendar",
                "category": "productivity",
                "icon": "google-calendar",
                "suggested_spheres": ["personal", "business"]
            },
            {
                "id": "slack",
                "name": "Slack",
                "category": "productivity",
                "icon": "slack",
                "suggested_spheres": ["business", "team"]
            },
            {
                "id": "stripe",
                "name": "Stripe",
                "category": "finance",
                "icon": "stripe",
                "suggested_spheres": ["business"]
            },
            {
                "id": "linkedin",
                "name": "LinkedIn",
                "category": "social",
                "icon": "linkedin",
                "suggested_spheres": ["business", "social"]
            },
            # ... autres plateformes
        ]
    }

@router_profiles.post("/platforms/connect")
async def connect_platform(
    user_id: UUID,
    platform_id: str,
    sphere_ids: List[str],
    entity_id: Optional[UUID] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Initie la connexion à une plateforme.
    """
    auth_url = await initiate_platform_auth(
        db, user_id, platform_id, sphere_ids, entity_id
    )
    return {"auth_url": auth_url}

@router_profiles.post("/platforms/callback/{platform_id}")
async def platform_auth_callback(
    platform_id: str,
    code: str,
    state: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Callback OAuth pour finaliser la connexion.
    """
    connection = await complete_platform_auth(db, platform_id, code, state)
    return {"status": "connected", "connection": connection}

@router_profiles.get("/platforms/connections")
async def list_connections(
    user_id: UUID,
    sphere_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """
    Liste les connexions actives de l'utilisateur.
    """
    connections = await get_user_connections(db, user_id, sphere_id)
    return {"connections": connections}

@router_profiles.delete("/platforms/connections/{connection_id}")
async def disconnect_platform(
    connection_id: UUID,
    user_id: UUID,
    db: AsyncSession = Depends(get_db)
):
    """
    Déconnecte une plateforme.
    """
    await remove_platform_connection(db, connection_id, user_id)
    return {"status": "disconnected"}

# ═══════════════════════════════════════════════════════════════════
# SPHERE-SPECIFIC PROFILES
# ═══════════════════════════════════════════════════════════════════

@router_profiles.get("/sphere/{sphere_id}")
async def get_sphere_profile(
    user_id: UUID,
    sphere_id: str,
    db: AsyncSession = Depends(get_db)
):
    """
    Récupère le profil complet d'une sphère.
    """
    profile = await get_sphere_profile_data(db, user_id, sphere_id)
    entities = await get_user_entities(db, user_id, sphere_id=sphere_id)
    connections = await get_user_connections(db, user_id, sphere_id)
    
    return {
        "sphere_id": sphere_id,
        "profile": profile,
        "entities": entities,
        "connections": connections,
        "is_configured": profile.is_configured if profile else False
    }

@router_profiles.put("/sphere/{sphere_id}")
async def update_sphere_profile(
    user_id: UUID,
    sphere_id: str,
    profile_data: dict,
    db: AsyncSession = Depends(get_db)
):
    """
    Met à jour le profil d'une sphère.
    """
    profile = await update_sphere_profile_data(db, user_id, sphere_id, profile_data)
    return profile
```

---

# 📊 RÉSUMÉ DU SYSTÈME

```
╔═══════════════════════════════════════════════════════════════════════════════╗
║                    ONBOARDING & SPHERE PROFILES SYSTEM                        ║
╠═══════════════════════════════════════════════════════════════════════════════╣
║                                                                               ║
║   🎓 ONBOARDING (7 étapes)                                                   ║
║   ├── 1. Bienvenue & Introduction                                            ║
║   ├── 2. Choix de l'univers (4 thèmes)                                       ║
║   ├── 3. Attribution des 8 pièces aux 8 sphères                              ║
║   ├── 4. Tutorial interactif (4 concepts)                                    ║
║   ├── 5. Connexion plateformes (optionnel)                                   ║
║   ├── 6. Résumé des choix                                                    ║
║   └── 7. Configuration des profils (optionnel, peut être fait après)         ║
║                                                                               ║
║   👤 PROFILS PAR SPHÈRE                                                      ║
║   ├── Personal: Infos perso, santé, objectifs                                ║
║   ├── Business: Entreprises, branches, clients, partenaires                  ║
║   ├── Government: Identité, documents, échéances                             ║
║   ├── Creative: Portfolio, style, compétences                                ║
║   ├── Community: Associations, groupes, rôles                                ║
║   ├── Social: Profils sociaux, audiences, calendrier                         ║
║   ├── Entertainment: Préférences, abonnements, listes                        ║
║   └── My Team: Agents IA, outils, labs, budget tokens                        ║
║                                                                               ║
║   🏢 ENTITÉS                                                                 ║
║   ├── Types: company, organization, client, partner, association             ║
║   ├── Branches: division, department, team, project, location                ║
║   ├── Relations: owner, employee, client, partner, member                    ║
║   └── Thème personnalisé par entité (optionnel)                              ║
║                                                                               ║
║   🔌 PLATEFORMES                                                             ║
║   ├── Productivité: Google, Outlook, Notion, Slack, Teams                    ║
║   ├── Finance: QuickBooks, Stripe, Xero, Hubspot                             ║
║   ├── Social: LinkedIn, Twitter, Instagram, Facebook, TikTok                 ║
║   └── Stockage: Google Drive, Dropbox, OneDrive                              ║
║                                                                               ║
╚═══════════════════════════════════════════════════════════════════════════════╝
```

---

*CHE·NU™ Onboarding & Sphere Profiles v1.0*
*Personnalisation Complète de l'Expérience Utilisateur*
