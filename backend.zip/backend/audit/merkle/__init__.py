"""CHE·NU™ V69 — Merkle utilities"""
