"""Professeur Agent Module"""
from .agent import *
