"""
CHE·NU™ Finance Agent V68

Personal & Business Finance Management with full CANON compliance.

CANON COMPLIANCE:
- Rule #1: Human Sovereignty - All transactions require approval
- Rule #2: Autonomy Isolation - Analysis is read-only sandbox
- Rule #5: No Ranking - Transactions chronological only
- Rule #6: Traceability - Full audit trail on all operations
"""

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from enum import Enum
from typing import Optional, List, Dict, Any
from uuid import UUID, uuid4
import logging

logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════════════════════════

class AccountType(Enum):
    """Types of financial accounts."""
    CHECKING = "checking"
    SAVINGS = "savings"
    CREDIT_CARD = "credit_card"
    INVESTMENT = "investment"
    CASH = "cash"
    LOAN = "loan"


class TransactionStatus(Enum):
    """Transaction approval status - CANON Rule #1."""
    DRAFT = "draft"              # Created, not yet approved
    PENDING_APPROVAL = "pending" # Awaiting human approval
    APPROVED = "approved"        # Human approved
    REJECTED = "rejected"        # Human rejected
    COMPLETED = "completed"      # Executed
    CANCELLED = "cancelled"      # Cancelled


class TransactionType(Enum):
    """Types of transactions."""
    INCOME = "income"
    EXPENSE = "expense"
    TRANSFER = "transfer"
    INVESTMENT = "investment"
    REFUND = "refund"


class BudgetStatus(Enum):
    """Budget status."""
    DRAFT = "draft"
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    ARCHIVED = "archived"


class CheckpointType(Enum):
    """Checkpoint types for governance."""
    LARGE_TRANSACTION = "large_transaction"
    BUDGET_OVERRIDE = "budget_override"
    INVESTMENT_DECISION = "investment_decision"
    RECURRING_SETUP = "recurring_setup"


# ═══════════════════════════════════════════════════════════════════════════════
# DATA MODELS
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class Account:
    """Financial account."""
    id: UUID
    name: str
    account_type: AccountType
    currency: str
    balance: Decimal
    institution: Optional[str]
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_active: bool = True


@dataclass
class Category:
    """Transaction category."""
    id: UUID
    name: str
    parent_id: Optional[UUID]
    color: str
    icon: str
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


@dataclass
class Transaction:
    """
    Financial transaction with approval workflow.
    
    CANON Rule #1: Transactions start as DRAFT, require human approval.
    """
    id: UUID
    account_id: UUID
    amount: Decimal
    transaction_type: TransactionType
    category_id: Optional[UUID]
    description: str
    date: datetime
    status: TransactionStatus  # DRAFT → PENDING → APPROVED → COMPLETED
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    notes: str = ""
    tags: List[str] = field(default_factory=list)
    # For transfers
    to_account_id: Optional[UUID] = None
    # Recurring
    is_recurring: bool = False
    recurrence_rule: Optional[str] = None


@dataclass
class Budget:
    """
    Budget with spending limits.
    
    CANON: Budgets require approval to activate.
    """
    id: UUID
    name: str
    category_id: Optional[UUID]
    amount: Decimal
    period: str  # "monthly", "weekly", "yearly"
    start_date: datetime
    end_date: Optional[datetime]
    status: BudgetStatus
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    spent: Decimal = Decimal("0.00")
    alert_threshold: float = 0.8  # Alert at 80%


@dataclass
class Goal:
    """Financial goal (savings target)."""
    id: UUID
    name: str
    target_amount: Decimal
    current_amount: Decimal
    target_date: Optional[datetime]
    account_id: Optional[UUID]
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_achieved: bool = False


@dataclass
class Investment:
    """
    Investment holding.
    
    CANON Rule #2: Investment decisions are SANDBOX only.
    User must approve before any actual trade.
    """
    id: UUID
    symbol: str
    name: str
    quantity: Decimal
    purchase_price: Decimal
    purchase_date: datetime
    account_id: UUID
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    current_price: Optional[Decimal] = None


@dataclass
class Checkpoint:
    """
    Governance checkpoint for sensitive operations.
    
    CANON Rule #1: Human must approve before execution.
    """
    id: UUID
    checkpoint_type: CheckpointType
    entity_id: UUID
    entity_type: str
    reason: str
    requires_approval: bool
    created_by: str
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    approved: Optional[bool] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None


@dataclass
class FinancialReport:
    """
    Read-only financial report.
    
    CANON Rule #2: Analysis is read-only, no side effects.
    """
    id: UUID
    report_type: str
    period_start: datetime
    period_end: datetime
    data: Dict[str, Any]
    generated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    generated_by: str = "system"


# ═══════════════════════════════════════════════════════════════════════════════
# FINANCE AGENT
# ═══════════════════════════════════════════════════════════════════════════════

class FinanceAgent:
    """
    CHE·NU Finance Agent with full CANON compliance.
    
    Key CANON Features:
    - All transactions require human approval (Rule #1)
    - Investment analysis is sandbox-only (Rule #2)
    - Transactions listed chronologically, no ranking (Rule #5)
    - Full audit trail on all operations (Rule #6)
    """
    
    # Large transaction threshold requiring checkpoint
    LARGE_TRANSACTION_THRESHOLD = Decimal("1000.00")
    
    def __init__(self):
        """Initialize finance agent."""
        self.accounts: Dict[UUID, Account] = {}
        self.transactions: Dict[UUID, Transaction] = {}
        self.categories: Dict[UUID, Category] = {}
        self.budgets: Dict[UUID, Budget] = {}
        self.goals: Dict[UUID, Goal] = {}
        self.investments: Dict[UUID, Investment] = {}
        self.checkpoints: Dict[UUID, Checkpoint] = {}
        self.reports: Dict[UUID, FinancialReport] = {}
        
        logger.info("FinanceAgent initialized")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # ACCOUNT MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_account(
        self,
        name: str,
        account_type: AccountType,
        currency: str,
        user_id: str,
        initial_balance: Decimal = Decimal("0.00"),
        institution: Optional[str] = None
    ) -> Account:
        """Create a new financial account."""
        account = Account(
            id=uuid4(),
            name=name,
            account_type=account_type,
            currency=currency,
            balance=initial_balance,
            institution=institution,
            created_by=user_id
        )
        
        self.accounts[account.id] = account
        logger.info(f"Account created: {account.id} by {user_id}")
        
        return account
    
    async def get_accounts(self, user_id: str) -> List[Account]:
        """
        Get all accounts for user.
        
        CANON Rule #5: Returns in creation order (chronological).
        """
        accounts = [a for a in self.accounts.values() if a.created_by == user_id]
        # Chronological order, NOT sorted by balance or any ranking
        return sorted(accounts, key=lambda a: a.created_at)
    
    async def get_account(self, account_id: UUID) -> Optional[Account]:
        """Get account by ID."""
        return self.accounts.get(account_id)
    
    async def update_account_balance(
        self,
        account_id: UUID,
        new_balance: Decimal,
        user_id: str
    ) -> Account:
        """Update account balance (manual adjustment)."""
        account = self.accounts.get(account_id)
        if not account:
            raise ValueError(f"Account {account_id} not found")
        
        account.balance = new_balance
        logger.info(f"Account {account_id} balance updated by {user_id}")
        
        return account
    
    # ═══════════════════════════════════════════════════════════════════════════
    # TRANSACTION MANAGEMENT (CANON Rule #1: Human Approval)
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_transaction(
        self,
        account_id: UUID,
        amount: Decimal,
        transaction_type: TransactionType,
        description: str,
        user_id: str,
        category_id: Optional[UUID] = None,
        date: Optional[datetime] = None,
        to_account_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        notes: str = ""
    ) -> Transaction:
        """
        Create a transaction in DRAFT status.
        
        CANON Rule #1: Transaction starts as DRAFT, requires human approval.
        """
        # Verify account exists
        if account_id not in self.accounts:
            raise ValueError(f"Account {account_id} not found")
        
        transaction = Transaction(
            id=uuid4(),
            account_id=account_id,
            amount=amount,
            transaction_type=transaction_type,
            category_id=category_id,
            description=description,
            date=date or datetime.now(timezone.utc),
            status=TransactionStatus.DRAFT,  # CANON: Always start as DRAFT
            created_by=user_id,
            to_account_id=to_account_id,
            tags=tags or [],
            notes=notes
        )
        
        self.transactions[transaction.id] = transaction
        logger.info(f"Transaction DRAFT created: {transaction.id} by {user_id}")
        
        return transaction
    
    async def submit_transaction_for_approval(
        self,
        transaction_id: UUID,
        user_id: str
    ) -> tuple[Transaction, Optional[Checkpoint]]:
        """
        Submit transaction for approval.
        
        CANON Rule #1: Creates checkpoint if large transaction.
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            raise ValueError(f"Transaction {transaction_id} not found")
        
        if transaction.status != TransactionStatus.DRAFT:
            raise ValueError(f"Transaction must be DRAFT to submit")
        
        transaction.status = TransactionStatus.PENDING_APPROVAL
        
        # Check if checkpoint needed (large transaction)
        checkpoint = None
        if transaction.amount >= self.LARGE_TRANSACTION_THRESHOLD:
            checkpoint = Checkpoint(
                id=uuid4(),
                checkpoint_type=CheckpointType.LARGE_TRANSACTION,
                entity_id=transaction.id,
                entity_type="transaction",
                reason=f"Large transaction: {transaction.amount}",
                requires_approval=True,
                created_by=user_id
            )
            self.checkpoints[checkpoint.id] = checkpoint
            logger.info(f"Checkpoint created for large transaction: {checkpoint.id}")
        
        logger.info(f"Transaction {transaction_id} submitted for approval")
        
        return transaction, checkpoint
    
    async def approve_transaction(
        self,
        transaction_id: UUID,
        approver_id: str
    ) -> Transaction:
        """
        Approve a pending transaction.
        
        CANON Rule #1: Human explicitly approves.
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            raise ValueError(f"Transaction {transaction_id} not found")
        
        if transaction.status != TransactionStatus.PENDING_APPROVAL:
            raise ValueError(f"Transaction must be PENDING_APPROVAL")
        
        transaction.status = TransactionStatus.APPROVED
        transaction.approved_by = approver_id
        transaction.approved_at = datetime.now(timezone.utc)
        
        logger.info(f"Transaction {transaction_id} APPROVED by {approver_id}")
        
        return transaction
    
    async def reject_transaction(
        self,
        transaction_id: UUID,
        rejector_id: str,
        reason: str = ""
    ) -> Transaction:
        """
        Reject a pending transaction.
        
        CANON Rule #1: Human can reject.
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            raise ValueError(f"Transaction {transaction_id} not found")
        
        if transaction.status != TransactionStatus.PENDING_APPROVAL:
            raise ValueError(f"Transaction must be PENDING_APPROVAL")
        
        transaction.status = TransactionStatus.REJECTED
        transaction.notes = f"Rejected by {rejector_id}: {reason}"
        
        logger.info(f"Transaction {transaction_id} REJECTED by {rejector_id}")
        
        return transaction
    
    async def execute_transaction(
        self,
        transaction_id: UUID,
        executor_id: str
    ) -> Transaction:
        """
        Execute an approved transaction.
        
        CANON Rule #1: Only executes after human approval.
        """
        transaction = self.transactions.get(transaction_id)
        if not transaction:
            raise ValueError(f"Transaction {transaction_id} not found")
        
        if transaction.status != TransactionStatus.APPROVED:
            raise ValueError(
                f"Transaction must be APPROVED before execution. "
                f"Current status: {transaction.status.value}"
            )
        
        # Update account balance
        account = self.accounts.get(transaction.account_id)
        if not account:
            raise ValueError(f"Account {transaction.account_id} not found")
        
        if transaction.transaction_type == TransactionType.INCOME:
            account.balance += transaction.amount
        elif transaction.transaction_type == TransactionType.EXPENSE:
            account.balance -= transaction.amount
        elif transaction.transaction_type == TransactionType.TRANSFER:
            if transaction.to_account_id:
                to_account = self.accounts.get(transaction.to_account_id)
                if to_account:
                    account.balance -= transaction.amount
                    to_account.balance += transaction.amount
        
        # Update budget spending
        if transaction.category_id:
            await self._update_budget_spending(
                transaction.category_id,
                transaction.amount
            )
        
        transaction.status = TransactionStatus.COMPLETED
        
        logger.info(f"Transaction {transaction_id} EXECUTED by {executor_id}")
        
        return transaction
    
    async def get_transactions(
        self,
        user_id: str,
        account_id: Optional[UUID] = None,
        limit: int = 50
    ) -> List[Transaction]:
        """
        Get transactions.
        
        CANON Rule #5: Returns in chronological order, NO RANKING.
        """
        transactions = list(self.transactions.values())
        
        if account_id:
            transactions = [t for t in transactions if t.account_id == account_id]
        
        # CANON Rule #5: Chronological order ONLY, no ranking by amount or priority
        transactions = sorted(transactions, key=lambda t: t.date, reverse=True)
        
        return transactions[:limit]
    
    # ═══════════════════════════════════════════════════════════════════════════
    # BUDGET MANAGEMENT
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_budget(
        self,
        name: str,
        amount: Decimal,
        period: str,
        user_id: str,
        category_id: Optional[UUID] = None,
        start_date: Optional[datetime] = None,
        alert_threshold: float = 0.8
    ) -> Budget:
        """
        Create a budget in DRAFT status.
        
        CANON: Budgets start as DRAFT, require activation.
        """
        budget = Budget(
            id=uuid4(),
            name=name,
            category_id=category_id,
            amount=amount,
            period=period,
            start_date=start_date or datetime.now(timezone.utc),
            end_date=None,
            status=BudgetStatus.DRAFT,
            created_by=user_id,
            alert_threshold=alert_threshold
        )
        
        self.budgets[budget.id] = budget
        logger.info(f"Budget DRAFT created: {budget.id}")
        
        return budget
    
    async def activate_budget(
        self,
        budget_id: UUID,
        user_id: str
    ) -> Budget:
        """Activate a draft budget."""
        budget = self.budgets.get(budget_id)
        if not budget:
            raise ValueError(f"Budget {budget_id} not found")
        
        if budget.status != BudgetStatus.DRAFT:
            raise ValueError("Budget must be DRAFT to activate")
        
        budget.status = BudgetStatus.ACTIVE
        logger.info(f"Budget {budget_id} activated by {user_id}")
        
        return budget
    
    async def get_budgets(self, user_id: str) -> List[Budget]:
        """Get all budgets for user (chronological)."""
        budgets = [b for b in self.budgets.values() if b.created_by == user_id]
        return sorted(budgets, key=lambda b: b.created_at)
    
    async def get_budget_status(self, budget_id: UUID) -> Dict[str, Any]:
        """Get budget spending status."""
        budget = self.budgets.get(budget_id)
        if not budget:
            raise ValueError(f"Budget {budget_id} not found")
        
        percentage = float(budget.spent / budget.amount) if budget.amount > 0 else 0
        remaining = budget.amount - budget.spent
        is_over = budget.spent > budget.amount
        is_warning = percentage >= budget.alert_threshold
        
        return {
            "budget_id": budget.id,
            "name": budget.name,
            "amount": float(budget.amount),
            "spent": float(budget.spent),
            "remaining": float(remaining),
            "percentage": percentage,
            "is_over_budget": is_over,
            "is_warning": is_warning,
            "status": budget.status.value
        }
    
    async def _update_budget_spending(
        self,
        category_id: UUID,
        amount: Decimal
    ) -> None:
        """Update budget spending for category."""
        for budget in self.budgets.values():
            if budget.category_id == category_id and budget.status == BudgetStatus.ACTIVE:
                budget.spent += amount
    
    # ═══════════════════════════════════════════════════════════════════════════
    # GOALS
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_goal(
        self,
        name: str,
        target_amount: Decimal,
        user_id: str,
        target_date: Optional[datetime] = None,
        account_id: Optional[UUID] = None,
        initial_amount: Decimal = Decimal("0.00")
    ) -> Goal:
        """Create a financial goal."""
        goal = Goal(
            id=uuid4(),
            name=name,
            target_amount=target_amount,
            current_amount=initial_amount,
            target_date=target_date,
            account_id=account_id,
            created_by=user_id
        )
        
        self.goals[goal.id] = goal
        logger.info(f"Goal created: {goal.id}")
        
        return goal
    
    async def update_goal_progress(
        self,
        goal_id: UUID,
        amount: Decimal,
        user_id: str
    ) -> Goal:
        """Update goal progress."""
        goal = self.goals.get(goal_id)
        if not goal:
            raise ValueError(f"Goal {goal_id} not found")
        
        goal.current_amount = amount
        
        if goal.current_amount >= goal.target_amount:
            goal.is_achieved = True
            logger.info(f"Goal {goal_id} ACHIEVED!")
        
        return goal
    
    async def get_goals(self, user_id: str) -> List[Goal]:
        """Get all goals for user (chronological)."""
        goals = [g for g in self.goals.values() if g.created_by == user_id]
        return sorted(goals, key=lambda g: g.created_at)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # INVESTMENTS (CANON Rule #2: Sandbox Analysis)
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def analyze_investment_opportunity(
        self,
        symbol: str,
        amount: Decimal,
        user_id: str
    ) -> Dict[str, Any]:
        """
        Analyze investment opportunity.
        
        CANON Rule #2: This is READ-ONLY analysis, no actual trade.
        Returns analysis for human decision.
        """
        # Simulated analysis (in production would call market APIs)
        analysis = {
            "symbol": symbol,
            "proposed_amount": float(amount),
            "analysis_type": "sandbox",  # CANON: Clearly marked as sandbox
            "is_simulation": True,        # CANON: Cannot be mistaken for real
            "metrics": {
                "risk_level": "medium",
                "volatility": 0.15,
                "estimated_return": 0.08
            },
            "recommendation": "Review before trading",
            "requires_human_approval": True,  # CANON Rule #1
            "generated_at": datetime.now(timezone.utc).isoformat()
        }
        
        logger.info(f"Investment analysis (SANDBOX) for {symbol} by {user_id}")
        
        return analysis
    
    async def create_investment_with_approval(
        self,
        symbol: str,
        name: str,
        quantity: Decimal,
        price: Decimal,
        account_id: UUID,
        user_id: str
    ) -> tuple[Investment, Checkpoint]:
        """
        Create investment record with mandatory checkpoint.
        
        CANON Rule #1 & #2: Investment requires explicit human approval.
        """
        investment = Investment(
            id=uuid4(),
            symbol=symbol,
            name=name,
            quantity=quantity,
            purchase_price=price,
            purchase_date=datetime.now(timezone.utc),
            account_id=account_id,
            created_by=user_id,
            current_price=price
        )
        
        # MANDATORY checkpoint for investments
        checkpoint = Checkpoint(
            id=uuid4(),
            checkpoint_type=CheckpointType.INVESTMENT_DECISION,
            entity_id=investment.id,
            entity_type="investment",
            reason=f"Investment in {symbol}: {quantity} @ {price}",
            requires_approval=True,
            created_by=user_id
        )
        
        self.investments[investment.id] = investment
        self.checkpoints[checkpoint.id] = checkpoint
        
        logger.info(f"Investment created with checkpoint: {investment.id}")
        
        return investment, checkpoint
    
    async def get_investments(self, user_id: str) -> List[Investment]:
        """Get all investments (chronological)."""
        investments = [i for i in self.investments.values() if i.created_by == user_id]
        return sorted(investments, key=lambda i: i.created_at)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CATEGORIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def create_category(
        self,
        name: str,
        user_id: str,
        color: str = "#3B82F6",
        icon: str = "folder",
        parent_id: Optional[UUID] = None
    ) -> Category:
        """Create a transaction category."""
        category = Category(
            id=uuid4(),
            name=name,
            parent_id=parent_id,
            color=color,
            icon=icon,
            created_by=user_id
        )
        
        self.categories[category.id] = category
        
        return category
    
    async def get_categories(self, user_id: str) -> List[Category]:
        """
        Get categories.
        
        CANON Rule #5: Alphabetical order (user-controlled, not algorithmic).
        """
        categories = [c for c in self.categories.values() if c.created_by == user_id]
        return sorted(categories, key=lambda c: c.name.lower())
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CHECKPOINTS (CANON Rule #1)
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_pending_checkpoints(self, user_id: str) -> List[Checkpoint]:
        """Get all pending checkpoints requiring approval."""
        pending = [
            c for c in self.checkpoints.values()
            if c.approved is None and c.requires_approval
        ]
        return sorted(pending, key=lambda c: c.created_at)
    
    async def approve_checkpoint(
        self,
        checkpoint_id: UUID,
        approver_id: str
    ) -> Checkpoint:
        """Approve a checkpoint."""
        checkpoint = self.checkpoints.get(checkpoint_id)
        if not checkpoint:
            raise ValueError(f"Checkpoint {checkpoint_id} not found")
        
        checkpoint.approved = True
        checkpoint.approved_by = approver_id
        checkpoint.approved_at = datetime.now(timezone.utc)
        
        logger.info(f"Checkpoint {checkpoint_id} APPROVED by {approver_id}")
        
        return checkpoint
    
    async def reject_checkpoint(
        self,
        checkpoint_id: UUID,
        rejector_id: str
    ) -> Checkpoint:
        """Reject a checkpoint."""
        checkpoint = self.checkpoints.get(checkpoint_id)
        if not checkpoint:
            raise ValueError(f"Checkpoint {checkpoint_id} not found")
        
        checkpoint.approved = False
        checkpoint.approved_by = rejector_id
        checkpoint.approved_at = datetime.now(timezone.utc)
        
        logger.info(f"Checkpoint {checkpoint_id} REJECTED by {rejector_id}")
        
        return checkpoint
    
    # ═══════════════════════════════════════════════════════════════════════════
    # REPORTS (CANON Rule #2: Read-Only Analysis)
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def generate_spending_report(
        self,
        user_id: str,
        start_date: datetime,
        end_date: datetime
    ) -> FinancialReport:
        """
        Generate spending report.
        
        CANON Rule #2: Read-only analysis, no side effects.
        """
        transactions = [
            t for t in self.transactions.values()
            if t.created_by == user_id
            and start_date <= t.date <= end_date
            and t.status == TransactionStatus.COMPLETED
        ]
        
        # Calculate by category
        by_category: Dict[str, Decimal] = {}
        total_income = Decimal("0.00")
        total_expense = Decimal("0.00")
        
        for t in transactions:
            if t.transaction_type == TransactionType.INCOME:
                total_income += t.amount
            elif t.transaction_type == TransactionType.EXPENSE:
                total_expense += t.amount
                cat_name = str(t.category_id) if t.category_id else "Uncategorized"
                by_category[cat_name] = by_category.get(cat_name, Decimal("0.00")) + t.amount
        
        report = FinancialReport(
            id=uuid4(),
            report_type="spending",
            period_start=start_date,
            period_end=end_date,
            data={
                "total_income": float(total_income),
                "total_expense": float(total_expense),
                "net": float(total_income - total_expense),
                "by_category": {k: float(v) for k, v in by_category.items()},
                "transaction_count": len(transactions),
                "is_read_only": True  # CANON marker
            },
            generated_by=user_id
        )
        
        self.reports[report.id] = report
        
        return report
    
    async def generate_net_worth_report(self, user_id: str) -> FinancialReport:
        """Generate net worth report (read-only)."""
        accounts = [a for a in self.accounts.values() if a.created_by == user_id]
        
        assets = Decimal("0.00")
        liabilities = Decimal("0.00")
        
        for account in accounts:
            if account.account_type in [AccountType.CHECKING, AccountType.SAVINGS, 
                                         AccountType.INVESTMENT, AccountType.CASH]:
                assets += account.balance
            elif account.account_type in [AccountType.CREDIT_CARD, AccountType.LOAN]:
                liabilities += abs(account.balance)
        
        # Add investments
        investments = [i for i in self.investments.values() if i.created_by == user_id]
        investment_value = sum(
            i.quantity * (i.current_price or i.purchase_price) 
            for i in investments
        )
        assets += investment_value
        
        report = FinancialReport(
            id=uuid4(),
            report_type="net_worth",
            period_start=datetime.now(timezone.utc),
            period_end=datetime.now(timezone.utc),
            data={
                "assets": float(assets),
                "liabilities": float(liabilities),
                "net_worth": float(assets - liabilities),
                "investment_value": float(investment_value),
                "account_count": len(accounts),
                "is_read_only": True  # CANON marker
            },
            generated_by=user_id
        )
        
        self.reports[report.id] = report
        
        return report
    
    # ═══════════════════════════════════════════════════════════════════════════
    # HEALTH CHECK
    # ═══════════════════════════════════════════════════════════════════════════
    
    async def get_health(self) -> Dict[str, Any]:
        """Get agent health status."""
        return {
            "status": "healthy",
            "agent": "FinanceAgent",
            "version": "V68",
            "accounts": len(self.accounts),
            "transactions": len(self.transactions),
            "budgets": len(self.budgets),
            "goals": len(self.goals),
            "investments": len(self.investments),
            "pending_checkpoints": len([
                c for c in self.checkpoints.values() if c.approved is None
            ]),
            "canon_compliant": True
        }


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import asyncio
    
    async def test():
        agent = FinanceAgent()
        
        # Create account
        account = await agent.create_account(
            name="Checking",
            account_type=AccountType.CHECKING,
            currency="CAD",
            user_id="user_001",
            initial_balance=Decimal("5000.00")
        )
        print(f"✅ Account created: {account.name}")
        
        # Create transaction (DRAFT)
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("150.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Groceries",
            user_id="user_001"
        )
        print(f"✅ Transaction DRAFT: {tx.status.value}")
        
        # Submit for approval
        tx, checkpoint = await agent.submit_transaction_for_approval(tx.id, "user_001")
        print(f"✅ Transaction PENDING: {tx.status.value}")
        
        # Approve
        tx = await agent.approve_transaction(tx.id, "user_001")
        print(f"✅ Transaction APPROVED: {tx.status.value}")
        
        # Execute
        tx = await agent.execute_transaction(tx.id, "user_001")
        print(f"✅ Transaction COMPLETED: {tx.status.value}")
        
        # Check balance
        account = await agent.get_account(account.id)
        print(f"✅ New balance: {account.balance}")
        
        # Health check
        health = await agent.get_health()
        print(f"✅ Health: {health['status']}")
        
        print("\n🎉 All tests passed!")
    
    asyncio.run(test())
