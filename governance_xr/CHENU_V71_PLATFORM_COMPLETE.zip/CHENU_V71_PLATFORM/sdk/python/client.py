"""
CHE·NU™ V70 — PYTHON SDK CLIENT
===============================
Client SDK for GP2 API integration.

Usage:
    from sdk import ChenuClient
    
    client = ChenuClient("http://localhost:8000", api_key="...")
    result = await client.nova.validate("simulate market")

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional
import asyncio
import logging

logger = logging.getLogger("chenu.sdk")


# =============================================================================
# EXCEPTIONS
# =============================================================================

class ChenuError(Exception):
    """Base exception for CHE·NU SDK."""
    pass


class AuthenticationError(ChenuError):
    """Authentication failed."""
    pass


class GovernanceError(ChenuError):
    """Governance violation."""
    pass


class APIError(ChenuError):
    """API request failed."""
    
    def __init__(self, status_code: int, message: str, details: dict = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(f"[{status_code}] {message}")


# =============================================================================
# RESPONSE MODELS
# =============================================================================

@dataclass
class NovaResponse:
    """Response from NOVA validation."""
    success: bool
    request_id: str
    validation_result: dict
    is_refusal: bool = False
    refusal_reason: Optional[str] = None
    governance: dict = field(default_factory=dict)


@dataclass
class EthicsResponse:
    """Response from ethics validation."""
    success: bool
    is_valid: bool
    violations: list[str] = field(default_factory=list)
    forbidden_state: Optional[str] = None


@dataclass
class DecisionResponse:
    """Response from decision loop."""
    success: bool
    package_id: str
    simulation_id: str
    causal_trace_id: str
    xr_scene_id: str
    options: list[dict] = field(default_factory=list)
    requires_hitl: bool = True


@dataclass
class HealthResponse:
    """Health check response."""
    status: str
    version: str
    components: dict = field(default_factory=dict)
    governance: dict = field(default_factory=dict)


# =============================================================================
# HTTP CLIENT
# =============================================================================

class HTTPClient:
    """Async HTTP client wrapper."""
    
    def __init__(
        self,
        base_url: str,
        api_key: Optional[str] = None,
        timeout: int = 30,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client = None
    
    async def _get_client(self):
        """Get or create httpx client."""
        if self._client is None:
            import httpx
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=self.timeout,
            )
        return self._client
    
    def _get_headers(self) -> dict:
        """Get request headers."""
        headers = {
            "Content-Type": "application/json",
            "X-Client": "chenu-sdk-python",
            "X-SDK-Version": "70.0.0",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    async def get(self, path: str, params: dict = None) -> dict:
        """Make GET request."""
        client = await self._get_client()
        response = await client.get(
            path,
            params=params,
            headers=self._get_headers(),
        )
        return self._handle_response(response)
    
    async def post(self, path: str, data: dict = None) -> dict:
        """Make POST request."""
        client = await self._get_client()
        response = await client.post(
            path,
            json=data,
            headers=self._get_headers(),
        )
        return self._handle_response(response)
    
    def _handle_response(self, response) -> dict:
        """Handle API response."""
        if response.status_code == 401:
            raise AuthenticationError("Invalid or expired token")
        
        if response.status_code == 403:
            data = response.json()
            raise GovernanceError(data.get("message", "Governance violation"))
        
        if response.status_code >= 400:
            data = response.json()
            raise APIError(
                status_code=response.status_code,
                message=data.get("message", "Request failed"),
                details=data,
            )
        
        return response.json()
    
    async def close(self):
        """Close the client."""
        if self._client:
            await self._client.aclose()
            self._client = None


# =============================================================================
# NOVA CLIENT
# =============================================================================

class NovaClient:
    """Client for NOVA kernel operations."""
    
    def __init__(self, http: HTTPClient):
        self._http = http
    
    async def validate(
        self,
        intent: str,
        context: dict = None,
    ) -> NovaResponse:
        """Validate intent through NOVA."""
        data = await self._http.post("/api/v1/nova/validate", {
            "intent": intent,
            "context": context or {},
        })
        
        return NovaResponse(
            success=data.get("success", False),
            request_id=data.get("request_id", ""),
            validation_result=data.get("validation_result", {}),
            is_refusal=data.get("is_refusal", False),
            refusal_reason=data.get("refusal_reason"),
            governance=data.get("governance", {}),
        )
    
    async def compliance_status(self) -> dict:
        """Get NOVA compliance status."""
        return await self._http.get("/api/v1/nova/compliance")


# =============================================================================
# ETHICS CLIENT
# =============================================================================

class EthicsClient:
    """Client for ethics canon operations."""
    
    def __init__(self, http: HTTPClient):
        self._http = http
    
    async def validate(
        self,
        action: str,
        actor_type: str = "system_intelligence",
    ) -> EthicsResponse:
        """Validate action against ethics canon."""
        data = await self._http.post("/api/v1/ethics/validate", {
            "action_description": action,
            "actor_type": actor_type,
        })
        
        return EthicsResponse(
            success=data.get("success", False),
            is_valid=data.get("is_valid", False),
            violations=data.get("violations", []),
            forbidden_state=data.get("forbidden_state"),
        )
    
    async def get_canon(self) -> dict:
        """Get the Master Ethics Canon."""
        return await self._http.get("/api/v1/ethics/canon")


# =============================================================================
# CIVILIZATION CLIENT
# =============================================================================

class CivilizationClient:
    """Client for Civilization OS operations."""
    
    def __init__(self, http: HTTPClient):
        self._http = http
    
    async def decision_loop(
        self,
        intent: str,
        initial_state: dict = None,
        cycles: int = 10,
    ) -> DecisionResponse:
        """Execute decision loop."""
        data = await self._http.post("/api/v1/civilization/decision-loop", {
            "user_intent": intent,
            "initial_state": initial_state or {},
            "simulation_cycles": cycles,
        })
        
        return DecisionResponse(
            success=data.get("success", False),
            package_id=data.get("package_id", ""),
            simulation_id=data.get("simulation_id", ""),
            causal_trace_id=data.get("causal_trace_id", ""),
            xr_scene_id=data.get("xr_scene_id", ""),
            options=data.get("options", []),
            requires_hitl=data.get("requires_hitl", True),
        )
    
    async def approve(
        self,
        package_id: str,
        selected_option: int = None,
        comments: str = None,
    ) -> dict:
        """Approve decision package (HITL)."""
        return await self._http.post(f"/api/v1/civilization/approve/{package_id}", {
            "selected_option": selected_option,
            "comments": comments,
        })


# =============================================================================
# FAILSAFE CLIENT
# =============================================================================

class FailsafeClient:
    """Client for failsafe operations."""
    
    def __init__(self, http: HTTPClient):
        self._http = http
    
    async def check(self, indicators: dict = None) -> dict:
        """Check crisis indicators."""
        return await self._http.post("/api/v1/failsafe/check", {
            "indicators": indicators or {},
        })
    
    async def activate(self, level: str, reason: str = "") -> dict:
        """Activate failsafe level."""
        return await self._http.post(f"/api/v1/failsafe/activate/{level}", {
            "reason": reason,
        })


# =============================================================================
# MAIN CLIENT
# =============================================================================

class ChenuClient:
    """
    CHE·NU GP2 SDK Client.
    
    Usage:
        async with ChenuClient("http://localhost:8000", api_key="...") as client:
            result = await client.nova.validate("simulate scenario")
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: Optional[str] = None,
        timeout: int = 30,
    ):
        self._http = HTTPClient(base_url, api_key, timeout)
        
        # Sub-clients
        self.nova = NovaClient(self._http)
        self.ethics = EthicsClient(self._http)
        self.civilization = CivilizationClient(self._http)
        self.failsafe = FailsafeClient(self._http)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
    
    async def close(self):
        """Close the client."""
        await self._http.close()
    
    # =========================================================================
    # HEALTH
    # =========================================================================
    
    async def health(self) -> HealthResponse:
        """Check system health."""
        data = await self._http.get("/health")
        
        return HealthResponse(
            status=data.get("status", "unknown"),
            version=data.get("version", ""),
            components=data.get("components", {}),
            governance=data.get("governance", {}),
        )
    
    async def info(self) -> dict:
        """Get system info."""
        return await self._http.get("/info")
    
    # =========================================================================
    # AUTH
    # =========================================================================
    
    async def login(self, username: str, password: str) -> dict:
        """Login and get tokens."""
        return await self._http.post("/api/v1/auth/login", {
            "username": username,
            "password": password,
        })
    
    async def refresh_token(self, refresh_token: str) -> dict:
        """Refresh access token."""
        return await self._http.post("/api/v1/auth/refresh", {
            "refresh_token": refresh_token,
        })


# =============================================================================
# SYNC WRAPPER
# =============================================================================

class ChenuClientSync:
    """
    Synchronous wrapper for ChenuClient.
    
    Usage:
        client = ChenuClientSync("http://localhost:8000")
        result = client.nova.validate("simulate scenario")
    """
    
    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: Optional[str] = None,
    ):
        self._async_client = ChenuClient(base_url, api_key)
        self._loop = None
    
    def _get_loop(self):
        if self._loop is None:
            try:
                self._loop = asyncio.get_event_loop()
            except RuntimeError:
                self._loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._loop)
        return self._loop
    
    def _run(self, coro):
        return self._get_loop().run_until_complete(coro)
    
    @property
    def nova(self) -> "SyncNovaClient":
        return SyncNovaClient(self._async_client.nova, self._run)
    
    @property
    def ethics(self) -> "SyncEthicsClient":
        return SyncEthicsClient(self._async_client.ethics, self._run)
    
    @property
    def civilization(self) -> "SyncCivilizationClient":
        return SyncCivilizationClient(self._async_client.civilization, self._run)
    
    def health(self) -> HealthResponse:
        return self._run(self._async_client.health())
    
    def close(self):
        self._run(self._async_client.close())


class SyncNovaClient:
    def __init__(self, async_client, runner):
        self._async = async_client
        self._run = runner
    
    def validate(self, intent: str, context: dict = None) -> NovaResponse:
        return self._run(self._async.validate(intent, context))


class SyncEthicsClient:
    def __init__(self, async_client, runner):
        self._async = async_client
        self._run = runner
    
    def validate(self, action: str, actor_type: str = "system_intelligence") -> EthicsResponse:
        return self._run(self._async.validate(action, actor_type))


class SyncCivilizationClient:
    def __init__(self, async_client, runner):
        self._async = async_client
        self._run = runner
    
    def decision_loop(self, intent: str, initial_state: dict = None, cycles: int = 10) -> DecisionResponse:
        return self._run(self._async.decision_loop(intent, initial_state, cycles))


# =============================================================================
# CONVENIENCE
# =============================================================================

def create_client(
    base_url: str = "http://localhost:8000",
    api_key: Optional[str] = None,
    sync: bool = False,
):
    """Create a CHE·NU client."""
    if sync:
        return ChenuClientSync(base_url, api_key)
    return ChenuClient(base_url, api_key)
