"""
CHE·NU™ Cache & Performance Module
===================================

Comprehensive caching and performance monitoring for CHE·NU.

Components:
- CacheService: Redis-backed caching with TTL, tags, invalidation
- ResponseCacheMiddleware: FastAPI response caching
- QueryProfiler: Database query optimization
- PerformanceMonitor: System performance monitoring

Author: CHE·NU Backend Team
Version: 1.0.0
"""

from .cache_service import (
    CacheService,
    CacheStrategy,
    CacheRegion,
    CacheEntry,
    CacheStats,
    CacheKeyBuilder,
    cache_service,
    cached,
    cache_invalidate,
    REGION_TTLS,
)

from .query_optimizer import (
    QueryProfiler,
    QueryProfile,
    QueryStats as QueryOptimizerStats,
    QueryComplexity,
    NPlusOneDetector,
    BatchLoader,
    IndexAnalyzer,
    IndexRecommendation,
    query_profiler,
    index_analyzer,
    optimized_query,
    with_eager_loading,
    setup_query_profiling,
)

from .performance_monitor import (
    PerformanceMonitor,
    HealthStatus,
    HealthCheck,
    MetricType,
    TimingMetric,
    Histogram,
    Counter,
    Gauge,
    performance_monitor,
    database_health_check,
    redis_health_check,
    cache_health_check,
    create_performance_middleware,
)


__all__ = [
    # Cache Service
    "CacheService",
    "CacheStrategy",
    "CacheRegion",
    "CacheEntry",
    "CacheStats",
    "CacheKeyBuilder",
    "cache_service",
    "cached",
    "cache_invalidate",
    "REGION_TTLS",
    
    # Query Optimizer
    "QueryProfiler",
    "QueryProfile",
    "QueryOptimizerStats",
    "QueryComplexity",
    "NPlusOneDetector",
    "BatchLoader",
    "IndexAnalyzer",
    "IndexRecommendation",
    "query_profiler",
    "index_analyzer",
    "optimized_query",
    "with_eager_loading",
    "setup_query_profiling",
    
    # Performance Monitor
    "PerformanceMonitor",
    "HealthStatus",
    "HealthCheck",
    "MetricType",
    "TimingMetric",
    "Histogram",
    "Counter",
    "Gauge",
    "performance_monitor",
    "database_health_check",
    "redis_health_check",
    "cache_health_check",
    "create_performance_middleware",
]
