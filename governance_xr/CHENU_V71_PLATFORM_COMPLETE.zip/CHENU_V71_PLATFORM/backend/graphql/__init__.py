"""
CHE·NU™ V70 — GRAPHQL PACKAGE
=============================
GraphQL API for GP2.
"""

from .schema import schema, create_graphql_router

__all__ = ["schema", "create_graphql_router"]

__version__ = "70.0.0"
