"""
CHE·NU™ V72 — Response Caching Middleware

FastAPI middleware for automatic response caching with:
- ETag generation and validation
- Conditional requests (If-None-Match, If-Modified-Since)
- Identity-scoped cache headers
- Governance-aware cache control

R&D Compliance:
- Rule #1: No caching of pending checkpoints (HTTP 423)
- Rule #3: Identity-scoped cache keys
- Rule #6: Cache events logged
"""

from typing import Optional, Callable, Dict, Any, List, Set
from datetime import datetime, timedelta
from uuid import UUID
import hashlib
import json
import logging
from functools import wraps

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.datastructures import MutableHeaders

logger = logging.getLogger(__name__)


# ==================== Cache Control Headers ====================

class CacheControl:
    """HTTP Cache-Control header builder."""
    
    def __init__(self):
        self.directives: List[str] = []
    
    def private(self) -> 'CacheControl':
        """Mark as private (identity-scoped)."""
        self.directives.append("private")
        return self
    
    def public(self) -> 'CacheControl':
        """Mark as public (shared cache)."""
        self.directives.append("public")
        return self
    
    def no_cache(self) -> 'CacheControl':
        """Require validation on each request."""
        self.directives.append("no-cache")
        return self
    
    def no_store(self) -> 'CacheControl':
        """Never cache (sensitive data)."""
        self.directives.append("no-store")
        return self
    
    def max_age(self, seconds: int) -> 'CacheControl':
        """Set max-age directive."""
        self.directives.append(f"max-age={seconds}")
        return self
    
    def s_maxage(self, seconds: int) -> 'CacheControl':
        """Set s-maxage for shared caches."""
        self.directives.append(f"s-maxage={seconds}")
        return self
    
    def must_revalidate(self) -> 'CacheControl':
        """Must revalidate after expiry."""
        self.directives.append("must-revalidate")
        return self
    
    def stale_while_revalidate(self, seconds: int) -> 'CacheControl':
        """Serve stale while revalidating in background."""
        self.directives.append(f"stale-while-revalidate={seconds}")
        return self
    
    def immutable(self) -> 'CacheControl':
        """Mark as immutable (won't change)."""
        self.directives.append("immutable")
        return self
    
    def build(self) -> str:
        """Build the header value."""
        return ", ".join(self.directives)


# ==================== Cache Profiles ====================

class CacheProfile:
    """Predefined cache profiles for different resource types."""
    
    # Identity-scoped, short TTL (user data)
    PRIVATE_SHORT = CacheControl().private().max_age(60).must_revalidate().build()
    
    # Identity-scoped, medium TTL (thread data)
    PRIVATE_MEDIUM = CacheControl().private().max_age(300).must_revalidate().build()
    
    # Identity-scoped, long TTL (immutable events)
    PRIVATE_LONG = CacheControl().private().max_age(3600).immutable().build()
    
    # No caching (checkpoints, real-time)
    NO_CACHE = CacheControl().no_store().no_cache().build()
    
    # Public resources (schema, docs)
    PUBLIC_LONG = CacheControl().public().max_age(86400).build()
    
    # Static assets
    STATIC = CacheControl().public().max_age(31536000).immutable().build()


# ==================== ETag Generation ====================

def generate_etag(content: Any, weak: bool = False) -> str:
    """
    Generate ETag for content.
    
    Args:
        content: Content to hash
        weak: If True, generate weak ETag
    
    Returns:
        ETag header value
    """
    if isinstance(content, (dict, list)):
        content_str = json.dumps(content, sort_keys=True, default=str)
    else:
        content_str = str(content)
    
    # Create hash
    hash_value = hashlib.md5(content_str.encode()).hexdigest()[:16]
    
    if weak:
        return f'W/"{hash_value}"'
    return f'"{hash_value}"'


def validate_etag(request_etag: str, current_etag: str) -> bool:
    """
    Validate If-None-Match header against current ETag.
    
    Args:
        request_etag: ETag from request header
        current_etag: Current resource ETag
    
    Returns:
        True if ETags match (304 Not Modified)
    """
    if not request_etag:
        return False
    
    # Handle multiple ETags in header
    request_etags = [e.strip() for e in request_etag.split(",")]
    
    for etag in request_etags:
        # Handle weak comparison
        normalized = etag.replace('W/', '')
        current_normalized = current_etag.replace('W/', '')
        
        if normalized == current_normalized:
            return True
    
    return False


# ==================== Route Configuration ====================

class CacheableRoute:
    """Configuration for a cacheable route."""
    
    def __init__(
        self,
        path_pattern: str,
        methods: Set[str],
        cache_control: str,
        vary_on: Optional[List[str]] = None,
        etag_enabled: bool = True,
        identity_scoped: bool = True,
        exclude_status_codes: Optional[Set[int]] = None
    ):
        self.path_pattern = path_pattern
        self.methods = methods
        self.cache_control = cache_control
        self.vary_on = vary_on or ["Authorization"]
        self.etag_enabled = etag_enabled
        self.identity_scoped = identity_scoped
        self.exclude_status_codes = exclude_status_codes or {400, 401, 403, 404, 423, 500}


# Default cache configurations for CHE·NU routes
DEFAULT_CACHE_ROUTES = [
    # Threads (identity-scoped)
    CacheableRoute(
        "/api/v2/threads",
        {"GET"},
        CacheProfile.PRIVATE_SHORT,
        vary_on=["Authorization"]
    ),
    CacheableRoute(
        "/api/v2/threads/{thread_id}",
        {"GET"},
        CacheProfile.PRIVATE_MEDIUM,
        vary_on=["Authorization"]
    ),
    CacheableRoute(
        "/api/v2/threads/{thread_id}/events",
        {"GET"},
        CacheProfile.PRIVATE_LONG,  # Events are immutable
        vary_on=["Authorization"]
    ),
    
    # Spheres (identity-scoped)
    CacheableRoute(
        "/api/v2/spheres",
        {"GET"},
        CacheProfile.PRIVATE_MEDIUM,
        vary_on=["Authorization"]
    ),
    CacheableRoute(
        "/api/v2/spheres/{sphere_id}",
        {"GET"},
        CacheProfile.PRIVATE_MEDIUM,
        vary_on=["Authorization"]
    ),
    
    # Agents (longer cache - relatively static)
    CacheableRoute(
        "/api/v2/agents",
        {"GET"},
        CacheProfile.PRIVATE_MEDIUM,
        vary_on=["Authorization"]
    ),
    
    # XR Blueprints (medium cache)
    CacheableRoute(
        "/api/v2/xr/{thread_id}/blueprint",
        {"GET"},
        CacheProfile.PRIVATE_MEDIUM,
        vary_on=["Authorization"]
    ),
    
    # Health/Status (public, no auth)
    CacheableRoute(
        "/api/v2/health",
        {"GET"},
        CacheProfile.PUBLIC_LONG,
        identity_scoped=False,
        vary_on=[]
    ),
    
    # Checkpoints - NEVER cache
    CacheableRoute(
        "/api/v2/checkpoints",
        {"GET", "POST"},
        CacheProfile.NO_CACHE,
        etag_enabled=False
    ),
    
    # Nova - NEVER cache
    CacheableRoute(
        "/api/v2/nova",
        {"POST"},
        CacheProfile.NO_CACHE,
        etag_enabled=False
    ),
]


# ==================== Caching Middleware ====================

class ResponseCacheMiddleware(BaseHTTPMiddleware):
    """
    Middleware for automatic response caching.
    
    Features:
    - Automatic Cache-Control headers
    - ETag generation and validation
    - Conditional requests (304 Not Modified)
    - Identity-scoped caching
    - Governance-aware (no caching HTTP 423)
    """
    
    def __init__(
        self,
        app,
        cache_routes: Optional[List[CacheableRoute]] = None,
        default_cache_control: str = CacheProfile.NO_CACHE
    ):
        super().__init__(app)
        self.cache_routes = cache_routes or DEFAULT_CACHE_ROUTES
        self.default_cache_control = default_cache_control
        self._route_cache = self._build_route_cache()
    
    def _build_route_cache(self) -> Dict[str, CacheableRoute]:
        """Build lookup table for routes."""
        cache = {}
        for route in self.cache_routes:
            # Use simplified pattern matching
            cache[route.path_pattern] = route
        return cache
    
    def _find_route_config(self, path: str, method: str) -> Optional[CacheableRoute]:
        """Find matching cache configuration for a path."""
        for pattern, config in self._route_cache.items():
            if method not in config.methods:
                continue
            
            # Simple pattern matching (exact or prefix)
            if self._path_matches(path, pattern):
                return config
        
        return None
    
    def _path_matches(self, path: str, pattern: str) -> bool:
        """Check if path matches pattern with wildcards."""
        # Remove trailing slashes for comparison
        path = path.rstrip("/")
        pattern = pattern.rstrip("/")
        
        # Handle path parameters like {thread_id}
        path_parts = path.split("/")
        pattern_parts = pattern.split("/")
        
        if len(path_parts) != len(pattern_parts):
            return False
        
        for path_part, pattern_part in zip(path_parts, pattern_parts):
            if pattern_part.startswith("{") and pattern_part.endswith("}"):
                continue  # Wildcard match
            if path_part != pattern_part:
                return False
        
        return True
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with caching logic."""
        method = request.method
        path = request.url.path
        
        # Find cache configuration
        route_config = self._find_route_config(path, method)
        
        # Only cache GET requests by default
        if method != "GET" or not route_config:
            response = await call_next(request)
            # Add default no-cache headers for non-GET
            if method != "GET":
                response.headers["Cache-Control"] = CacheProfile.NO_CACHE
            return response
        
        # Check If-None-Match header for conditional request
        request_etag = request.headers.get("If-None-Match")
        
        # Call the actual endpoint
        response = await call_next(request)
        
        # Don't cache error responses or governance blocks
        if response.status_code in route_config.exclude_status_codes:
            response.headers["Cache-Control"] = CacheProfile.NO_CACHE
            return response
        
        # Add Cache-Control header
        response.headers["Cache-Control"] = route_config.cache_control
        
        # Add Vary header for proper cache key variation
        if route_config.vary_on:
            response.headers["Vary"] = ", ".join(route_config.vary_on)
        
        # Generate and add ETag if enabled
        if route_config.etag_enabled and response.status_code == 200:
            # Read response body for ETag generation
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            
            etag = generate_etag(body)
            response.headers["ETag"] = etag
            
            # Check for conditional request match
            if request_etag and validate_etag(request_etag, etag):
                # Return 304 Not Modified
                return Response(
                    status_code=304,
                    headers={
                        "Cache-Control": route_config.cache_control,
                        "ETag": etag,
                        "Vary": ", ".join(route_config.vary_on) if route_config.vary_on else ""
                    }
                )
            
            # Return response with body (had to read it for ETag)
            return Response(
                content=body,
                status_code=response.status_code,
                headers=dict(response.headers),
                media_type=response.media_type
            )
        
        return response


# ==================== Cache Decorator ====================

def cache_response(
    cache_control: str = CacheProfile.PRIVATE_SHORT,
    etag: bool = True,
    vary_on: Optional[List[str]] = None
):
    """
    Decorator for explicit route-level cache control.
    
    Usage:
        @router.get("/threads")
        @cache_response(cache_control=CacheProfile.PRIVATE_MEDIUM)
        async def list_threads():
            ...
    """
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            result = await func(*args, **kwargs)
            
            # If result is a Response, add headers
            if isinstance(result, Response):
                result.headers["Cache-Control"] = cache_control
                if vary_on:
                    result.headers["Vary"] = ", ".join(vary_on)
                if etag and hasattr(result, "body"):
                    result.headers["ETag"] = generate_etag(result.body)
                return result
            
            # Create JSONResponse with cache headers
            response = JSONResponse(content=result)
            response.headers["Cache-Control"] = cache_control
            if vary_on:
                response.headers["Vary"] = ", ".join(vary_on)
            if etag:
                response.headers["ETag"] = generate_etag(result)
            return response
        
        return wrapper
    return decorator


def no_cache(func: Callable):
    """Decorator to explicitly disable caching for a route."""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        result = await func(*args, **kwargs)
        
        if isinstance(result, Response):
            result.headers["Cache-Control"] = CacheProfile.NO_CACHE
            return result
        
        response = JSONResponse(content=result)
        response.headers["Cache-Control"] = CacheProfile.NO_CACHE
        return response
    
    return wrapper


# ==================== Cache Invalidation ====================

class CacheInvalidator:
    """
    Service for cache invalidation via Surrogate-Key headers.
    
    Works with CDN/reverse proxy for targeted invalidation.
    """
    
    HEADER_NAME = "Surrogate-Key"
    
    @classmethod
    def add_keys(cls, response: Response, *keys: str) -> None:
        """Add surrogate keys to response for invalidation."""
        existing = response.headers.get(cls.HEADER_NAME, "")
        all_keys = set(existing.split()) | set(keys)
        response.headers[cls.HEADER_NAME] = " ".join(all_keys)
    
    @classmethod
    def thread_key(cls, thread_id: UUID) -> str:
        """Generate surrogate key for a Thread."""
        return f"thread-{thread_id}"
    
    @classmethod
    def sphere_key(cls, sphere_id: UUID) -> str:
        """Generate surrogate key for a Sphere."""
        return f"sphere-{sphere_id}"
    
    @classmethod
    def user_key(cls, user_id: UUID) -> str:
        """Generate surrogate key for a user."""
        return f"user-{user_id}"
    
    @classmethod
    def agent_key(cls, agent_id: str) -> str:
        """Generate surrogate key for an agent."""
        return f"agent-{agent_id}"


# ==================== Exports ====================

__all__ = [
    'CacheControl',
    'CacheProfile',
    'CacheableRoute',
    'ResponseCacheMiddleware',
    'cache_response',
    'no_cache',
    'generate_etag',
    'validate_etag',
    'CacheInvalidator',
    'DEFAULT_CACHE_ROUTES'
]
