#!/bin/bash
# ============================================================================
# CHE·NU Backend Docker Entrypoint
# 
# Purpose: Initialize and start the CHE·NU backend service
# 
# R&D COMPLIANCE: ✅
# - Rule #6: Full logging and traceability
# - Graceful shutdown handling
# - Health check validation before accepting traffic
# ============================================================================

set -e

# ============================================================================
# Configuration
# ============================================================================
CHENU_HOST="${CHENU_HOST:-0.0.0.0}"
CHENU_PORT="${CHENU_PORT:-8000}"
CHENU_ENV="${CHENU_ENV:-production}"
CHENU_LOG_LEVEL="${CHENU_LOG_LEVEL:-INFO}"
GUNICORN_WORKERS="${GUNICORN_WORKERS:-4}"
GUNICORN_THREADS="${GUNICORN_THREADS:-2}"
GUNICORN_TIMEOUT="${GUNICORN_TIMEOUT:-120}"
GUNICORN_GRACEFUL_TIMEOUT="${GUNICORN_GRACEFUL_TIMEOUT:-30}"
STARTUP_TIMEOUT="${STARTUP_TIMEOUT:-60}"

# ============================================================================
# Logging Functions
# ============================================================================
log_info() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [INFO] $1"
}

log_warn() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [WARN] $1" >&2
}

log_error() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR] $1" >&2
}

# ============================================================================
# Signal Handling (Graceful Shutdown)
# ============================================================================
shutdown_handler() {
    log_info "Received shutdown signal, initiating graceful shutdown..."
    
    # Send SIGTERM to gunicorn master process
    if [ -n "$GUNICORN_PID" ]; then
        log_info "Sending SIGTERM to Gunicorn (PID: $GUNICORN_PID)"
        kill -TERM "$GUNICORN_PID" 2>/dev/null || true
        
        # Wait for graceful shutdown
        local wait_count=0
        while [ $wait_count -lt $GUNICORN_GRACEFUL_TIMEOUT ]; do
            if ! kill -0 "$GUNICORN_PID" 2>/dev/null; then
                log_info "Gunicorn shut down gracefully"
                break
            fi
            sleep 1
            wait_count=$((wait_count + 1))
        done
        
        # Force kill if still running
        if kill -0 "$GUNICORN_PID" 2>/dev/null; then
            log_warn "Graceful shutdown timeout, forcing termination"
            kill -9 "$GUNICORN_PID" 2>/dev/null || true
        fi
    fi
    
    log_info "Shutdown complete"
    exit 0
}

trap shutdown_handler SIGTERM SIGINT SIGQUIT

# ============================================================================
# Pre-flight Checks
# ============================================================================
preflight_checks() {
    log_info "Running pre-flight checks..."
    
    # Check Python
    if ! command -v python &> /dev/null; then
        log_error "Python not found"
        exit 1
    fi
    log_info "✓ Python: $(python --version)"
    
    # Check required environment variables
    local required_vars=("DATABASE_URL")
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            log_error "Required environment variable $var is not set"
            exit 1
        fi
    done
    log_info "✓ Required environment variables set"
    
    # Check optional but recommended variables
    local recommended_vars=("JWT_SECRET_KEY" "REDIS_URL")
    for var in "${recommended_vars[@]}"; do
        if [ -z "${!var}" ]; then
            log_warn "Recommended environment variable $var is not set"
        fi
    done
    
    # Warn if using default JWT secret
    if [ "$JWT_SECRET_KEY" = "dev_secret_key_change_in_production" ] && [ "$CHENU_ENV" = "production" ]; then
        log_error "SECURITY WARNING: Using default JWT secret in production!"
        if [ "${ALLOW_DEFAULT_SECRET:-false}" != "true" ]; then
            exit 1
        fi
    fi
    
    log_info "✓ Pre-flight checks passed"
}

# ============================================================================
# Wait for Dependencies
# ============================================================================
wait_for_postgres() {
    log_info "Waiting for PostgreSQL..."
    
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if python -c "
import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
import os

async def check():
    engine = create_async_engine(os.environ['DATABASE_URL'])
    async with engine.begin() as conn:
        await conn.execute('SELECT 1')
    await engine.dispose()
    return True

asyncio.run(check())
" 2>/dev/null; then
            log_info "✓ PostgreSQL is ready"
            return 0
        fi
        
        attempt=$((attempt + 1))
        log_info "PostgreSQL not ready, retrying ($attempt/$max_attempts)..."
        sleep 2
    done
    
    log_error "Failed to connect to PostgreSQL after $max_attempts attempts"
    exit 1
}

wait_for_redis() {
    if [ -z "$REDIS_URL" ]; then
        log_info "REDIS_URL not set, skipping Redis check"
        return 0
    fi
    
    log_info "Waiting for Redis..."
    
    local max_attempts=15
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if python -c "
import redis
import os
from urllib.parse import urlparse

url = urlparse(os.environ['REDIS_URL'])
r = redis.Redis(host=url.hostname, port=url.port or 6379)
r.ping()
" 2>/dev/null; then
            log_info "✓ Redis is ready"
            return 0
        fi
        
        attempt=$((attempt + 1))
        log_info "Redis not ready, retrying ($attempt/$max_attempts)..."
        sleep 1
    done
    
    log_warn "Could not connect to Redis, continuing without cache"
}

# ============================================================================
# Database Migrations
# ============================================================================
run_migrations() {
    if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
        log_info "Running database migrations..."
        
        cd /app
        if alembic upgrade head; then
            log_info "✓ Migrations completed successfully"
        else
            log_error "Migrations failed"
            exit 1
        fi
    else
        log_info "Skipping migrations (RUN_MIGRATIONS not set to true)"
    fi
}

# ============================================================================
# Start Application
# ============================================================================
start_gunicorn() {
    log_info "Starting CHE·NU Backend..."
    log_info "  Environment: $CHENU_ENV"
    log_info "  Host: $CHENU_HOST"
    log_info "  Port: $CHENU_PORT"
    log_info "  Workers: $GUNICORN_WORKERS"
    log_info "  Threads: $GUNICORN_THREADS"
    log_info "  Timeout: $GUNICORN_TIMEOUT"
    log_info "  Log Level: $CHENU_LOG_LEVEL"
    
    cd /app
    
    # Build gunicorn command
    local cmd="gunicorn backend.api.main:app"
    cmd="$cmd --bind $CHENU_HOST:$CHENU_PORT"
    cmd="$cmd --workers $GUNICORN_WORKERS"
    cmd="$cmd --threads $GUNICORN_THREADS"
    cmd="$cmd --timeout $GUNICORN_TIMEOUT"
    cmd="$cmd --graceful-timeout $GUNICORN_GRACEFUL_TIMEOUT"
    cmd="$cmd --worker-class uvicorn.workers.UvicornWorker"
    cmd="$cmd --log-level ${CHENU_LOG_LEVEL,,}"  # lowercase
    cmd="$cmd --access-logfile -"
    cmd="$cmd --error-logfile -"
    cmd="$cmd --capture-output"
    cmd="$cmd --enable-stdio-inheritance"
    
    # Add max requests for memory leak protection
    if [ -n "$GUNICORN_MAX_REQUESTS" ]; then
        cmd="$cmd --max-requests $GUNICORN_MAX_REQUESTS"
        cmd="$cmd --max-requests-jitter ${GUNICORN_MAX_REQUESTS_JITTER:-50}"
    fi
    
    # Add preload for faster worker startup
    if [ "${GUNICORN_PRELOAD:-false}" = "true" ]; then
        cmd="$cmd --preload"
    fi
    
    # Start gunicorn in background to capture PID
    log_info "Executing: $cmd"
    exec $cmd &
    GUNICORN_PID=$!
    
    # Wait for startup
    log_info "Waiting for application to start (PID: $GUNICORN_PID)..."
    local wait_count=0
    while [ $wait_count -lt $STARTUP_TIMEOUT ]; do
        if curl -sf "http://localhost:$CHENU_PORT/health" > /dev/null 2>&1; then
            log_info "✓ Application is healthy and ready to accept traffic"
            break
        fi
        
        # Check if process died
        if ! kill -0 "$GUNICORN_PID" 2>/dev/null; then
            log_error "Application process died during startup"
            exit 1
        fi
        
        sleep 1
        wait_count=$((wait_count + 1))
    done
    
    if [ $wait_count -ge $STARTUP_TIMEOUT ]; then
        log_error "Application failed to start within $STARTUP_TIMEOUT seconds"
        exit 1
    fi
    
    log_info "=========================================="
    log_info "  CHE·NU Backend Started Successfully"
    log_info "  Listening on: http://$CHENU_HOST:$CHENU_PORT"
    log_info "  API Docs: http://$CHENU_HOST:$CHENU_PORT/docs"
    log_info "  Health: http://$CHENU_HOST:$CHENU_PORT/health"
    log_info "=========================================="
    
    # Wait for gunicorn to exit
    wait $GUNICORN_PID
}

start_uvicorn_dev() {
    log_info "Starting CHE·NU Backend (Development Mode)..."
    log_info "  Host: $CHENU_HOST"
    log_info "  Port: $CHENU_PORT"
    log_info "  Hot Reload: Enabled"
    
    cd /app
    
    exec uvicorn backend.api.main:app \
        --host "$CHENU_HOST" \
        --port "$CHENU_PORT" \
        --reload \
        --reload-dir /app/backend \
        --log-level "${CHENU_LOG_LEVEL,,}"
}

# ============================================================================
# Main
# ============================================================================
main() {
    log_info "=========================================="
    log_info "  CHE·NU Backend Entrypoint"
    log_info "  Version: $(cat /app/VERSION 2>/dev/null || echo 'unknown')"
    log_info "  Environment: $CHENU_ENV"
    log_info "=========================================="
    
    # Run pre-flight checks
    preflight_checks
    
    # Wait for dependencies
    wait_for_postgres
    wait_for_redis
    
    # Run migrations if enabled
    run_migrations
    
    # Start application based on environment
    if [ "$CHENU_ENV" = "development" ]; then
        start_uvicorn_dev
    else
        start_gunicorn
    fi
}

# Handle custom commands (e.g., docker exec ... bash)
if [ "$1" = "bash" ] || [ "$1" = "sh" ]; then
    exec "$@"
elif [ "$1" = "python" ]; then
    exec "$@"
elif [ "$1" = "alembic" ]; then
    cd /app
    exec "$@"
elif [ "$1" = "pytest" ]; then
    cd /app
    exec "$@"
elif [ -n "$1" ]; then
    exec "$@"
else
    main
fi
