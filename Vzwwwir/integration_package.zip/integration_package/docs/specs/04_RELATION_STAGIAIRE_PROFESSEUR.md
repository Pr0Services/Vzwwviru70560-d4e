# 04 — Relation Stagiaire ↔ Professeur

## Stagiaire
- Curiosité
- Passif
- Observe les conversations
- Élimine le bruit

## Professeur
- Intention
- Actif par cycle
- Observe le système
- Empêche la dérive

## Boucle saine
1. Le stagiaire détecte
2. Le signal est promu
3. Le professeur intervient
4. Le système se stabilise
5. Le stagiaire observe à nouveau
