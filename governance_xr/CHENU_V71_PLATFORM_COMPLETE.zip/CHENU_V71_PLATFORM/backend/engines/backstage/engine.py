"""
CHE·NU™ V70 — BACKSTAGE INTELLIGENCE ENGINE
============================================
Invisible cognitive layer for background operations.

Based on: BACKSTAGE_INTELLIGENCE_CHAPTER.md (Chapters 109-118)

Backstage Intelligence is NOT an agent that users interact with directly.
It is the foundational intelligence infrastructure that makes all other
CHE·NU components more effective.

Behavioral Principles:
- Predictability: Consistent and predictable operations
- Invisibility: Normal operations occur without user awareness
- Safety-First: Errs on the side of caution
- Governance Compliance: Respects all governance rules

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
from uuid import uuid4
import logging
import re

logger = logging.getLogger("chenu.backstage")


# =============================================================================
# ENUMS
# =============================================================================

class AnalysisType(str, Enum):
    """Types of backstage analysis."""
    SPHERE_DETECTION = "sphere_detection"
    DOMAIN_DETECTION = "domain_detection"
    INTENT_EXTRACTION = "intent_extraction"
    ENTITY_DETECTION = "entity_detection"
    CLASSIFICATION = "classification"
    SAFETY_CHECK = "safety_check"


class ClassificationType(str, Enum):
    """Content classification types."""
    DOCUMENT = "document"
    TASK = "task"
    MEDIA = "media"
    XR_OBJECT = "xr_object"
    COMMUNICATION = "communication"


class SafetyLevel(str, Enum):
    """Safety check levels."""
    SAFE = "safe"
    CAUTION = "caution"
    REQUIRES_APPROVAL = "requires_approval"
    BLOCKED = "blocked"


# =============================================================================
# ANALYSIS MODELS
# =============================================================================

@dataclass
class ContextAnalysis:
    """Result of context analysis."""
    analysis_id: str = field(default_factory=lambda: f"CTX_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Detected context
    sphere: str = ""
    domain: str = ""
    identity_id: str = ""
    
    # Intent
    detected_intent: str = ""
    intent_confidence: float = 0.0
    
    # Related items
    related_threads: List[str] = field(default_factory=list)
    related_dataspaces: List[str] = field(default_factory=list)
    
    # Metadata
    analysis_type: AnalysisType = AnalysisType.SPHERE_DETECTION


@dataclass
class EntityDetection:
    """Detected entities from content."""
    detection_id: str = field(default_factory=lambda: f"ENT_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Detected entities
    projects: List[str] = field(default_factory=list)
    tasks: List[str] = field(default_factory=list)
    deadlines: List[Dict[str, Any]] = field(default_factory=list)
    people: List[str] = field(default_factory=list)
    properties: List[str] = field(default_factory=list)
    amounts: List[Dict[str, Any]] = field(default_factory=list)
    
    # Source
    source_text: str = ""


@dataclass
class Classification:
    """Content classification result."""
    classification_id: str = field(default_factory=lambda: f"CLS_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Classification
    content_type: ClassificationType = ClassificationType.DOCUMENT
    category: str = ""
    subcategory: str = ""
    
    # Domain
    detected_domain: str = ""
    domain_confidence: float = 0.0
    
    # Target
    suggested_dataspace: Optional[str] = None
    suggested_tags: List[str] = field(default_factory=list)


@dataclass
class SafetyCheck:
    """Safety check result."""
    check_id: str = field(default_factory=lambda: f"SAFE_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Result
    level: SafetyLevel = SafetyLevel.SAFE
    
    # Details
    checks_performed: List[str] = field(default_factory=list)
    issues_found: List[str] = field(default_factory=list)
    
    # Governance
    requires_hitl: bool = False
    blocked_reason: Optional[str] = None


@dataclass
class PreparedContent:
    """Content prepared by backstage."""
    content_id: str = field(default_factory=lambda: f"PREP_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Original
    original_content: str = ""
    
    # Prepared
    normalized_text: str = ""
    extracted_metadata: Dict[str, Any] = field(default_factory=dict)
    summary: str = ""
    
    # Entities
    entities: Optional[EntityDetection] = None
    
    # Classification
    classification: Optional[Classification] = None
    
    # Safety
    safety_check: Optional[SafetyCheck] = None


# =============================================================================
# BACKSTAGE INTELLIGENCE ENGINE
# =============================================================================

class BackstageIntelligence:
    """
    CHE·NU Backstage Intelligence.
    
    The invisible cognitive layer that performs essential background
    operations without interrupting user flow.
    
    Core Responsibilities:
    - Context Analysis
    - Data Preparation
    - Classification
    - Routing
    - Safety Validation
    - Optimization
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        # Domain patterns
        self._domain_patterns: Dict[str, List[str]] = {
            "construction": [
                r"contractor", r"building", r"renovation", r"punch.?list",
                r"rfi", r"change.?order", r"subcontractor", r"blueprint"
            ],
            "finance": [
                r"budget", r"revenue", r"expense", r"profit", r"cash.?flow",
                r"investment", r"forecast", r"financial"
            ],
            "immobilier": [
                r"property", r"tenant", r"lease", r"rent", r"landlord",
                r"unit", r"building", r"occupancy", r"bail"
            ],
            "architecture": [
                r"design", r"architect", r"floor.?plan", r"elevation",
                r"rendering", r"specification"
            ],
            "legal": [
                r"contract", r"agreement", r"clause", r"liability",
                r"compliance", r"legal"
            ],
        }
        
        # Sphere patterns
        self._sphere_patterns: Dict[str, List[str]] = {
            "personal": [r"my", r"personal", r"home", r"family"],
            "enterprise": [r"company", r"business", r"team", r"project"],
            "creative": [r"design", r"create", r"art", r"content"],
            "scholar": [r"research", r"study", r"learn", r"academic"],
        }
        
        # Compile patterns
        self._compiled_domain = {
            domain: [re.compile(p, re.IGNORECASE) for p in patterns]
            for domain, patterns in self._domain_patterns.items()
        }
        self._compiled_sphere = {
            sphere: [re.compile(p, re.IGNORECASE) for p in patterns]
            for sphere, patterns in self._sphere_patterns.items()
        }
        
        logger.info("BackstageIntelligence initialized (invisible mode)")
    
    # =========================================================================
    # CONTEXT ANALYSIS
    # =========================================================================
    
    def analyze_context(
        self,
        content: str,
        current_sphere: Optional[str] = None,
        current_domain: Optional[str] = None,
    ) -> ContextAnalysis:
        """
        Analyze content context.
        
        Detects sphere, domain, and extracts intent.
        """
        analysis = ContextAnalysis()
        
        # Detect sphere
        analysis.sphere = self._detect_sphere(content, current_sphere)
        
        # Detect domain
        analysis.domain = self._detect_domain(content, current_domain)
        
        # Extract intent
        intent, confidence = self._extract_intent(content)
        analysis.detected_intent = intent
        analysis.intent_confidence = confidence
        
        logger.debug(
            f"Context analyzed: sphere={analysis.sphere}, "
            f"domain={analysis.domain}, intent={analysis.detected_intent}"
        )
        
        return analysis
    
    def _detect_sphere(
        self,
        content: str,
        current: Optional[str] = None,
    ) -> str:
        """Detect sphere from content."""
        scores: Dict[str, int] = {s: 0 for s in self._compiled_sphere}
        
        for sphere, patterns in self._compiled_sphere.items():
            for pattern in patterns:
                if pattern.search(content):
                    scores[sphere] += 1
        
        best = max(scores, key=scores.get)
        if scores[best] > 0:
            return best
        
        return current or "personal"
    
    def _detect_domain(
        self,
        content: str,
        current: Optional[str] = None,
    ) -> str:
        """Detect domain from content."""
        scores: Dict[str, int] = {d: 0 for d in self._compiled_domain}
        
        for domain, patterns in self._compiled_domain.items():
            for pattern in patterns:
                if pattern.search(content):
                    scores[domain] += 1
        
        best = max(scores, key=scores.get)
        if scores[best] > 0:
            return best
        
        return current or "general"
    
    def _extract_intent(self, content: str) -> Tuple[str, float]:
        """Extract intent from content."""
        content_lower = content.lower()
        
        intent_patterns = [
            (r"create|make|build|start", "create", 0.7),
            (r"find|search|look for", "search", 0.7),
            (r"edit|modify|change|update", "edit", 0.7),
            (r"delete|remove|cancel", "delete", 0.7),
            (r"send|share|distribute", "share", 0.7),
            (r"analyze|review|check", "analyze", 0.6),
            (r"schedule|plan|organize", "plan", 0.6),
        ]
        
        for pattern, intent, confidence in intent_patterns:
            if re.search(pattern, content_lower):
                return intent, confidence
        
        return "unknown", 0.3
    
    # =========================================================================
    # ENTITY DETECTION
    # =========================================================================
    
    def detect_entities(self, content: str) -> EntityDetection:
        """
        Detect entities in content.
        
        Identifies projects, tasks, deadlines, people, properties, amounts.
        """
        detection = EntityDetection(source_text=content)
        
        # Detect people (simple pattern)
        people_pattern = r'\b([A-Z][a-z]+ [A-Z][a-z]+)\b'
        detection.people = list(set(re.findall(people_pattern, content)))
        
        # Detect amounts
        amount_pattern = r'\$[\d,]+(?:\.\d{2})?|\d+(?:,\d{3})*(?:\.\d{2})?\s*(?:dollars?|€|CAD|USD)'
        amounts = re.findall(amount_pattern, content)
        detection.amounts = [{"value": a, "currency": "detected"} for a in amounts]
        
        # Detect dates/deadlines
        date_pattern = r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b|\b(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}\b'
        dates = re.findall(date_pattern, content)
        detection.deadlines = [{"date": d} for d in dates]
        
        # Detect project mentions
        project_pattern = r'project\s+["\']?([^"\',.]+)["\']?'
        detection.projects = re.findall(project_pattern, content, re.IGNORECASE)
        
        # Detect task mentions
        task_pattern = r'task[s]?\s*:\s*([^.]+)'
        detection.tasks = re.findall(task_pattern, content, re.IGNORECASE)
        
        logger.debug(f"Entities detected: {len(detection.people)} people, {len(detection.amounts)} amounts")
        
        return detection
    
    # =========================================================================
    # CLASSIFICATION
    # =========================================================================
    
    def classify_content(
        self,
        content: str,
        filename: Optional[str] = None,
    ) -> Classification:
        """
        Classify content by type and domain.
        """
        classification = Classification()
        
        # Detect content type from filename
        if filename:
            ext = filename.split(".")[-1].lower() if "." in filename else ""
            type_map = {
                "pdf": ClassificationType.DOCUMENT,
                "docx": ClassificationType.DOCUMENT,
                "doc": ClassificationType.DOCUMENT,
                "xlsx": ClassificationType.DOCUMENT,
                "jpg": ClassificationType.MEDIA,
                "png": ClassificationType.MEDIA,
                "mp4": ClassificationType.MEDIA,
                "obj": ClassificationType.XR_OBJECT,
                "gltf": ClassificationType.XR_OBJECT,
            }
            classification.content_type = type_map.get(ext, ClassificationType.DOCUMENT)
        
        # Detect domain
        classification.detected_domain = self._detect_domain(content)
        classification.domain_confidence = 0.7
        
        # Suggest tags
        classification.suggested_tags = self._suggest_tags(content)
        
        return classification
    
    def _suggest_tags(self, content: str) -> List[str]:
        """Suggest tags for content."""
        tags = []
        content_lower = content.lower()
        
        tag_patterns = {
            "urgent": r"urgent|asap|immediately",
            "draft": r"draft|wip|working",
            "final": r"final|approved|completed",
            "review": r"review|feedback|check",
            "confidential": r"confidential|private|sensitive",
        }
        
        for tag, pattern in tag_patterns.items():
            if re.search(pattern, content_lower):
                tags.append(tag)
        
        return tags
    
    # =========================================================================
    # SAFETY VALIDATION
    # =========================================================================
    
    def check_safety(
        self,
        content: str,
        action: str = "unknown",
    ) -> SafetyCheck:
        """
        Perform safety check on content/action.
        
        Safety-First: When uncertain, err on the side of caution.
        """
        check = SafetyCheck()
        check.checks_performed = [
            "cross_identity_check",
            "pii_detection",
            "governance_compliance",
            "action_authorization",
        ]
        
        content_lower = content.lower()
        
        # Check for sensitive content
        sensitive_patterns = [
            (r"ssn|social.?security", "SSN detected"),
            (r"password|secret.?key", "Credentials detected"),
            (r"credit.?card|\d{16}", "Financial data detected"),
        ]
        
        for pattern, issue in sensitive_patterns:
            if re.search(pattern, content_lower):
                check.issues_found.append(issue)
                check.level = SafetyLevel.CAUTION
        
        # Check for actions requiring approval
        approval_actions = ["delete_all", "export", "share_external"]
        if action in approval_actions:
            check.requires_hitl = True
            check.level = SafetyLevel.REQUIRES_APPROVAL
        
        # Check for blocked actions
        blocked_patterns = [
            (r"override.?governance", "Governance override attempt"),
            (r"cross.?identity.?access", "Cross-identity access attempt"),
        ]
        
        for pattern, reason in blocked_patterns:
            if re.search(pattern, content_lower):
                check.level = SafetyLevel.BLOCKED
                check.blocked_reason = reason
                break
        
        if not check.issues_found and check.level == SafetyLevel.SAFE:
            logger.debug("Safety check passed")
        else:
            logger.warning(f"Safety check: {check.level.value} - {check.issues_found}")
        
        return check
    
    # =========================================================================
    # DATA PREPARATION
    # =========================================================================
    
    def prepare_content(
        self,
        content: str,
        filename: Optional[str] = None,
    ) -> PreparedContent:
        """
        Prepare content for processing.
        
        Normalizes, extracts metadata, summarizes, and validates.
        """
        prepared = PreparedContent(original_content=content)
        
        # Normalize text
        prepared.normalized_text = self._normalize_text(content)
        
        # Extract metadata
        prepared.extracted_metadata = self._extract_metadata(content, filename)
        
        # Generate summary
        prepared.summary = self._generate_summary(content)
        
        # Detect entities
        prepared.entities = self.detect_entities(content)
        
        # Classify
        prepared.classification = self.classify_content(content, filename)
        
        # Safety check
        prepared.safety_check = self.check_safety(content)
        
        logger.debug(f"Content prepared: {prepared.content_id}")
        
        return prepared
    
    def _normalize_text(self, text: str) -> str:
        """Normalize text formatting."""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        # Trim
        text = text.strip()
        return text
    
    def _extract_metadata(
        self,
        content: str,
        filename: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Extract metadata from content."""
        metadata = {
            "length": len(content),
            "word_count": len(content.split()),
            "has_numbers": bool(re.search(r'\d', content)),
            "has_urls": bool(re.search(r'https?://', content)),
        }
        
        if filename:
            metadata["filename"] = filename
            if "." in filename:
                metadata["extension"] = filename.split(".")[-1].lower()
        
        return metadata
    
    def _generate_summary(self, content: str, max_length: int = 200) -> str:
        """Generate brief summary."""
        # Simple extraction - first sentences
        sentences = re.split(r'[.!?]+', content)
        summary = ""
        
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            if len(summary) + len(sentence) < max_length:
                summary += sentence + ". "
            else:
                break
        
        return summary.strip()
    
    # =========================================================================
    # ROUTING
    # =========================================================================
    
    def suggest_route(
        self,
        content: str,
        context: Optional[ContextAnalysis] = None,
    ) -> Dict[str, Any]:
        """
        Suggest routing for content.
        
        Determines best destination based on analysis.
        """
        if not context:
            context = self.analyze_context(content)
        
        return {
            "suggested_sphere": context.sphere,
            "suggested_domain": context.domain,
            "suggested_dataspace": None,  # Would be determined by actual DataSpaces
            "related_threads": context.related_threads,
            "confidence": context.intent_confidence,
        }
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get backstage statistics."""
        return {
            "status": "invisible_mode",
            "domains_supported": list(self._domain_patterns.keys()),
            "spheres_supported": list(self._sphere_patterns.keys()),
            "capabilities": [
                "context_analysis",
                "entity_detection",
                "classification",
                "safety_validation",
                "data_preparation",
                "routing",
            ],
            "governance": {
                "safety_first": True,
                "governance_compliance": True,
                "no_autonomous_action": True,
                "invisible_operation": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_backstage_intelligence: Optional[BackstageIntelligence] = None


def get_backstage_intelligence() -> BackstageIntelligence:
    """Get the backstage intelligence singleton."""
    global _backstage_intelligence
    if _backstage_intelligence is None:
        _backstage_intelligence = BackstageIntelligence()
    return _backstage_intelligence
