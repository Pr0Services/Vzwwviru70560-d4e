#!/usr/bin/env python3
"""
CHE·NU™ Database Migration Script
=================================

Utility script for managing database migrations.

Usage:
    python run_migrations.py upgrade       # Apply all pending migrations
    python run_migrations.py downgrade     # Rollback last migration
    python run_migrations.py history       # Show migration history
    python run_migrations.py current       # Show current revision
    python run_migrations.py heads         # Show head revisions
    python run_migrations.py create NAME   # Create new migration
"""

import os
import sys
import subprocess
import argparse


def get_alembic_ini_path():
    """Get path to alembic.ini."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_dir, "alembic.ini")


def run_alembic(*args):
    """Run alembic command."""
    alembic_ini = get_alembic_ini_path()
    cmd = ["alembic", "-c", alembic_ini] + list(args)
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    return result.returncode


def upgrade(revision="head"):
    """Apply migrations up to revision."""
    print(f"\n🚀 Upgrading database to: {revision}")
    return run_alembic("upgrade", revision)


def downgrade(revision="-1"):
    """Rollback migrations to revision."""
    print(f"\n⬇️ Downgrading database to: {revision}")
    return run_alembic("downgrade", revision)


def history():
    """Show migration history."""
    print("\n📜 Migration history:")
    return run_alembic("history", "--verbose")


def current():
    """Show current revision."""
    print("\n📍 Current revision:")
    return run_alembic("current")


def heads():
    """Show head revisions."""
    print("\n🎯 Head revisions:")
    return run_alembic("heads")


def create(name):
    """Create new migration."""
    print(f"\n📝 Creating migration: {name}")
    return run_alembic("revision", "--autogenerate", "-m", name)


def main():
    parser = argparse.ArgumentParser(
        description="CHE·NU Database Migration Tool"
    )
    parser.add_argument(
        "command",
        choices=["upgrade", "downgrade", "history", "current", "heads", "create"],
        help="Migration command"
    )
    parser.add_argument(
        "args",
        nargs="*",
        help="Additional arguments (revision for upgrade/downgrade, name for create)"
    )
    
    args = parser.parse_args()
    
    commands = {
        "upgrade": lambda a: upgrade(a[0] if a else "head"),
        "downgrade": lambda a: downgrade(a[0] if a else "-1"),
        "history": lambda a: history(),
        "current": lambda a: current(),
        "heads": lambda a: heads(),
        "create": lambda a: create(a[0]) if a else print("❌ Name required for create"),
    }
    
    result = commands[args.command](args.args)
    sys.exit(result or 0)


if __name__ == "__main__":
    main()
