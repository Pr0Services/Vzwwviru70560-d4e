# Alignement Zero Point

Créé: 2026-01-10

- Respiration 4-4-6 × 6
- Question unique (1 phrase)
- Contrainte (ce que je refuse)
- Octave + Sphère
- Journal (archive)
