"""
CHE·NU™ V70 — WORKSPACE ENGINE
==============================
Main workspace engine orchestrating all components.

Based on: WORKSPACE_ENGINE_CHAPTER.md (Chapters 97-108)

The Workspace Engine is CHE·NU's primary interaction surface—
an adaptive, intelligent, multi-modal surface that automatically
assumes the optimal form for any given task.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4
import logging

from .models import (
    WorkspaceMode,
    SphereContext,
    DomainContext,
    IntentSignal,
    WorkflowStage,
    TransitionType,
    WorkspaceState,
    ModeTransition,
    IntentDetection,
    GestureSignal,
    AgentSignal,
    WorkspaceAgent,
    CollaborationSession,
    DataSpaceLink,
    XRLaunchConfig,
    PipelineExecution,
    create_workspace,
    create_xr_launch,
)
from .modes import (
    MODE_REGISTRY,
    get_mode_config,
    get_mode_capabilities,
    get_domain_templates,
    ModeCapability,
)
from .intent import IntentDetector, get_intent_detector
from .pipelines import (
    WorkflowPipeline,
    PipelineStep,
    get_pipeline_template,
    list_available_pipelines,
)

logger = logging.getLogger("chenu.workspace.engine")


# =============================================================================
# WORKSPACE ENGINE
# =============================================================================

class WorkspaceEngine:
    """
    CHE·NU Workspace Engine.
    
    The adaptive, intelligent, multi-modal interaction surface.
    
    Features:
    - Intent Detection (NLP, Gesture, Context, Agent)
    - Mode Management (9 modes + hybrid)
    - Workflow Pipelines
    - Agent Collaboration
    - DataSpace Integration
    - XR Launch (READ ONLY)
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        # Intent detection
        self._intent_detector = get_intent_detector()
        
        # Active workspaces
        self._workspaces: Dict[str, WorkspaceState] = {}
        
        # Active pipelines
        self._pipelines: Dict[str, PipelineExecution] = {}
        
        # Active agents
        self._agents: Dict[str, WorkspaceAgent] = {}
        
        # Collaboration sessions
        self._sessions: Dict[str, CollaborationSession] = {}
        
        # DataSpace links
        self._dataspace_links: Dict[str, DataSpaceLink] = {}
        
        # Transition history
        self._transitions: List[ModeTransition] = []
        
        logger.info("WorkspaceEngine initialized")
    
    # =========================================================================
    # WORKSPACE MANAGEMENT
    # =========================================================================
    
    def create_workspace(
        self,
        owner_id: str,
        title: str = "",
        mode: WorkspaceMode = WorkspaceMode.DOCUMENT,
        sphere: SphereContext = SphereContext.PERSONAL,
        domain: DomainContext = DomainContext.GENERAL,
    ) -> WorkspaceState:
        """Create a new workspace."""
        workspace = create_workspace(
            mode=mode,
            sphere=sphere,
            domain=domain,
            owner_id=owner_id,
            title=title,
        )
        
        self._workspaces[workspace.workspace_id] = workspace
        
        logger.info(f"Created workspace: {workspace.workspace_id} in {mode.value} mode")
        
        return workspace
    
    def get_workspace(self, workspace_id: str) -> Optional[WorkspaceState]:
        """Get workspace by ID."""
        return self._workspaces.get(workspace_id)
    
    def list_workspaces(
        self,
        owner_id: Optional[str] = None,
        sphere: Optional[SphereContext] = None,
        mode: Optional[WorkspaceMode] = None,
    ) -> List[WorkspaceState]:
        """List workspaces with optional filters."""
        workspaces = list(self._workspaces.values())
        
        if owner_id:
            workspaces = [w for w in workspaces if w.owner_id == owner_id]
        
        if sphere:
            workspaces = [w for w in workspaces if w.sphere == sphere]
        
        if mode:
            workspaces = [w for w in workspaces if w.current_mode == mode]
        
        return workspaces
    
    def close_workspace(self, workspace_id: str) -> bool:
        """Close a workspace."""
        if workspace_id in self._workspaces:
            self._workspaces[workspace_id].is_active = False
            logger.info(f"Closed workspace: {workspace_id}")
            return True
        return False
    
    # =========================================================================
    # INTENT DETECTION
    # =========================================================================
    
    def detect_intent(
        self,
        workspace_id: str,
        text: Optional[str] = None,
        gesture: Optional[GestureSignal] = None,
        agent_signal: Optional[AgentSignal] = None,
        data_type: Optional[str] = None,
    ) -> IntentDetection:
        """Detect user intent for a workspace."""
        workspace = self.get_workspace(workspace_id)
        
        detection = self._intent_detector.detect(
            text=text,
            gesture=gesture,
            agent_signal=agent_signal,
            current_state=workspace,
            data_type=data_type,
        )
        
        logger.debug(
            f"Intent detected: {detection.parsed_intent} "
            f"-> {detection.suggested_mode} (conf: {detection.confidence:.2f})"
        )
        
        return detection
    
    def suggest_mode(
        self,
        workspace_id: str,
        intent: str,
    ) -> Tuple[WorkspaceMode, float]:
        """Suggest a mode based on intent."""
        detection = self.detect_intent(workspace_id, text=intent)
        return (detection.suggested_mode or WorkspaceMode.DOCUMENT, detection.confidence)
    
    # =========================================================================
    # MODE TRANSITIONS
    # =========================================================================
    
    def transition_mode(
        self,
        workspace_id: str,
        target_mode: WorkspaceMode,
        reason: str = "",
        user_id: str = "",
    ) -> ModeTransition:
        """Transition workspace to a new mode."""
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            raise ValueError(f"Workspace not found: {workspace_id}")
        
        # Determine transition type
        if target_mode == WorkspaceMode.HYBRID:
            transition_type = TransitionType.HYBRID_CREATE
        elif target_mode == workspace.current_mode:
            transition_type = TransitionType.CONFIRM
        else:
            transition_type = TransitionType.TRANSFORM
        
        # Create transition record
        transition = ModeTransition(
            from_mode=workspace.current_mode,
            to_mode=target_mode,
            transition_type=transition_type,
            trigger_reason=reason,
            user_id=user_id,
            synthetic=True,  # GOVERNANCE
        )
        
        # Update workspace
        workspace.previous_mode = workspace.current_mode
        workspace.current_mode = target_mode
        workspace.updated_at = datetime.utcnow()
        
        # Handle hybrid mode
        if target_mode == WorkspaceMode.HYBRID and workspace.previous_mode:
            workspace.hybrid_modes = [workspace.previous_mode]
        
        # Record transition
        self._transitions.append(transition)
        
        logger.info(
            f"Workspace {workspace_id} transitioned: "
            f"{transition.from_mode.value} -> {transition.to_mode.value}"
        )
        
        return transition
    
    def add_hybrid_mode(
        self,
        workspace_id: str,
        mode: WorkspaceMode,
    ) -> bool:
        """Add a mode to hybrid workspace."""
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            return False
        
        if workspace.current_mode != WorkspaceMode.HYBRID:
            # First, transition to hybrid
            self.transition_mode(workspace_id, WorkspaceMode.HYBRID)
        
        # Check max modes (from HybridMode config)
        hybrid_config = get_mode_config(WorkspaceMode.HYBRID)
        if len(workspace.hybrid_modes) >= hybrid_config.max_simultaneous_modes:
            logger.warning(f"Max hybrid modes reached for workspace {workspace_id}")
            return False
        
        if mode not in workspace.hybrid_modes:
            workspace.hybrid_modes.append(mode)
            logger.info(f"Added {mode.value} to hybrid workspace {workspace_id}")
        
        return True
    
    def get_mode_capabilities(
        self,
        workspace_id: str,
    ) -> Set[ModeCapability]:
        """Get capabilities for current workspace mode."""
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            return set()
        
        capabilities = get_mode_capabilities(workspace.current_mode)
        
        # Add capabilities from hybrid modes
        if workspace.current_mode == WorkspaceMode.HYBRID:
            for mode in workspace.hybrid_modes:
                capabilities.update(get_mode_capabilities(mode))
        
        return capabilities
    
    # =========================================================================
    # WORKFLOW PIPELINES
    # =========================================================================
    
    def start_pipeline(
        self,
        workspace_id: str,
        pipeline_type: str,
        domain: Optional[DomainContext] = None,
    ) -> Optional[PipelineExecution]:
        """Start a workflow pipeline for a workspace."""
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            return None
        
        # Get pipeline template
        pipeline = get_pipeline_template(
            pipeline_type,
            domain or workspace.domain,
        )
        if not pipeline:
            logger.warning(f"Unknown pipeline type: {pipeline_type}")
            return None
        
        # Link to workspace
        pipeline.workspace_id = workspace_id
        
        # Create execution
        execution = PipelineExecution(
            pipeline_id=pipeline.pipeline_id,
            total_steps=len(pipeline.steps),
            current_step_id=pipeline.steps[0].step_id if pipeline.steps else None,
            status="running",
            synthetic=True,  # GOVERNANCE
        )
        
        self._pipelines[execution.execution_id] = execution
        
        logger.info(
            f"Started pipeline {pipeline_type} for workspace {workspace_id}: "
            f"{execution.execution_id}"
        )
        
        return execution
    
    def advance_pipeline(
        self,
        execution_id: str,
        step_output: Optional[Dict[str, Any]] = None,
    ) -> Optional[PipelineStep]:
        """Advance pipeline to next step."""
        execution = self._pipelines.get(execution_id)
        if not execution or execution.status != "running":
            return None
        
        # Record output
        if step_output:
            execution.outputs[execution.current_step_id] = step_output
        
        # Move to next step
        execution.steps_completed += 1
        
        if execution.steps_completed >= execution.total_steps:
            execution.status = "completed"
            execution.completed_at = datetime.utcnow()
            logger.info(f"Pipeline completed: {execution_id}")
            return None
        
        # Get next step
        # Note: In production, would fetch from pipeline definition
        execution.audit_trail.append({
            "step": execution.steps_completed,
            "timestamp": datetime.utcnow().isoformat(),
            "synthetic": True,
        })
        
        return None  # Would return actual next step
    
    def get_available_pipelines(self) -> List[str]:
        """Get list of available pipeline types."""
        return list_available_pipelines()
    
    # =========================================================================
    # AGENT COLLABORATION
    # =========================================================================
    
    def activate_agent(
        self,
        workspace_id: str,
        agent_type: str,
    ) -> WorkspaceAgent:
        """Activate an agent for a workspace."""
        agent = WorkspaceAgent(
            agent_id=f"AGENT_{uuid4().hex[:8]}",
            agent_type=agent_type,
            is_active=True,
            last_signal=datetime.utcnow(),
            synthetic=True,  # GOVERNANCE
            governance_level="strict",
        )
        
        self._agents[agent.agent_id] = agent
        
        logger.info(f"Activated agent {agent_type} for workspace {workspace_id}")
        
        return agent
    
    def receive_agent_signal(
        self,
        workspace_id: str,
        agent_id: str,
        suggestion: str,
        confidence: float = 0.5,
    ) -> IntentDetection:
        """Receive and process an agent signal."""
        agent = self._agents.get(agent_id)
        if not agent:
            raise ValueError(f"Agent not found: {agent_id}")
        
        signal = AgentSignal(
            agent_id=agent_id,
            agent_type=agent.agent_type,
            suggestion=suggestion,
            confidence=confidence,
            synthetic=True,  # GOVERNANCE
        )
        
        # Update agent last signal time
        agent.last_signal = datetime.utcnow()
        
        # Detect intent from signal
        return self.detect_intent(workspace_id, agent_signal=signal)
    
    # =========================================================================
    # COLLABORATION
    # =========================================================================
    
    def start_collaboration(
        self,
        workspace_id: str,
        participants: List[str],
    ) -> CollaborationSession:
        """Start a collaboration session."""
        session = CollaborationSession(
            workspace_id=workspace_id,
            participants=participants,
            is_active=True,
        )
        
        self._sessions[session.session_id] = session
        
        logger.info(
            f"Started collaboration session {session.session_id} "
            f"for workspace {workspace_id} with {len(participants)} participants"
        )
        
        return session
    
    def end_collaboration(self, session_id: str) -> bool:
        """End a collaboration session."""
        session = self._sessions.get(session_id)
        if session:
            session.is_active = False
            logger.info(f"Ended collaboration session {session_id}")
            return True
        return False
    
    # =========================================================================
    # DATASPACE INTEGRATION
    # =========================================================================
    
    def link_dataspace(
        self,
        workspace_id: str,
        dataspace_id: str,
        sync_mode: str = "bidirectional",
    ) -> DataSpaceLink:
        """Link workspace to a DataSpace."""
        link = DataSpaceLink(
            workspace_id=workspace_id,
            dataspace_id=dataspace_id,
            sync_mode=sync_mode,
            synthetic=True,  # GOVERNANCE
        )
        
        self._dataspace_links[link.link_id] = link
        
        # Update workspace
        workspace = self.get_workspace(workspace_id)
        if workspace:
            workspace.dataspace_id = dataspace_id
        
        logger.info(f"Linked workspace {workspace_id} to DataSpace {dataspace_id}")
        
        return link
    
    def sync_dataspace(self, workspace_id: str) -> bool:
        """Sync workspace with linked DataSpace."""
        workspace = self.get_workspace(workspace_id)
        if not workspace or not workspace.dataspace_id:
            return False
        
        # Find link
        link = next(
            (l for l in self._dataspace_links.values() 
             if l.workspace_id == workspace_id),
            None
        )
        
        if link:
            link.last_sync = datetime.utcnow()
            logger.info(f"Synced workspace {workspace_id} with DataSpace")
            return True
        
        return False
    
    # =========================================================================
    # XR LAUNCH (READ ONLY)
    # =========================================================================
    
    def prepare_xr_launch(
        self,
        workspace_id: str,
        environment_type: str,
        participants: Optional[List[str]] = None,
    ) -> XRLaunchConfig:
        """
        Prepare XR launch configuration.
        
        CRITICAL: XR is always READ ONLY.
        """
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            raise ValueError(f"Workspace not found: {workspace_id}")
        
        config = create_xr_launch(
            workspace_id=workspace_id,
            environment_type=environment_type,
            participants=participants,
        )
        
        # GOVERNANCE: Ensure read-only
        assert config.read_only == True, "XR must be read-only"
        
        logger.info(
            f"Prepared XR launch for workspace {workspace_id}: "
            f"{environment_type} (READ ONLY)"
        )
        
        return config
    
    # =========================================================================
    # DOMAIN TEMPLATES
    # =========================================================================
    
    def get_templates(
        self,
        workspace_id: str,
    ) -> List[str]:
        """Get available templates for workspace."""
        workspace = self.get_workspace(workspace_id)
        if not workspace:
            return []
        
        return get_domain_templates(workspace.current_mode, workspace.domain)
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        return {
            "total_workspaces": len(self._workspaces),
            "active_workspaces": sum(1 for w in self._workspaces.values() if w.is_active),
            "active_pipelines": sum(
                1 for p in self._pipelines.values() if p.status == "running"
            ),
            "active_agents": sum(1 for a in self._agents.values() if a.is_active),
            "active_sessions": sum(1 for s in self._sessions.values() if s.is_active),
            "total_transitions": len(self._transitions),
            "governance": {
                "synthetic_only": True,
                "xr_read_only": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_workspace_engine: Optional[WorkspaceEngine] = None


def get_workspace_engine() -> WorkspaceEngine:
    """Get the workspace engine singleton."""
    global _workspace_engine
    if _workspace_engine is None:
        _workspace_engine = WorkspaceEngine()
    return _workspace_engine


# =============================================================================
# TYPE HINTS FIX
# =============================================================================

from typing import Tuple
