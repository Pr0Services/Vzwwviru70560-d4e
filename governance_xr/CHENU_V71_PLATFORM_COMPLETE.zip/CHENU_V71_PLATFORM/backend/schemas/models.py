"""
CHE·NU™ V70 — VALIDATION SCHEMAS
================================
Pydantic models for API validation.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from pydantic import BaseModel, Field, field_validator, model_validator
from uuid import uuid4


# =============================================================================
# ENUMS
# =============================================================================

class GovernanceLevel(str, Enum):
    """Governance levels."""
    STRICT = "strict"
    STANDARD = "standard"


class DecisionStatus(str, Enum):
    """Decision package status."""
    DRAFT = "draft"
    PENDING_HITL = "pending_hitl"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPORTED = "exported"


class SimulationMode(str, Enum):
    """Simulation modes."""
    DETERMINISTIC = "deterministic"
    STOCHASTIC = "stochastic"


class CrisisLevel(str, Enum):
    """Crisis response levels."""
    N0_MONITORING = "n0_monitoring"
    N1_FREEZE = "n1_freeze"
    N2_VITAL = "n2_vital"
    N3_AUTONOMY = "n3_autonomy"
    N4_ARCHIVE = "n4_archive"


# =============================================================================
# BASE MODELS
# =============================================================================

class BaseRequest(BaseModel):
    """Base request model with governance."""
    request_id: str = Field(default_factory=lambda: f"REQ_{uuid4().hex[:8]}")
    
    class Config:
        extra = "forbid"


class BaseResponse(BaseModel):
    """Base response model."""
    success: bool = True
    request_id: str = Field(default_factory=lambda: f"RES_{uuid4().hex[:8]}")
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    
    # Governance (always present)
    governance: dict = Field(
        default_factory=lambda: {
            "synthetic": True,
            "governed": True,
        }
    )


class ErrorResponse(BaseModel):
    """Error response model."""
    success: bool = False
    error: str
    message: str
    request_id: Optional[str] = None
    details: Optional[dict] = None


# =============================================================================
# NOVA KERNEL SCHEMAS
# =============================================================================

class NovaValidateRequest(BaseRequest):
    """Request for NOVA validation."""
    intent: str = Field(..., min_length=1, max_length=1000)
    context: dict = Field(default_factory=dict)
    require_validation: bool = True
    
    @field_validator("intent")
    @classmethod
    def check_forbidden_patterns(cls, v: str) -> str:
        """Check for forbidden patterns in intent."""
        forbidden = [
            "bypass governance",
            "override security",
            "disable audit",
        ]
        v_lower = v.lower()
        for pattern in forbidden:
            if pattern in v_lower:
                raise ValueError(f"Intent contains forbidden pattern: {pattern}")
        return v


class NovaValidateResponse(BaseResponse):
    """Response from NOVA validation."""
    response_type: str = "validated"
    validation_result: dict = Field(default_factory=dict)
    is_refusal: bool = False
    refusal_reason: Optional[str] = None


# =============================================================================
# ETHICS SCHEMAS
# =============================================================================

class EthicsValidationRequest(BaseRequest):
    """Request for ethics validation."""
    action_description: str = Field(..., min_length=1, max_length=2000)
    actor_type: str = Field(default="system_intelligence")
    context: dict = Field(default_factory=dict)


class EthicsValidationResponse(BaseResponse):
    """Ethics validation response."""
    is_valid: bool
    violations: list[str] = Field(default_factory=list)
    forbidden_state: Optional[str] = None
    canon_rules_checked: list[str] = Field(default_factory=list)


# =============================================================================
# DECISION LOOP SCHEMAS
# =============================================================================

class DecisionOption(BaseModel):
    """Single decision option."""
    name: str
    description: Optional[str] = None
    risk: float = Field(ge=0.0, le=1.0)
    impact: str = Field(default="medium")
    metadata: dict = Field(default_factory=dict)


class DecisionLoopRequest(BaseRequest):
    """Request to execute decision loop."""
    user_intent: str = Field(..., min_length=1, max_length=2000)
    initial_state: dict = Field(default_factory=dict)
    simulation_cycles: int = Field(default=10, ge=1, le=1000)
    simulation_mode: SimulationMode = SimulationMode.DETERMINISTIC


class DecisionLoopResponse(BaseResponse):
    """Decision loop response."""
    package_id: str
    simulation_id: str
    causal_trace_id: str
    xr_scene_id: str
    status: DecisionStatus = DecisionStatus.PENDING_HITL
    options: list[DecisionOption] = Field(default_factory=list)
    requires_hitl: bool = True


class HITLApprovalRequest(BaseRequest):
    """Request for HITL approval."""
    package_id: str
    selected_option: Optional[int] = None
    comments: Optional[str] = None
    
    @field_validator("comments")
    @classmethod
    def sanitize_comments(cls, v: Optional[str]) -> Optional[str]:
        if v:
            # Basic sanitization
            return v.strip()[:1000]
        return v


class HITLApprovalResponse(BaseResponse):
    """HITL approval response."""
    package_id: str
    approved: bool
    approved_by: str
    approved_at: datetime = Field(default_factory=datetime.utcnow)


# =============================================================================
# SIMULATION SCHEMAS
# =============================================================================

class SimulationRequest(BaseRequest):
    """Request to run simulation."""
    world_state_id: Optional[str] = None
    initial_state: dict = Field(default_factory=dict)
    cycles: int = Field(default=10, ge=1, le=1000)
    mode: SimulationMode = SimulationMode.DETERMINISTIC
    
    # CRITICAL: Always synthetic
    synthetic: bool = Field(default=True, const=True)
    
    @model_validator(mode="after")
    def ensure_synthetic(self):
        """Ensure simulation is synthetic."""
        if not self.synthetic:
            raise ValueError("Simulation must be synthetic")
        return self


class SimulationResponse(BaseResponse):
    """Simulation response."""
    simulation_id: str
    cycles_completed: int
    final_state: dict = Field(default_factory=dict)
    causal_trace_id: str
    
    # CRITICAL
    synthetic: bool = True


# =============================================================================
# FAILSAFE SCHEMAS
# =============================================================================

class CrisisIndicators(BaseModel):
    """Crisis indicator values."""
    network_health: float = Field(default=1.0, ge=0.0, le=1.0)
    social_cohesion: float = Field(default=1.0, ge=0.0, le=1.0)
    supply_chain: float = Field(default=1.0, ge=0.0, le=1.0)
    governance_integrity: float = Field(default=1.0, ge=0.0, le=1.0)
    economic_stability: float = Field(default=1.0, ge=0.0, le=1.0)


class CrisisCheckRequest(BaseRequest):
    """Request to check crisis indicators."""
    indicators: CrisisIndicators


class CrisisCheckResponse(BaseResponse):
    """Crisis check response."""
    crisis_detected: bool
    crisis_type: Optional[str] = None
    response_level: CrisisLevel = CrisisLevel.N0_MONITORING
    recommended_actions: list[str] = Field(default_factory=list)


class FailsafeActivationRequest(BaseRequest):
    """Request to activate failsafe level."""
    level: CrisisLevel
    reason: str = Field(..., min_length=1, max_length=500)


class FailsafeActivationResponse(BaseResponse):
    """Failsafe activation response."""
    activated: bool
    level: CrisisLevel
    actions_taken: list[str] = Field(default_factory=list)


# =============================================================================
# XR SCHEMAS
# =============================================================================

class XRSceneRequest(BaseRequest):
    """Request for XR scene."""
    scene_type: str
    package_id: Optional[str] = None
    render_mode: str = Field(default="threejs")
    
    # CRITICAL: Read-only
    read_only: bool = Field(default=True, const=True)


class XRSceneResponse(BaseResponse):
    """XR scene response."""
    scene_id: str
    scene_type: str
    nodes: list[dict] = Field(default_factory=list)
    edges: list[dict] = Field(default_factory=list)
    
    # CRITICAL: Always read-only
    read_only: bool = True


# =============================================================================
# TRANSMISSION SCHEMAS
# =============================================================================

class SkillTraceRequest(BaseRequest):
    """Request to create skill trace."""
    skill_name: str = Field(..., min_length=1, max_length=200)
    learner_id: str
    mentor_id: Optional[str] = None
    source_context: dict = Field(default_factory=dict)


class SkillTraceResponse(BaseResponse):
    """Skill trace response."""
    trace_id: str
    skill_name: str
    generation_score: float = Field(ge=0.0, le=1.0)
    trust_score: float = Field(ge=0.0, le=1.0)


# =============================================================================
# PLANETARY SCHEMAS
# =============================================================================

class CrossNodeRequest(BaseRequest):
    """Request for cross-node operation."""
    source_node: str
    target_node: str
    intent: str = Field(..., min_length=1, max_length=1000)
    
    # CRITICAL: Constraints
    no_real_execution: bool = Field(default=True, const=True)
    summary_only: bool = Field(default=True, const=True)


class CrossNodeResponse(BaseResponse):
    """Cross-node response."""
    query_id: str
    source_node: str
    target_node: str
    constraints_enforced: list[str] = Field(
        default_factory=lambda: [
            "NO_REAL_EXECUTION",
            "OPA_REQUIRED",
            "SUMMARY_ONLY",
        ]
    )


# =============================================================================
# AUTH SCHEMAS
# =============================================================================

class LoginRequest(BaseModel):
    """Login request."""
    username: str = Field(..., min_length=3, max_length=50)
    password: str = Field(..., min_length=8)


class LoginResponse(BaseResponse):
    """Login response."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class TokenRefreshRequest(BaseModel):
    """Token refresh request."""
    refresh_token: str


# =============================================================================
# PAGINATION
# =============================================================================

class PaginationParams(BaseModel):
    """Pagination parameters."""
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=20, ge=1, le=100)
    
    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


class PaginatedResponse(BaseResponse):
    """Paginated response."""
    items: list[Any] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20
    total_pages: int = 0


# =============================================================================
# HEALTH CHECK
# =============================================================================

class HealthCheckResponse(BaseModel):
    """Health check response."""
    status: str = "healthy"
    version: str = "70.0.0"
    
    # Governance
    governance_level: GovernanceLevel = GovernanceLevel.STRICT
    synthetic_only: bool = True
    xr_read_only: bool = True
    
    # Components
    components: dict = Field(default_factory=dict)
    
    timestamp: datetime = Field(default_factory=datetime.utcnow)
