export type SessionState = {
  lastRoute: string;
  lastSphereId?: string;
  startedAt: number;
};
