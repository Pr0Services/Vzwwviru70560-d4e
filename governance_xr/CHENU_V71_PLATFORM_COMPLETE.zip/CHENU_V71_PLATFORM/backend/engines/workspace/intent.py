"""
CHE·NU™ V70 — INTENT DETECTION ENGINE
=====================================
Intent detection layer for workspace engine.

Based on: WORKSPACE_ENGINE_CHAPTER.md (Chapter 97)

Signal Sources:
- NLP (Natural Language Processing)
- Gesture (User gestures)
- Context (Sphere, Domain)
- Agent Signals
- Workflow Stage
- Governance Requirements

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4
import re
import logging

from .models import (
    WorkspaceMode,
    SphereContext,
    DomainContext,
    IntentSignal,
    WorkflowStage,
    IntentDetection,
    GestureSignal,
    AgentSignal,
    WorkspaceState,
)
from .modes import suggest_mode_for_intent

logger = logging.getLogger("chenu.workspace.intent")


# =============================================================================
# INTENT PATTERNS
# =============================================================================

INTENT_PATTERNS: Dict[str, Dict[str, Any]] = {
    # Document creation intents
    "create_document": {
        "patterns": [
            r"write\s+(?:a\s+)?(\w+)",
            r"draft\s+(?:a\s+)?(\w+)",
            r"create\s+(?:a\s+)?document",
            r"compose\s+(?:a\s+)?(\w+)",
            r"start\s+(?:a\s+)?report",
        ],
        "mode": WorkspaceMode.DOCUMENT,
        "confidence_boost": 0.2,
    },
    
    # Task/Board intents
    "manage_tasks": {
        "patterns": [
            r"show\s+(?:my\s+)?tasks",
            r"organize\s+(?:my\s+)?work",
            r"kanban",
            r"sprint\s+planning",
            r"create\s+(?:a\s+)?board",
        ],
        "mode": WorkspaceMode.BOARD,
        "confidence_boost": 0.2,
    },
    
    # Timeline/Planning intents
    "plan_timeline": {
        "patterns": [
            r"plan\s+(?:the\s+)?schedule",
            r"create\s+(?:a\s+)?timeline",
            r"gantt",
            r"project\s+schedule",
            r"roadmap",
        ],
        "mode": WorkspaceMode.TIMELINE,
        "confidence_boost": 0.2,
    },
    
    # Calculation intents
    "calculate": {
        "patterns": [
            r"calculate",
            r"estimate",
            r"budget",
            r"spreadsheet",
            r"crunch\s+(?:the\s+)?numbers",
        ],
        "mode": WorkspaceMode.SPREADSHEET,
        "confidence_boost": 0.2,
    },
    
    # Dashboard intents
    "view_metrics": {
        "patterns": [
            r"show\s+(?:me\s+)?metrics",
            r"dashboard",
            r"kpi",
            r"overview",
            r"status\s+report",
        ],
        "mode": WorkspaceMode.DASHBOARD,
        "confidence_boost": 0.2,
    },
    
    # Diagram intents
    "create_diagram": {
        "patterns": [
            r"diagram",
            r"flowchart",
            r"mind\s*map",
            r"visualize\s+(?:the\s+)?process",
            r"architecture\s+diagram",
        ],
        "mode": WorkspaceMode.DIAGRAM,
        "confidence_boost": 0.2,
    },
    
    # Whiteboard intents
    "brainstorm": {
        "patterns": [
            r"brainstorm",
            r"whiteboard",
            r"sketch",
            r"creative\s+session",
            r"ideate",
        ],
        "mode": WorkspaceMode.WHITEBOARD,
        "confidence_boost": 0.2,
    },
    
    # XR intents
    "launch_xr": {
        "patterns": [
            r"vr\s+meeting",
            r"immersive",
            r"3d\s+view",
            r"walkthrough",
            r"xr\s+mode",
        ],
        "mode": WorkspaceMode.XR_LAUNCHER,
        "confidence_boost": 0.2,
    },
}


# Domain detection patterns
DOMAIN_PATTERNS: Dict[DomainContext, List[str]] = {
    DomainContext.CONSTRUCTION: [
        r"construction", r"building", r"contractor", r"punch\s*list",
        r"rfi", r"change\s*order", r"takeoff", r"subcontractor"
    ],
    DomainContext.FINANCE: [
        r"financial", r"budget", r"investment", r"revenue",
        r"profit", r"cash\s*flow", r"forecast"
    ],
    DomainContext.IMMOBILIER: [
        r"property", r"tenant", r"lease", r"rent",
        r"building", r"unit", r"occupancy", r"landlord"
    ],
    DomainContext.ARCHITECTURE: [
        r"design", r"architect", r"floor\s*plan", r"elevation",
        r"rendering", r"spec", r"building\s*program"
    ],
    DomainContext.LEGAL: [
        r"contract", r"legal", r"agreement", r"clause",
        r"liability", r"compliance"
    ],
}


# =============================================================================
# INTENT DETECTOR
# =============================================================================

class IntentDetector:
    """
    Detects user intent from multiple signal sources.
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        self._compiled_patterns: Dict[str, List[re.Pattern]] = {}
        self._compile_patterns()
    
    def _compile_patterns(self):
        """Pre-compile regex patterns."""
        for intent_name, intent_config in INTENT_PATTERNS.items():
            self._compiled_patterns[intent_name] = [
                re.compile(p, re.IGNORECASE) 
                for p in intent_config["patterns"]
            ]
        
        self._domain_patterns: Dict[DomainContext, List[re.Pattern]] = {
            domain: [re.compile(p, re.IGNORECASE) for p in patterns]
            for domain, patterns in DOMAIN_PATTERNS.items()
        }
    
    # =========================================================================
    # NLP DETECTION
    # =========================================================================
    
    def detect_from_nlp(
        self,
        text: str,
        current_state: Optional[WorkspaceState] = None,
    ) -> IntentDetection:
        """Detect intent from natural language input."""
        detection = IntentDetection(
            raw_input=text,
            signals=[IntentSignal.NLP],
        )
        
        # Match intent patterns
        best_match: Optional[Tuple[str, float]] = None
        
        for intent_name, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    config = INTENT_PATTERNS[intent_name]
                    confidence = 0.6 + config.get("confidence_boost", 0)
                    
                    if best_match is None or confidence > best_match[1]:
                        best_match = (intent_name, confidence)
                        detection.suggested_mode = config["mode"]
                        detection.parsed_intent = intent_name
        
        if best_match:
            detection.confidence = best_match[1]
        else:
            # Fallback to keyword-based suggestion
            detection.suggested_mode = suggest_mode_for_intent(text)
            detection.confidence = 0.4
        
        # Detect domain
        detection.suggested_domain = self._detect_domain(text)
        
        # Apply context
        if current_state:
            detection.current_mode = current_state.current_mode
            detection.current_sphere = current_state.sphere
            
            # Boost confidence if domain matches
            if detection.suggested_domain == current_state.domain:
                detection.confidence = min(1.0, detection.confidence + 0.1)
        
        return detection
    
    def _detect_domain(self, text: str) -> DomainContext:
        """Detect domain context from text."""
        domain_scores: Dict[DomainContext, int] = {d: 0 for d in DomainContext}
        
        for domain, patterns in self._domain_patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    domain_scores[domain] += 1
        
        # Find highest scoring domain
        max_domain = max(domain_scores, key=domain_scores.get)
        if domain_scores[max_domain] > 0:
            return max_domain
        
        return DomainContext.GENERAL
    
    # =========================================================================
    # GESTURE DETECTION
    # =========================================================================
    
    def detect_from_gesture(
        self,
        gesture: GestureSignal,
        current_state: Optional[WorkspaceState] = None,
    ) -> IntentDetection:
        """Detect intent from gesture signal."""
        detection = IntentDetection(
            signals=[IntentSignal.GESTURE],
            raw_input=f"gesture:{gesture.gesture_type}",
        )
        
        # Map gestures to modes
        gesture_mode_map = {
            "swipe_left": None,  # Navigation, not mode change
            "swipe_right": None,
            "pinch_in": WorkspaceMode.DASHBOARD,  # Zoom out = overview
            "pinch_out": None,  # Zoom in = detail
            "two_finger_tap": WorkspaceMode.HYBRID,  # Split view
            "long_press": WorkspaceMode.BOARD,  # Quick actions
            "draw_circle": WorkspaceMode.WHITEBOARD,
        }
        
        if gesture.gesture_type in gesture_mode_map:
            mode = gesture_mode_map[gesture.gesture_type]
            if mode:
                detection.suggested_mode = mode
                detection.confidence = 0.5
                detection.parsed_intent = f"gesture_{gesture.gesture_type}"
        
        if current_state:
            detection.current_mode = current_state.current_mode
        
        return detection
    
    # =========================================================================
    # AGENT SIGNAL DETECTION
    # =========================================================================
    
    def detect_from_agent(
        self,
        signal: AgentSignal,
        current_state: Optional[WorkspaceState] = None,
    ) -> IntentDetection:
        """Detect intent from agent signal."""
        detection = IntentDetection(
            signals=[IntentSignal.AGENT],
            raw_input=f"agent:{signal.agent_type}:{signal.suggestion}",
            parsed_intent=signal.suggestion,
            confidence=signal.confidence * 0.8,  # Reduce agent confidence slightly
        )
        
        # Trust agent mode suggestions
        detection.suggested_mode = suggest_mode_for_intent(signal.suggestion)
        
        detection.metadata["agent_id"] = signal.agent_id
        detection.metadata["agent_reasoning"] = signal.reasoning
        
        if current_state:
            detection.current_mode = current_state.current_mode
        
        return detection
    
    # =========================================================================
    # CONTEXT DETECTION
    # =========================================================================
    
    def detect_from_context(
        self,
        sphere: SphereContext,
        domain: DomainContext,
        workflow_stage: WorkflowStage,
        data_type: Optional[str] = None,
    ) -> IntentDetection:
        """Detect intent from context signals."""
        detection = IntentDetection(
            signals=[IntentSignal.CONTEXT],
        )
        
        detection.suggested_domain = domain
        
        # Suggest mode based on context
        context_mode_hints: Dict[Tuple[SphereContext, WorkflowStage], WorkspaceMode] = {
            (SphereContext.ENTERPRISE, WorkflowStage.PLANNING): WorkspaceMode.TIMELINE,
            (SphereContext.ENTERPRISE, WorkflowStage.EXECUTION): WorkspaceMode.BOARD,
            (SphereContext.CREATIVE, WorkflowStage.INITIATION): WorkspaceMode.WHITEBOARD,
            (SphereContext.SCHOLAR, WorkflowStage.EXECUTION): WorkspaceMode.DOCUMENT,
            (SphereContext.PERSONAL, WorkflowStage.REVIEW): WorkspaceMode.DASHBOARD,
        }
        
        key = (sphere, workflow_stage)
        if key in context_mode_hints:
            detection.suggested_mode = context_mode_hints[key]
            detection.confidence = 0.4
        
        # Data type hints
        if data_type:
            data_mode_map = {
                "text": WorkspaceMode.DOCUMENT,
                "tasks": WorkspaceMode.BOARD,
                "numbers": WorkspaceMode.SPREADSHEET,
                "timeline": WorkspaceMode.TIMELINE,
                "media": WorkspaceMode.WHITEBOARD,
                "3d": WorkspaceMode.XR_LAUNCHER,
            }
            if data_type in data_mode_map:
                detection.suggested_mode = data_mode_map[data_type]
                detection.confidence = 0.5
        
        return detection
    
    # =========================================================================
    # COMBINED DETECTION
    # =========================================================================
    
    def detect(
        self,
        text: Optional[str] = None,
        gesture: Optional[GestureSignal] = None,
        agent_signal: Optional[AgentSignal] = None,
        current_state: Optional[WorkspaceState] = None,
        data_type: Optional[str] = None,
    ) -> IntentDetection:
        """
        Detect intent from all available signals.
        
        Combines multiple signal sources with weighted confidence.
        """
        detections: List[IntentDetection] = []
        
        # Collect detections from all sources
        if text:
            detections.append(self.detect_from_nlp(text, current_state))
        
        if gesture:
            detections.append(self.detect_from_gesture(gesture, current_state))
        
        if agent_signal:
            detections.append(self.detect_from_agent(agent_signal, current_state))
        
        if current_state:
            detections.append(self.detect_from_context(
                current_state.sphere,
                current_state.domain,
                current_state.workflow_stage,
                data_type,
            ))
        
        if not detections:
            # No signals, return empty detection
            return IntentDetection()
        
        # Combine detections
        return self._combine_detections(detections, current_state)
    
    def _combine_detections(
        self,
        detections: List[IntentDetection],
        current_state: Optional[WorkspaceState],
    ) -> IntentDetection:
        """Combine multiple detections into a final result."""
        combined = IntentDetection()
        
        # Collect all signals
        for d in detections:
            combined.signals.extend(d.signals)
        
        # Weight by confidence
        mode_votes: Dict[WorkspaceMode, float] = {}
        domain_votes: Dict[DomainContext, float] = {}
        
        for d in detections:
            if d.suggested_mode:
                mode_votes[d.suggested_mode] = mode_votes.get(d.suggested_mode, 0) + d.confidence
            if d.suggested_domain:
                domain_votes[d.suggested_domain] = domain_votes.get(d.suggested_domain, 0) + d.confidence
        
        # Select highest voted mode
        if mode_votes:
            combined.suggested_mode = max(mode_votes, key=mode_votes.get)
            combined.confidence = mode_votes[combined.suggested_mode] / len(detections)
        
        # Select highest voted domain
        if domain_votes:
            combined.suggested_domain = max(domain_votes, key=domain_votes.get)
        
        # Collect metadata
        combined.raw_input = " | ".join(d.raw_input for d in detections if d.raw_input)
        combined.parsed_intent = next((d.parsed_intent for d in detections if d.parsed_intent), "")
        
        if current_state:
            combined.current_mode = current_state.current_mode
            combined.current_sphere = current_state.sphere
        
        return combined


# =============================================================================
# SINGLETON
# =============================================================================

_intent_detector: Optional[IntentDetector] = None


def get_intent_detector() -> IntentDetector:
    """Get the intent detector singleton."""
    global _intent_detector
    if _intent_detector is None:
        _intent_detector = IntentDetector()
    return _intent_detector
