"""
CHE·NU™ V70 — BACKSTAGE INTELLIGENCE PACKAGE
=============================================
Invisible cognitive layer for background operations.

Based on: BACKSTAGE_INTELLIGENCE_CHAPTER.md (Chapters 109-118)

GOUVERNANCE > EXÉCUTION
"""

from .engine import (
    # Enums
    AnalysisType,
    ClassificationType,
    SafetyLevel,
    # Models
    ContextAnalysis,
    EntityDetection,
    Classification,
    SafetyCheck,
    PreparedContent,
    # Engine
    BackstageIntelligence,
    get_backstage_intelligence,
)

__all__ = [
    "AnalysisType",
    "ClassificationType",
    "SafetyLevel",
    "ContextAnalysis",
    "EntityDetection",
    "Classification",
    "SafetyCheck",
    "PreparedContent",
    "BackstageIntelligence",
    "get_backstage_intelligence",
]

__version__ = "70.0.0"
