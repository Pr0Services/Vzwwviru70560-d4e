"""
CHE·NU™ Response Cache Middleware — FastAPI Response Caching
=============================================================

Middleware for automatic response caching with:
- Route-based caching rules
- ETag generation and validation
- Conditional GET support (304 Not Modified)
- Cache-Control headers
- Query parameter awareness
- Per-user cache isolation

Author: CHE·NU Backend Team
Version: 1.0.0
"""

from typing import Optional, Dict, Any, List, Callable, Set
from datetime import datetime, timedelta
from uuid import UUID
import hashlib
import json
import time
import logging
import re
from dataclasses import dataclass, field
from enum import Enum

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from .cache_service import (
    cache_service,
    CacheKeyBuilder,
    CacheRegion,
    REGION_TTLS,
)

logger = logging.getLogger(__name__)


class CacheControl(str, Enum):
    """Cache-Control directive options."""
    NO_CACHE = "no-cache"
    NO_STORE = "no-store"
    PRIVATE = "private"
    PUBLIC = "public"
    MAX_AGE = "max-age"
    MUST_REVALIDATE = "must-revalidate"


@dataclass
class CacheRule:
    """Configuration for caching a route pattern."""
    pattern: str                          # URL pattern (regex)
    methods: Set[str] = field(default_factory=lambda: {"GET"})
    ttl: int = 300                        # TTL in seconds
    region: CacheRegion = CacheRegion.API_RESPONSE
    private: bool = False                 # Per-user cache
    vary_headers: List[str] = field(default_factory=list)  # Vary by headers
    vary_query_params: List[str] = field(default_factory=list)  # Vary by params
    cache_control: List[str] = field(default_factory=lambda: ["private", "max-age=300"])
    etag: bool = True                     # Generate ETag
    
    def matches(self, method: str, path: str) -> bool:
        """Check if rule matches request."""
        if method.upper() not in self.methods:
            return False
        return bool(re.match(self.pattern, path))


@dataclass
class ResponseCacheStats:
    """Statistics for response caching."""
    hits: int = 0
    misses: int = 0
    bypassed: int = 0
    errors: int = 0
    etag_hits: int = 0
    total_time_saved_ms: float = 0.0
    
    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses + self.bypassed
        return (self.hits / total * 100) if total > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "hits": self.hits,
            "misses": self.misses,
            "bypassed": self.bypassed,
            "errors": self.errors,
            "etag_hits": self.etag_hits,
            "hit_rate": round(self.hit_rate, 2),
            "total_time_saved_ms": round(self.total_time_saved_ms, 2),
        }


class ResponseCacheMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware for response caching.
    
    Features:
    - Configurable cache rules per route
    - ETag generation and 304 Not Modified support
    - Per-user cache isolation
    - Cache-Control header management
    - Query parameter and header-based variation
    """
    
    # Default rules for CHE·NU
    DEFAULT_RULES: List[CacheRule] = [
        # Static data - long cache
        CacheRule(
            pattern=r"^/api/v2/agents/?$",
            ttl=3600,
            region=CacheRegion.STATIC,
            private=False,
            cache_control=["public", "max-age=3600"],
        ),
        
        # User's spheres - short cache, private
        CacheRule(
            pattern=r"^/api/v2/spheres/?$",
            ttl=60,
            region=CacheRegion.HOT,
            private=True,
            cache_control=["private", "max-age=60"],
        ),
        
        # Thread list - short cache, private
        CacheRule(
            pattern=r"^/api/v2/threads/?$",
            ttl=30,
            region=CacheRegion.HOT,
            private=True,
            vary_query_params=["sphere_id", "status", "page", "limit"],
            cache_control=["private", "max-age=30"],
        ),
        
        # Individual thread - medium cache, private
        CacheRule(
            pattern=r"^/api/v2/threads/[a-f0-9-]+/?$",
            ttl=120,
            region=CacheRegion.WARM,
            private=True,
            cache_control=["private", "max-age=120"],
        ),
        
        # Thread events - short cache, private
        CacheRule(
            pattern=r"^/api/v2/threads/[a-f0-9-]+/events/?$",
            ttl=30,
            region=CacheRegion.HOT,
            private=True,
            vary_query_params=["page", "limit"],
            cache_control=["private", "max-age=30"],
        ),
        
        # XR blueprint - medium cache
        CacheRule(
            pattern=r"^/api/v2/xr/[a-f0-9-]+/blueprint/?$",
            ttl=300,
            region=CacheRegion.WARM,
            private=True,
            cache_control=["private", "max-age=300"],
        ),
        
        # Agent info - long cache
        CacheRule(
            pattern=r"^/api/v2/agents/[a-zA-Z_-]+/?$",
            ttl=1800,
            region=CacheRegion.COLD,
            private=False,
            cache_control=["public", "max-age=1800"],
        ),
    ]
    
    # Paths to never cache
    BYPASS_PATTERNS: List[str] = [
        r"^/api/v2/auth/.*",           # Authentication
        r"^/api/v2/checkpoints/.*",    # Governance
        r"^/api/v2/nova/process.*",    # AI processing
        r"^/ws/.*",                     # WebSocket
        r"^/health.*",                  # Health checks
        r"^/metrics.*",                 # Metrics
    ]
    
    # Methods to never cache
    NON_CACHEABLE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
    
    def __init__(
        self,
        app,
        rules: Optional[List[CacheRule]] = None,
        enabled: bool = True,
        debug: bool = False,
    ):
        """
        Initialize response cache middleware.
        
        Args:
            app: FastAPI application
            rules: Custom caching rules (extends defaults)
            enabled: Enable/disable caching
            debug: Add debug headers
        """
        super().__init__(app)
        self.rules = (rules or []) + self.DEFAULT_RULES
        self.enabled = enabled
        self.debug = debug
        self.stats = ResponseCacheStats()
        
        # Compile bypass patterns
        self._bypass_patterns = [
            re.compile(p) for p in self.BYPASS_PATTERNS
        ]
        
        logger.info(
            f"ResponseCacheMiddleware initialized "
            f"(enabled={enabled}, rules={len(self.rules)})"
        )
    
    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Process request with caching logic."""
        start_time = time.time()
        
        # Check if caching is enabled
        if not self.enabled:
            return await call_next(request)
        
        # Check if method is cacheable
        if request.method.upper() in self.NON_CACHEABLE_METHODS:
            return await call_next(request)
        
        # Check bypass patterns
        path = request.url.path
        if self._should_bypass(path):
            self.stats.bypassed += 1
            return await call_next(request)
        
        # Find matching rule
        rule = self._find_rule(request.method, path)
        if not rule:
            return await call_next(request)
        
        # Build cache key
        cache_key = self._build_cache_key(request, rule)
        
        try:
            # Try to get cached response
            cached = await cache_service.get(cache_key)
            
            if cached:
                # Check ETag / If-None-Match
                if rule.etag:
                    client_etag = request.headers.get("if-none-match")
                    if client_etag and client_etag == cached.get("etag"):
                        self.stats.etag_hits += 1
                        self.stats.hits += 1
                        return Response(
                            status_code=304,
                            headers=self._build_cache_headers(rule, cached.get("etag")),
                        )
                
                # Return cached response
                self.stats.hits += 1
                elapsed = (time.time() - start_time) * 1000
                self.stats.total_time_saved_ms += cached.get("original_time_ms", 0) - elapsed
                
                response = JSONResponse(
                    content=cached["body"],
                    status_code=cached["status_code"],
                    headers=self._build_cache_headers(rule, cached.get("etag")),
                )
                
                if self.debug:
                    response.headers["X-Cache"] = "HIT"
                    response.headers["X-Cache-Key"] = cache_key
                
                return response
            
            # Cache miss - call actual endpoint
            self.stats.misses += 1
            response = await call_next(request)
            
            # Only cache successful responses
            if 200 <= response.status_code < 300:
                await self._cache_response(
                    cache_key, request, response, rule, start_time
                )
            
            if self.debug:
                response.headers["X-Cache"] = "MISS"
                response.headers["X-Cache-Key"] = cache_key
            
            return response
            
        except Exception as e:
            self.stats.errors += 1
            logger.error(f"Response cache error: {e}")
            return await call_next(request)
    
    def _should_bypass(self, path: str) -> bool:
        """Check if path should bypass cache."""
        for pattern in self._bypass_patterns:
            if pattern.match(path):
                return True
        return False
    
    def _find_rule(self, method: str, path: str) -> Optional[CacheRule]:
        """Find matching cache rule."""
        for rule in self.rules:
            if rule.matches(method, path):
                return rule
        return None
    
    def _build_cache_key(self, request: Request, rule: CacheRule) -> str:
        """Build cache key for request."""
        parts = [request.method.upper(), request.url.path]
        
        # Add query parameters
        if rule.vary_query_params:
            for param in sorted(rule.vary_query_params):
                value = request.query_params.get(param)
                if value:
                    parts.append(f"{param}={value}")
        else:
            # Include all query params by default
            for key in sorted(request.query_params.keys()):
                parts.append(f"{key}={request.query_params[key]}")
        
        # Add varying headers
        for header in rule.vary_headers:
            value = request.headers.get(header)
            if value:
                parts.append(f"h:{header}={value}")
        
        # Add user ID for private caches
        if rule.private:
            # Extract user from auth (simplified - in real code would decode JWT)
            auth_header = request.headers.get("authorization", "")
            if auth_header.startswith("Bearer "):
                # Hash the token for privacy
                token_hash = hashlib.md5(auth_header.encode()).hexdigest()[:8]
                parts.append(f"user:{token_hash}")
        
        # Hash the key
        key_string = "|".join(parts)
        key_hash = hashlib.md5(key_string.encode()).hexdigest()
        
        return CacheKeyBuilder.build("response", key_hash)
    
    async def _cache_response(
        self,
        cache_key: str,
        request: Request,
        response: Response,
        rule: CacheRule,
        start_time: float,
    ) -> None:
        """Cache the response."""
        try:
            # Read response body
            body = b""
            async for chunk in response.body_iterator:
                body += chunk
            
            # Parse JSON body
            try:
                json_body = json.loads(body.decode())
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Non-JSON response, don't cache
                return
            
            # Generate ETag
            etag = None
            if rule.etag:
                etag = f'"{hashlib.md5(body).hexdigest()}"'
            
            # Calculate response time
            response_time_ms = (time.time() - start_time) * 1000
            
            # Build cache entry
            cache_data = {
                "body": json_body,
                "status_code": response.status_code,
                "etag": etag,
                "cached_at": datetime.utcnow().isoformat(),
                "original_time_ms": response_time_ms,
            }
            
            # Store in cache
            await cache_service.set(
                cache_key,
                cache_data,
                ttl=rule.ttl,
                region=rule.region,
                tags=[f"route:{request.url.path}"],
            )
            
            logger.debug(
                f"Cached response: {request.url.path} "
                f"(ttl={rule.ttl}s, size={len(body)})"
            )
            
        except Exception as e:
            logger.error(f"Failed to cache response: {e}")
    
    def _build_cache_headers(
        self,
        rule: CacheRule,
        etag: Optional[str] = None,
    ) -> Dict[str, str]:
        """Build cache-related response headers."""
        headers = {
            "Cache-Control": ", ".join(rule.cache_control),
        }
        
        if etag:
            headers["ETag"] = etag
        
        if rule.vary_headers:
            headers["Vary"] = ", ".join(rule.vary_headers)
        
        return headers
    
    def get_stats(self) -> Dict[str, Any]:
        """Get middleware statistics."""
        return {
            "middleware": self.stats.to_dict(),
            "cache": cache_service.get_stats(),
        }


class ConditionalCacheMiddleware(BaseHTTPMiddleware):
    """
    Lightweight middleware for conditional request handling.
    
    Only handles ETag/Last-Modified without full response caching.
    Useful for resources where you want 304 support but not caching.
    """
    
    async def dispatch(
        self,
        request: Request,
        call_next: RequestResponseEndpoint,
    ) -> Response:
        """Handle conditional requests."""
        # Only for GET/HEAD
        if request.method.upper() not in {"GET", "HEAD"}:
            return await call_next(request)
        
        response = await call_next(request)
        
        # Get ETag from response
        etag = response.headers.get("etag")
        last_modified = response.headers.get("last-modified")
        
        # Check If-None-Match
        if etag:
            if_none_match = request.headers.get("if-none-match")
            if if_none_match and if_none_match == etag:
                return Response(status_code=304)
        
        # Check If-Modified-Since
        if last_modified:
            if_modified = request.headers.get("if-modified-since")
            if if_modified and if_modified == last_modified:
                return Response(status_code=304)
        
        return response


# ==========================================================================
# Cache Control Utilities
# ==========================================================================

def no_cache_response(response: Response) -> Response:
    """Mark response as non-cacheable."""
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response


def cache_response(
    response: Response,
    max_age: int = 300,
    private: bool = True,
    etag: Optional[str] = None,
) -> Response:
    """Add cache headers to response."""
    directives = []
    
    if private:
        directives.append("private")
    else:
        directives.append("public")
    
    directives.append(f"max-age={max_age}")
    
    response.headers["Cache-Control"] = ", ".join(directives)
    
    if etag:
        response.headers["ETag"] = etag
    
    return response


def generate_etag(content: Any) -> str:
    """Generate ETag for content."""
    if isinstance(content, str):
        data = content.encode()
    elif isinstance(content, bytes):
        data = content
    else:
        data = json.dumps(content, sort_keys=True).encode()
    
    return f'"{hashlib.md5(data).hexdigest()}"'


# ==========================================================================
# Exports
# ==========================================================================

__all__ = [
    "ResponseCacheMiddleware",
    "ConditionalCacheMiddleware",
    "CacheRule",
    "CacheControl",
    "ResponseCacheStats",
    "no_cache_response",
    "cache_response",
    "generate_etag",
]
