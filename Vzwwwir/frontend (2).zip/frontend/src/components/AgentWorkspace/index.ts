/**
 * CHE·NU V51 — AGENT WORKSPACE COMPONENTS
 * ========================================
 */

export { default as AgentWorkspacePage } from './AgentWorkspacePage';
export type { AgentWorkspacePageProps } from './AgentWorkspacePage';
