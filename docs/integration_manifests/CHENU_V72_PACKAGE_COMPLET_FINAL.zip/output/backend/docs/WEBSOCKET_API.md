# CHE·NU™ WebSocket API Reference

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║                      CHE·NU™ — REAL-TIME WEBSOCKET API                              ║
║                                                                                      ║
║                    Version: 2.0 | Date: January 2026 | Status: CANON               ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

## Overview

CHE·NU provides real-time updates via WebSocket connections. This enables:
- Live Thread event updates
- Checkpoint notifications
- Agent execution status
- Presence indicators
- Collaborative editing

## Connection

### General Connection

```
ws://localhost:8000/ws/connect?token=<access_token>
```

### Thread-Specific Connection

```
ws://localhost:8000/ws/thread/{thread_id}?token=<access_token>
```

Automatically subscribes to all events for the specified thread.

## Authentication

WebSocket connections require a valid JWT token passed as a query parameter:

```javascript
const ws = new WebSocket(`ws://localhost:8000/ws/connect?token=${accessToken}`);
```

If the token is invalid or expired, the connection will be closed with code `4001`.

## Connection Lifecycle

### 1. Connection Established

When connected, server sends:

```json
{
  "type": "system",
  "event": "connection.established",
  "data": {
    "connection_id": "uuid",
    "user_id": "uuid",
    "connected_at": "2026-01-07T10:00:00Z"
  }
}
```

### 2. Heartbeat (Ping/Pong)

Send periodic pings to keep connection alive:

```json
{"action": "ping"}
```

Server responds:

```json
{
  "type": "system",
  "event": "pong",
  "data": {
    "timestamp": "2026-01-07T10:00:00Z"
  }
}
```

Recommended ping interval: 30 seconds.

### 3. Connection Closed

Server may close connection with codes:
- `1000` - Normal closure
- `4001` - Authentication failed
- `4002` - Token expired
- `4003` - Rate limited
- `4004` - Server error

## Channel Subscription

### Subscribe to Channel

```json
{
  "action": "subscribe",
  "channel": "thread:123e4567-e89b-12d3-a456-426614174000"
}
```

Server confirms:

```json
{
  "type": "system",
  "event": "subscribed",
  "data": {
    "channel": "thread:123e4567-e89b-12d3-a456-426614174000",
    "subscribed_at": "2026-01-07T10:00:00Z"
  }
}
```

### Unsubscribe from Channel

```json
{
  "action": "unsubscribe",
  "channel": "thread:123e4567-e89b-12d3-a456-426614174000"
}
```

Server confirms:

```json
{
  "type": "system",
  "event": "unsubscribed",
  "data": {
    "channel": "thread:123e4567-e89b-12d3-a456-426614174000"
  }
}
```

## Channel Types

### Thread Channels

Subscribe to Thread events:

```
thread:{thread_id}
```

Events:
- `thread.created`
- `thread.updated`
- `thread.archived`
- `thread.event_appended`
- `thread.snapshot_created`
- `thread.action_created`
- `thread.action_completed`
- `thread.decision_recorded`

### Sphere Channels

Subscribe to Sphere events:

```
sphere:{sphere_id}
```

Events:
- `sphere.updated`
- `sphere.thread_created`
- `sphere.quick_capture_added`

### User Channels

Subscribe to user-specific events:

```
user:{user_id}
```

Events:
- `checkpoint.created`
- `checkpoint.resolved`
- `agent.execution_started`
- `agent.execution_completed`
- `notification.created`

### Global Channels

Subscribe to system-wide events:

```
global:system
```

Events:
- `system.maintenance`
- `system.announcement`

## Event Format

All events follow this format:

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "thread.event_appended",
  "data": {
    // Event-specific data
  },
  "timestamp": "2026-01-07T10:00:00Z",
  "sequence": 12345
}
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `type` | string | Always `"event"` for events |
| `channel` | string | Channel that sent the event |
| `event_type` | string | Type of event |
| `data` | object | Event-specific payload |
| `timestamp` | string | ISO 8601 timestamp |
| `sequence` | number | Monotonically increasing sequence number |

## Event Types

### Thread Events

#### thread.created

```json
{
  "type": "event",
  "channel": "sphere:uuid",
  "event_type": "thread.created",
  "data": {
    "thread": {
      "id": "uuid",
      "founding_intent": "Build a finance tracker",
      "thread_type": "personal",
      "sphere_id": "uuid",
      "status": "active",
      "created_at": "2026-01-07T10:00:00Z",
      "created_by": "uuid"
    }
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### thread.event_appended

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "thread.event_appended",
  "data": {
    "event": {
      "id": "uuid",
      "event_type": "note.added",
      "timestamp": "2026-01-07T10:00:00Z",
      "data": {
        "content": "Note content",
        "tags": ["tag1", "tag2"]
      },
      "actor_id": "uuid"
    },
    "thread_updated_at": "2026-01-07T10:00:00Z",
    "event_count": 16
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### thread.action_completed

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "thread.action_completed",
  "data": {
    "action": {
      "id": "uuid",
      "title": "Design database",
      "status": "completed",
      "completed_at": "2026-01-07T10:00:00Z",
      "completed_by": "uuid"
    }
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

### Checkpoint Events

#### checkpoint.created

```json
{
  "type": "event",
  "channel": "user:uuid",
  "event_type": "checkpoint.created",
  "data": {
    "checkpoint": {
      "id": "uuid",
      "type": "governance",
      "status": "pending",
      "reason": "Agent execution requires approval",
      "created_at": "2026-01-07T10:00:00Z",
      "expires_at": "2026-01-07T11:00:00Z",
      "context": {
        "agent_id": "uuid",
        "agent_name": "Note Organizer",
        "action": "execute"
      }
    }
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### checkpoint.resolved

```json
{
  "type": "event",
  "channel": "user:uuid",
  "event_type": "checkpoint.resolved",
  "data": {
    "checkpoint": {
      "id": "uuid",
      "status": "approved",
      "resolved_at": "2026-01-07T10:05:00Z",
      "resolved_by": "uuid"
    },
    "result": {
      // Execution result if approved
    }
  },
  "timestamp": "2026-01-07T10:05:00Z"
}
```

### Agent Events

#### agent.execution_started

```json
{
  "type": "event",
  "channel": "user:uuid",
  "event_type": "agent.execution_started",
  "data": {
    "execution_id": "uuid",
    "agent_id": "uuid",
    "agent_name": "Note Organizer",
    "started_at": "2026-01-07T10:00:00Z",
    "estimated_duration_ms": 2000
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### agent.execution_completed

```json
{
  "type": "event",
  "channel": "user:uuid",
  "event_type": "agent.execution_completed",
  "data": {
    "execution_id": "uuid",
    "agent_id": "uuid",
    "status": "completed",
    "output": {
      // Agent output
    },
    "tokens_used": 150,
    "duration_ms": 1500,
    "completed_at": "2026-01-07T10:00:01.500Z"
  },
  "timestamp": "2026-01-07T10:00:01.500Z"
}
```

### XR Events

#### xr.user_joined

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "xr.user_joined",
  "data": {
    "user_id": "uuid",
    "display_name": "John",
    "avatar_url": "https://...",
    "position": {"x": 0, "y": 0, "z": 0}
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### xr.user_moved

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "xr.user_moved",
  "data": {
    "user_id": "uuid",
    "position": {"x": 1.5, "y": 0, "z": -2.0},
    "rotation": {"x": 0, "y": 45, "z": 0}
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

### Presence Events

#### presence.user_online

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "presence.user_online",
  "data": {
    "user_id": "uuid",
    "display_name": "John",
    "online_at": "2026-01-07T10:00:00Z"
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

#### presence.user_offline

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "presence.user_offline",
  "data": {
    "user_id": "uuid",
    "offline_at": "2026-01-07T10:30:00Z"
  },
  "timestamp": "2026-01-07T10:30:00Z"
}
```

#### presence.user_typing

```json
{
  "type": "event",
  "channel": "thread:uuid",
  "event_type": "presence.user_typing",
  "data": {
    "user_id": "uuid",
    "is_typing": true
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

## Client Messages

### Available Actions

| Action | Description |
|--------|-------------|
| `ping` | Heartbeat |
| `subscribe` | Subscribe to channel |
| `unsubscribe` | Unsubscribe from channel |
| `presence` | Update presence status |

### Presence Update

```json
{
  "action": "presence",
  "channel": "thread:uuid",
  "data": {
    "status": "active",
    "position": {"x": 1.0, "y": 0, "z": -1.5}
  }
}
```

## Error Messages

### Error Format

```json
{
  "type": "error",
  "code": "SUBSCRIPTION_FAILED",
  "message": "Cannot subscribe to channel: permission denied",
  "data": {
    "channel": "thread:uuid"
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

### Error Codes

| Code | Description |
|------|-------------|
| `INVALID_MESSAGE` | Message format invalid |
| `UNKNOWN_ACTION` | Unknown action type |
| `SUBSCRIPTION_FAILED` | Cannot subscribe to channel |
| `PERMISSION_DENIED` | No access to resource |
| `RATE_LIMITED` | Too many messages |
| `INTERNAL_ERROR` | Server error |

## Rate Limiting

- Maximum 50 messages per minute
- Maximum 10 subscriptions per connection
- Maximum 5 connections per user

When rate limited, server sends:

```json
{
  "type": "error",
  "code": "RATE_LIMITED",
  "message": "Too many messages, please slow down",
  "data": {
    "retry_after_ms": 5000
  },
  "timestamp": "2026-01-07T10:00:00Z"
}
```

## Client Implementation Examples

### JavaScript/TypeScript

```typescript
class ChenuWebSocket {
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private pingInterval: NodeJS.Timeout | null = null;
  
  constructor(private token: string, private baseUrl: string) {}
  
  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      const url = `${this.baseUrl}/ws/connect?token=${this.token}`;
      this.ws = new WebSocket(url);
      
      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.reconnectAttempts = 0;
        this.startPing();
        resolve();
      };
      
      this.ws.onclose = (event) => {
        console.log('WebSocket closed:', event.code);
        this.stopPing();
        
        if (event.code !== 1000 && this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnect();
        }
      };
      
      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        reject(error);
      };
      
      this.ws.onmessage = (event) => {
        const message = JSON.parse(event.data);
        this.handleMessage(message);
      };
    });
  }
  
  private startPing() {
    this.pingInterval = setInterval(() => {
      this.send({ action: 'ping' });
    }, 30000);
  }
  
  private stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }
  
  private reconnect() {
    this.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
    console.log(`Reconnecting in ${delay}ms...`);
    setTimeout(() => this.connect(), delay);
  }
  
  private handleMessage(message: any) {
    switch (message.type) {
      case 'system':
        this.handleSystemMessage(message);
        break;
      case 'event':
        this.handleEvent(message);
        break;
      case 'error':
        this.handleError(message);
        break;
    }
  }
  
  private handleSystemMessage(message: any) {
    console.log('System message:', message.event);
  }
  
  private handleEvent(message: any) {
    // Emit event to subscribers
    console.log('Event:', message.event_type, message.data);
  }
  
  private handleError(message: any) {
    console.error('WebSocket error:', message.code, message.message);
  }
  
  subscribe(channel: string) {
    this.send({ action: 'subscribe', channel });
  }
  
  unsubscribe(channel: string) {
    this.send({ action: 'unsubscribe', channel });
  }
  
  private send(message: any) {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    }
  }
  
  disconnect() {
    this.stopPing();
    this.ws?.close(1000);
    this.ws = null;
  }
}

// Usage
const ws = new ChenuWebSocket(accessToken, 'ws://localhost:8000');
await ws.connect();
ws.subscribe('thread:123e4567-e89b-12d3-a456-426614174000');
```

### React Hook

```typescript
import { useEffect, useRef, useCallback, useState } from 'react';

interface UseChenuWebSocketOptions {
  token: string;
  baseUrl: string;
  channels?: string[];
  onEvent?: (event: any) => void;
}

export function useChenuWebSocket(options: UseChenuWebSocketOptions) {
  const { token, baseUrl, channels = [], onEvent } = options;
  const wsRef = useRef<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const connect = useCallback(() => {
    const url = `${baseUrl}/ws/connect?token=${token}`;
    const ws = new WebSocket(url);
    
    ws.onopen = () => {
      setConnected(true);
      setError(null);
      
      // Subscribe to channels
      channels.forEach(channel => {
        ws.send(JSON.stringify({ action: 'subscribe', channel }));
      });
    };
    
    ws.onclose = () => {
      setConnected(false);
    };
    
    ws.onerror = () => {
      setError('WebSocket connection failed');
    };
    
    ws.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === 'event' && onEvent) {
        onEvent(message);
      }
    };
    
    wsRef.current = ws;
    
    return () => {
      ws.close();
    };
  }, [token, baseUrl, channels, onEvent]);
  
  useEffect(() => {
    const cleanup = connect();
    return cleanup;
  }, [connect]);
  
  const subscribe = useCallback((channel: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'subscribe', channel }));
    }
  }, []);
  
  const unsubscribe = useCallback((channel: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'unsubscribe', channel }));
    }
  }, []);
  
  return {
    connected,
    error,
    subscribe,
    unsubscribe,
  };
}

// Usage in component
function ThreadPage({ threadId }: { threadId: string }) {
  const [events, setEvents] = useState<any[]>([]);
  
  const { connected } = useChenuWebSocket({
    token: accessToken,
    baseUrl: 'ws://localhost:8000',
    channels: [`thread:${threadId}`],
    onEvent: (event) => {
      setEvents(prev => [...prev, event]);
    },
  });
  
  return (
    <div>
      <p>Connected: {connected ? 'Yes' : 'No'}</p>
      <ul>
        {events.map((event, i) => (
          <li key={i}>{event.event_type}</li>
        ))}
      </ul>
    </div>
  );
}
```

### Python (asyncio)

```python
import asyncio
import json
import websockets

class ChenuWebSocket:
    def __init__(self, token: str, base_url: str):
        self.token = token
        self.base_url = base_url
        self.ws = None
        
    async def connect(self):
        url = f"{self.base_url}/ws/connect?token={self.token}"
        self.ws = await websockets.connect(url)
        
        # Start message handler
        asyncio.create_task(self._message_handler())
        
        # Start ping task
        asyncio.create_task(self._ping_task())
        
    async def _message_handler(self):
        async for message in self.ws:
            data = json.loads(message)
            await self._handle_message(data)
            
    async def _handle_message(self, message: dict):
        msg_type = message.get("type")
        
        if msg_type == "event":
            print(f"Event: {message['event_type']}")
            # Handle event
        elif msg_type == "error":
            print(f"Error: {message['code']} - {message['message']}")
        elif msg_type == "system":
            print(f"System: {message['event']}")
            
    async def _ping_task(self):
        while self.ws:
            await asyncio.sleep(30)
            await self.send({"action": "ping"})
            
    async def subscribe(self, channel: str):
        await self.send({"action": "subscribe", "channel": channel})
        
    async def unsubscribe(self, channel: str):
        await self.send({"action": "unsubscribe", "channel": channel})
        
    async def send(self, message: dict):
        if self.ws:
            await self.ws.send(json.dumps(message))
            
    async def close(self):
        if self.ws:
            await self.ws.close()
            self.ws = None

# Usage
async def main():
    ws = ChenuWebSocket(token="your_token", base_url="ws://localhost:8000")
    await ws.connect()
    await ws.subscribe("thread:123e4567-e89b-12d3-a456-426614174000")
    
    # Keep running
    await asyncio.sleep(3600)
    await ws.close()

asyncio.run(main())
```

## Best Practices

### 1. Connection Management

- Implement automatic reconnection with exponential backoff
- Handle token refresh before expiration
- Close connections gracefully

### 2. Event Handling

- Use sequence numbers to detect missed events
- Implement event deduplication
- Handle events idempotently

### 3. Performance

- Subscribe only to needed channels
- Unsubscribe when leaving views
- Batch UI updates

### 4. Error Handling

- Handle all error codes appropriately
- Show user-friendly error messages
- Log errors for debugging

---

```
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                      ║
║            "GOVERNANCE > EXECUTION • HUMANS > AUTOMATION"                           ║
║                                                                                      ║
║                     CHE·NU™ — Built for Decades                                     ║
║                                                                                      ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
```

---

**Version:** 2.0  
**Date:** January 2026  
**Status:** CANON  

© 2026 CHE·NU™ — All Rights Reserved
