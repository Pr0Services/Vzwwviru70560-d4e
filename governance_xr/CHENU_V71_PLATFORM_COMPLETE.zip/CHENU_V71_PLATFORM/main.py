"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                          CHE·NU™ V71 PLATFORM                                ║
║                                                                              ║
║                  Governed Intelligence Operating System                       ║
║                                                                              ║
║                        GOUVERNANCE > EXÉCUTION                               ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

Main entry point for the CHE·NU platform.

Version: 71.0.0
Date: January 2026
"""

import os
import sys
import logging
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("chenu")


# =============================================================================
# APPLICATION LIFESPAN
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    logger.info("🚀 CHE·NU™ V71 Platform starting...")
    logger.info("📋 Loading engines and modules...")
    
    # Startup
    yield
    
    # Shutdown
    logger.info("👋 CHE·NU™ V71 Platform shutting down...")


# =============================================================================
# APPLICATION FACTORY
# =============================================================================

def create_app() -> FastAPI:
    """
    Create the CHE·NU V71 Platform application.
    
    Integrates:
    - 15 Verticals (V68)
    - 14 GP2 Modules (26-39)
    - 9 Core Engines
    - Full Governance Stack
    """
    
    app = FastAPI(
        title="CHE·NU™ V71 Platform",
        description="""
        Governed Intelligence Operating System
        
        ## Core Principles
        - **GOUVERNANCE > EXÉCUTION**: All actions require governance approval
        - **HITL Required**: Human-In-The-Loop for sensitive operations
        - **Identity Isolation**: Strict cross-identity boundaries
        - **Audit Trail**: Complete traceability for all actions
        
        ## Architecture
        - 15 Verticals (Business, Creative, Education, etc.)
        - 14 Advanced Modules (GP2: Transmission, Heritage, Culture, etc.)
        - 9 Core Engines (Workspace, DataSpace, Nova, etc.)
        - Full Kubernetes-ready infrastructure
        """,
        version="71.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Root endpoint
    @app.get("/")
    async def root():
        return {
            "name": "CHE·NU™ V71 Platform",
            "version": "71.0.0",
            "status": "healthy",
            "governance": {
                "governance_over_execution": True,
                "hitl_required": True,
                "identity_isolation": True,
                "audit_trail": True,
            },
            "architecture": {
                "verticals": 15,
                "gp2_modules": 14,
                "engines": 9,
                "endpoints": "500+",
            },
            "endpoints": {
                "v1": "/api/v1",
                "v2": "/api/v2",
                "health": "/health",
                "docs": "/docs",
            }
        }
    
    # Health check
    @app.get("/health")
    async def health():
        return {
            "status": "healthy",
            "version": "71.0.0",
            "components": {
                "api": "up",
                "engines": "up",
                "governance": "up",
                "database": "up",
            }
        }
    
    # Import and include routers
    try:
        from backend.api.v1.main import app as v1_app
        app.mount("/api/v1", v1_app)
        logger.info("✅ API v1 mounted")
    except ImportError as e:
        logger.warning(f"⚠️ API v1 not available: {e}")
    
    # API v2 - Current unified API
    try:
        from backend.api.v2 import router as v2_router
        app.include_router(v2_router, prefix="/api/v2", tags=["API V2"])
        logger.info("✅ API v2 mounted (15 verticals, 14 modules, 9 engines)")
    except ImportError as e:
        logger.warning(f"⚠️ API v2 not available: {e}")
    
    logger.info("✅ CHE·NU™ V71 Platform initialized")
    
    return app


# Create app instance
app = create_app()


# =============================================================================
# ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("PORT", "8000"))
    host = os.getenv("HOST", "0.0.0.0")
    
    logger.info(f"🌐 Starting server on {host}:{port}")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True,
        log_level="info",
    )
