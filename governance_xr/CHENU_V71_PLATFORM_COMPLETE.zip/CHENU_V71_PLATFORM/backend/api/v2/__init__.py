"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                       CHE·NU™ V71 API V2 ROUTER                              ║
║                                                                              ║
║                  Unified API for all Verticals & Engines                      ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

API v2 provides:
- 15 Vertical endpoints
- 9 Engine endpoints
- 14 GP2 Module endpoints
- Unified governance layer

Base URL: /api/v2

GOUVERNANCE > EXÉCUTION
"""

from fastapi import FastAPI, APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from datetime import datetime
from uuid import uuid4
from typing import Dict, Any, List
import logging

logger = logging.getLogger("chenu.api.v2")

# =============================================================================
# API V2 APPLICATION
# =============================================================================

app = FastAPI(
    title="CHE·NU™ API V2",
    description="Governed Intelligence Operating System - API V2",
    version="2.0.0",
)

# Main router
router = APIRouter()


# =============================================================================
# HEALTH & INFO ENDPOINTS
# =============================================================================

@router.get("/")
async def api_v2_root():
    """API V2 root endpoint."""
    return {
        "api": "v2",
        "version": "2.0.0",
        "status": "healthy",
        "governance": True,
        "endpoints": {
            "verticals": "/api/v2/verticals",
            "engines": "/api/v2/engines",
            "modules": "/api/v2/modules",
            "governance": "/api/v2/governance",
        }
    }


@router.get("/health")
async def api_v2_health():
    """API V2 health check."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
    }


# =============================================================================
# VERTICALS ENDPOINTS
# =============================================================================

@router.get("/verticals")
async def list_verticals():
    """List all available verticals."""
    from backend.verticals import VERTICAL_REGISTRY
    return {
        "success": True,
        "data": {
            "count": len(VERTICAL_REGISTRY),
            "verticals": [
                {
                    "id": vid,
                    "name": v["name"],
                    "description": v["description"],
                    "status": v["status"],
                    "endpoints": v["endpoints"],
                    "coverage": v["coverage"],
                }
                for vid, v in VERTICAL_REGISTRY.items()
            ]
        }
    }


@router.get("/verticals/{vertical_id}")
async def get_vertical(vertical_id: str):
    """Get vertical details."""
    from backend.verticals import get_vertical as _get_vertical
    vertical = _get_vertical(vertical_id.upper())
    if not vertical:
        raise HTTPException(status_code=404, detail=f"Vertical {vertical_id} not found")
    return {
        "success": True,
        "data": {
            "id": vertical_id.upper(),
            **vertical
        }
    }


# =============================================================================
# ENGINES ENDPOINTS
# =============================================================================

@router.get("/engines")
async def list_engines():
    """List all available engines."""
    from backend.engines import ENGINE_REGISTRY
    return {
        "success": True,
        "data": {
            "count": len(ENGINE_REGISTRY),
            "engines": [
                {
                    "id": eid,
                    "name": e["name"],
                    "description": e["description"],
                    "status": e["status"],
                    "version": e["version"],
                }
                for eid, e in ENGINE_REGISTRY.items()
            ]
        }
    }


@router.get("/engines/{engine_id}")
async def get_engine(engine_id: str):
    """Get engine details."""
    from backend.engines import get_engine as _get_engine
    engine = _get_engine(engine_id.lower())
    if not engine:
        raise HTTPException(status_code=404, detail=f"Engine {engine_id} not found")
    return {
        "success": True,
        "data": {
            "id": engine_id.lower(),
            **engine
        }
    }


# =============================================================================
# MODULES ENDPOINTS (GP2)
# =============================================================================

@router.get("/modules")
async def list_modules():
    """List all GP2 modules."""
    from backend.modules import MODULE_REGISTRY
    return {
        "success": True,
        "data": {
            "count": len(MODULE_REGISTRY),
            "modules": [
                {
                    "id": mid,
                    "name": m["name"],
                    "description": m["description"],
                    "status": m["status"],
                    "version": m["version"],
                }
                for mid, m in MODULE_REGISTRY.items()
            ]
        }
    }


@router.get("/modules/{module_id}")
async def get_module(module_id: str):
    """Get module details."""
    from backend.modules import get_module as _get_module
    module = _get_module(module_id.lower())
    if not module:
        raise HTTPException(status_code=404, detail=f"Module {module_id} not found")
    return {
        "success": True,
        "data": {
            "id": module_id.lower(),
            **module
        }
    }


# =============================================================================
# GOVERNANCE ENDPOINTS
# =============================================================================

@router.get("/governance/rules")
async def get_governance_rules():
    """Get governance rules (7 R&D Rules)."""
    from backend import RND_RULES
    return {
        "success": True,
        "data": {
            "count": len(RND_RULES),
            "rules": [
                {"id": rid, "description": desc}
                for rid, desc in RND_RULES.items()
            ]
        }
    }


@router.get("/governance/hitl-actions")
async def get_hitl_actions():
    """Get HITL (Human-In-The-Loop) required actions."""
    from backend import HITL_ACTIONS
    return {
        "success": True,
        "data": {
            "count": len(HITL_ACTIONS),
            "actions": HITL_ACTIONS
        }
    }


@router.get("/governance/memory-laws")
async def get_memory_laws():
    """Get Ten Laws of Memory."""
    from backend.engines import TEN_LAWS_OF_MEMORY
    return {
        "success": True,
        "data": {
            "count": len(TEN_LAWS_OF_MEMORY),
            "laws": [
                {"id": lid, "description": desc}
                for lid, desc in TEN_LAWS_OF_MEMORY.items()
            ]
        }
    }


# =============================================================================
# STATISTICS ENDPOINT
# =============================================================================

@router.get("/stats")
async def get_platform_stats():
    """Get platform statistics."""
    from backend.verticals import get_total_endpoints, get_total_tests, VERTICAL_REGISTRY
    from backend.engines import ENGINE_REGISTRY
    from backend.modules import MODULE_REGISTRY
    
    return {
        "success": True,
        "data": {
            "version": "71.0.0",
            "verticals": {
                "count": len(VERTICAL_REGISTRY),
                "total_endpoints": get_total_endpoints(),
                "total_tests": get_total_tests(),
            },
            "engines": {
                "count": len(ENGINE_REGISTRY),
            },
            "modules": {
                "count": len(MODULE_REGISTRY),
            },
            "governance": {
                "rules": 7,
                "hitl_actions": 8,
                "memory_laws": 10,
            }
        }
    }


# =============================================================================
# INCLUDE ROUTER IN APP
# =============================================================================

app.include_router(router)

__all__ = ["app", "router"]
