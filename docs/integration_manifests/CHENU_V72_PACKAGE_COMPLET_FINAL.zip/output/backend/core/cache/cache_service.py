"""
CHE·NU™ Cache Service — Production-Grade Caching Layer
=====================================================

Comprehensive caching system with:
- Redis-backed caching with TTL
- Tag-based cache invalidation
- Pattern-based cache clearing
- Cache warming strategies
- Metrics and monitoring
- R&D Rule #6 compliant (full traceability)

Author: CHE·NU Backend Team
Version: 1.0.0
"""

from typing import Optional, Any, Dict, List, Callable, TypeVar, Generic, Union
from datetime import datetime, timedelta
from uuid import UUID
import json
import hashlib
import asyncio
import logging
import functools
from enum import Enum
from dataclasses import dataclass, field
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Type variable for generic cache
T = TypeVar('T')


class CacheStrategy(str, Enum):
    """Cache invalidation strategies."""
    TTL_ONLY = "ttl_only"           # Only expire on TTL
    WRITE_THROUGH = "write_through"  # Update cache on write
    WRITE_BEHIND = "write_behind"    # Async cache update
    REFRESH_AHEAD = "refresh_ahead"  # Refresh before expiry


class CacheRegion(str, Enum):
    """Predefined cache regions with default TTLs."""
    # Short-lived (1-5 minutes)
    HOT = "hot"                      # Frequently accessed, short TTL (1 min)
    SESSION = "session"              # Session data (5 min)
    
    # Medium (15-60 minutes)
    WARM = "warm"                    # Regular data (15 min)
    API_RESPONSE = "api_response"    # Cached API responses (30 min)
    
    # Long-lived (hours-days)
    COLD = "cold"                    # Infrequently accessed (1 hour)
    STATIC = "static"                # Static data (24 hours)
    
    # Special
    IMMORTAL = "immortal"            # Never expires (until invalidated)


# Default TTLs by region (in seconds)
REGION_TTLS: Dict[CacheRegion, int] = {
    CacheRegion.HOT: 60,
    CacheRegion.SESSION: 300,
    CacheRegion.WARM: 900,
    CacheRegion.API_RESPONSE: 1800,
    CacheRegion.COLD: 3600,
    CacheRegion.STATIC: 86400,
    CacheRegion.IMMORTAL: 0,  # 0 = no TTL
}


@dataclass
class CacheEntry:
    """Represents a cached entry with metadata."""
    key: str
    value: Any
    created_at: datetime
    expires_at: Optional[datetime]
    tags: List[str] = field(default_factory=list)
    region: CacheRegion = CacheRegion.WARM
    hits: int = 0
    last_accessed: Optional[datetime] = None
    version: int = 1
    
    def is_expired(self) -> bool:
        """Check if entry has expired."""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at
    
    def touch(self) -> None:
        """Update access metadata."""
        self.hits += 1
        self.last_accessed = datetime.utcnow()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage."""
        return {
            "key": self.key,
            "value": self.value,
            "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "tags": self.tags,
            "region": self.region.value,
            "hits": self.hits,
            "last_accessed": self.last_accessed.isoformat() if self.last_accessed else None,
            "version": self.version,
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CacheEntry":
        """Create from dictionary."""
        return cls(
            key=data["key"],
            value=data["value"],
            created_at=datetime.fromisoformat(data["created_at"]),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            tags=data.get("tags", []),
            region=CacheRegion(data.get("region", "warm")),
            hits=data.get("hits", 0),
            last_accessed=datetime.fromisoformat(data["last_accessed"]) if data.get("last_accessed") else None,
            version=data.get("version", 1),
        )


@dataclass
class CacheStats:
    """Cache statistics for monitoring."""
    hits: int = 0
    misses: int = 0
    sets: int = 0
    deletes: int = 0
    invalidations: int = 0
    evictions: int = 0
    errors: int = 0
    bytes_stored: int = 0
    
    @property
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        return (self.hits / total * 100) if total > 0 else 0.0
    
    @property
    def total_operations(self) -> int:
        """Total cache operations."""
        return self.hits + self.misses + self.sets + self.deletes
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "hits": self.hits,
            "misses": self.misses,
            "sets": self.sets,
            "deletes": self.deletes,
            "invalidations": self.invalidations,
            "evictions": self.evictions,
            "errors": self.errors,
            "bytes_stored": self.bytes_stored,
            "hit_rate": round(self.hit_rate, 2),
            "total_operations": self.total_operations,
        }


class CacheKeyBuilder:
    """Builds consistent cache keys."""
    
    NAMESPACE = "chenu"
    SEPARATOR = ":"
    
    @classmethod
    def build(
        cls,
        prefix: str,
        *args,
        **kwargs
    ) -> str:
        """Build a cache key from components."""
        parts = [cls.NAMESPACE, prefix]
        
        # Add positional args
        for arg in args:
            if isinstance(arg, UUID):
                parts.append(str(arg))
            elif isinstance(arg, (list, tuple)):
                parts.append("-".join(str(x) for x in arg))
            elif isinstance(arg, dict):
                parts.append(cls._hash_dict(arg))
            else:
                parts.append(str(arg))
        
        # Add keyword args (sorted for consistency)
        if kwargs:
            for key in sorted(kwargs.keys()):
                value = kwargs[key]
                if value is not None:
                    parts.append(f"{key}={value}")
        
        return cls.SEPARATOR.join(parts)
    
    @classmethod
    def _hash_dict(cls, d: Dict) -> str:
        """Create hash of dictionary for key."""
        serialized = json.dumps(d, sort_keys=True)
        return hashlib.md5(serialized.encode()).hexdigest()[:8]
    
    @classmethod
    def pattern(cls, prefix: str, *args) -> str:
        """Build pattern for cache key matching (for invalidation)."""
        parts = [cls.NAMESPACE, prefix]
        parts.extend(str(arg) for arg in args if arg is not None)
        parts.append("*")
        return cls.SEPARATOR.join(parts)
    
    # Predefined key builders
    @classmethod
    def thread(cls, thread_id: UUID) -> str:
        return cls.build("thread", thread_id)
    
    @classmethod
    def thread_events(cls, thread_id: UUID, page: int = 0) -> str:
        return cls.build("thread", thread_id, "events", page=page)
    
    @classmethod
    def thread_snapshot(cls, thread_id: UUID) -> str:
        return cls.build("thread", thread_id, "snapshot")
    
    @classmethod
    def sphere(cls, sphere_id: UUID) -> str:
        return cls.build("sphere", sphere_id)
    
    @classmethod
    def user_spheres(cls, user_id: UUID) -> str:
        return cls.build("user", user_id, "spheres")
    
    @classmethod
    def user_threads(cls, user_id: UUID, sphere_id: Optional[UUID] = None) -> str:
        if sphere_id:
            return cls.build("user", user_id, "threads", sphere_id=str(sphere_id))
        return cls.build("user", user_id, "threads")
    
    @classmethod
    def agent(cls, agent_id: str) -> str:
        return cls.build("agent", agent_id)
    
    @classmethod
    def agent_config(cls, user_id: UUID, agent_id: str) -> str:
        return cls.build("user", user_id, "agent", agent_id)
    
    @classmethod
    def xr_blueprint(cls, thread_id: UUID) -> str:
        return cls.build("xr", thread_id, "blueprint")
    
    @classmethod
    def xr_maturity(cls, thread_id: UUID) -> str:
        return cls.build("xr", thread_id, "maturity")
    
    @classmethod
    def api_response(cls, method: str, path: str, params_hash: str) -> str:
        return cls.build("api", method, path, params_hash)


class CacheService:
    """
    Production-grade caching service.
    
    Features:
    - Redis-backed storage
    - Tag-based invalidation
    - Region-based TTL
    - Metrics and monitoring
    - Async operations
    """
    
    def __init__(self, redis_client=None):
        """Initialize cache service."""
        self._redis = redis_client  # Injected Redis client
        self._local_cache: Dict[str, CacheEntry] = {}  # L1 cache
        self._stats = CacheStats()
        self._tag_keys: Dict[str, set] = {}  # tag -> set of keys
        self._use_local = redis_client is None
        
        logger.info(
            f"CacheService initialized (mode={'local' if self._use_local else 'redis'})"
        )
    
    def set_redis(self, redis_client) -> None:
        """Set Redis client (for late initialization)."""
        self._redis = redis_client
        self._use_local = False
        logger.info("CacheService switched to Redis mode")
    
    # ==========================================================================
    # Core Operations
    # ==========================================================================
    
    async def get(
        self,
        key: str,
        default: Any = None
    ) -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            key: Cache key
            default: Default if not found
            
        Returns:
            Cached value or default
        """
        try:
            entry = await self._get_entry(key)
            
            if entry is None:
                self._stats.misses += 1
                return default
            
            if entry.is_expired():
                await self.delete(key)
                self._stats.misses += 1
                return default
            
            entry.touch()
            self._stats.hits += 1
            
            logger.debug(f"Cache HIT: {key}")
            return entry.value
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache get error: {e}")
            return default
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None,
        region: CacheRegion = CacheRegion.WARM,
        tags: Optional[List[str]] = None
    ) -> bool:
        """
        Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time-to-live in seconds (overrides region default)
            region: Cache region
            tags: Tags for invalidation
            
        Returns:
            True if successful
        """
        try:
            # Calculate TTL
            actual_ttl = ttl if ttl is not None else REGION_TTLS.get(region, 900)
            expires_at = None
            if actual_ttl > 0:
                expires_at = datetime.utcnow() + timedelta(seconds=actual_ttl)
            
            # Create entry
            entry = CacheEntry(
                key=key,
                value=value,
                created_at=datetime.utcnow(),
                expires_at=expires_at,
                tags=tags or [],
                region=region,
            )
            
            # Store
            await self._set_entry(key, entry, actual_ttl)
            
            # Update tag index
            if tags:
                for tag in tags:
                    if tag not in self._tag_keys:
                        self._tag_keys[tag] = set()
                    self._tag_keys[tag].add(key)
            
            self._stats.sets += 1
            logger.debug(f"Cache SET: {key} (ttl={actual_ttl}s, region={region.value})")
            
            return True
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache set error: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache."""
        try:
            if self._use_local:
                if key in self._local_cache:
                    del self._local_cache[key]
            else:
                await self._redis.delete(key)
            
            self._stats.deletes += 1
            logger.debug(f"Cache DELETE: {key}")
            return True
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache delete error: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache."""
        try:
            if self._use_local:
                return key in self._local_cache
            return await self._redis.exists(key)
        except Exception as e:
            self._stats.errors += 1
            return False
    
    async def get_or_set(
        self,
        key: str,
        factory: Callable[[], Any],
        ttl: Optional[int] = None,
        region: CacheRegion = CacheRegion.WARM,
        tags: Optional[List[str]] = None
    ) -> Any:
        """
        Get from cache or compute and store.
        
        Args:
            key: Cache key
            factory: Function to compute value if not cached
            ttl: Time-to-live
            region: Cache region
            tags: Tags for invalidation
            
        Returns:
            Cached or computed value
        """
        value = await self.get(key)
        
        if value is not None:
            return value
        
        # Compute value
        if asyncio.iscoroutinefunction(factory):
            value = await factory()
        else:
            value = factory()
        
        # Cache it
        await self.set(key, value, ttl=ttl, region=region, tags=tags)
        
        return value
    
    # ==========================================================================
    # Batch Operations
    # ==========================================================================
    
    async def mget(self, keys: List[str]) -> Dict[str, Any]:
        """Get multiple keys at once."""
        results = {}
        
        try:
            if self._use_local:
                for key in keys:
                    if key in self._local_cache:
                        entry = self._local_cache[key]
                        if not entry.is_expired():
                            results[key] = entry.value
                            self._stats.hits += 1
                        else:
                            self._stats.misses += 1
                    else:
                        self._stats.misses += 1
            else:
                values = await self._redis.mget(keys)
                for key, value in zip(keys, values):
                    if value:
                        entry = CacheEntry.from_dict(json.loads(value))
                        if not entry.is_expired():
                            results[key] = entry.value
                            self._stats.hits += 1
                        else:
                            self._stats.misses += 1
                    else:
                        self._stats.misses += 1
            
            return results
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache mget error: {e}")
            return {}
    
    async def mset(
        self,
        items: Dict[str, Any],
        ttl: Optional[int] = None,
        region: CacheRegion = CacheRegion.WARM
    ) -> bool:
        """Set multiple keys at once."""
        try:
            for key, value in items.items():
                await self.set(key, value, ttl=ttl, region=region)
            return True
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache mset error: {e}")
            return False
    
    # ==========================================================================
    # Invalidation
    # ==========================================================================
    
    async def invalidate_by_tag(self, tag: str) -> int:
        """
        Invalidate all entries with given tag.
        
        Returns:
            Number of keys invalidated
        """
        count = 0
        
        try:
            if tag in self._tag_keys:
                keys = list(self._tag_keys[tag])
                for key in keys:
                    await self.delete(key)
                    count += 1
                del self._tag_keys[tag]
            
            self._stats.invalidations += count
            logger.info(f"Cache invalidated {count} keys with tag '{tag}'")
            
            return count
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache tag invalidation error: {e}")
            return 0
    
    async def invalidate_by_pattern(self, pattern: str) -> int:
        """
        Invalidate all entries matching pattern.
        
        Pattern uses Redis-style wildcards (* for any string).
        
        Returns:
            Number of keys invalidated
        """
        count = 0
        
        try:
            if self._use_local:
                import fnmatch
                keys_to_delete = [
                    k for k in self._local_cache.keys()
                    if fnmatch.fnmatch(k, pattern)
                ]
                for key in keys_to_delete:
                    await self.delete(key)
                    count += 1
            else:
                # Use Redis SCAN to find matching keys
                cursor = 0
                while True:
                    cursor, keys = await self._redis.scan(cursor, match=pattern, count=100)
                    for key in keys:
                        await self.delete(key)
                        count += 1
                    if cursor == 0:
                        break
            
            self._stats.invalidations += count
            logger.info(f"Cache invalidated {count} keys matching '{pattern}'")
            
            return count
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache pattern invalidation error: {e}")
            return 0
    
    async def invalidate_thread(self, thread_id: UUID) -> int:
        """Invalidate all cache entries for a thread."""
        pattern = CacheKeyBuilder.pattern("thread", thread_id)
        return await self.invalidate_by_pattern(pattern)
    
    async def invalidate_user(self, user_id: UUID) -> int:
        """Invalidate all cache entries for a user."""
        pattern = CacheKeyBuilder.pattern("user", user_id)
        return await self.invalidate_by_pattern(pattern)
    
    async def invalidate_sphere(self, sphere_id: UUID) -> int:
        """Invalidate all cache entries for a sphere."""
        pattern = CacheKeyBuilder.pattern("sphere", sphere_id)
        return await self.invalidate_by_pattern(pattern)
    
    async def clear(self) -> bool:
        """Clear entire cache."""
        try:
            if self._use_local:
                self._local_cache.clear()
            else:
                pattern = f"{CacheKeyBuilder.NAMESPACE}:*"
                cursor = 0
                while True:
                    cursor, keys = await self._redis.scan(cursor, match=pattern, count=1000)
                    if keys:
                        await self._redis.delete(*keys)
                    if cursor == 0:
                        break
            
            self._tag_keys.clear()
            logger.warning("Cache CLEARED")
            return True
            
        except Exception as e:
            self._stats.errors += 1
            logger.error(f"Cache clear error: {e}")
            return False
    
    # ==========================================================================
    # Statistics
    # ==========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        return self._stats.to_dict()
    
    def reset_stats(self) -> None:
        """Reset cache statistics."""
        self._stats = CacheStats()
    
    async def get_info(self) -> Dict[str, Any]:
        """Get detailed cache information."""
        info = {
            "mode": "local" if self._use_local else "redis",
            "stats": self.get_stats(),
            "tags": list(self._tag_keys.keys()),
            "tag_counts": {
                tag: len(keys) for tag, keys in self._tag_keys.items()
            },
        }
        
        if self._use_local:
            info["local_keys"] = len(self._local_cache)
        else:
            try:
                redis_info = await self._redis.info("memory")
                info["redis_memory"] = redis_info.get("used_memory_human", "unknown")
            except:
                pass
        
        return info
    
    # ==========================================================================
    # Internal Methods
    # ==========================================================================
    
    async def _get_entry(self, key: str) -> Optional[CacheEntry]:
        """Get cache entry from storage."""
        if self._use_local:
            return self._local_cache.get(key)
        
        data = await self._redis.get(key)
        if data:
            return CacheEntry.from_dict(json.loads(data))
        return None
    
    async def _set_entry(self, key: str, entry: CacheEntry, ttl: int) -> None:
        """Set cache entry in storage."""
        if self._use_local:
            self._local_cache[key] = entry
        else:
            data = json.dumps(entry.to_dict())
            if ttl > 0:
                await self._redis.setex(key, ttl, data)
            else:
                await self._redis.set(key, data)
            self._stats.bytes_stored = len(data)


# Singleton instance
cache_service = CacheService()


# ==========================================================================
# Cache Decorators
# ==========================================================================

def cached(
    key_builder: Callable[..., str],
    ttl: Optional[int] = None,
    region: CacheRegion = CacheRegion.WARM,
    tags: Optional[List[str]] = None
):
    """
    Decorator to cache function results.
    
    Usage:
        @cached(
            key_builder=lambda user_id: f"user:{user_id}:profile",
            ttl=300,
            region=CacheRegion.WARM
        )
        async def get_user_profile(user_id: UUID):
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Build cache key
            key = key_builder(*args, **kwargs)
            
            # Try cache
            cached_value = await cache_service.get(key)
            if cached_value is not None:
                return cached_value
            
            # Call function
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Cache result
            await cache_service.set(
                key, result, ttl=ttl, region=region, tags=tags
            )
            
            return result
        
        return wrapper
    return decorator


def cache_invalidate(
    key_pattern: Callable[..., str]
):
    """
    Decorator to invalidate cache after function execution.
    
    Usage:
        @cache_invalidate(
            key_pattern=lambda user_id: f"chenu:user:{user_id}:*"
        )
        async def update_user_profile(user_id: UUID, data: dict):
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Call function first
            if asyncio.iscoroutinefunction(func):
                result = await func(*args, **kwargs)
            else:
                result = func(*args, **kwargs)
            
            # Invalidate cache
            pattern = key_pattern(*args, **kwargs)
            await cache_service.invalidate_by_pattern(pattern)
            
            return result
        
        return wrapper
    return decorator


# ==========================================================================
# Exports
# ==========================================================================

__all__ = [
    "CacheService",
    "CacheStrategy",
    "CacheRegion",
    "CacheEntry",
    "CacheStats",
    "CacheKeyBuilder",
    "cache_service",
    "cached",
    "cache_invalidate",
    "REGION_TTLS",
]
