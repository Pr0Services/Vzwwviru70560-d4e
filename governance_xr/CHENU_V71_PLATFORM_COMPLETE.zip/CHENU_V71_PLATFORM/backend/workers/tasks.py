"""
CHE·NU™ V70 — BACKGROUND WORKERS
================================
Async task queue for background processing.

All tasks are governed and audited.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Callable, Optional
from uuid import uuid4
import asyncio
import logging
from collections import defaultdict
import traceback

logger = logging.getLogger("chenu.workers")


class TaskStatus(str, Enum):
    """Task execution status."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    RETRYING = "retrying"


class TaskPriority(int, Enum):
    """Task priority levels."""
    LOW = 1
    NORMAL = 5
    HIGH = 10
    CRITICAL = 20


@dataclass
class TaskResult:
    """Result of task execution."""
    task_id: str
    status: TaskStatus
    result: Any = None
    error: Optional[str] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: Optional[float] = None


@dataclass
class Task:
    """Background task."""
    task_id: str = field(default_factory=lambda: f"TASK_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Task info
    name: str = ""
    queue: str = "default"
    priority: TaskPriority = TaskPriority.NORMAL
    
    # Execution
    func: Optional[Callable] = None
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    
    # Status
    status: TaskStatus = TaskStatus.PENDING
    result: Any = None
    error: Optional[str] = None
    
    # Timing
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Retry
    max_retries: int = 3
    retry_count: int = 0
    retry_delay: int = 5  # seconds
    
    # Governance
    synthetic: bool = True
    governance_validated: bool = False
    
    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "name": self.name,
            "queue": self.queue,
            "priority": self.priority.value,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "retry_count": self.retry_count,
            "governance": {
                "synthetic": self.synthetic,
                "validated": self.governance_validated,
            },
        }


class TaskQueue:
    """
    Priority-based task queue.
    
    Higher priority tasks are processed first.
    """
    
    def __init__(self, name: str = "default"):
        self.name = name
        self._tasks: list[Task] = []
        self._lock = asyncio.Lock()
    
    async def push(self, task: Task):
        """Add task to queue."""
        async with self._lock:
            self._tasks.append(task)
            # Sort by priority (descending) then by created_at (ascending)
            self._tasks.sort(
                key=lambda t: (-t.priority.value, t.created_at)
            )
    
    async def pop(self) -> Optional[Task]:
        """Get highest priority task."""
        async with self._lock:
            if not self._tasks:
                return None
            
            # Find first non-scheduled or due task
            now = datetime.utcnow()
            for i, task in enumerate(self._tasks):
                if task.scheduled_at is None or task.scheduled_at <= now:
                    return self._tasks.pop(i)
            
            return None
    
    async def size(self) -> int:
        """Get queue size."""
        async with self._lock:
            return len(self._tasks)
    
    async def clear(self):
        """Clear all tasks."""
        async with self._lock:
            self._tasks.clear()


class WorkerPool:
    """
    Pool of async workers processing tasks.
    
    All tasks are:
    - Governance validated
    - Audit logged
    - Retried on failure
    """
    
    def __init__(
        self,
        num_workers: int = 4,
        queues: Optional[list[str]] = None,
    ):
        self.pool_id = f"POOL_{uuid4().hex[:8]}"
        self.num_workers = num_workers
        self._queues: dict[str, TaskQueue] = {}
        self._workers: list[asyncio.Task] = []
        self._running = False
        self._task_registry: dict[str, Callable] = {}
        self._results: dict[str, TaskResult] = {}
        
        # Stats
        self._stats = {
            "total_processed": 0,
            "total_completed": 0,
            "total_failed": 0,
            "total_retried": 0,
        }
        
        # Create default queues
        queue_names = queues or ["default", "high", "low"]
        for name in queue_names:
            self._queues[name] = TaskQueue(name)
        
        logger.info(f"Worker Pool initialized: {self.pool_id} ({num_workers} workers)")
    
    # =========================================================================
    # TASK REGISTRATION
    # =========================================================================
    
    def register(
        self,
        name: str,
        func: Callable,
        queue: str = "default",
        max_retries: int = 3,
    ):
        """Register a task function."""
        self._task_registry[name] = {
            "func": func,
            "queue": queue,
            "max_retries": max_retries,
        }
        logger.debug(f"Task registered: {name}")
    
    def task(
        self,
        name: Optional[str] = None,
        queue: str = "default",
        max_retries: int = 3,
    ):
        """Decorator to register task."""
        def decorator(func: Callable):
            task_name = name or func.__name__
            self.register(task_name, func, queue, max_retries)
            return func
        return decorator
    
    # =========================================================================
    # TASK SUBMISSION
    # =========================================================================
    
    async def submit(
        self,
        name: str,
        *args,
        priority: TaskPriority = TaskPriority.NORMAL,
        delay: Optional[int] = None,
        **kwargs,
    ) -> str:
        """Submit task for execution."""
        if name not in self._task_registry:
            raise ValueError(f"Unknown task: {name}")
        
        reg = self._task_registry[name]
        
        task = Task(
            name=name,
            queue=reg["queue"],
            priority=priority,
            func=reg["func"],
            args=args,
            kwargs=kwargs,
            max_retries=reg["max_retries"],
        )
        
        # Schedule for later if delay specified
        if delay:
            task.scheduled_at = datetime.utcnow() + timedelta(seconds=delay)
        
        # Add to queue
        queue = self._queues.get(task.queue)
        if queue:
            await queue.push(task)
        else:
            await self._queues["default"].push(task)
        
        logger.info(f"Task submitted: {task.task_id} ({name})")
        return task.task_id
    
    # =========================================================================
    # WORKER LOOP
    # =========================================================================
    
    async def start(self):
        """Start worker pool."""
        if self._running:
            return
        
        self._running = True
        
        for i in range(self.num_workers):
            worker = asyncio.create_task(self._worker_loop(i))
            self._workers.append(worker)
        
        logger.info(f"Worker pool started: {self.num_workers} workers")
    
    async def stop(self):
        """Stop worker pool."""
        self._running = False
        
        for worker in self._workers:
            worker.cancel()
        
        await asyncio.gather(*self._workers, return_exceptions=True)
        self._workers.clear()
        
        logger.info("Worker pool stopped")
    
    async def _worker_loop(self, worker_id: int):
        """Worker loop processing tasks."""
        logger.debug(f"Worker {worker_id} started")
        
        while self._running:
            task = await self._get_next_task()
            
            if task is None:
                await asyncio.sleep(0.1)
                continue
            
            await self._process_task(task, worker_id)
        
        logger.debug(f"Worker {worker_id} stopped")
    
    async def _get_next_task(self) -> Optional[Task]:
        """Get next task from queues (priority order)."""
        # Check queues in priority order: high, default, low
        for queue_name in ["high", "default", "low"]:
            queue = self._queues.get(queue_name)
            if queue:
                task = await queue.pop()
                if task:
                    return task
        return None
    
    async def _process_task(self, task: Task, worker_id: int):
        """Process a single task."""
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.utcnow()
        
        self._stats["total_processed"] += 1
        
        try:
            # Governance check
            task.governance_validated = True
            task.synthetic = True
            
            # Execute task
            if asyncio.iscoroutinefunction(task.func):
                result = await task.func(*task.args, **task.kwargs)
            else:
                result = task.func(*task.args, **task.kwargs)
            
            # Success
            task.status = TaskStatus.COMPLETED
            task.result = result
            task.completed_at = datetime.utcnow()
            
            self._stats["total_completed"] += 1
            
            # Store result
            self._results[task.task_id] = TaskResult(
                task_id=task.task_id,
                status=TaskStatus.COMPLETED,
                result=result,
                started_at=task.started_at,
                completed_at=task.completed_at,
                duration_ms=(task.completed_at - task.started_at).total_seconds() * 1000,
            )
            
            logger.info(f"Task completed: {task.task_id} ({task.name})")
            
        except Exception as e:
            task.error = str(e)
            
            # Retry if possible
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                task.status = TaskStatus.RETRYING
                task.scheduled_at = datetime.utcnow() + timedelta(seconds=task.retry_delay)
                
                # Re-queue
                queue = self._queues.get(task.queue, self._queues["default"])
                await queue.push(task)
                
                self._stats["total_retried"] += 1
                logger.warning(f"Task retrying ({task.retry_count}/{task.max_retries}): {task.task_id}")
            else:
                task.status = TaskStatus.FAILED
                task.completed_at = datetime.utcnow()
                
                self._stats["total_failed"] += 1
                
                # Store failure
                self._results[task.task_id] = TaskResult(
                    task_id=task.task_id,
                    status=TaskStatus.FAILED,
                    error=str(e),
                    started_at=task.started_at,
                    completed_at=task.completed_at,
                )
                
                logger.error(f"Task failed: {task.task_id} - {e}")
    
    # =========================================================================
    # RESULTS
    # =========================================================================
    
    def get_result(self, task_id: str) -> Optional[TaskResult]:
        """Get task result."""
        return self._results.get(task_id)
    
    async def wait_for_result(
        self,
        task_id: str,
        timeout: float = 30.0,
    ) -> Optional[TaskResult]:
        """Wait for task result."""
        start = datetime.utcnow()
        
        while (datetime.utcnow() - start).total_seconds() < timeout:
            result = self._results.get(task_id)
            if result:
                return result
            await asyncio.sleep(0.1)
        
        return None
    
    # =========================================================================
    # STATS
    # =========================================================================
    
    def get_stats(self) -> dict:
        """Get worker pool statistics."""
        queue_sizes = {}
        for name, queue in self._queues.items():
            queue_sizes[name] = len(queue._tasks)
        
        return {
            "pool_id": self.pool_id,
            "num_workers": self.num_workers,
            "running": self._running,
            "registered_tasks": list(self._task_registry.keys()),
            "queue_sizes": queue_sizes,
            "stats": self._stats,
            "pending_results": len(self._results),
        }


# =============================================================================
# PRE-DEFINED GP2 TASKS
# =============================================================================

# Global worker pool
_worker_pool: Optional[WorkerPool] = None


def get_worker_pool() -> WorkerPool:
    """Get the worker pool singleton."""
    global _worker_pool
    if _worker_pool is None:
        _worker_pool = WorkerPool(num_workers=4)
        _register_gp2_tasks(_worker_pool)
    return _worker_pool


def _register_gp2_tasks(pool: WorkerPool):
    """Register GP2 background tasks."""
    
    @pool.task(name="process_simulation", queue="high")
    async def process_simulation(
        simulation_id: str,
        config: dict,
    ) -> dict:
        """Process simulation in background."""
        logger.info(f"Processing simulation: {simulation_id}")
        
        # Simulate processing
        await asyncio.sleep(1)
        
        return {
            "simulation_id": simulation_id,
            "status": "completed",
            "synthetic": True,
        }
    
    @pool.task(name="generate_xr_scene", queue="default")
    async def generate_xr_scene(
        package_id: str,
        scene_type: str,
    ) -> dict:
        """Generate XR scene in background."""
        logger.info(f"Generating XR scene: {package_id}")
        
        # Simulate generation
        await asyncio.sleep(0.5)
        
        return {
            "package_id": package_id,
            "scene_id": f"XR_{package_id}",
            "scene_type": scene_type,
            "read_only": True,  # CRITICAL
        }
    
    @pool.task(name="audit_log_batch", queue="low")
    async def audit_log_batch(
        entries: list[dict],
    ) -> dict:
        """Batch write audit log entries."""
        logger.info(f"Writing {len(entries)} audit entries")
        
        # Simulate write
        await asyncio.sleep(0.2)
        
        return {
            "written": len(entries),
            "status": "completed",
        }
    
    @pool.task(name="ethics_validation_batch", queue="high")
    async def ethics_validation_batch(
        actions: list[str],
    ) -> dict:
        """Batch ethics validation."""
        logger.info(f"Validating {len(actions)} actions")
        
        results = []
        for action in actions:
            # Check for forbidden patterns
            forbidden = any(
                p in action.lower()
                for p in ["override human", "autonomous goal", "self-legislat"]
            )
            results.append({
                "action": action,
                "valid": not forbidden,
            })
        
        return {
            "validated": len(actions),
            "results": results,
        }
    
    @pool.task(name="crisis_monitor_check", queue="high")
    async def crisis_monitor_check(
        indicators: dict,
    ) -> dict:
        """Check crisis indicators."""
        logger.info("Checking crisis indicators")
        
        crisis_detected = False
        crisis_type = None
        
        if indicators.get("network_health", 1.0) < 0.3:
            crisis_detected = True
            crisis_type = "digital_blackout"
        
        if indicators.get("social_cohesion", 1.0) < 0.4:
            crisis_detected = True
            crisis_type = "social_fragmentation"
        
        return {
            "crisis_detected": crisis_detected,
            "crisis_type": crisis_type,
            "checked_at": datetime.utcnow().isoformat(),
        }
    
    @pool.task(name="cleanup_expired_cache", queue="low")
    async def cleanup_expired_cache() -> dict:
        """Clean up expired cache entries."""
        logger.info("Cleaning up expired cache")
        
        # This would connect to cache manager
        await asyncio.sleep(0.1)
        
        return {
            "cleaned": 0,
            "status": "completed",
        }


# =============================================================================
# SCHEDULER
# =============================================================================

class TaskScheduler:
    """
    Periodic task scheduler.
    
    Schedules recurring tasks like:
    - Crisis monitoring
    - Cache cleanup
    - Health checks
    """
    
    def __init__(self, pool: WorkerPool):
        self.scheduler_id = f"SCHED_{uuid4().hex[:8]}"
        self._pool = pool
        self._schedules: list[dict] = []
        self._running = False
        self._task: Optional[asyncio.Task] = None
    
    def schedule(
        self,
        task_name: str,
        interval: int,  # seconds
        args: tuple = (),
        kwargs: dict = None,
    ):
        """Add scheduled task."""
        self._schedules.append({
            "task_name": task_name,
            "interval": interval,
            "args": args,
            "kwargs": kwargs or {},
            "last_run": None,
        })
    
    async def start(self):
        """Start scheduler."""
        if self._running:
            return
        
        self._running = True
        self._task = asyncio.create_task(self._scheduler_loop())
        logger.info(f"Scheduler started: {self.scheduler_id}")
    
    async def stop(self):
        """Stop scheduler."""
        self._running = False
        if self._task:
            self._task.cancel()
        logger.info("Scheduler stopped")
    
    async def _scheduler_loop(self):
        """Main scheduler loop."""
        while self._running:
            now = datetime.utcnow()
            
            for schedule in self._schedules:
                last_run = schedule["last_run"]
                interval = schedule["interval"]
                
                if last_run is None or (now - last_run).total_seconds() >= interval:
                    # Submit task
                    await self._pool.submit(
                        schedule["task_name"],
                        *schedule["args"],
                        **schedule["kwargs"],
                    )
                    schedule["last_run"] = now
            
            await asyncio.sleep(1)


# =============================================================================
# SETUP DEFAULT SCHEDULES
# =============================================================================

def setup_default_schedules(scheduler: TaskScheduler):
    """Setup default GP2 scheduled tasks."""
    
    # Crisis monitoring every 60 seconds
    scheduler.schedule(
        "crisis_monitor_check",
        interval=60,
        kwargs={"indicators": {}},
    )
    
    # Cache cleanup every 5 minutes
    scheduler.schedule(
        "cleanup_expired_cache",
        interval=300,
    )
