"""
CHE·NU™ Identity Boundary Middleware

Enforces identity isolation across all requests.

R&D Rule: Each user only sees their own data.
Cross-identity access returns HTTP 403.

This middleware:
1. Extracts identity_id from JWT
2. Attaches it to request state
3. Provides utilities for boundary checking
"""

import logging
from typing import Optional, Callable
from uuid import UUID

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from backend.core.security import (
    verify_access_token,
    TokenVerificationError,
    is_token_blacklisted,
)

logger = logging.getLogger(__name__)


class IdentityBoundaryMiddleware(BaseHTTPMiddleware):
    """
    Middleware that enforces identity boundary on all requests.
    
    Extracts identity_id from JWT and attaches to request state.
    All downstream handlers can access request.state.identity_id.
    """
    
    # Paths that don't require authentication
    PUBLIC_PATHS = {
        "/",
        "/health",
        "/health/ready",
        "/health/live",
        "/docs",
        "/redoc",
        "/openapi.json",
        "/api/v2/auth/register",
        "/api/v2/auth/login",
        "/api/v2/auth/refresh",
    }
    
    # Path prefixes that are public
    PUBLIC_PREFIXES = [
        "/static/",
        "/favicon",
    ]
    
    async def dispatch(
        self,
        request: Request,
        call_next: Callable,
    ) -> Response:
        """Process request and enforce identity boundary."""
        
        # Skip public paths
        if self._is_public_path(request.url.path):
            return await call_next(request)
        
        # Extract and validate token
        identity_info = await self._extract_identity(request)
        
        if identity_info:
            # Attach identity to request state
            request.state.user_id = identity_info["user_id"]
            request.state.identity_id = identity_info["identity_id"]
            request.state.roles = identity_info["roles"]
            request.state.token_id = identity_info["token_id"]
        else:
            # No valid identity - clear state
            request.state.user_id = None
            request.state.identity_id = None
            request.state.roles = []
            request.state.token_id = None
        
        # Continue with request
        response = await call_next(request)
        
        # Add identity header for debugging (only in non-production)
        if identity_info and request.app.state.debug:
            response.headers["X-Identity-ID"] = identity_info["identity_id"]
        
        return response
    
    def _is_public_path(self, path: str) -> bool:
        """Check if path is public (no auth required)."""
        if path in self.PUBLIC_PATHS:
            return True
        
        for prefix in self.PUBLIC_PREFIXES:
            if path.startswith(prefix):
                return True
        
        return False
    
    async def _extract_identity(self, request: Request) -> Optional[dict]:
        """
        Extract identity information from request.
        
        Returns dict with user_id, identity_id, roles, token_id
        or None if no valid token.
        """
        # Get Authorization header
        auth_header = request.headers.get("Authorization")
        
        if not auth_header:
            return None
        
        # Parse Bearer token
        parts = auth_header.split()
        if len(parts) != 2 or parts[0].lower() != "bearer":
            return None
        
        token = parts[1]
        
        try:
            # Verify token
            payload = verify_access_token(token)
            
            # Check if blacklisted
            if is_token_blacklisted(payload.jti):
                logger.warning(f"Blacklisted token used: {payload.jti}")
                return None
            
            return {
                "user_id": payload.sub,
                "identity_id": payload.identity_id,
                "roles": payload.roles,
                "token_id": payload.jti,
            }
            
        except TokenVerificationError as e:
            logger.debug(f"Token verification failed: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error in identity extraction: {e}")
            return None


# ═══════════════════════════════════════════════════════════════════════════════
# IDENTITY BOUNDARY CHECKER
# ═══════════════════════════════════════════════════════════════════════════════

class IdentityBoundaryChecker:
    """
    Utility class for checking identity boundaries.
    
    Usage in services:
        checker = IdentityBoundaryChecker(request.state.identity_id)
        checker.check_access(resource.identity_id, "Thread")
    """
    
    def __init__(self, current_identity_id: str):
        self.current_identity_id = current_identity_id
    
    def check_access(
        self,
        resource_identity_id: str,
        resource_type: str = "resource",
    ) -> bool:
        """
        Check if current identity can access a resource.
        
        Args:
            resource_identity_id: Identity that owns the resource
            resource_type: Type of resource (for error message)
            
        Returns:
            True if access is allowed
            
        Raises:
            IdentityBoundaryViolation: If access is denied
        """
        if self.current_identity_id != resource_identity_id:
            from backend.core.exceptions import IdentityBoundaryError
            raise IdentityBoundaryError(
                requested_identity=self.current_identity_id,
                resource_identity=resource_identity_id,
                resource_type=resource_type,
            )
        return True
    
    def can_access(self, resource_identity_id: str) -> bool:
        """
        Check if current identity can access a resource (no exception).
        
        Returns:
            True if access is allowed, False otherwise
        """
        return self.current_identity_id == resource_identity_id
    
    def filter_query(self, query, identity_column):
        """
        Add identity filter to SQLAlchemy query.
        
        Usage:
            query = checker.filter_query(
                select(Thread),
                Thread.identity_id
            )
        """
        return query.where(identity_column == self.current_identity_id)


def get_identity_checker(request: Request) -> IdentityBoundaryChecker:
    """
    FastAPI dependency for identity boundary checking.
    
    Usage:
        @router.get("/items/{id}")
        async def get_item(
            id: str,
            checker: IdentityBoundaryChecker = Depends(get_identity_checker),
        ):
            item = await get_item_by_id(id)
            checker.check_access(item.identity_id, "Item")
            return item
    """
    identity_id = getattr(request.state, "identity_id", None)
    
    if not identity_id:
        from backend.core.exceptions import AuthenticationError
        raise AuthenticationError(message="Authentication required")
    
    return IdentityBoundaryChecker(identity_id)


# ═══════════════════════════════════════════════════════════════════════════════
# AUDIT LOGGING FOR BOUNDARY VIOLATIONS
# ═══════════════════════════════════════════════════════════════════════════════

async def log_boundary_violation(
    request: Request,
    requested_identity: str,
    resource_identity: str,
    resource_type: str,
    resource_id: str,
) -> None:
    """
    Log identity boundary violation for security audit.
    
    This should be called whenever a boundary violation is detected.
    Logs are stored for security analysis.
    """
    logger.warning(
        "IDENTITY_BOUNDARY_VIOLATION",
        extra={
            "event_type": "security.boundary_violation",
            "requested_identity": requested_identity,
            "resource_identity": resource_identity,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "path": request.url.path,
            "method": request.method,
            "client_ip": request.client.host if request.client else None,
            "user_agent": request.headers.get("User-Agent"),
        },
    )
    
    # TODO: Store in audit table for analysis
    # await audit_service.log_security_event(...)


# ═══════════════════════════════════════════════════════════════════════════════
# RATE LIMITING BY IDENTITY
# ═══════════════════════════════════════════════════════════════════════════════

class IdentityRateLimiter:
    """
    Rate limiter scoped to identity.
    
    Prevents abuse by limiting requests per identity.
    """
    
    def __init__(
        self,
        requests_per_minute: int = 60,
        requests_per_hour: int = 1000,
    ):
        self.requests_per_minute = requests_per_minute
        self.requests_per_hour = requests_per_hour
    
    async def check_limit(self, identity_id: str) -> bool:
        """
        Check if identity is within rate limits.
        
        Returns True if within limits, False if exceeded.
        """
        from backend.core.redis import rate_limit_cache
        
        minute_key = f"rate:{identity_id}:minute"
        hour_key = f"rate:{identity_id}:hour"
        
        # Check minute limit
        minute_count = await rate_limit_cache.get(minute_key) or 0
        if minute_count >= self.requests_per_minute:
            return False
        
        # Check hour limit
        hour_count = await rate_limit_cache.get(hour_key) or 0
        if hour_count >= self.requests_per_hour:
            return False
        
        # Increment counters
        await rate_limit_cache.incr(minute_key)
        await rate_limit_cache.expire(minute_key, 60)
        
        await rate_limit_cache.incr(hour_key)
        await rate_limit_cache.expire(hour_key, 3600)
        
        return True
    
    async def get_remaining(self, identity_id: str) -> dict:
        """Get remaining requests for identity."""
        from backend.core.redis import rate_limit_cache
        
        minute_count = await rate_limit_cache.get(f"rate:{identity_id}:minute") or 0
        hour_count = await rate_limit_cache.get(f"rate:{identity_id}:hour") or 0
        
        return {
            "minute": {
                "limit": self.requests_per_minute,
                "remaining": max(0, self.requests_per_minute - int(minute_count)),
            },
            "hour": {
                "limit": self.requests_per_hour,
                "remaining": max(0, self.requests_per_hour - int(hour_count)),
            },
        }
