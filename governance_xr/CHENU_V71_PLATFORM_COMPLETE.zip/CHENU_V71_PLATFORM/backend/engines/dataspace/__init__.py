"""
CHE·NU™ V70 — DATASPACE ENGINE PACKAGE
======================================
Intelligent governed storage system.

Based on: DATASPACE_ENGINE_CHAPTER.md

A DataSpace is CHE·NU's fundamental unit of intelligent, governed storage.
Unlike traditional folders, databases, or file systems, a DataSpace is a
structured, intelligent, governed container that serves as a self-contained
micro-environment.

Core Principle: A DataSpace = a "self-contained OS micro-environment"
that understands its contents, maintains its history, respects its
governance rules, and serves its designated purpose.

GOUVERNANCE > EXÉCUTION
"""

from .models import (
    # Enums
    DataSpaceType,
    DataSpaceStatus,
    ContentType,
    DocumentType,
    MediaType,
    TaskStatus,
    TaskPriority,
    DiagramType,
    HierarchyLevel,
    # Content Models
    DataSpaceDocument,
    DataSpaceTask,
    DataSpaceMedia,
    DataSpaceDiagram,
    DataSpaceXRScene,
    DataSpaceTimeline,
    AgentMemory,
    DataSpaceDecision,
    DataSpaceRelationship,
    # DataSpace
    DataSpace,
    DataSpaceMetadata,
    # Factories
    create_dataspace,
    create_project_dataspace,
    create_building_dataspace,
    create_meeting_dataspace,
)

from .engine import (
    DataSpaceEngine,
    get_dataspace_engine,
)

__all__ = [
    # Enums
    "DataSpaceType",
    "DataSpaceStatus",
    "ContentType",
    "DocumentType",
    "MediaType",
    "TaskStatus",
    "TaskPriority",
    "DiagramType",
    "HierarchyLevel",
    # Content Models
    "DataSpaceDocument",
    "DataSpaceTask",
    "DataSpaceMedia",
    "DataSpaceDiagram",
    "DataSpaceXRScene",
    "DataSpaceTimeline",
    "AgentMemory",
    "DataSpaceDecision",
    "DataSpaceRelationship",
    # DataSpace
    "DataSpace",
    "DataSpaceMetadata",
    # Factories
    "create_dataspace",
    "create_project_dataspace",
    "create_building_dataspace",
    "create_meeting_dataspace",
    # Engine
    "DataSpaceEngine",
    "get_dataspace_engine",
]

__version__ = "70.0.0"
