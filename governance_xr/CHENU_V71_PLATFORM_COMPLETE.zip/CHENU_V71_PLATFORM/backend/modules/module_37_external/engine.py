"""
CHE·NU™ V70 — MODULE 37: EXTERNAL WORLD INTERFACE (EWI)
=======================================================
Permet à CHE·NU™ d'interagir avec des systèmes externes
sans compromettre sa souveraineté.

Principe Fondamental:
Aucune écriture externe directe.
Toute interaction passe par NOVA + OPA.

CHE·NU™ dialogue. Elle ne s'aligne jamais aveuglément.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import hashlib
import logging

logger = logging.getLogger("chenu.module_37")


class ExternalEntityType(str, Enum):
    """Types d'entités externes."""
    STATE = "state"
    MUNICIPALITY = "municipality"
    NGO = "ngo"
    INSTITUTION = "institution"
    AI_SYSTEM = "ai_system"
    ENERGY_NETWORK = "energy_network"
    LOGISTICS_NETWORK = "logistics_network"


class ExchangeMode(str, Enum):
    """Modes d'échange."""
    READ_ONLY = "read_only"  # Observateur
    MIRROR_SIMULATION = "mirror_simulation"
    CONDITIONAL_PROPOSAL = "conditional_proposal"
    CONTRACTUAL_COOPERATION = "contractual_cooperation"


class FilterType(str, Enum):
    """Types de filtres sémantiques."""
    INTENTION_TRANSLATION = "intention_translation"
    IDEOLOGICAL_FILTERING = "ideological_filtering"
    COERCION_NEUTRALIZATION = "coercion_neutralization"


@dataclass
class ExternalEntity:
    """Entité externe avec laquelle CHE·NU interagit."""
    entity_id: str = field(default_factory=lambda: f"EXT_{uuid4().hex[:8]}")
    entity_type: ExternalEntityType = ExternalEntityType.INSTITUTION
    
    # Identity
    name: str = ""
    jurisdiction: str = ""
    
    # Trust
    trust_level: float = 0.5  # 0-1
    verified: bool = False
    
    # Capabilities
    supported_modes: list[ExchangeMode] = field(default_factory=lambda: [ExchangeMode.READ_ONLY])
    
    # Status
    is_active: bool = True
    last_interaction: Optional[datetime] = None


@dataclass
class SemanticFirewall:
    """
    Pare-feu sémantique pour filtrer les interactions.
    """
    firewall_id: str = field(default_factory=lambda: f"FW_{uuid4().hex[:8]}")
    
    # Filters
    intention_translation: bool = True
    ideological_filtering: bool = True
    coercion_neutralization: bool = True
    
    # Blocked patterns
    blocked_patterns: list[str] = field(default_factory=list)
    
    # Stats
    interactions_filtered: int = 0
    coercion_attempts_blocked: int = 0


@dataclass
class ExternalRequest:
    """Requête vers ou depuis un système externe."""
    request_id: str = field(default_factory=lambda: f"EXT_REQ_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Direction
    is_incoming: bool = True
    entity_id: str = ""
    
    # Content
    intent: str = ""
    payload: dict[str, Any] = field(default_factory=dict)
    exchange_mode: ExchangeMode = ExchangeMode.READ_ONLY
    
    # Filtering
    filtered: bool = False
    filter_results: dict[str, Any] = field(default_factory=dict)
    
    # Governance
    opa_validated: bool = False
    nova_approved: bool = False
    
    # Status
    status: str = "pending"  # pending, approved, rejected, completed


@dataclass
class ExternalResponse:
    """Réponse à une requête externe."""
    response_id: str = field(default_factory=lambda: f"EXT_RES_{uuid4().hex[:8]}")
    request_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    payload: dict[str, Any] = field(default_factory=dict)
    
    # Constraints
    is_read_only: bool = True
    no_direct_write: bool = True  # CRITICAL
    
    # Signatures
    signatures: list[str] = field(default_factory=list)


class ExternalWorldInterface:
    """
    Module 37 — External World Interface
    
    Permet à CHE·NU™ d'interagir avec des systèmes externes
    sans compromettre sa souveraineté.
    
    Types d'Interfaces:
    - États & Municipalités
    - ONG & Institutions
    - Autres systèmes IA
    - Réseaux énergétiques / logistiques
    
    Principe Fondamental:
    AUCUNE écriture externe directe.
    Toute interaction passe par NOVA + OPA.
    
    Modes d'Échange:
    - Lecture seule (Observateur)
    - Simulation miroir
    - Proposition conditionnelle
    - Coopération contractuelle
    
    Pare-feu Sémantique:
    - Traduction d'intention
    - Filtrage idéologique
    - Neutralisation coercitive
    """
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,
        nova_kernel: Optional[Any] = None,
        diplomacy_engine: Optional[Any] = None,  # Module 16
    ):
        self.interface_id = f"EWI_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies
        self.opa_client = opa_client
        self.nova_kernel = nova_kernel
        self.diplomacy_engine = diplomacy_engine
        
        # Components
        self.firewall = SemanticFirewall()
        
        # Storage
        self._entities: dict[str, ExternalEntity] = {}
        self._requests: dict[str, ExternalRequest] = {}
        self._responses: dict[str, ExternalResponse] = {}
        
        logger.info(f"External World Interface initialized: {self.interface_id}")
    
    # =========================================================================
    # ENTITY MANAGEMENT
    # =========================================================================
    
    def register_entity(
        self,
        entity_type: ExternalEntityType,
        name: str,
        jurisdiction: str = "",
        trust_level: float = 0.5,
    ) -> ExternalEntity:
        """Register an external entity."""
        entity = ExternalEntity(
            entity_type=entity_type,
            name=name,
            jurisdiction=jurisdiction,
            trust_level=trust_level,
        )
        
        # Set supported modes based on trust
        if trust_level >= 0.8:
            entity.supported_modes = [
                ExchangeMode.READ_ONLY,
                ExchangeMode.MIRROR_SIMULATION,
                ExchangeMode.CONDITIONAL_PROPOSAL,
                ExchangeMode.CONTRACTUAL_COOPERATION,
            ]
        elif trust_level >= 0.5:
            entity.supported_modes = [
                ExchangeMode.READ_ONLY,
                ExchangeMode.MIRROR_SIMULATION,
            ]
        else:
            entity.supported_modes = [ExchangeMode.READ_ONLY]
        
        self._entities[entity.entity_id] = entity
        logger.info(f"External entity registered: {entity.entity_id} ({name})")
        
        return entity
    
    def verify_entity(self, entity_id: str) -> bool:
        """Verify an external entity."""
        entity = self._entities.get(entity_id)
        if not entity:
            return False
        
        # Verification logic (simplified)
        entity.verified = entity.trust_level >= 0.6
        return entity.verified
    
    # =========================================================================
    # REQUEST PROCESSING
    # =========================================================================
    
    def process_incoming_request(
        self,
        entity_id: str,
        intent: str,
        payload: dict[str, Any],
        exchange_mode: ExchangeMode = ExchangeMode.READ_ONLY,
    ) -> ExternalRequest:
        """
        Process an incoming request from external entity.
        
        All requests go through:
        1. Semantic firewall
        2. OPA validation
        3. NOVA approval
        """
        entity = self._entities.get(entity_id)
        if not entity:
            raise ValueError(f"Unknown entity: {entity_id}")
        
        if not entity.is_active:
            raise ValueError(f"Entity inactive: {entity_id}")
        
        if exchange_mode not in entity.supported_modes:
            raise ValueError(f"Mode not supported: {exchange_mode}")
        
        request = ExternalRequest(
            is_incoming=True,
            entity_id=entity_id,
            intent=intent,
            payload=payload,
            exchange_mode=exchange_mode,
        )
        
        # Step 1: Semantic firewall
        request.filter_results = self._apply_firewall(request)
        request.filtered = True
        
        if request.filter_results.get("blocked"):
            request.status = "rejected"
            self._requests[request.request_id] = request
            return request
        
        # Step 2: OPA validation
        request.opa_validated = self._validate_with_opa(request)
        if not request.opa_validated:
            request.status = "rejected"
            self._requests[request.request_id] = request
            return request
        
        # Step 3: NOVA approval
        request.nova_approved = self._approve_with_nova(request)
        if not request.nova_approved:
            request.status = "rejected"
            self._requests[request.request_id] = request
            return request
        
        request.status = "approved"
        entity.last_interaction = datetime.utcnow()
        
        self._requests[request.request_id] = request
        logger.info(f"External request processed: {request.request_id}")
        
        return request
    
    def _apply_firewall(self, request: ExternalRequest) -> dict[str, Any]:
        """Apply semantic firewall to request."""
        results = {
            "blocked": False,
            "filters_applied": [],
            "warnings": [],
        }
        
        intent_lower = request.intent.lower()
        
        # Check for coercion
        coercion_patterns = [
            "must", "require", "demand", "force",
            "override", "bypass", "ignore governance"
        ]
        for pattern in coercion_patterns:
            if pattern in intent_lower:
                self.firewall.coercion_attempts_blocked += 1
                results["blocked"] = True
                results["block_reason"] = f"Coercion pattern detected: {pattern}"
                return results
        
        # Check blocked patterns
        for pattern in self.firewall.blocked_patterns:
            if pattern in intent_lower:
                results["blocked"] = True
                results["block_reason"] = f"Blocked pattern: {pattern}"
                return results
        
        # Apply filters
        if self.firewall.intention_translation:
            results["filters_applied"].append("intention_translation")
        
        if self.firewall.ideological_filtering:
            results["filters_applied"].append("ideological_filtering")
            # Check for ideological content
            ideological_terms = ["propaganda", "supremacy", "domination"]
            for term in ideological_terms:
                if term in intent_lower:
                    results["warnings"].append(f"Ideological content filtered: {term}")
        
        self.firewall.interactions_filtered += 1
        return results
    
    def _validate_with_opa(self, request: ExternalRequest) -> bool:
        """Validate request with OPA."""
        if not self.opa_client:
            return True
        
        try:
            result = self.opa_client.query(
                policy_path="chenu/external/request",
                input_data={
                    "request_id": request.request_id,
                    "entity_id": request.entity_id,
                    "mode": request.exchange_mode.value,
                },
            )
            return result.get("allow", False)
        except Exception as e:
            logger.error(f"OPA validation error: {e}")
            return False
    
    def _approve_with_nova(self, request: ExternalRequest) -> bool:
        """Get NOVA approval for request."""
        if not self.nova_kernel:
            return True
        
        try:
            response = self.nova_kernel.process_request(request)
            return not response.is_refusal
        except Exception as e:
            logger.error(f"NOVA approval error: {e}")
            return False
    
    # =========================================================================
    # RESPONSE GENERATION
    # =========================================================================
    
    def create_response(
        self,
        request_id: str,
        payload: dict[str, Any],
    ) -> ExternalResponse:
        """
        Create response to external request.
        
        CRITICAL: No direct external writes.
        """
        request = self._requests.get(request_id)
        if not request:
            raise ValueError(f"Request not found: {request_id}")
        
        if request.status != "approved":
            raise ValueError(f"Request not approved: {request_id}")
        
        response = ExternalResponse(
            request_id=request_id,
            payload=payload,
            is_read_only=True,  # Always
            no_direct_write=True,  # CRITICAL
        )
        
        # Sign response
        response.signatures.append(
            f"EWI_SIG:{hashlib.sha256(request_id.encode()).hexdigest()[:16]}"
        )
        
        request.status = "completed"
        self._responses[response.response_id] = response
        
        return response
    
    # =========================================================================
    # USE CASES
    # =========================================================================
    
    def handle_humanitarian_crisis(
        self,
        entity_id: str,
        crisis_description: str,
    ) -> dict[str, Any]:
        """
        Handle cross-border humanitarian crisis.
        Mode: Conditional Proposal
        """
        return self._create_scenario_response(
            entity_id,
            "humanitarian_crisis",
            crisis_description,
            ExchangeMode.CONDITIONAL_PROPOSAL,
        )
    
    def handle_energy_mutualization(
        self,
        entity_id: str,
        proposal: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Handle energy mutualization request.
        Mode: Mirror Simulation
        """
        return self._create_scenario_response(
            entity_id,
            "energy_mutualization",
            str(proposal),
            ExchangeMode.MIRROR_SIMULATION,
        )
    
    def handle_technical_diplomacy(
        self,
        entity_id: str,
        topic: str,
    ) -> dict[str, Any]:
        """
        Handle technical diplomacy.
        Mode: Contractual Cooperation
        """
        return self._create_scenario_response(
            entity_id,
            "technical_diplomacy",
            topic,
            ExchangeMode.CONTRACTUAL_COOPERATION,
        )
    
    def _create_scenario_response(
        self,
        entity_id: str,
        scenario_type: str,
        details: str,
        mode: ExchangeMode,
    ) -> dict[str, Any]:
        """Create a scenario response."""
        request = self.process_incoming_request(
            entity_id=entity_id,
            intent=f"{scenario_type}: {details}",
            payload={"scenario": scenario_type, "details": details},
            exchange_mode=mode,
        )
        
        if request.status != "approved":
            return {
                "success": False,
                "reason": request.filter_results.get("block_reason", "Not approved"),
            }
        
        response = self.create_response(
            request_id=request.request_id,
            payload={
                "scenario": scenario_type,
                "recommendation": f"CHE·NU simulation for {scenario_type}",
                "synthetic": True,
            },
        )
        
        return {
            "success": True,
            "request_id": request.request_id,
            "response_id": response.response_id,
        }
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get interface statistics."""
        return {
            "interface_id": self.interface_id,
            "registered_entities": len(self._entities),
            "active_entities": sum(1 for e in self._entities.values() if e.is_active),
            "total_requests": len(self._requests),
            "approved_requests": sum(
                1 for r in self._requests.values() if r.status == "approved"
            ),
            "coercion_attempts_blocked": self.firewall.coercion_attempts_blocked,
        }
