# CHE·NU™ V70 — ARCHITECTURE DOCUMENTATION

## Complete System Architecture with Mermaid Diagrams

---

## 1. COMPLETE ENGINE STACK OVERVIEW

```mermaid
graph TB
    subgraph "USER LAYER"
        UI[User Interface]
        OCW[OCW - Operational Cognitive Workspace]
        WS[Workspace Engine]
    end
    
    subgraph "ACTION LAYER"
        OC[1-Click Assistant Engine]
        AO[Agent Orchestrator]
    end
    
    subgraph "INTELLIGENCE LAYER"
        BI[Backstage Intelligence]
        AG[287 Agents]
    end
    
    subgraph "SAFETY LAYER"
        MG[Memory & Governance Engine]
        AUDIT[Audit System]
        HITL[HITL Checkpoints]
    end
    
    subgraph "DATA LAYER"
        DS[DataSpace Engine]
        TH[Thread Engine]
        FT[File Transform Engine]
    end
    
    subgraph "DOMAIN LAYER"
        IMM[Immobilier]
        CON[Construction]
        FIN[Finance]
        CRE[Creative]
    end
    
    subgraph "EXPERIENCE LAYER"
        MT[Meeting System]
        XR[XR Spatial Engine - READ ONLY]
    end
    
    UI --> OCW
    UI --> WS
    OCW --> OC
    WS --> OC
    OC --> BI
    OC --> AO
    AO --> AG
    BI --> AG
    AG --> MG
    MG --> HITL
    HITL --> DS
    MG --> DS
    MG --> TH
    DS --> IMM
    DS --> CON
    DS --> FIN
    DS --> CRE
    MT --> DS
    XR -.->|READ ONLY| DS
    MG --> AUDIT
```

---

## 2. GOVERNANCE PRINCIPLES

```
╔════════════════════════════════════════════════════════════════╗
║                    GOUVERNANCE > EXÉCUTION                      ║
╠════════════════════════════════════════════════════════════════╣
║                                                                 ║
║  ┌─────────────────────────────────────────────────────────┐   ║
║  │  1. XR READ ONLY        - No writes through XR          │   ║
║  │  2. SYNTHETIC ONLY      - All simulations synthetic     │   ║
║  │  3. HITL REQUIRED       - Human approval for actions    │   ║
║  │  4. TEN LAWS OF MEMORY  - Memory governance enforced    │   ║
║  │  5. L0 NOT HIREABLE     - System agents protected       │   ║
║  │  6. CONSENT REQUIRED    - Recording needs approval      │   ║
║  │  7. TAL COMPLIANCE      - Quebec rental laws            │   ║
║  │  8. IDENTITY SCOPING    - No cross-identity access      │   ║
║  └─────────────────────────────────────────────────────────┘   ║
║                                                                 ║
╚════════════════════════════════════════════════════════════════╝
```

---

## 3. IDENTITY & SPHERE HIERARCHY

```mermaid
graph TB
    subgraph "USER"
        U[User Account]
    end
    
    subgraph "IDENTITIES"
        IP[Personal Identity]
        IE[Enterprise Identity]
        IC[Creative Identity]
        ID[Design Identity]
        IA[Architecture Identity]
        ICO[Construction Identity]
    end
    
    subgraph "9 SPHERES"
        S1[👤 Personal]
        S2[💼 Business]
        S3[🏛️ Government]
        S4[🎨 Creative Studio]
        S5[🤝 Community]
        S6[📱 Social & Media]
        S7[🎬 Entertainment]
        S8[👥 My Team]
        S9[📚 Scholar]
    end
    
    subgraph "6 BUREAU SECTIONS"
        B1[QuickCapture]
        B2[ResumeWorkspace]
        B3[Threads]
        B4[DataFiles]
        B5[ActiveAgents]
        B6[Meetings]
    end
    
    U --> IP
    U --> IE
    U --> IC
    U --> ID
    U --> IA
    U --> ICO
    
    IP --> S1
    IE --> S2
    IC --> S4
    
    S1 --> B1
    S1 --> B2
    S1 --> B3
    S1 --> B4
    S1 --> B5
    S1 --> B6
```

---

## 4. AGENT HIERARCHY (L0-L3) — 287 AGENTS

```mermaid
graph TB
    subgraph "L0 - SYSTEM (Never Hired)"
        L0A[🌟 Nova Intelligence]
        L0B[🎭 Backstage Intelligence]
    end
    
    subgraph "L1 - ORCHESTRATOR (One per User)"
        L1A[🎯 User Orchestrator]
    end
    
    subgraph "L2 - SPHERE CHIEFS"
        L2A[👤 Personal Chief]
        L2B[💼 Business Chief]
        L2C[🏗️ Construction Chief]
        L2D[🏠 Immobilier Chief]
        L2E[💰 Finance Chief]
        L2F[🎨 Creative Director]
        L2G[📅 Meeting Facilitator]
        L2H[📚 Scholar Chief]
    end
    
    subgraph "L3 - TASK AGENTS (287 Total)"
        L3A[Estimator]
        L3B[Materials Expert]
        L3C[Safety Inspector]
        L3D[Property Manager]
        L3E[Lease Analyst]
        L3F[Accountant]
        L3G[Meeting Scribe]
        L3H[...250+ more]
    end
    
    L0A -.->|System Only| L1A
    L0B -.->|Invisible| L1A
    
    L1A --> L2A
    L1A --> L2B
    L1A --> L2C
    L1A --> L2D
    L1A --> L2E
    L1A --> L2F
    L1A --> L2G
    L1A --> L2H
    
    L2C --> L3A
    L2C --> L3B
    L2C --> L3C
    L2D --> L3D
    L2D --> L3E
    L2E --> L3F
    L2G --> L3G
```

---

## 5. 1-CLICK ASSISTANT WORKFLOW

```mermaid
flowchart TB
    subgraph "INPUT"
        A[User Command]
        B[File Upload]
        C[Context]
        D[DataSpace]
    end
    
    subgraph "INTENT INTERPRETER"
        E[Parse Intent]
        F[Detect Domain]
        G[Identify Sphere]
        H[Find Gaps]
    end
    
    subgraph "WORKFLOW CONSTRUCTOR"
        I[Build Pipeline]
        J[Assign Tasks]
        K[Map Dependencies]
        L[Add HITL Checkpoints]
    end
    
    subgraph "AGENT ORCHESTRATOR"
        M[Select Agents]
        N[Coordinate Actions]
        O[Monitor Compliance]
        P[Quality Check]
    end
    
    subgraph "OUTPUT SYNTHESIZER"
        Q[Assemble Results]
        R[Format Output]
        S[Generate Dashboard]
        T[Store in DataSpace]
    end
    
    subgraph "GOVERNANCE"
        U[Verify Permissions]
        V[HITL Approval]
        W[Log Actions]
        X[Enable Undo]
    end
    
    A --> E
    B --> E
    C --> E
    D --> E
    
    E --> F --> G --> H
    H --> I --> J --> K --> L
    L --> V
    V -->|Approved| M
    M --> N --> O --> P
    P --> Q --> R --> S --> T
    
    M --> U
    T --> W
    W --> X
```

---

## 6. TEN LAWS OF MEMORY

```mermaid
graph TB
    subgraph "VISIBILITY LAWS"
        L1[Law 1: No Hidden Memory]
        L2[Law 2: Explicit Storage Approval]
    end
    
    subgraph "SCOPING LAWS"
        L3[Law 3: Identity Scoping]
        L4[Law 4: No Cross-Identity Access]
    end
    
    subgraph "CONTROL LAWS"
        L5[Law 5: Reversibility]
        L6[Law 6: Operation Logging]
        L7[Law 7: No Self-Directed Agent Learning]
    end
    
    subgraph "CONTEXT LAWS"
        L8[Law 8: Domain Awareness]
        L9[Law 9: DataSpace Foundation]
        L10[Law 10: User-Controlled Lifespan]
    end
    
    L1 --> |Enforced| DB[(Database Constraint)]
    L2 --> |Enforced| HITL[HITL Checkpoint]
    L3 --> |Enforced| DB
    L4 --> |Enforced| BLOCK[Cross-Identity Block Table]
    L5 --> |Enforced| DB
    L6 --> |Enforced| AUDIT[Audit Log]
    L7 --> |Enforced| DB
    L8 --> |Enforced| API[API Validation]
    L9 --> |Enforced| API
    L10 --> |Enforced| API
```

---

## 7. MEMORY & GOVERNANCE FLOW

```mermaid
flowchart TB
    subgraph "MEMORY TYPES"
        ST[Short-Term Memory]
        MT[Mid-Term Memory]
        LT[Long-Term Memory]
        PIN[Pinned Memory]
        ARC[Archived Memory]
    end
    
    subgraph "STORAGE"
        DS[DataSpaces]
        TH[Threads]
        IP[Identity Profiles]
    end
    
    subgraph "GOVERNANCE CHECKS"
        IC[Identity Check]
        PC[Permission Check]
        DC[Domain Check]
        SC[Sphere Check]
        XIC[Cross-Identity Block]
    end
    
    subgraph "ACTIONS"
        APP[✓ Approve]
        BLK[✗ Block]
        ELV[↑ Elevate to HITL]
        LOG[📝 Log]
    end
    
    ST --> DS
    MT --> DS
    MT --> TH
    LT --> IP
    PIN --> IP
    
    DS --> IC
    IC --> XIC
    XIC -->|Blocked| BLK
    XIC -->|OK| PC
    PC --> DC
    DC --> SC
    
    SC -->|Allowed| APP
    SC -->|Denied| BLK
    SC -->|Sensitive| ELV
    
    APP --> LOG
    BLK --> LOG
    ELV --> LOG
```

---

## 8. WORKSPACE ENGINE MODES

```mermaid
flowchart LR
    subgraph "9 WORKSPACE MODES"
        DOC[📄 Document]
        BRD[📋 Board]
        TML[📅 Timeline]
        SPR[📊 Spreadsheet]
        DSH[📈 Dashboard]
        DGM[🔀 Diagram]
        WBD[🎨 Whiteboard]
        XRM[🥽 XR Mode]
        HYB[🔄 Hybrid]
    end
    
    subgraph "TRANSFORMATIONS"
        T1[Data Preserved]
        T2[Layout Adapted]
        T3[Reversible]
    end
    
    DOC <--> T1
    BRD <--> T1
    TML <--> T1
    SPR <--> T1
    DSH <--> T1
    DGM <--> T1
    WBD <--> T1
    XRM <-.->|READ ONLY| T1
    HYB <--> T1
    
    T1 <--> T2
    T2 <--> T3
```

---

## 9. BACKSTAGE INTELLIGENCE PIPELINE

```mermaid
sequenceDiagram
    participant U as User
    participant WS as Workspace
    participant BI as Backstage Intelligence
    participant CL as Classifier
    participant PR as Pre-Processor
    participant AG as Agents
    participant DS as DataSpace
    
    U->>WS: User Action
    WS->>BI: Context Signal
    BI->>CL: Classify Input
    CL->>BI: Classification
    BI->>PR: Pre-process
    PR->>BI: Prepared Data
    BI->>AG: Suggest Agents
    BI->>DS: Fetch Relevant Data
    DS->>BI: Context Data
    BI->>WS: Ready State
    WS->>U: Instant Response
    
    Note over BI: Invisible to User
    Note over BI: No Data Storage
    Note over BI: Synthetic Only
```

---

## 10. MEETING SYSTEM FLOW

```mermaid
stateDiagram-v2
    [*] --> Scheduled
    Scheduled --> Active: Start Meeting
    Active --> Active: Add Notes
    Active --> Active: Record Decisions
    Active --> Active: Create Tasks
    Active --> Completed: End Meeting
    Completed --> [*]
    
    state Active {
        [*] --> Running
        Running --> Paused: Pause
        Paused --> Running: Resume
        Running --> XR_Mode: Enter XR
        XR_Mode --> Running: Exit XR
        
        state "Consent Check" as CC
        Running --> CC: Enable Recording
        CC --> Recording: All Consent ✓
        CC --> Running: Consent Missing ✗
    }
    
    state Completed {
        [*] --> Processing
        Processing --> Summary_Generated
        Summary_Generated --> Tasks_Routed
        Tasks_Routed --> [*]
    }
```

---

## 11. IMMOBILIER DOMAIN MODEL

```mermaid
erDiagram
    PROPERTY ||--o{ UNIT : has
    PROPERTY ||--o{ LEASE : has
    LEASE ||--|| TENANT : with
    LEASE ||--o{ PAYMENT : generates
    PROPERTY ||--o{ MAINTENANCE : requires
    PROPERTY }o--|| DATASPACE : stored_in
    
    PROPERTY {
        uuid id PK
        string type
        string address
        decimal value
        string status
        boolean tal_compliant
    }
    
    UNIT {
        uuid id PK
        string number
        decimal rent
        string status
    }
    
    TENANT {
        uuid id PK
        string name
        string email
        string phone
    }
    
    LEASE {
        uuid id PK
        date start_date
        date end_date
        decimal monthly_rent
        boolean section_g_disclosed
        boolean tal_registered
    }
    
    PAYMENT {
        uuid id PK
        date payment_date
        decimal amount
        string status
    }
    
    MAINTENANCE {
        uuid id PK
        string title
        string category
        string priority
        string status
    }
```

---

## 12. DATASPACE RELATIONSHIPS

```mermaid
erDiagram
    DATASPACE ||--o{ DATASPACE_ITEM : contains
    DATASPACE ||--o{ DATASPACE_LINK : links
    DATASPACE }o--|| IDENTITY : belongs_to
    DATASPACE }o--o| SPHERE : scoped_to
    DATASPACE }o--o| DOMAIN : typed_by
    DATASPACE ||--o{ THREAD : has
    DATASPACE ||--o{ FILE : stores
    DATASPACE ||--o{ WORKSPACE : viewed_in
    
    DATASPACE {
        uuid id PK
        string name
        string type
        uuid owner_id FK
        uuid identity_id FK
        uuid sphere_id FK
        uuid domain_id FK
        jsonb metadata
        tsvector search_vector
    }
    
    DATASPACE_ITEM {
        uuid id PK
        uuid dataspace_id FK
        string type
        text content
        integer position
    }
    
    DATASPACE_LINK {
        uuid id PK
        uuid source_id FK
        uuid target_id FK
        string link_type
    }
```

---

## 13. GOVERNANCE AUDIT TRAIL

```mermaid
sequenceDiagram
    participant U as User
    participant A as Action
    participant G as Governance
    participant P as Permission
    participant L as Audit Log
    participant R as Reversibility
    
    U->>A: Request Action
    A->>G: Check Governance
    G->>P: Verify Permission
    
    alt Permission Granted
        P->>A: Approved
        A->>L: Log Action (before/after state)
        L->>R: Save Reversible State
        A->>U: Action Complete ✓
    else Permission Denied
        P->>G: Denied
        G->>L: Log Denial
        G->>U: Explain Denial ✗
    else HITL Required
        P->>G: Needs Human Approval
        G->>U: Request HITL Approval
        U->>G: Approve/Deny
        G->>L: Log HITL Decision
        alt HITL Approved
            G->>A: Execute
        else HITL Denied
            G->>U: Action Cancelled
        end
    end
```

---

## 14. XR SPATIAL ENGINE (READ ONLY)

```mermaid
flowchart TB
    subgraph "INPUT SOURCES"
        BP[Blueprints]
        MD[3D Models]
        DS[DataSpaces]
        MT[Meetings]
    end
    
    subgraph "XR ENGINE"
        SP[Spatial Parser]
        RG[Room Generator]
        OB[Object Manager]
        AV[Avatar System]
    end
    
    subgraph "XR ROOM - READ ONLY"
        SC[Scene]
        OBJ[Objects]
        USR[Users]
        INT[Interactions]
    end
    
    subgraph "OUTPUT - VIEW ONLY"
        VR[VR Experience]
        AR[AR Overlay]
        DT[Desktop 3D]
        MB[Mobile View]
    end
    
    BP --> SP
    MD --> SP
    DS -.->|READ| RG
    MT -.->|READ| RG
    
    SP --> RG
    RG --> SC
    OB --> OBJ
    AV --> USR
    
    SC --> VR
    SC --> AR
    SC --> DT
    SC --> MB
    
    style SC fill:#f9f,stroke:#333
    style OBJ fill:#f9f,stroke:#333
    
    Note1[XR CANNOT WRITE TO DATA LAYER]
```

---

## 15. COMPLETE DATA FLOW

```mermaid
flowchart TB
    subgraph "USER INPUT"
        CMD[Command]
        FILE[File]
        CTX[Context]
    end
    
    subgraph "PROCESSING"
        BI[Backstage Intelligence]
        OC[1-Click Engine]
        AG[287 Agents]
    end
    
    subgraph "GOVERNANCE LAYER"
        MG[Memory & Governance]
        ID[Identity Check]
        PM[Permission Check]
        HITL[HITL Checkpoint]
    end
    
    subgraph "STORAGE"
        DS[DataSpaces]
        TH[Threads]
        FL[Files]
    end
    
    subgraph "OUTPUT"
        DOC[Documents]
        DSH[Dashboards]
        XRS[XR Scenes - READ ONLY]
        RPT[Reports]
    end
    
    CMD --> BI
    FILE --> BI
    CTX --> BI
    
    BI --> OC
    OC --> AG
    AG --> MG
    
    MG --> ID
    ID --> PM
    PM --> HITL
    
    HITL -->|Approved| DS
    HITL -->|Approved| TH
    HITL -->|Approved| FL
    
    DS --> DOC
    DS --> DSH
    DS -.->|READ ONLY| XRS
    DS --> RPT
```

---

## 16. API ARCHITECTURE

```mermaid
graph TB
    subgraph "API GATEWAY"
        GW[FastAPI Application]
    end
    
    subgraph "ROUTERS"
        R1[/v1/identities]
        R2[/v1/dataspaces]
        R3[/v1/threads]
        R4[/v1/workspaces]
        R5[/v1/oneclick]
        R6[/v1/backstage]
        R7[/v1/memory]
        R8[/v1/governance]
        R9[/v1/agents]
        R10[/v1/meetings]
        R11[/v1/immobilier]
    end
    
    subgraph "MIDDLEWARE"
        AUTH[JWT Auth]
        CORS[CORS]
        LOG[Request Logging]
        HITL[HITL Interceptor]
    end
    
    subgraph "ENGINES"
        WE[Workspace Engine]
        DE[DataSpace Engine]
        OE[OneClick Engine]
        BE[Backstage Engine]
        ME[Memory Engine]
        AE[Agent Engine]
    end
    
    GW --> AUTH
    AUTH --> CORS
    CORS --> LOG
    LOG --> HITL
    
    HITL --> R1
    HITL --> R2
    HITL --> R3
    HITL --> R4
    HITL --> R5
    HITL --> R6
    HITL --> R7
    HITL --> R8
    HITL --> R9
    HITL --> R10
    HITL --> R11
    
    R4 --> WE
    R2 --> DE
    R5 --> OE
    R6 --> BE
    R7 --> ME
    R9 --> AE
```

---

*CHE·NU™ V70 Architecture Documentation — January 2026*
*GOUVERNANCE > EXÉCUTION*
