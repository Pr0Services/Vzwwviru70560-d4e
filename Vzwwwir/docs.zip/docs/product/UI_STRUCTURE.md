# CHE·NU™ — UI STRUCTURE

> **VERSION:** V1 FREEZE  
> **SCOPE:** Interface structure without visual design specifics

---

## 1. LAYOUT ARCHITECTURE

### 1.1 The 3 Hub Model

```
┌─────────────────────────────────────────────────────────────────────────┐
│                              VIEWPORT                                    │
├─────────┬─────────────────────────────────────────────────────┬─────────┤
│         │                                                     │         │
│  LEFT   │                    CENTER HUB                       │  RIGHT  │
│  HUB    │               (Main Workspace)                      │  HUB    │
│         │                                                     │         │
│ 240px   │                    Flexible                         │  320px  │
│ fixed   │                                                     │  fixed  │
│         │                                                     │         │
│         │                                                     │         │
├─────────┴─────────────────────────────────────────────────────┴─────────┤
│                             BOTTOM HUB                                   │
│                              (64px fixed)                               │
└─────────────────────────────────────────────────────────────────────────┘
```

### 1.2 Hub Responsibilities

| Hub | Purpose | Contents |
|-----|---------|----------|
| **LEFT** | Navigation | Sphere selector, search, quick access |
| **CENTER** | Workspace | Active bureau, content, main interactions |
| **RIGHT** | Intelligence | Nova, agents, tokens, notifications |
| **BOTTOM** | Status | Quick actions, status bar, Nova access |

---

## 2. LEFT HUB (Navigation)

### 2.1 Structure

```
┌─────────────────────────┐
│       LOGO / HOME       │ ← Click returns to dashboard
├─────────────────────────┤
│     🔍 SEARCH BAR       │ ← Global search
├─────────────────────────┤
│                         │
│   SPHERE SELECTOR       │
│                         │
│   🏠 Personal           │ ← Active sphere highlighted
│   💼 Business           │
│   🏛️ Government         │
│   🎨 Studio             │
│   👥 Community          │
│   📱 Social             │
│   🎬 Entertainment      │
│   🤝 My Team            │
│                         │
├─────────────────────────┤
│     QUICK ACCESS        │
│   • Recent threads      │
│   • Pinned items        │
│   • Favorites           │
├─────────────────────────┤
│       SETTINGS          │ ← User settings access
│       HELP              │ ← Help & documentation
└─────────────────────────┘
```

### 2.2 States

| State | Visual |
|-------|--------|
| Active sphere | Highlighted background, bold text |
| Hover sphere | Subtle highlight |
| Collapsed | Icons only, no labels |
| Expanded | Full labels visible |

---

## 3. CENTER HUB (Workspace)

### 3.1 Bureau Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  BUREAU HEADER                                                   │
│  [Sphere Icon] Sphere Name > Section Name                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  SECTION TABS                                                    │
│  ┌──────┬──────┬──────┬──────┬──────┬──────┬──────┬──────┬────┐ │
│  │Dash  │Notes │Tasks │Proj  │Thread│Meet  │Data  │Agent │Rep │ │
│  └──────┴──────┴──────┴──────┴──────┴──────┴──────┴──────┴────┘ │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│                      SECTION CONTENT                             │
│                                                                  │
│                    (Varies by section)                           │
│                                                                  │
│                                                                  │
│                                                                  │
│                                                                  │
│                                                                  │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│  ACTION BAR                                                      │
│  [+ New] [Filter] [Sort] [View Options]                         │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 Section Content Templates

#### Dashboard
```
┌─────────────────────────────────────────────────────────────────┐
│  METRICS ROW                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐            │
│  │ Threads │  │ Tokens  │  │  Tasks  │  │ Meetings│            │
│  │   12    │  │ 3,450   │  │    5    │  │    2    │            │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘            │
├─────────────────────────────────────────────────────────────────┤
│  RECENT ACTIVITY                    │  QUICK ACTIONS            │
│  • Thread created 2h ago            │  [New Thread]             │
│  • Meeting scheduled                │  [New Task]               │
│  • Agent completed task             │  [View Reports]           │
└─────────────────────────────────────────────────────────────────┘
```

#### Threads
```
┌─────────────────────────────────────────────────────────────────┐
│  THREAD LIST                        │  THREAD DETAIL            │
│  ┌────────────────────────────────┐ │  ┌───────────────────────┐│
│  │ ● Active Thread 1              │ │  │ Thread Title          ││
│  │   Last: 2h ago | 150 tokens    │ │  │                       ││
│  ├────────────────────────────────┤ │  │ Message history...    ││
│  │ ○ Thread 2                     │ │  │                       ││
│  │   Last: 1d ago | 500 tokens    │ │  │                       ││
│  ├────────────────────────────────┤ │  │                       ││
│  │ ○ Thread 3                     │ │  │                       ││
│  └────────────────────────────────┘ │  │ ┌───────────────────┐ ││
│                                     │  │ │ Input box...      │ ││
│                                     │  │ └───────────────────┘ ││
└─────────────────────────────────────────────────────────────────┘
```

---

## 4. RIGHT HUB (Intelligence)

### 4.1 Structure

```
┌─────────────────────────┐
│      NOVA STATUS        │
│   ┌───────────────────┐ │
│   │       ✧           │ │ ← Nova icon (animated when active)
│   │      Nova         │ │
│   │      Idle         │ │
│   └───────────────────┘ │
├─────────────────────────┤
│     ACTIVE AGENTS       │
│   ┌─────────────────┐   │
│   │ 🤖 Orchestrator │   │
│   │    Working...   │   │
│   └─────────────────┘   │
├─────────────────────────┤
│      TOKEN STATUS       │
│   ┌─────────────────┐   │
│   │ Balance: 7,500  │   │
│   │ ████████░░ 75%  │   │
│   │ Budget: 10,000  │   │
│   └─────────────────┘   │
├─────────────────────────┤
│     NOTIFICATIONS       │
│   • Thread response     │
│   • Budget warning      │
│   • Agent complete      │
├─────────────────────────┤
│    QUICK NOVA CHAT      │
│   ┌─────────────────┐   │
│   │ Ask Nova...     │   │
│   └─────────────────┘   │
└─────────────────────────┘
```

### 4.2 States

| Component | States |
|-----------|--------|
| Nova | Idle, Thinking, Speaking |
| Agent | Idle, Working, Complete, Error |
| Tokens | Normal, Warning (80%), Critical (95%) |

---

## 5. BOTTOM HUB (Status Bar)

### 5.1 Structure

```
┌─────────────────────────────────────────────────────────────────────────┐
│ 🏠 Personal > Threads          │  ✧ Nova  │  🔔 3  │  ⚡ 7,500 tokens  │
│                                │  Ready   │        │                    │
└─────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Elements

| Position | Content |
|----------|---------|
| Left | Breadcrumb / current location |
| Center | Nova status (clickable to open chat) |
| Right-center | Notification count |
| Right | Token balance |

---

## 6. RESPONSIVE BEHAVIOR

### 6.1 Breakpoints

| Breakpoint | Width | Layout Change |
|------------|-------|---------------|
| Desktop XL | >1440px | Full 3-hub layout |
| Desktop | 1024-1440px | Standard 3-hub |
| Tablet | 768-1024px | Collapsible left hub |
| Mobile | <768px | Single hub, bottom nav |

### 6.2 Mobile Layout

```
┌─────────────────────────┐
│       HEADER            │
│  [☰]  CHE·NU  [✧] [🔔] │
├─────────────────────────┤
│                         │
│                         │
│     MAIN CONTENT        │
│                         │
│                         │
│                         │
│                         │
├─────────────────────────┤
│      BOTTOM NAV         │
│ 🏠  📋  💬  👤  ⚡      │
└─────────────────────────┘
```

---

## 7. NAVIGATION PATTERNS

### 7.1 Primary Navigation

```
User clicks sphere → Bureau loads → Default section (Dashboard) shows
User clicks section tab → Section content loads
User clicks item → Detail view opens (or side panel)
```

### 7.2 Breadcrumb Pattern

```
Home > [Sphere] > [Section] > [Item]

Examples:
• Home > Personal > Threads > Q4 Planning
• Home > Business > Meetings > Team Sync
```

### 7.3 Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd/Ctrl + K` | Global search |
| `Cmd/Ctrl + N` | New thread |
| `Cmd/Ctrl + 1-8` | Switch sphere |
| `Esc` | Close modal/panel |
| `?` | Show shortcuts |

---

## 8. MODAL & PANEL RULES

### 8.1 Modal Types

| Type | Use Case | Width |
|------|----------|-------|
| Dialog | Confirmations, alerts | 400px |
| Form | Create/edit items | 600px |
| Detail | Full item view | 800px |

### 8.2 Panel Rules

- Side panels slide from right
- Max width: 50% of viewport
- Can be pinned or floating
- Stack maximum: 2 panels

---

## 9. LOADING STATES

### 9.1 Skeleton Screens

```
┌─────────────────────────────────────┐
│ ████████████████████░░░░░░░░░░░░░░ │
│                                     │
│ ████████████████████████░░░░░░░░░░ │
│ ████████████████░░░░░░░░░░░░░░░░░░ │
│                                     │
│ ████████████████████████████░░░░░░ │
└─────────────────────────────────────┘
```

### 9.2 Loading Indicators

| Context | Indicator |
|---------|-----------|
| Full page | Centered spinner |
| Section | Skeleton screen |
| Button | Inline spinner |
| Nova | Animated icon |

---

## 10. EMPTY STATES

### 10.1 Template

```
┌─────────────────────────────────────┐
│                                     │
│            [Illustration]           │
│                                     │
│         No threads yet              │
│                                     │
│   Start a conversation with Nova    │
│   to create your first thread.      │
│                                     │
│         [Create Thread]             │
│                                     │
└─────────────────────────────────────┘
```

---

## 11. ACCESSIBILITY REQUIREMENTS

| Requirement | Implementation |
|-------------|----------------|
| Focus management | Visible focus rings |
| Screen readers | ARIA labels |
| Keyboard nav | Full keyboard support |
| Color contrast | WCAG AA minimum |
| Motion | Respect reduced-motion |

---

**END OF UI STRUCTURE**
