"""
CHE·NU™ V70 — MODULE 37: EXTERNAL WORLD INTERFACE
CHE·NU™ dialogue. Elle ne s'aligne jamais aveuglément.
"""

from .engine import (
    ExternalEntityType,
    ExchangeMode,
    FilterType,
    ExternalEntity,
    SemanticFirewall,
    ExternalRequest,
    ExternalResponse,
    ExternalWorldInterface,
)

__all__ = [
    "ExternalEntityType",
    "ExchangeMode",
    "FilterType",
    "ExternalEntity",
    "SemanticFirewall",
    "ExternalRequest",
    "ExternalResponse",
    "ExternalWorldInterface",
]

__version__ = "70.0.0"
