"""
WEBSOCKET ROUTES
================

FastAPI WebSocket endpoints for CHE·NU real-time features.

Endpoints:
- /ws/connect - Main WebSocket connection endpoint
- /ws/thread/{thread_id} - Thread-specific WebSocket
- /ws/health - WebSocket service health

R&D COMPLIANCE:
- Rule #1: Checkpoints sent via WebSocket still require approval action
- Rule #3: Identity boundary enforced - only access own data
- Rule #6: All connections and events logged

VERSION: 1.0.0
"""

from typing import Optional, Dict, Any
from uuid import UUID
from datetime import datetime
import json
import logging

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Query, Depends, HTTPException
from fastapi.security import HTTPBearer

from .connection_manager import (
    ConnectionManager,
    get_connection_manager,
    ConnectionState,
    SubscriptionType,
    EventType
)
from .event_broadcaster import get_event_broadcaster

logger = logging.getLogger(__name__)

router = APIRouter(tags=["WebSocket"])


# =============================================================================
# WEBSOCKET ENDPOINTS
# =============================================================================

@router.websocket("/ws/connect")
async def websocket_connect(
    websocket: WebSocket,
    token: Optional[str] = Query(None)
):
    """
    Main WebSocket connection endpoint.
    
    Connection Flow:
    1. Client connects with optional token query param
    2. Server accepts connection
    3. Client sends authenticate message with identity
    4. Client subscribes to events
    5. Server broadcasts events based on subscriptions
    
    Message Format (Client -> Server):
    {
        "action": "authenticate|subscribe|unsubscribe|ping|join_presence|leave_presence",
        "payload": {...},
        "request_id": "optional-uuid"
    }
    
    Message Format (Server -> Client):
    {
        "type": "connection|subscription|event|system|error",
        "event": "event.name",
        "data": {...},
        "timestamp": "ISO timestamp",
        "request_id": "echoed if provided"
    }
    """
    manager = get_connection_manager()
    connection_id = await manager.connect(websocket)
    
    # If token provided, try to authenticate immediately
    if token:
        # In production, validate JWT and extract identity_id
        # For now, we'll wait for explicit authenticate message
        pass
    
    try:
        while True:
            # Receive message from client
            data = await websocket.receive_json()
            
            # Handle message
            response = await _handle_websocket_message(manager, connection_id, data)
            
            # Send response if any
            if response:
                response["request_id"] = data.get("request_id")
                await websocket.send_json(response)
    
    except WebSocketDisconnect:
        logger.info(f"WebSocket client disconnected: {connection_id}")
    except Exception as e:
        logger.error(f"WebSocket error for {connection_id}: {e}")
    finally:
        await manager.disconnect(connection_id)


@router.websocket("/ws/thread/{thread_id}")
async def websocket_thread(
    websocket: WebSocket,
    thread_id: str,
    token: Optional[str] = Query(None)
):
    """
    Thread-specific WebSocket connection.
    
    Automatically subscribes to:
    - Thread events
    - Thread presence
    
    Client still needs to authenticate.
    """
    manager = get_connection_manager()
    connection_id = await manager.connect(websocket)
    
    try:
        # First message should be authentication
        auth_data = await websocket.receive_json()
        
        if auth_data.get("action") != "authenticate":
            await websocket.send_json({
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "First message must be authenticate"},
                "timestamp": datetime.utcnow().isoformat()
            })
            return
        
        # Authenticate
        identity_id = auth_data.get("payload", {}).get("identity_id")
        if not identity_id:
            await websocket.send_json({
                "type": "error",
                "event": EventType.UNAUTHORIZED.value,
                "data": {"message": "identity_id required"},
                "timestamp": datetime.utcnow().isoformat()
            })
            return
        
        await manager.authenticate(connection_id, identity_id)
        
        # Auto-subscribe to Thread
        await manager.subscribe(connection_id, SubscriptionType.THREAD, thread_id)
        
        # Auto-join presence
        await manager.join_presence(connection_id, thread_id)
        
        # Notify presence
        broadcaster = get_event_broadcaster()
        await broadcaster.broadcast_presence_update(
            room_id=thread_id,
            identity_id=identity_id,
            status="online",
            activity="viewing thread"
        )
        
        # Main message loop
        while True:
            data = await websocket.receive_json()
            response = await _handle_websocket_message(manager, connection_id, data)
            
            if response:
                response["request_id"] = data.get("request_id")
                await websocket.send_json(response)
    
    except WebSocketDisconnect:
        logger.info(f"Thread WebSocket client disconnected: {connection_id}")
    except Exception as e:
        logger.error(f"Thread WebSocket error for {connection_id}: {e}")
    finally:
        # Leave presence before disconnecting
        await manager.leave_presence(connection_id, thread_id)
        await manager.disconnect(connection_id)


# =============================================================================
# HTTP ENDPOINTS (WebSocket Service Info)
# =============================================================================

@router.get("/ws/health")
async def websocket_health():
    """WebSocket service health check"""
    manager = get_connection_manager()
    stats = manager.get_stats()
    
    return {
        "status": "healthy",
        "service": "websocket",
        "stats": stats,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get("/ws/stats")
async def websocket_stats():
    """Get WebSocket service statistics"""
    manager = get_connection_manager()
    broadcaster = get_event_broadcaster()
    
    return {
        "connection_manager": manager.get_stats(),
        "broadcasts": {
            "total_broadcasts": broadcaster.get_broadcast_count()
        },
        "timestamp": datetime.utcnow().isoformat()
    }


# =============================================================================
# MESSAGE HANDLERS
# =============================================================================

async def _handle_websocket_message(
    manager: ConnectionManager,
    connection_id: str,
    data: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    """
    Handle incoming WebSocket message.
    
    Actions:
    - authenticate: Link connection to identity
    - subscribe: Subscribe to events
    - unsubscribe: Unsubscribe from events
    - ping: Keepalive ping
    - join_presence: Join a presence room
    - leave_presence: Leave a presence room
    - get_presence: Get users in a room
    
    Returns response dict or None.
    """
    action = data.get("action")
    payload = data.get("payload", {})
    
    if action == "authenticate":
        identity_id = payload.get("identity_id")
        if not identity_id:
            return {
                "type": "error",
                "event": EventType.UNAUTHORIZED.value,
                "data": {"message": "identity_id required"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        metadata = payload.get("metadata", {})
        success = await manager.authenticate(connection_id, identity_id, metadata)
        
        if success:
            return None  # authenticate() already sends response
        else:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "Authentication failed"},
                "timestamp": datetime.utcnow().isoformat()
            }
    
    elif action == "subscribe":
        try:
            sub_type = SubscriptionType(payload.get("type"))
        except ValueError:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": f"Invalid subscription type: {payload.get('type')}"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        target_id = payload.get("target_id")
        if not target_id:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "target_id required"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        # subscribe() sends its own response
        subscription_id = await manager.subscribe(connection_id, sub_type, target_id)
        
        if not subscription_id:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "Subscription failed - ensure you are authenticated"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        return None  # subscribe() already sends response
    
    elif action == "unsubscribe":
        try:
            sub_type = SubscriptionType(payload.get("type"))
        except ValueError:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": f"Invalid subscription type: {payload.get('type')}"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        target_id = payload.get("target_id")
        await manager.unsubscribe(connection_id, sub_type, target_id)
        return None  # unsubscribe() sends response
    
    elif action == "ping":
        return {
            "type": "system",
            "event": "pong",
            "data": {"message": "pong"},
            "timestamp": datetime.utcnow().isoformat()
        }
    
    elif action == "join_presence":
        room_id = payload.get("room_id")
        if not room_id:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "room_id required"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        await manager.join_presence(connection_id, room_id)
        return {
            "type": "presence",
            "event": "presence_joined",
            "data": {"room_id": room_id},
            "timestamp": datetime.utcnow().isoformat()
        }
    
    elif action == "leave_presence":
        room_id = payload.get("room_id")
        if not room_id:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "room_id required"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        await manager.leave_presence(connection_id, room_id)
        return {
            "type": "presence",
            "event": "presence_left",
            "data": {"room_id": room_id},
            "timestamp": datetime.utcnow().isoformat()
        }
    
    elif action == "get_presence":
        room_id = payload.get("room_id")
        if not room_id:
            return {
                "type": "error",
                "event": EventType.ERROR.value,
                "data": {"message": "room_id required"},
                "timestamp": datetime.utcnow().isoformat()
            }
        
        identities = await manager.get_presence(room_id)
        return {
            "type": "presence",
            "event": "presence_list",
            "data": {
                "room_id": room_id,
                "identities": identities
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    else:
        return {
            "type": "error",
            "event": EventType.ERROR.value,
            "data": {"message": f"Unknown action: {action}"},
            "timestamp": datetime.utcnow().isoformat()
        }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "router",
    "websocket_connect",
    "websocket_thread",
    "websocket_health",
    "websocket_stats"
]
