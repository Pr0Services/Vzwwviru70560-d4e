
# SCRIPT 2 — LES IA AUSSI SONT SURCHARGÉES
Date: 2026-01-07

[VISUEL]
Flux de texte. Conversations qui se superposent.
Fragments qui se mélangent.

[VOIX]
"Même les intelligences artificielles vivent ce problème."

"Elles ne voient pas une histoire.
Elles voient des fragments."

"Elles cherchent leur mémoire.
Elles reconstruisent le passé.
Elles recalculent ce qui devrait déjà être su."

"Plus on leur donne de puissance,
plus elles consomment d’énergie pour se souvenir mal."

"Le problème n’est pas l’intelligence.
C’est l’absence de mémoire fiable."
