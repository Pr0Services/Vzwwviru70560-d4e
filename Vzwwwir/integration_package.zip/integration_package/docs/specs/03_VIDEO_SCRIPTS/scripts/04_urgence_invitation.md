
# SCRIPT 4 — L’URGENCE ET L’INVITATION
Date: 2026-01-07

[VISUEL]
Plusieurs véhicules.
Certains roulent à fond.
D’autres roulent léger, maîtrisés.

[VOIX]
"La puissance est déjà là.
L’énergie devient critique.
Le temps d’adaptation diminue."

"Continuer comme avant,
c’est accélérer avec un camion surchargé."

"AT-OM est un espace pour apprendre à conduire ensemble."

"Nous invitons les premiers arrivants.
Pas pour tester.
Mais pour participer à quelque chose de nécessaire."

"Parce que la question n’est plus :
Peut-on aller plus vite ?

Mais :
Sait-on encore pourquoi on accélère ?"
