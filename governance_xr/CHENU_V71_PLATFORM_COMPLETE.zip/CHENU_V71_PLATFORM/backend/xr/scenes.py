"""
CHE·NU™ V70 — XR SCENES FOR GP2
===============================
WebXR-ready scene configurations for GP2 modules.

CRITICAL: XR = READ ONLY
All scenes are visualization-only, no write operations.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import json
import hashlib
import logging

logger = logging.getLogger("chenu.xr.gp2")


class SceneType(str, Enum):
    """Types of XR scenes."""
    DECISION_SPACE = "decision_space"
    CAUSAL_GRAPH = "causal_graph"
    CIVILIZATION_MAP = "civilization_map"
    FAILSAFE_MONITOR = "failsafe_monitor"
    ETHICS_DASHBOARD = "ethics_dashboard"
    TRANSMISSION_FLOW = "transmission_flow"
    HERITAGE_TREE = "heritage_tree"
    PLANETARY_NETWORK = "planetary_network"
    COLLAPSE_HEATMAP = "collapse_heatmap"
    MEANING_CONSTELLATION = "meaning_constellation"


class RenderMode(str, Enum):
    """Rendering modes."""
    WEBXR = "webxr"
    THREEJS = "threejs"
    AFRAME = "aframe"
    BABYLON = "babylon"
    STATIC_2D = "static_2d"


@dataclass
class XRVector3:
    """3D Vector for XR positioning."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    
    def to_dict(self) -> dict:
        return {"x": self.x, "y": self.y, "z": self.z}


@dataclass
class XRColor:
    """Color for XR elements."""
    r: float = 1.0
    g: float = 1.0
    b: float = 1.0
    a: float = 1.0
    
    def to_hex(self) -> str:
        return f"#{int(self.r*255):02x}{int(self.g*255):02x}{int(self.b*255):02x}"
    
    def to_dict(self) -> dict:
        return {"r": self.r, "g": self.g, "b": self.b, "a": self.a}


# CHE·NU Brand Colors
COLORS = {
    "sacred_gold": XRColor(0.847, 0.698, 0.416),      # #D8B26A
    "ancient_stone": XRColor(0.553, 0.514, 0.443),    # #8D8371
    "jungle_emerald": XRColor(0.247, 0.447, 0.286),   # #3F7249
    "cenote_turquoise": XRColor(0.243, 0.706, 0.635), # #3EB4A2
    "shadow_moss": XRColor(0.184, 0.298, 0.224),      # #2F4C39
    "earth_ember": XRColor(0.478, 0.349, 0.227),      # #7A593A
    "ui_slate": XRColor(0.118, 0.122, 0.133),         # #1E1F22
    "soft_sand": XRColor(0.914, 0.894, 0.839),        # #E9E4D6
}


@dataclass
class XRNode:
    """Node in XR scene."""
    node_id: str = field(default_factory=lambda: f"NODE_{uuid4().hex[:8]}")
    label: str = ""
    position: XRVector3 = field(default_factory=XRVector3)
    scale: XRVector3 = field(default_factory=lambda: XRVector3(1, 1, 1))
    color: XRColor = field(default_factory=XRColor)
    node_type: str = "default"
    metadata: dict = field(default_factory=dict)
    
    # READ ONLY flag
    read_only: bool = True
    
    def to_dict(self) -> dict:
        return {
            "id": self.node_id,
            "label": self.label,
            "position": self.position.to_dict(),
            "scale": self.scale.to_dict(),
            "color": self.color.to_dict(),
            "type": self.node_type,
            "metadata": self.metadata,
            "read_only": self.read_only,
        }


@dataclass
class XREdge:
    """Edge connecting nodes in XR scene."""
    edge_id: str = field(default_factory=lambda: f"EDGE_{uuid4().hex[:8]}")
    source_id: str = ""
    target_id: str = ""
    label: str = ""
    color: XRColor = field(default_factory=lambda: COLORS["cenote_turquoise"])
    width: float = 0.02
    edge_type: str = "causal"
    animated: bool = True
    
    def to_dict(self) -> dict:
        return {
            "id": self.edge_id,
            "source": self.source_id,
            "target": self.target_id,
            "label": self.label,
            "color": self.color.to_dict(),
            "width": self.width,
            "type": self.edge_type,
            "animated": self.animated,
        }


@dataclass
class XRScene:
    """
    Complete XR Scene configuration.
    
    CRITICAL: All scenes are READ ONLY.
    """
    scene_id: str = field(default_factory=lambda: f"XR_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Scene info
    scene_type: SceneType = SceneType.DECISION_SPACE
    title: str = ""
    description: str = ""
    
    # Rendering
    render_mode: RenderMode = RenderMode.THREEJS
    
    # Elements
    nodes: list[XRNode] = field(default_factory=list)
    edges: list[XREdge] = field(default_factory=list)
    
    # Camera
    camera_position: XRVector3 = field(default_factory=lambda: XRVector3(0, 5, 10))
    camera_target: XRVector3 = field(default_factory=XRVector3)
    
    # Environment
    background_color: XRColor = field(default_factory=lambda: COLORS["ui_slate"])
    ambient_light: float = 0.5
    
    # GOVERNANCE (CRITICAL)
    read_only: bool = True  # ALWAYS TRUE
    synthetic: bool = True  # ALWAYS TRUE
    
    # Verification
    integrity_hash: str = ""
    signatures: list[str] = field(default_factory=list)
    
    def compute_hash(self) -> str:
        """Compute integrity hash."""
        content = json.dumps({
            "scene_id": self.scene_id,
            "scene_type": self.scene_type.value,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()
    
    def verify_integrity(self) -> bool:
        """Verify scene integrity."""
        return self.integrity_hash == self.compute_hash()
    
    def to_dict(self) -> dict:
        return {
            "scene_id": self.scene_id,
            "created_at": self.created_at.isoformat(),
            "scene_type": self.scene_type.value,
            "title": self.title,
            "description": self.description,
            "render_mode": self.render_mode.value,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
            "camera": {
                "position": self.camera_position.to_dict(),
                "target": self.camera_target.to_dict(),
            },
            "environment": {
                "background": self.background_color.to_dict(),
                "ambient_light": self.ambient_light,
            },
            "governance": {
                "read_only": self.read_only,
                "synthetic": self.synthetic,
            },
            "verification": {
                "integrity_hash": self.integrity_hash,
                "signatures": self.signatures,
            },
        }
    
    def to_aframe(self) -> str:
        """Export to A-Frame HTML."""
        nodes_html = []
        for node in self.nodes:
            pos = node.position
            color = node.color.to_hex()
            nodes_html.append(
                f'<a-sphere position="{pos.x} {pos.y} {pos.z}" '
                f'radius="0.3" color="{color}" '
                f'data-node-id="{node.node_id}" '
                f'data-read-only="true"></a-sphere>'
            )
        
        return f"""
<!DOCTYPE html>
<html>
<head>
    <title>{self.title}</title>
    <script src="https://aframe.io/releases/1.4.0/aframe.min.js"></script>
</head>
<body>
    <a-scene background="color: {self.background_color.to_hex()}">
        <!-- Camera -->
        <a-camera position="{self.camera_position.x} {self.camera_position.y} {self.camera_position.z}">
        </a-camera>
        
        <!-- Nodes (READ ONLY) -->
        {''.join(nodes_html)}
        
        <!-- Ambient Light -->
        <a-light type="ambient" intensity="{self.ambient_light}"></a-light>
        
        <!-- Governance Marker -->
        <a-text value="READ ONLY - SYNTHETIC" position="0 -2 0" align="center" color="#D8B26A"></a-text>
    </a-scene>
</body>
</html>
"""


class XRSceneBuilder:
    """
    Builder for XR scenes.
    
    CRITICAL: All built scenes are READ ONLY.
    """
    
    def __init__(self):
        self.builder_id = f"XR_BUILDER_{uuid4().hex[:8]}"
    
    # =========================================================================
    # DECISION SPACE SCENE
    # =========================================================================
    
    def build_decision_space(
        self,
        package_id: str,
        options: list[dict],
        causal_trace: dict = None,
    ) -> XRScene:
        """Build decision space visualization."""
        scene = XRScene(
            scene_type=SceneType.DECISION_SPACE,
            title=f"Decision Space: {package_id}",
            description="Decision options with risk/impact visualization",
        )
        
        # Central decision node
        central = XRNode(
            node_id=f"CENTRAL_{package_id}",
            label="Decision Point",
            position=XRVector3(0, 2, 0),
            color=COLORS["sacred_gold"],
            node_type="decision_point",
        )
        scene.nodes.append(central)
        
        # Option nodes arranged in circle
        num_options = len(options)
        for i, opt in enumerate(options):
            angle = (2 * 3.14159 * i) / max(num_options, 1)
            x = 3 * __import__("math").cos(angle)
            z = 3 * __import__("math").sin(angle)
            
            # Color based on risk
            risk = opt.get("risk", 0.5)
            if risk < 0.3:
                color = COLORS["jungle_emerald"]
            elif risk < 0.6:
                color = COLORS["sacred_gold"]
            else:
                color = COLORS["earth_ember"]
            
            node = XRNode(
                node_id=f"OPT_{i}",
                label=opt.get("name", f"Option {i+1}"),
                position=XRVector3(x, 2, z),
                color=color,
                node_type="option",
                metadata={
                    "risk": risk,
                    "impact": opt.get("impact", "medium"),
                },
            )
            scene.nodes.append(node)
            
            # Edge from central to option
            edge = XREdge(
                source_id=central.node_id,
                target_id=node.node_id,
                label=f"Risk: {risk:.0%}",
                color=color,
            )
            scene.edges.append(edge)
        
        # Compute integrity
        scene.integrity_hash = scene.compute_hash()
        
        return scene
    
    # =========================================================================
    # CAUSAL GRAPH SCENE
    # =========================================================================
    
    def build_causal_graph(
        self,
        trace_id: str,
        events: list[dict],
        causal_links: list[dict],
    ) -> XRScene:
        """Build causal graph visualization."""
        scene = XRScene(
            scene_type=SceneType.CAUSAL_GRAPH,
            title=f"Causal Graph: {trace_id}",
            description="Causal relationships between events",
        )
        
        # Create event nodes
        for i, event in enumerate(events):
            node = XRNode(
                node_id=event.get("event_id", f"EVT_{i}"),
                label=event.get("label", f"Event {i}"),
                position=XRVector3(i * 2 - len(events), 2, 0),
                color=COLORS["cenote_turquoise"],
                node_type="event",
                metadata=event.get("data", {}),
            )
            scene.nodes.append(node)
        
        # Create causal edges
        for link in causal_links:
            edge = XREdge(
                source_id=link.get("source"),
                target_id=link.get("target"),
                label=link.get("strength", ""),
                color=COLORS["sacred_gold"],
                edge_type="causal",
            )
            scene.edges.append(edge)
        
        scene.integrity_hash = scene.compute_hash()
        return scene
    
    # =========================================================================
    # FAILSAFE MONITOR SCENE
    # =========================================================================
    
    def build_failsafe_monitor(
        self,
        current_level: str,
        indicators: dict,
    ) -> XRScene:
        """Build failsafe monitor visualization."""
        scene = XRScene(
            scene_type=SceneType.FAILSAFE_MONITOR,
            title="Civilizational Failsafe Monitor",
            description="Real-time crisis monitoring dashboard",
        )
        
        # Level indicator tower
        levels = ["n0", "n1", "n2", "n3", "n4"]
        for i, level in enumerate(levels):
            is_active = level == current_level
            is_below = levels.index(level) <= levels.index(current_level)
            
            if is_active:
                color = COLORS["sacred_gold"]
            elif is_below:
                color = COLORS["earth_ember"]
            else:
                color = COLORS["shadow_moss"]
            
            node = XRNode(
                node_id=f"LEVEL_{level}",
                label=level.upper(),
                position=XRVector3(-3, i * 1.5, 0),
                scale=XRVector3(1, 0.5, 1),
                color=color,
                node_type="level_indicator",
            )
            scene.nodes.append(node)
        
        # Indicator gauges
        gauge_positions = [
            ("network", XRVector3(0, 4, 0)),
            ("social", XRVector3(2, 4, 0)),
            ("supply", XRVector3(4, 4, 0)),
        ]
        
        for name, pos in gauge_positions:
            value = indicators.get(f"{name}_health", 0.8)
            if value > 0.7:
                color = COLORS["jungle_emerald"]
            elif value > 0.4:
                color = COLORS["sacred_gold"]
            else:
                color = COLORS["earth_ember"]
            
            node = XRNode(
                node_id=f"GAUGE_{name}",
                label=f"{name.title()}: {value:.0%}",
                position=pos,
                color=color,
                node_type="gauge",
                metadata={"value": value},
            )
            scene.nodes.append(node)
        
        scene.integrity_hash = scene.compute_hash()
        return scene
    
    # =========================================================================
    # COLLAPSE HEATMAP SCENE
    # =========================================================================
    
    def build_collapse_heatmap(
        self,
        entity_id: str,
        indicators: dict,
    ) -> XRScene:
        """Build collapse prevention heatmap."""
        scene = XRScene(
            scene_type=SceneType.COLLAPSE_HEATMAP,
            title=f"Collapse Heatmap: {entity_id}",
            description="Risk heatmap for collapse prevention",
        )
        
        # Grid of risk cells
        categories = ["cognitive", "social", "symbolic"]
        time_periods = ["past", "present", "future"]
        
        for i, cat in enumerate(categories):
            for j, period in enumerate(time_periods):
                risk = indicators.get(f"{cat}_{period}", 0.3)
                
                if risk < 0.3:
                    color = COLORS["jungle_emerald"]
                elif risk < 0.6:
                    color = COLORS["sacred_gold"]
                else:
                    color = COLORS["earth_ember"]
                
                node = XRNode(
                    node_id=f"HEAT_{cat}_{period}",
                    label=f"{cat[:3]}/{period[:3]}",
                    position=XRVector3(j * 2, i * 2, 0),
                    scale=XRVector3(1.5, 1.5, 0.1),
                    color=color,
                    node_type="heatmap_cell",
                    metadata={"risk": risk},
                )
                scene.nodes.append(node)
        
        scene.integrity_hash = scene.compute_hash()
        return scene
    
    # =========================================================================
    # MEANING CONSTELLATION SCENE
    # =========================================================================
    
    def build_meaning_constellation(
        self,
        entity_id: str,
        meaning_map: dict,
    ) -> XRScene:
        """Build meaning constellation visualization."""
        scene = XRScene(
            scene_type=SceneType.MEANING_CONSTELLATION,
            title=f"Meaning Constellation: {entity_id}",
            description="Three-axis meaning visualization",
        )
        
        # Central purpose star
        central = XRNode(
            node_id="CENTRAL_PURPOSE",
            label="Purpose Core",
            position=XRVector3(0, 2, 0),
            color=COLORS["sacred_gold"],
            node_type="purpose_core",
        )
        scene.nodes.append(central)
        
        # Three meaning axes
        axes = [
            ("individual", XRVector3(3, 2, 0), COLORS["jungle_emerald"]),
            ("collective", XRVector3(-1.5, 2, 2.6), COLORS["cenote_turquoise"]),
            ("temporal", XRVector3(-1.5, 2, -2.6), COLORS["earth_ember"]),
        ]
        
        for axis_name, pos, color in axes:
            score = meaning_map.get(f"{axis_name}_score", 0.5)
            
            node = XRNode(
                node_id=f"AXIS_{axis_name}",
                label=f"{axis_name.title()}: {score:.0%}",
                position=pos,
                scale=XRVector3(score * 2, score * 2, score * 2),
                color=color,
                node_type="meaning_axis",
                metadata={"score": score},
            )
            scene.nodes.append(node)
            
            edge = XREdge(
                source_id=central.node_id,
                target_id=node.node_id,
                label=f"{score:.0%}",
                color=color,
                width=0.05 * score,
            )
            scene.edges.append(edge)
        
        scene.integrity_hash = scene.compute_hash()
        return scene
    
    # =========================================================================
    # PLANETARY NETWORK SCENE
    # =========================================================================
    
    def build_planetary_network(
        self,
        nodes_data: list[dict],
        connections: list[dict],
    ) -> XRScene:
        """Build planetary coordination network."""
        scene = XRScene(
            scene_type=SceneType.PLANETARY_NETWORK,
            title="Planetary Coordination Network",
            description="Sovereign node network visualization",
        )
        
        # Create sovereign nodes
        for i, node_data in enumerate(nodes_data):
            angle = (2 * 3.14159 * i) / max(len(nodes_data), 1)
            radius = 5
            x = radius * __import__("math").cos(angle)
            z = radius * __import__("math").sin(angle)
            
            trust = node_data.get("trust_level", 0.5)
            if trust > 0.7:
                color = COLORS["jungle_emerald"]
            elif trust > 0.4:
                color = COLORS["cenote_turquoise"]
            else:
                color = COLORS["ancient_stone"]
            
            node = XRNode(
                node_id=node_data.get("node_id", f"NODE_{i}"),
                label=node_data.get("name", f"Node {i}"),
                position=XRVector3(x, 2, z),
                color=color,
                node_type="sovereign_node",
                metadata={
                    "trust_level": trust,
                    "jurisdiction": node_data.get("jurisdiction", ""),
                },
            )
            scene.nodes.append(node)
        
        # Create connections
        for conn in connections:
            edge = XREdge(
                source_id=conn.get("source"),
                target_id=conn.get("target"),
                label=conn.get("mode", "read_only"),
                color=COLORS["cenote_turquoise"],
                edge_type="coordination",
            )
            scene.edges.append(edge)
        
        scene.integrity_hash = scene.compute_hash()
        return scene


# =============================================================================
# XR SCENE MANAGER
# =============================================================================

class XRSceneManager:
    """
    Manager for XR scenes.
    
    CRITICAL: All scenes are READ ONLY.
    """
    
    def __init__(self):
        self.manager_id = f"XR_MGR_{uuid4().hex[:8]}"
        self._scenes: dict[str, XRScene] = {}
        self._builder = XRSceneBuilder()
        
        logger.info(f"XR Scene Manager initialized: {self.manager_id}")
    
    def create_scene(
        self,
        scene_type: SceneType,
        **kwargs,
    ) -> XRScene:
        """Create a new XR scene."""
        builder_methods = {
            SceneType.DECISION_SPACE: self._builder.build_decision_space,
            SceneType.CAUSAL_GRAPH: self._builder.build_causal_graph,
            SceneType.FAILSAFE_MONITOR: self._builder.build_failsafe_monitor,
            SceneType.COLLAPSE_HEATMAP: self._builder.build_collapse_heatmap,
            SceneType.MEANING_CONSTELLATION: self._builder.build_meaning_constellation,
            SceneType.PLANETARY_NETWORK: self._builder.build_planetary_network,
        }
        
        builder_method = builder_methods.get(scene_type)
        if builder_method:
            scene = builder_method(**kwargs)
        else:
            scene = XRScene(scene_type=scene_type)
            scene.integrity_hash = scene.compute_hash()
        
        # Ensure READ ONLY
        scene.read_only = True
        scene.synthetic = True
        
        self._scenes[scene.scene_id] = scene
        logger.info(f"Scene created: {scene.scene_id} ({scene_type.value})")
        
        return scene
    
    def get_scene(self, scene_id: str) -> Optional[XRScene]:
        """Get scene by ID."""
        return self._scenes.get(scene_id)
    
    def verify_scene(self, scene_id: str) -> bool:
        """Verify scene integrity."""
        scene = self._scenes.get(scene_id)
        if not scene:
            return False
        return scene.verify_integrity()
    
    def export_scene(self, scene_id: str, format: str = "json") -> Optional[str]:
        """Export scene to format."""
        scene = self._scenes.get(scene_id)
        if not scene:
            return None
        
        if format == "json":
            return json.dumps(scene.to_dict(), indent=2)
        elif format == "aframe":
            return scene.to_aframe()
        else:
            return json.dumps(scene.to_dict())
    
    def get_stats(self) -> dict:
        """Get manager statistics."""
        return {
            "manager_id": self.manager_id,
            "total_scenes": len(self._scenes),
            "scenes_by_type": {
                t.value: sum(1 for s in self._scenes.values() if s.scene_type == t)
                for t in SceneType
            },
            "all_read_only": all(s.read_only for s in self._scenes.values()),
        }
