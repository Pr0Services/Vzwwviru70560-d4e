"""
CHE·NU™ V70 — PROMETHEUS METRICS
================================
Detailed metrics for GP2 system monitoring.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from datetime import datetime
from typing import Any, Callable, Optional
from functools import wraps
import time
import logging

logger = logging.getLogger("chenu.metrics")

# Try to import prometheus_client
try:
    from prometheus_client import (
        Counter,
        Gauge,
        Histogram,
        Summary,
        Info,
        generate_latest,
        CONTENT_TYPE_LATEST,
        CollectorRegistry,
    )
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False
    logger.warning("prometheus_client not installed, metrics disabled")


# =============================================================================
# METRIC DEFINITIONS
# =============================================================================

if PROMETHEUS_AVAILABLE:
    # Create a custom registry
    REGISTRY = CollectorRegistry()
    
    # =========================================================================
    # SYSTEM INFO
    # =========================================================================
    
    SYSTEM_INFO = Info(
        'chenu_gp2_system',
        'CHE·NU GP2 system information',
        registry=REGISTRY,
    )
    
    # =========================================================================
    # REQUEST METRICS
    # =========================================================================
    
    REQUEST_COUNT = Counter(
        'chenu_gp2_requests_total',
        'Total number of requests',
        ['method', 'endpoint', 'status'],
        registry=REGISTRY,
    )
    
    REQUEST_LATENCY = Histogram(
        'chenu_gp2_request_latency_seconds',
        'Request latency in seconds',
        ['method', 'endpoint'],
        buckets=[0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0],
        registry=REGISTRY,
    )
    
    ACTIVE_REQUESTS = Gauge(
        'chenu_gp2_active_requests',
        'Number of active requests',
        registry=REGISTRY,
    )
    
    # =========================================================================
    # GOVERNANCE METRICS
    # =========================================================================
    
    GOVERNANCE_CHECKS = Counter(
        'chenu_gp2_governance_checks_total',
        'Total governance checks',
        ['module', 'result'],
        registry=REGISTRY,
    )
    
    GOVERNANCE_VIOLATIONS = Counter(
        'chenu_gp2_governance_violations_total',
        'Total governance violations',
        ['module', 'violation_type'],
        registry=REGISTRY,
    )
    
    OPA_DECISIONS = Counter(
        'chenu_gp2_opa_decisions_total',
        'Total OPA decisions',
        ['policy', 'result'],
        registry=REGISTRY,
    )
    
    OPA_LATENCY = Histogram(
        'chenu_gp2_opa_latency_seconds',
        'OPA decision latency',
        ['policy'],
        buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # NOVA METRICS
    # =========================================================================
    
    NOVA_REQUESTS = Counter(
        'chenu_gp2_nova_requests_total',
        'Total NOVA requests',
        ['status'],
        registry=REGISTRY,
    )
    
    NOVA_REFUSALS = Counter(
        'chenu_gp2_nova_refusals_total',
        'Total NOVA refusals',
        ['reason'],
        registry=REGISTRY,
    )
    
    NOVA_PROCESSING_TIME = Histogram(
        'chenu_gp2_nova_processing_seconds',
        'NOVA processing time',
        buckets=[0.1, 0.25, 0.5, 1.0, 2.5, 5.0],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # ETHICS METRICS
    # =========================================================================
    
    ETHICS_VALIDATIONS = Counter(
        'chenu_gp2_ethics_validations_total',
        'Total ethics validations',
        ['result'],
        registry=REGISTRY,
    )
    
    ETHICS_VIOLATIONS = Counter(
        'chenu_gp2_ethics_violations_total',
        'Total ethics violations by type',
        ['violation_type'],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # DECISION LOOP METRICS
    # =========================================================================
    
    DECISION_LOOPS = Counter(
        'chenu_gp2_decision_loops_total',
        'Total decision loops',
        ['status'],
        registry=REGISTRY,
    )
    
    HITL_PENDING = Gauge(
        'chenu_gp2_hitl_pending',
        'Number of pending HITL approvals',
        registry=REGISTRY,
    )
    
    HITL_APPROVALS = Counter(
        'chenu_gp2_hitl_approvals_total',
        'Total HITL approvals',
        ['result'],
        registry=REGISTRY,
    )
    
    SIMULATION_CYCLES = Histogram(
        'chenu_gp2_simulation_cycles',
        'Number of simulation cycles',
        buckets=[1, 5, 10, 25, 50, 100, 250, 500, 1000],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # FAILSAFE METRICS
    # =========================================================================
    
    FAILSAFE_LEVEL = Gauge(
        'chenu_gp2_failsafe_level',
        'Current failsafe level (0-4)',
        registry=REGISTRY,
    )
    
    CRISIS_DETECTIONS = Counter(
        'chenu_gp2_crisis_detections_total',
        'Total crisis detections',
        ['crisis_type'],
        registry=REGISTRY,
    )
    
    FAILSAFE_ACTIVATIONS = Counter(
        'chenu_gp2_failsafe_activations_total',
        'Total failsafe activations',
        ['level'],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # XR METRICS
    # =========================================================================
    
    XR_SCENES_GENERATED = Counter(
        'chenu_gp2_xr_scenes_generated_total',
        'Total XR scenes generated',
        ['scene_type'],
        registry=REGISTRY,
    )
    
    XR_SCENE_SIZE = Histogram(
        'chenu_gp2_xr_scene_size_bytes',
        'XR scene size in bytes',
        buckets=[1024, 10240, 102400, 1048576, 10485760],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # WORKER METRICS
    # =========================================================================
    
    TASKS_SUBMITTED = Counter(
        'chenu_gp2_tasks_submitted_total',
        'Total tasks submitted',
        ['task_name', 'queue'],
        registry=REGISTRY,
    )
    
    TASKS_COMPLETED = Counter(
        'chenu_gp2_tasks_completed_total',
        'Total tasks completed',
        ['task_name', 'status'],
        registry=REGISTRY,
    )
    
    TASK_DURATION = Histogram(
        'chenu_gp2_task_duration_seconds',
        'Task duration in seconds',
        ['task_name'],
        buckets=[0.1, 0.5, 1.0, 5.0, 10.0, 30.0, 60.0],
        registry=REGISTRY,
    )
    
    TASK_QUEUE_SIZE = Gauge(
        'chenu_gp2_task_queue_size',
        'Current task queue size',
        ['queue'],
        registry=REGISTRY,
    )
    
    WORKERS_ACTIVE = Gauge(
        'chenu_gp2_workers_active',
        'Number of active workers',
        registry=REGISTRY,
    )
    
    # =========================================================================
    # CACHE METRICS
    # =========================================================================
    
    CACHE_HITS = Counter(
        'chenu_gp2_cache_hits_total',
        'Total cache hits',
        ['namespace'],
        registry=REGISTRY,
    )
    
    CACHE_MISSES = Counter(
        'chenu_gp2_cache_misses_total',
        'Total cache misses',
        ['namespace'],
        registry=REGISTRY,
    )
    
    CACHE_SIZE = Gauge(
        'chenu_gp2_cache_size',
        'Current cache size',
        ['namespace'],
        registry=REGISTRY,
    )
    
    # =========================================================================
    # AUTH METRICS
    # =========================================================================
    
    AUTH_ATTEMPTS = Counter(
        'chenu_gp2_auth_attempts_total',
        'Total authentication attempts',
        ['result'],
        registry=REGISTRY,
    )
    
    ACTIVE_SESSIONS = Gauge(
        'chenu_gp2_active_sessions',
        'Number of active sessions',
        registry=REGISTRY,
    )
    
    TOKEN_VALIDATIONS = Counter(
        'chenu_gp2_token_validations_total',
        'Total token validations',
        ['result'],
        registry=REGISTRY,
    )


# =============================================================================
# METRICS COLLECTOR
# =============================================================================

class MetricsCollector:
    """
    Centralized metrics collector for GP2.
    """
    
    def __init__(self):
        self._enabled = PROMETHEUS_AVAILABLE
        
        if self._enabled:
            # Set system info
            SYSTEM_INFO.info({
                'version': '70.0.0',
                'governance_level': 'strict',
                'synthetic_only': 'true',
                'xr_read_only': 'true',
            })
            
            # Initialize gauges
            FAILSAFE_LEVEL.set(0)
            HITL_PENDING.set(0)
            ACTIVE_REQUESTS.set(0)
        
        logger.info(f"Metrics collector initialized (enabled={self._enabled})")
    
    # =========================================================================
    # REQUEST METRICS
    # =========================================================================
    
    def record_request(
        self,
        method: str,
        endpoint: str,
        status: int,
        duration: float,
    ):
        """Record request metrics."""
        if not self._enabled:
            return
        
        REQUEST_COUNT.labels(
            method=method,
            endpoint=endpoint,
            status=str(status),
        ).inc()
        
        REQUEST_LATENCY.labels(
            method=method,
            endpoint=endpoint,
        ).observe(duration)
    
    def inc_active_requests(self):
        if self._enabled:
            ACTIVE_REQUESTS.inc()
    
    def dec_active_requests(self):
        if self._enabled:
            ACTIVE_REQUESTS.dec()
    
    # =========================================================================
    # GOVERNANCE METRICS
    # =========================================================================
    
    def record_governance_check(
        self,
        module: str,
        passed: bool,
    ):
        """Record governance check."""
        if not self._enabled:
            return
        
        GOVERNANCE_CHECKS.labels(
            module=module,
            result="pass" if passed else "fail",
        ).inc()
    
    def record_governance_violation(
        self,
        module: str,
        violation_type: str,
    ):
        """Record governance violation."""
        if not self._enabled:
            return
        
        GOVERNANCE_VIOLATIONS.labels(
            module=module,
            violation_type=violation_type,
        ).inc()
    
    def record_opa_decision(
        self,
        policy: str,
        allowed: bool,
        latency: float,
    ):
        """Record OPA decision."""
        if not self._enabled:
            return
        
        OPA_DECISIONS.labels(
            policy=policy,
            result="allow" if allowed else "deny",
        ).inc()
        
        OPA_LATENCY.labels(policy=policy).observe(latency)
    
    # =========================================================================
    # NOVA METRICS
    # =========================================================================
    
    def record_nova_request(
        self,
        status: str,
        is_refusal: bool = False,
        refusal_reason: str = None,
        duration: float = 0,
    ):
        """Record NOVA request."""
        if not self._enabled:
            return
        
        NOVA_REQUESTS.labels(status=status).inc()
        
        if is_refusal and refusal_reason:
            NOVA_REFUSALS.labels(reason=refusal_reason).inc()
        
        if duration > 0:
            NOVA_PROCESSING_TIME.observe(duration)
    
    # =========================================================================
    # ETHICS METRICS
    # =========================================================================
    
    def record_ethics_validation(
        self,
        is_valid: bool,
        violations: list[str] = None,
    ):
        """Record ethics validation."""
        if not self._enabled:
            return
        
        ETHICS_VALIDATIONS.labels(
            result="valid" if is_valid else "invalid",
        ).inc()
        
        if violations:
            for violation in violations:
                ETHICS_VIOLATIONS.labels(violation_type=violation).inc()
    
    # =========================================================================
    # DECISION LOOP METRICS
    # =========================================================================
    
    def record_decision_loop(
        self,
        status: str,
        cycles: int = 0,
    ):
        """Record decision loop."""
        if not self._enabled:
            return
        
        DECISION_LOOPS.labels(status=status).inc()
        
        if cycles > 0:
            SIMULATION_CYCLES.observe(cycles)
    
    def set_hitl_pending(self, count: int):
        if self._enabled:
            HITL_PENDING.set(count)
    
    def record_hitl_approval(self, approved: bool):
        if self._enabled:
            HITL_APPROVALS.labels(
                result="approved" if approved else "rejected",
            ).inc()
    
    # =========================================================================
    # FAILSAFE METRICS
    # =========================================================================
    
    def set_failsafe_level(self, level: int):
        if self._enabled:
            FAILSAFE_LEVEL.set(level)
    
    def record_crisis_detection(self, crisis_type: str):
        if self._enabled:
            CRISIS_DETECTIONS.labels(crisis_type=crisis_type).inc()
    
    def record_failsafe_activation(self, level: str):
        if self._enabled:
            FAILSAFE_ACTIVATIONS.labels(level=level).inc()
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def export(self) -> bytes:
        """Export metrics in Prometheus format."""
        if not self._enabled:
            return b"# Metrics disabled\n"
        return generate_latest(REGISTRY)
    
    def content_type(self) -> str:
        """Get content type for metrics."""
        if not self._enabled:
            return "text/plain"
        return CONTENT_TYPE_LATEST


# =============================================================================
# DECORATORS
# =============================================================================

def track_request(endpoint: str = ""):
    """Decorator to track request metrics."""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            collector = get_metrics_collector()
            collector.inc_active_requests()
            
            start = time.time()
            status = 200
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                status = 500
                raise
            finally:
                duration = time.time() - start
                collector.dec_active_requests()
                collector.record_request(
                    method="POST",
                    endpoint=endpoint or func.__name__,
                    status=status,
                    duration=duration,
                )
        
        return wrapper
    return decorator


def track_task(task_name: str = ""):
    """Decorator to track task metrics."""
    def decorator(func: Callable):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            collector = get_metrics_collector()
            name = task_name or func.__name__
            
            if PROMETHEUS_AVAILABLE:
                TASKS_SUBMITTED.labels(task_name=name, queue="default").inc()
            
            start = time.time()
            status = "completed"
            
            try:
                result = await func(*args, **kwargs)
                return result
            except Exception as e:
                status = "failed"
                raise
            finally:
                duration = time.time() - start
                if PROMETHEUS_AVAILABLE:
                    TASKS_COMPLETED.labels(task_name=name, status=status).inc()
                    TASK_DURATION.labels(task_name=name).observe(duration)
        
        return wrapper
    return decorator


# =============================================================================
# SINGLETON
# =============================================================================

_metrics_collector: Optional[MetricsCollector] = None


def get_metrics_collector() -> MetricsCollector:
    """Get the metrics collector singleton."""
    global _metrics_collector
    if _metrics_collector is None:
        _metrics_collector = MetricsCollector()
    return _metrics_collector
