
# SCRIPT 3 — LE VIRAGE AT-OM
Date: 2026-01-07

[VISUEL]
La remorque disparaît.
La voiture est la même. Mais plus légère.

[VOIX]
"AT-OM n’a pas été créé pour accélérer."

"Il a été créé pour enlever le poids inutile."

"Ici, les décisions deviennent des objets.
Les erreurs deviennent de l’apprentissage.
La mémoire devient canonique."

"Les agents ne devinent plus.
Ils consultent."

"On n’efface pas le passé.
On s’appuie dessus."
