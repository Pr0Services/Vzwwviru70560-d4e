"""
CHE·NU™ V70 — WORKSPACE ENGINE MODELS
=====================================
Data models for the adaptive workspace engine.

Based on: WORKSPACE_ENGINE_CHAPTER.md (Chapters 97-108)

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Set
from uuid import uuid4


# =============================================================================
# ENUMS
# =============================================================================

class WorkspaceMode(str, Enum):
    """Available workspace modes."""
    DOCUMENT = "document"
    BOARD = "board"
    TIMELINE = "timeline"
    SPREADSHEET = "spreadsheet"
    DASHBOARD = "dashboard"
    DIAGRAM = "diagram"
    WHITEBOARD = "whiteboard"
    XR_LAUNCHER = "xr_launcher"
    HYBRID = "hybrid"


class SphereContext(str, Enum):
    """CHE·NU sphere contexts (9 spheres)."""
    PERSONAL = "personal"
    ENTERPRISE = "enterprise"
    GOVERNMENT = "government"
    CREATIVE = "creative"
    COMMUNITY = "community"
    SOCIAL = "social"
    ENTERTAINMENT = "entertainment"
    TEAM = "team"
    SCHOLAR = "scholar"


class DomainContext(str, Enum):
    """Domain specializations."""
    GENERAL = "general"
    CONSTRUCTION = "construction"
    FINANCE = "finance"
    IMMOBILIER = "immobilier"
    ARCHITECTURE = "architecture"
    LEGAL = "legal"
    HEALTHCARE = "healthcare"
    EDUCATION = "education"


class IntentSignal(str, Enum):
    """Types of intent signals."""
    NLP = "nlp"
    GESTURE = "gesture"
    CONTEXT = "context"
    DOMAIN = "domain"
    AGENT = "agent"
    WORKFLOW = "workflow"
    GOVERNANCE = "governance"


class WorkflowStage(str, Enum):
    """Workflow stages."""
    INITIATION = "initiation"
    PLANNING = "planning"
    EXECUTION = "execution"
    REVIEW = "review"
    COMPLETION = "completion"
    ARCHIVE = "archive"


class TransitionType(str, Enum):
    """Mode transition types."""
    CONFIRM = "confirm"
    TRANSFORM = "transform"
    HYBRID_CREATE = "hybrid_create"
    SPLIT = "split"
    MERGE = "merge"


# =============================================================================
# INTENT MODELS
# =============================================================================

@dataclass
class IntentDetection:
    """Detected user intent."""
    intent_id: str = field(default_factory=lambda: f"INT_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Signal sources
    signals: List[IntentSignal] = field(default_factory=list)
    confidence: float = 0.0
    
    # Detected intent
    raw_input: str = ""
    parsed_intent: str = ""
    suggested_mode: Optional[WorkspaceMode] = None
    suggested_domain: Optional[DomainContext] = None
    
    # Context
    current_mode: Optional[WorkspaceMode] = None
    current_sphere: Optional[SphereContext] = None
    
    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GestureSignal:
    """Gesture-based intent signal."""
    gesture_type: str = ""  # swipe, pinch, tap, drag, etc.
    direction: Optional[str] = None
    magnitude: float = 0.0
    target_element: Optional[str] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class AgentSignal:
    """Agent-suggested intent signal."""
    agent_id: str = ""
    agent_type: str = ""
    suggestion: str = ""
    confidence: float = 0.0
    reasoning: str = ""
    synthetic: bool = True  # GOVERNANCE: Always synthetic


# =============================================================================
# WORKSPACE MODELS
# =============================================================================

@dataclass
class WorkspaceState:
    """Current state of a workspace."""
    workspace_id: str = field(default_factory=lambda: f"WS_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    
    # Mode
    current_mode: WorkspaceMode = WorkspaceMode.DOCUMENT
    previous_mode: Optional[WorkspaceMode] = None
    hybrid_modes: List[WorkspaceMode] = field(default_factory=list)
    
    # Context
    sphere: SphereContext = SphereContext.PERSONAL
    domain: DomainContext = DomainContext.GENERAL
    workflow_stage: WorkflowStage = WorkflowStage.INITIATION
    
    # Content
    title: str = ""
    content: Dict[str, Any] = field(default_factory=dict)
    
    # Links
    dataspace_id: Optional[str] = None
    project_id: Optional[str] = None
    meeting_id: Optional[str] = None
    
    # Users
    owner_id: str = ""
    collaborators: List[str] = field(default_factory=list)
    
    # Governance
    governance_level: str = "strict"
    synthetic: bool = True
    
    # State
    is_active: bool = True
    is_locked: bool = False


@dataclass
class ModeConfiguration:
    """Configuration for a specific mode."""
    mode: WorkspaceMode
    
    # Layout
    layout_template: str = "default"
    panel_arrangement: List[str] = field(default_factory=list)
    toolbar_items: List[str] = field(default_factory=list)
    
    # Domain specialization
    domain_tools: Dict[str, List[str]] = field(default_factory=dict)
    domain_templates: Dict[str, List[str]] = field(default_factory=dict)
    
    # Capabilities
    capabilities: Set[str] = field(default_factory=set)
    restrictions: Set[str] = field(default_factory=set)
    
    # XR settings (for XR_LAUNCHER mode)
    xr_enabled: bool = False
    xr_read_only: bool = True  # GOVERNANCE: XR always read-only


@dataclass
class ModeTransition:
    """Record of a mode transition."""
    transition_id: str = field(default_factory=lambda: f"TRANS_{uuid4().hex[:8]}")
    timestamp: datetime = field(default_factory=datetime.utcnow)
    
    # Transition
    from_mode: WorkspaceMode
    to_mode: WorkspaceMode
    transition_type: TransitionType
    
    # Trigger
    trigger_intent: Optional[IntentDetection] = None
    trigger_reason: str = ""
    
    # Content transformation
    content_preserved: bool = True
    transformation_applied: Optional[str] = None
    
    # Audit
    user_id: str = ""
    synthetic: bool = True


# =============================================================================
# WORKFLOW PIPELINE MODELS
# =============================================================================

@dataclass
class PipelineStep:
    """A step in a workflow pipeline."""
    step_id: str = field(default_factory=lambda: f"STEP_{uuid4().hex[:8]}")
    order: int = 0
    name: str = ""
    description: str = ""
    
    # Action
    action_type: str = ""
    action_params: Dict[str, Any] = field(default_factory=dict)
    
    # Mode
    required_mode: Optional[WorkspaceMode] = None
    
    # Status
    status: str = "pending"  # pending, active, completed, skipped
    completed_at: Optional[datetime] = None
    
    # Governance
    requires_hitl: bool = False
    hitl_approved: bool = False


@dataclass
class WorkflowPipeline:
    """A workflow pipeline definition."""
    pipeline_id: str = field(default_factory=lambda: f"PIPE_{uuid4().hex[:8]}")
    name: str = ""
    description: str = ""
    
    # Type
    pipeline_type: str = ""  # project, meeting, document, xr, property, estimation, review
    
    # Steps
    steps: List[PipelineStep] = field(default_factory=list)
    current_step: int = 0
    
    # Context
    domain: DomainContext = DomainContext.GENERAL
    sphere: SphereContext = SphereContext.PERSONAL
    
    # Links
    workspace_id: Optional[str] = None
    dataspace_id: Optional[str] = None
    
    # Status
    status: str = "pending"  # pending, active, completed, cancelled
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    
    # Governance
    synthetic: bool = True
    governance_validated: bool = False


@dataclass
class PipelineExecution:
    """Execution record for a pipeline."""
    execution_id: str = field(default_factory=lambda: f"EXEC_{uuid4().hex[:8]}")
    pipeline_id: str = ""
    
    # Timing
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # Progress
    steps_completed: int = 0
    total_steps: int = 0
    current_step_id: Optional[str] = None
    
    # Results
    outputs: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    
    # Status
    status: str = "running"  # running, completed, failed, cancelled
    
    # Governance
    synthetic: bool = True
    audit_trail: List[Dict[str, Any]] = field(default_factory=list)


# =============================================================================
# COLLABORATION MODELS
# =============================================================================

@dataclass
class WorkspaceAgent:
    """An agent collaborating in the workspace."""
    agent_id: str = ""
    agent_type: str = ""  # organizer, layout, domain, meeting, xr_connect
    
    # Status
    is_active: bool = True
    last_signal: Optional[datetime] = None
    
    # Capabilities
    capabilities: Set[str] = field(default_factory=set)
    current_task: Optional[str] = None
    
    # Governance
    synthetic: bool = True
    governance_level: str = "strict"


@dataclass
class CollaborationSession:
    """A multi-user collaboration session."""
    session_id: str = field(default_factory=lambda: f"COLLAB_{uuid4().hex[:8]}")
    workspace_id: str = ""
    
    # Participants
    participants: List[str] = field(default_factory=list)
    active_agents: List[WorkspaceAgent] = field(default_factory=list)
    
    # Status
    started_at: datetime = field(default_factory=datetime.utcnow)
    is_active: bool = True
    
    # XR
    xr_enabled: bool = False
    xr_read_only: bool = True  # GOVERNANCE


# =============================================================================
# DATASPACE LINK MODELS
# =============================================================================

@dataclass
class DataSpaceLink:
    """Link between workspace and DataSpace."""
    link_id: str = field(default_factory=lambda: f"LINK_{uuid4().hex[:8]}")
    
    workspace_id: str = ""
    dataspace_id: str = ""
    
    # Sync
    sync_mode: str = "bidirectional"  # bidirectional, workspace_to_ds, ds_to_workspace
    last_sync: Optional[datetime] = None
    
    # Content mapping
    content_mapping: Dict[str, str] = field(default_factory=dict)
    
    # Governance
    synthetic: bool = True
    audit_enabled: bool = True


# =============================================================================
# XR MODELS (READ ONLY)
# =============================================================================

@dataclass
class XRLaunchConfig:
    """Configuration for XR launch (READ ONLY)."""
    config_id: str = field(default_factory=lambda: f"XRCFG_{uuid4().hex[:8]}")
    
    # Environment
    environment_type: str = ""  # meeting, spatial_board, property_walkthrough, design_review
    
    # Content
    workspace_id: str = ""
    content_to_send: List[str] = field(default_factory=list)
    
    # Participants
    participants: List[str] = field(default_factory=list)
    
    # Controls
    gesture_controls: bool = True
    voice_commands: bool = True
    spatial_audio: bool = True
    mixed_reality: bool = False
    
    # CRITICAL: Always read-only
    read_only: bool = True  # GOVERNANCE: XR never writes


# =============================================================================
# FACTORY FUNCTIONS
# =============================================================================

def create_workspace(
    mode: WorkspaceMode = WorkspaceMode.DOCUMENT,
    sphere: SphereContext = SphereContext.PERSONAL,
    domain: DomainContext = DomainContext.GENERAL,
    owner_id: str = "",
    title: str = "",
) -> WorkspaceState:
    """Create a new workspace state."""
    return WorkspaceState(
        current_mode=mode,
        sphere=sphere,
        domain=domain,
        owner_id=owner_id,
        title=title,
        synthetic=True,  # GOVERNANCE
        governance_level="strict",
    )


def create_pipeline(
    pipeline_type: str,
    domain: DomainContext = DomainContext.GENERAL,
    steps: List[PipelineStep] = None,
) -> WorkflowPipeline:
    """Create a new workflow pipeline."""
    return WorkflowPipeline(
        pipeline_type=pipeline_type,
        domain=domain,
        steps=steps or [],
        synthetic=True,  # GOVERNANCE
    )


def create_xr_launch(
    workspace_id: str,
    environment_type: str,
    participants: List[str] = None,
) -> XRLaunchConfig:
    """Create XR launch configuration (READ ONLY)."""
    return XRLaunchConfig(
        workspace_id=workspace_id,
        environment_type=environment_type,
        participants=participants or [],
        read_only=True,  # GOVERNANCE: Always read-only
    )
