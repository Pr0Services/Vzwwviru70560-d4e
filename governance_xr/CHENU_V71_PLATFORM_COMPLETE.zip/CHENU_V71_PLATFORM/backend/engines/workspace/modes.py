"""
CHE·NU™ V70 — WORKSPACE MODES
=============================
Mode definitions and capabilities for workspace engine.

Based on: WORKSPACE_ENGINE_CHAPTER.md (Chapter 98)

Modes:
- Document Mode
- Board Mode
- Timeline Mode
- Spreadsheet Mode
- Dashboard Mode
- Diagram Mode
- Whiteboard Mode
- XR Launcher Mode
- Hybrid Mode

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from enum import Enum

from .models import (
    WorkspaceMode,
    DomainContext,
    SphereContext,
    ModeConfiguration,
)


# =============================================================================
# MODE CAPABILITY DEFINITIONS
# =============================================================================

class ModeCapability(str, Enum):
    """Available capabilities across modes."""
    # Document
    RICH_TEXT_EDITING = "rich_text_editing"
    DOMAIN_TEMPLATES = "domain_templates"
    AI_DRAFTING = "ai_drafting"
    AGENT_ANNOTATIONS = "agent_annotations"
    VERSION_CONTROL = "version_control"
    EXPORT_FORMATS = "export_formats"
    VOICE_TO_TEXT = "voice_to_text"
    CITATIONS = "citations"
    
    # Board
    DRAGGABLE_CARDS = "draggable_cards"
    CUSTOM_COLUMNS = "custom_columns"
    SWIMLANES = "swimlanes"
    AUTO_GROUPING = "auto_grouping"
    CARD_TEMPLATES = "card_templates"
    PROGRESS_METRICS = "progress_metrics"
    CALENDAR_INTEGRATION = "calendar_integration"
    DEPENDENCY_TRACKING = "dependency_tracking"
    
    # Timeline
    GANTT_VIEW = "gantt_view"
    ROADMAP_VIEW = "roadmap_view"
    MILESTONES = "milestones"
    RESOURCE_ALLOCATION = "resource_allocation"
    CRITICAL_PATH = "critical_path"
    MULTI_SCALE = "multi_scale"
    BASELINE_COMPARISON = "baseline_comparison"
    
    # Spreadsheet
    FORMULAS = "formulas"
    DOMAIN_FUNCTIONS = "domain_functions"
    AGGREGATIONS = "aggregations"
    CURRENCY_HANDLING = "currency_handling"
    UNIT_CONVERSIONS = "unit_conversions"
    DATA_VALIDATION = "data_validation"
    CONDITIONAL_FORMAT = "conditional_format"
    PIVOT_TABLES = "pivot_tables"
    CHARTS = "charts"
    
    # Dashboard
    WIDGET_GRID = "widget_grid"
    KPI_DISPLAYS = "kpi_displays"
    RISK_MONITORS = "risk_monitors"
    PORTFOLIO_SNAPSHOTS = "portfolio_snapshots"
    PROJECT_SUMMARIES = "project_summaries"
    FINANCIAL_CHARTS = "financial_charts"
    MEETING_SUMMARIES = "meeting_summaries"
    DATA_INTEGRATION = "data_integration"
    
    # Diagram
    MIND_MAP = "mind_map"
    FLOWCHART = "flowchart"
    MERMAID_GENERATION = "mermaid_generation"
    ARCHITECTURE_DIAGRAMS = "architecture_diagrams"
    PROCESS_FLOWS = "process_flows"
    ER_DIAGRAMS = "er_diagrams"
    NETWORK_DIAGRAMS = "network_diagrams"
    AUTO_LAYOUT = "auto_layout"
    
    # Whiteboard
    INFINITE_CANVAS = "infinite_canvas"
    FREEHAND_DRAWING = "freehand_drawing"
    SHAPE_RECOGNITION = "shape_recognition"
    STICKY_NOTES = "sticky_notes"
    MEDIA_EMBEDDING = "media_embedding"
    REALTIME_COLLAB = "realtime_collab"
    SECTION_TOOLS = "section_tools"
    
    # XR
    XR_SEND = "xr_send"
    XR_MEETINGS = "xr_meetings"
    SPATIAL_BOARDS = "spatial_boards"
    OBJECT_MANIPULATION = "object_manipulation"
    PREVIEW_3D = "preview_3d"
    GESTURE_CONTROLS = "gesture_controls"
    VOICE_COMMANDS = "voice_commands"
    SPATIAL_AUDIO = "spatial_audio"
    MIXED_REALITY = "mixed_reality"
    
    # Hybrid
    MULTI_MODE = "multi_mode"
    SPLIT_VIEW = "split_view"
    SYNC_CONTENT = "sync_content"


# =============================================================================
# MODE DEFINITIONS
# =============================================================================

@dataclass
class DocumentMode:
    """Document Mode - Structured text creation and editing."""
    
    mode = WorkspaceMode.DOCUMENT
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.RICH_TEXT_EDITING,
        ModeCapability.DOMAIN_TEMPLATES,
        ModeCapability.AI_DRAFTING,
        ModeCapability.AGENT_ANNOTATIONS,
        ModeCapability.VERSION_CONTROL,
        ModeCapability.EXPORT_FORMATS,
        ModeCapability.VOICE_TO_TEXT,
        ModeCapability.CITATIONS,
    })
    
    # Domain specializations
    domain_templates: Dict[DomainContext, List[str]] = field(default_factory=lambda: {
        DomainContext.CONSTRUCTION: [
            "specifications", "scope_document", "rfi", "change_order",
            "daily_report", "punch_list", "safety_report"
        ],
        DomainContext.FINANCE: [
            "report", "proposal", "analysis", "memo",
            "investment_summary", "budget_narrative"
        ],
        DomainContext.IMMOBILIER: [
            "lease_agreement", "property_description", "inspection_report",
            "tenant_notice", "maintenance_request"
        ],
        DomainContext.ARCHITECTURE: [
            "design_brief", "building_program", "specification",
            "meeting_minutes", "site_analysis"
        ],
        DomainContext.LEGAL: [
            "contract", "amendment", "notice", "memorandum"
        ],
    })
    
    export_formats: List[str] = field(default_factory=lambda: [
        "pdf", "docx", "md", "html", "txt"
    ])


@dataclass
class BoardMode:
    """Board Mode - Visual task and project organization."""
    
    mode = WorkspaceMode.BOARD
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.DRAGGABLE_CARDS,
        ModeCapability.CUSTOM_COLUMNS,
        ModeCapability.SWIMLANES,
        ModeCapability.AUTO_GROUPING,
        ModeCapability.CARD_TEMPLATES,
        ModeCapability.PROGRESS_METRICS,
        ModeCapability.CALENDAR_INTEGRATION,
        ModeCapability.DEPENDENCY_TRACKING,
    })
    
    # Default column configurations
    column_presets: Dict[str, List[str]] = field(default_factory=lambda: {
        "kanban": ["backlog", "todo", "in_progress", "review", "done"],
        "scrum": ["sprint_backlog", "in_progress", "testing", "done"],
        "status": ["not_started", "active", "blocked", "completed"],
        "priority": ["critical", "high", "medium", "low"],
        "immobilier": ["new_request", "investigating", "scheduled", "completed"],
        "construction": ["pending", "approved", "in_progress", "inspection", "closed"],
    })
    
    # Swimlane options
    swimlane_types: List[str] = field(default_factory=lambda: [
        "project", "team", "domain", "assignee", "priority", "category"
    ])


@dataclass
class TimelineMode:
    """Timeline Mode - Chronological visualization."""
    
    mode = WorkspaceMode.TIMELINE
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.GANTT_VIEW,
        ModeCapability.ROADMAP_VIEW,
        ModeCapability.MILESTONES,
        ModeCapability.RESOURCE_ALLOCATION,
        ModeCapability.CRITICAL_PATH,
        ModeCapability.MULTI_SCALE,
        ModeCapability.BASELINE_COMPARISON,
        ModeCapability.CALENDAR_INTEGRATION,
    })
    
    # Scale options
    scales: List[str] = field(default_factory=lambda: [
        "hour", "day", "week", "month", "quarter", "year"
    ])
    
    # Domain applications
    domain_applications: Dict[DomainContext, List[str]] = field(default_factory=lambda: {
        DomainContext.CONSTRUCTION: [
            "project_schedule", "phase_planning", "resource_timeline"
        ],
        DomainContext.IMMOBILIER: [
            "lease_timeline", "renovation_schedule", "tenant_lifecycle"
        ],
        DomainContext.GENERAL: [
            "product_roadmap", "strategic_planning", "goal_tracking"
        ],
    })


@dataclass
class SpreadsheetMode:
    """Spreadsheet Mode - Tabular data manipulation."""
    
    mode = WorkspaceMode.SPREADSHEET
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.FORMULAS,
        ModeCapability.DOMAIN_FUNCTIONS,
        ModeCapability.AGGREGATIONS,
        ModeCapability.CURRENCY_HANDLING,
        ModeCapability.UNIT_CONVERSIONS,
        ModeCapability.DATA_VALIDATION,
        ModeCapability.CONDITIONAL_FORMAT,
        ModeCapability.PIVOT_TABLES,
        ModeCapability.CHARTS,
    })
    
    # Domain-specific functions
    domain_functions: Dict[DomainContext, List[str]] = field(default_factory=lambda: {
        DomainContext.CONSTRUCTION: [
            "MATERIAL_COST", "LABOR_HOURS", "MARKUP", "CONTINGENCY",
            "UNIT_CONVERT", "TAKEOFF_TOTAL"
        ],
        DomainContext.FINANCE: [
            "NPV", "IRR", "PMT", "FV", "CURRENCY_CONVERT",
            "COMPOUND_INTEREST", "AMORTIZATION"
        ],
        DomainContext.IMMOBILIER: [
            "RENT_ROLL", "CAP_RATE", "NOI", "VACANCY_RATE",
            "PRICE_PER_SQFT", "GRM"
        ],
    })
    
    # Specialized templates
    templates: Dict[DomainContext, List[str]] = field(default_factory=lambda: {
        DomainContext.CONSTRUCTION: [
            "estimation_worksheet", "material_takeoff", "labor_schedule",
            "budget_tracking", "change_order_log"
        ],
        DomainContext.IMMOBILIER: [
            "rent_roll", "income_expense", "tenant_payments",
            "maintenance_budget", "cap_rate_analysis"
        ],
        DomainContext.FINANCE: [
            "budget_variance", "cash_flow", "investment_analysis",
            "loan_amortization"
        ],
    })


@dataclass
class DashboardMode:
    """Dashboard Mode - Real-time monitoring and metrics."""
    
    mode = WorkspaceMode.DASHBOARD
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.WIDGET_GRID,
        ModeCapability.KPI_DISPLAYS,
        ModeCapability.RISK_MONITORS,
        ModeCapability.PORTFOLIO_SNAPSHOTS,
        ModeCapability.PROJECT_SUMMARIES,
        ModeCapability.FINANCIAL_CHARTS,
        ModeCapability.MEETING_SUMMARIES,
        ModeCapability.DATA_INTEGRATION,
    })
    
    # Widget types
    widget_types: List[str] = field(default_factory=lambda: [
        "kpi_card", "chart", "table", "progress_bar", "gauge",
        "calendar", "task_list", "feed", "map", "heatmap"
    ])
    
    # Dashboard templates
    templates: Dict[str, List[str]] = field(default_factory=lambda: {
        "personal_cockpit": [
            "life_metrics", "goals", "finances", "calendar", "tasks"
        ],
        "enterprise_operations": [
            "team_performance", "project_status", "budget", "timeline"
        ],
        "immobilier_portfolio": [
            "occupancy", "revenue", "maintenance", "tenant_health"
        ],
        "construction_project": [
            "progress", "budget", "safety", "schedule", "weather"
        ],
        "financial": [
            "cash_flow", "budgets", "forecasts", "variance", "trends"
        ],
    })


@dataclass
class DiagramMode:
    """Diagram Mode - Visual representation of systems and processes."""
    
    mode = WorkspaceMode.DIAGRAM
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.MIND_MAP,
        ModeCapability.FLOWCHART,
        ModeCapability.MERMAID_GENERATION,
        ModeCapability.ARCHITECTURE_DIAGRAMS,
        ModeCapability.PROCESS_FLOWS,
        ModeCapability.ER_DIAGRAMS,
        ModeCapability.NETWORK_DIAGRAMS,
        ModeCapability.AUTO_LAYOUT,
    })
    
    # Diagram types
    diagram_types: List[str] = field(default_factory=lambda: [
        "mind_map", "flowchart", "sequence", "class", "state",
        "er", "network", "org_chart", "architecture", "process"
    ])
    
    # AI assistance features
    ai_features: List[str] = field(default_factory=lambda: [
        "text_to_diagram", "optimization_suggestions",
        "auto_layout", "cross_reference"
    ])


@dataclass
class WhiteboardMode:
    """Whiteboard Mode - Freeform creative space."""
    
    mode = WorkspaceMode.WHITEBOARD
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.INFINITE_CANVAS,
        ModeCapability.FREEHAND_DRAWING,
        ModeCapability.SHAPE_RECOGNITION,
        ModeCapability.STICKY_NOTES,
        ModeCapability.MEDIA_EMBEDDING,
        ModeCapability.REALTIME_COLLAB,
        ModeCapability.SECTION_TOOLS,
    })
    
    # Creative features
    creative_features: List[str] = field(default_factory=lambda: [
        "mood_boards", "storyboarding", "brainstorming",
        "design_thinking", "strategy_mapping"
    ])
    
    # Tools
    drawing_tools: List[str] = field(default_factory=lambda: [
        "pen", "marker", "highlighter", "eraser",
        "shapes", "arrows", "text", "sticky_note"
    ])


@dataclass
class XRLauncherMode:
    """XR Launcher Mode - Gateway to immersive experiences (READ ONLY)."""
    
    mode = WorkspaceMode.XR_LAUNCHER
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.XR_SEND,
        ModeCapability.XR_MEETINGS,
        ModeCapability.SPATIAL_BOARDS,
        ModeCapability.OBJECT_MANIPULATION,
        ModeCapability.PREVIEW_3D,
        ModeCapability.GESTURE_CONTROLS,
        ModeCapability.VOICE_COMMANDS,
        ModeCapability.SPATIAL_AUDIO,
        ModeCapability.MIXED_REALITY,
    })
    
    # XR environment types
    environment_types: List[str] = field(default_factory=lambda: [
        "meeting_room", "collaborative_space", "property_walkthrough",
        "design_review", "training_environment", "presentation_hall"
    ])
    
    # CRITICAL: Always read-only
    read_only: bool = True  # GOVERNANCE: XR never writes


@dataclass
class HybridMode:
    """Hybrid Mode - Multiple modes simultaneously."""
    
    mode = WorkspaceMode.HYBRID
    
    capabilities: Set[ModeCapability] = field(default_factory=lambda: {
        ModeCapability.MULTI_MODE,
        ModeCapability.SPLIT_VIEW,
        ModeCapability.SYNC_CONTENT,
    })
    
    # Common combinations
    common_combinations: List[List[WorkspaceMode]] = field(default_factory=lambda: [
        [WorkspaceMode.DOCUMENT, WorkspaceMode.BOARD],
        [WorkspaceMode.SPREADSHEET, WorkspaceMode.DASHBOARD],
        [WorkspaceMode.TIMELINE, WorkspaceMode.BOARD],
        [WorkspaceMode.WHITEBOARD, WorkspaceMode.DOCUMENT],
        [WorkspaceMode.DIAGRAM, WorkspaceMode.DOCUMENT],
    ])
    
    # Max modes in hybrid
    max_simultaneous_modes: int = 3


# =============================================================================
# MODE REGISTRY
# =============================================================================

MODE_REGISTRY: Dict[WorkspaceMode, Any] = {
    WorkspaceMode.DOCUMENT: DocumentMode(),
    WorkspaceMode.BOARD: BoardMode(),
    WorkspaceMode.TIMELINE: TimelineMode(),
    WorkspaceMode.SPREADSHEET: SpreadsheetMode(),
    WorkspaceMode.DASHBOARD: DashboardMode(),
    WorkspaceMode.DIAGRAM: DiagramMode(),
    WorkspaceMode.WHITEBOARD: WhiteboardMode(),
    WorkspaceMode.XR_LAUNCHER: XRLauncherMode(),
    WorkspaceMode.HYBRID: HybridMode(),
}


def get_mode_config(mode: WorkspaceMode) -> Any:
    """Get configuration for a workspace mode."""
    return MODE_REGISTRY.get(mode)


def get_mode_capabilities(mode: WorkspaceMode) -> Set[ModeCapability]:
    """Get capabilities for a workspace mode."""
    config = get_mode_config(mode)
    if config:
        return config.capabilities
    return set()


def get_domain_templates(mode: WorkspaceMode, domain: DomainContext) -> List[str]:
    """Get domain-specific templates for a mode."""
    config = get_mode_config(mode)
    if hasattr(config, 'domain_templates'):
        return config.domain_templates.get(domain, [])
    if hasattr(config, 'templates'):
        return config.templates.get(domain.value, [])
    return []


def suggest_mode_for_intent(intent: str) -> WorkspaceMode:
    """Suggest a workspace mode based on intent keywords."""
    intent_lower = intent.lower()
    
    # Document indicators
    if any(kw in intent_lower for kw in ["write", "draft", "document", "report", "memo"]):
        return WorkspaceMode.DOCUMENT
    
    # Board indicators
    if any(kw in intent_lower for kw in ["task", "kanban", "board", "sprint", "backlog"]):
        return WorkspaceMode.BOARD
    
    # Timeline indicators
    if any(kw in intent_lower for kw in ["schedule", "timeline", "gantt", "roadmap", "plan"]):
        return WorkspaceMode.TIMELINE
    
    # Spreadsheet indicators
    if any(kw in intent_lower for kw in ["calculate", "spreadsheet", "budget", "estimate", "numbers"]):
        return WorkspaceMode.SPREADSHEET
    
    # Dashboard indicators
    if any(kw in intent_lower for kw in ["dashboard", "metrics", "kpi", "monitor", "overview"]):
        return WorkspaceMode.DASHBOARD
    
    # Diagram indicators
    if any(kw in intent_lower for kw in ["diagram", "flowchart", "mindmap", "process", "architecture"]):
        return WorkspaceMode.DIAGRAM
    
    # Whiteboard indicators
    if any(kw in intent_lower for kw in ["brainstorm", "whiteboard", "sketch", "freeform", "creative"]):
        return WorkspaceMode.WHITEBOARD
    
    # XR indicators
    if any(kw in intent_lower for kw in ["vr", "xr", "immersive", "3d", "walkthrough"]):
        return WorkspaceMode.XR_LAUNCHER
    
    # Default to document
    return WorkspaceMode.DOCUMENT
