"""
LLM Module
==========

Multi-provider LLM routing system for CHE·NU.

Exports:
- LLMRouter: Main router class
- LLMProvider: Supported providers enum
- TaskType: Task type enum
- RoutingStrategy: Routing strategy enum
- LLMRequest: Request model
- LLMResponse: Response model
- get_llm_router: Singleton getter

VERSION: 1.0.0
"""

from backend.services.llm.llm_router import (
    # Main classes
    LLMRouter,
    get_llm_router,
    
    # Enums
    LLMProvider,
    TaskType,
    RoutingStrategy,
    
    # Models
    LLMRequest,
    LLMResponse,
    TokenBudget,
    ProviderConfig,
    ModelSpec,
    
    # Registry
    MODEL_REGISTRY,
    TASK_PROVIDER_RECOMMENDATIONS,
    
    # Exceptions
    LLMRouterError,
    BudgetExceededError,
    RateLimitExceededError,
    ModelNotFoundError,
    ProviderNotAvailableError,
)

__all__ = [
    # Main classes
    "LLMRouter",
    "get_llm_router",
    
    # Enums
    "LLMProvider",
    "TaskType",
    "RoutingStrategy",
    
    # Models
    "LLMRequest",
    "LLMResponse",
    "TokenBudget",
    "ProviderConfig",
    "ModelSpec",
    
    # Registry
    "MODEL_REGISTRY",
    "TASK_PROVIDER_RECOMMENDATIONS",
    
    # Exceptions
    "LLMRouterError",
    "BudgetExceededError",
    "RateLimitExceededError",
    "ModelNotFoundError",
    "ProviderNotAvailableError",
]
