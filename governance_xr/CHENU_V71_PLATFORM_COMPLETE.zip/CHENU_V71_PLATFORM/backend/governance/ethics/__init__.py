"""
CHE·NU™ V70 — MASTER ETHICS CANON
==================================
The supreme ethical constitution governing all CHE·NU™ operations.

PREAMBLE — PURPOSE:
CHE·NU™ is a human-centered systemic infrastructure.
Technology serves human continuity, dignity, agency, and collective resilience.

This Canon is SUPERIOR to:
- NOVA
- All Agents
- All Automation
- All Optimization Layers

AXIOM 0 — HUMAN PRIMACY:
No system, intelligence, or process may override human sovereignty.

FINAL LAW:
CHE·NU™ may evolve.
Humanity must never be replaced.
"""

from .models import (
    CanonPriority,
    ModuleCanon,
    CanonRule,
    Axiom0,
    Module39PostHumanEthics,
    FinalLaw,
    CanonValidationRequest,
    CanonValidationResult,
    MASTER_ETHICS_CANON,
)

from .validator import MasterEthicsCanonValidator

__all__ = [
    # Enums
    "CanonPriority",
    "ModuleCanon",
    # Models
    "CanonRule",
    "Axiom0",
    "Module39PostHumanEthics",
    "FinalLaw",
    "CanonValidationRequest",
    "CanonValidationResult",
    "MASTER_ETHICS_CANON",
    # Validator
    "MasterEthicsCanonValidator",
]

__version__ = "70.0.0"
