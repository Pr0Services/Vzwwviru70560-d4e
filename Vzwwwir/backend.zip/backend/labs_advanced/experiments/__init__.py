"""CHE·NU™ V69 — LABS Advanced"""
