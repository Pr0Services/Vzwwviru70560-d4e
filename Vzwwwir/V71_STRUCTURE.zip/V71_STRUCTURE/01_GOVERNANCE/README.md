# 01_GOVERNANCE

## Modules
- OPA_GOVERNANCE.md - Règles OPA
- POST_HUMAN_ETHICS.md - Éthique post-humaine
- NOVA_KERNEL_RULES.md - NOVA système (pas agent)

## Principe
Aucune action sans validation OPA.
NOVA n'apparaît jamais comme agent utilisateur.
