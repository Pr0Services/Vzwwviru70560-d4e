"""
CHE·NU™ V70 — AGENT SYSTEM PACKAGE
==================================
Complete 287-agent management system.

Based on: CHENU_V52_02_AGENTS_DICTIONARY.pdf
          CHENU_V52_28_AGENT_MANAGEMENT.pdf

Agent Hierarchy (4 Levels):
- L0 System: Nova Intelligence (never hired)
- L1 Orchestrator: One per user
- L2 Sphere: Domain specialists (9 spheres)
- L3 Task: Specific capabilities (287 total)

GOUVERNANCE > EXÉCUTION
"""

from .prompts import (
    AGENT_PROMPTS,
    get_agent_prompt,
    render_prompt,
    list_available_prompts,
)
from .engine import (
    # Enums
    AgentLevel,
    AgentStatus,
    AgentLifecycleStage,
    Sphere,
    # Models
    AgentScope,
    AgentEncoding,
    Agent,
    HiredAgent,
    AgentExecution,
    # Registry
    create_agent_registry,
    # Engine
    AgentSystemEngine,
    get_agent_system_engine,
)

__all__ = [
    # Enums
    "AgentLevel",
    "AgentStatus",
    "AgentLifecycleStage",
    "Sphere",
    # Models
    "AgentScope",
    "AgentEncoding",
    "Agent",
    "HiredAgent",
    "AgentExecution",
    # Registry
    "create_agent_registry",
    # Engine
    "AgentSystemEngine",
    "get_agent_system_engine",
    # Prompts
    "AGENT_PROMPTS",
    "get_agent_prompt",
    "render_prompt",
    "list_available_prompts",
]

__version__ = "70.0.0"
