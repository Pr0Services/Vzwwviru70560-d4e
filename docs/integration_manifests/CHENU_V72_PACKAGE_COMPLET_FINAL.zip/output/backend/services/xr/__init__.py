"""
XR Module
=========

XR Environment Generator for CHE·NU.

Components:
- MaturityService: Thread maturity computation
- MaturityScorer: Scoring logic
- XRRendererService: Blueprint generation and rendering
- BlueprintGenerator: Zone and item generation

R&D COMPLIANCE:
- Rule #3: XR is PROJECTION, Thread is truth
- Rule #1: Write interactions emit events
- Rule #6: Full traceability

VERSION: 1.0.0
"""

from backend.services.xr.maturity_service import (
    MaturityService,
    MaturityScorer,
)

from backend.services.xr.xr_renderer_service import (
    XRRendererService,
    BlueprintGenerator,
)

__all__ = [
    "MaturityService",
    "MaturityScorer",
    "XRRendererService",
    "BlueprintGenerator",
]
