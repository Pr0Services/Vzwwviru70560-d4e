# 🤖 CHE·NU™ V72 — PLAN PARALLÈLE 2 AGENTS CLAUDE

```
╔══════════════════════════════════════════════════════════════════════════════════════════════════╗
║                                                                                                  ║
║                    🤖 AGENT-A (BACKEND)              🤖 AGENT-B (FRONTEND)                      ║
║                    ═══════════════════              ════════════════════                        ║
║                                                                                                  ║
║                    Python / FastAPI                  React / TypeScript                         ║
║                    Services + API                    Components + Pages                         ║
║                    Database + Tests                  Stores + Hooks                             ║
║                                                                                                  ║
╚══════════════════════════════════════════════════════════════════════════════════════════════════╝
```

**Durée:** 14 jours  
**Méthode:** Travail parallèle avec contrats d'interface  
**Sync:** Fichiers API contracts partagés

---

## 📋 RÈGLES DE PARALLÉLISATION

### 🚫 ZONES EXCLUSIVES (pas de chevauchement)

```
AGENT-A UNIQUEMENT:                    AGENT-B UNIQUEMENT:
─────────────────────                  ─────────────────────
backend/**                             frontend/src/pages/**
├── api/                               frontend/src/components/**
├── services/                          frontend/src/stores/**
├── schemas/                           frontend/src/hooks/**
├── models/                            frontend/src/features/**
├── migrations/                        frontend/src/types/**
└── tests/                             frontend/cypress/**
```

### 🤝 ZONES PARTAGÉES (coordination requise)

```
PARTAGÉ (créé par AGENT-A, lu par AGENT-B):
──────────────────────────────────────────
/shared/api-contracts/     → Contrats d'API (OpenAPI)
/shared/types/             → Types TypeScript générés
/docs/api/                 → Documentation endpoints
```

### 📡 CONTRAT D'INTERFACE

Les deux agents DOIVENT respecter les contrats d'API définis.
- AGENT-A crée l'endpoint backend + met à jour le contrat
- AGENT-B consomme le contrat pour créer le client frontend

---

## 🗂️ STRUCTURE DES TÂCHES

```
TASK-A-XXX = Tâche Agent A (Backend)
TASK-B-XXX = Tâche Agent B (Frontend)
DEP: = Dépendance (attendre l'autre agent)
SYNC: = Point de synchronisation
```

---

# 📅 SPRINT 1: FONDATIONS (Jours 1-3)

## JOUR 1 — SETUP & INTÉGRATION

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-001: Intégrer packages Codex dans V71                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ INPUT:  - governance_xr_decision.zip                                       │
│         - AT-OM-main (V71)                                                  │
│                                                                             │
│ ACTIONS:                                                                    │
│ □ Créer backend/services/governance/                                       │
│ □ Copier cea_service.py                                                    │
│ □ Copier orchestrator_service.py                                           │
│ □ Copier backlog_service.py                                                │
│ □ Copier decision_point_service.py                                         │
│ □ Créer backend/services/xr/                                               │
│ □ Copier xr_renderer_service.py                                            │
│ □ Copier maturity_service.py                                               │
│ □ Copier schemas dans backend/schemas/                                     │
│ □ Fixer les imports                                                        │
│ □ Vérifier que pytest passe                                                │
│                                                                             │
│ OUTPUT: Backend avec nouveaux services intégrés                            │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-002: Créer API Contract v1                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer /shared/api-contracts/auth.yaml                                    │
│ □ Créer /shared/api-contracts/spheres.yaml                                 │
│ □ Créer /shared/api-contracts/threads.yaml                                 │
│ □ Documenter tous les endpoints prévus                                     │
│                                                                             │
│ OUTPUT: Contrats OpenAPI pour AGENT-B                                      │
│ TEMPS:  1 heure                                                            │
│ SYNC:   AGENT-B peut commencer après cette tâche                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-001: Setup structure features                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/features/decision-points/                             │
│ □ Créer frontend/src/features/governance/                                  │
│ □ Créer frontend/src/features/thread-lobby/                                │
│ □ Créer frontend/src/features/xr-viewer/                                   │
│ □ Copier types de governance-xr.types.ts                                   │
│ □ Setup structure index.ts pour chaque feature                             │
│                                                                             │
│ OUTPUT: Structure frontend prête                                           │
│ TEMPS:  1-2 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-002: API Client base                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│ DEP:    TASK-A-002 (API contracts)                                         │
│                                                                             │
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/api/client.ts (axios instance)                        │
│ □ Créer frontend/src/api/auth.api.ts                                       │
│ □ Créer frontend/src/api/spheres.api.ts                                    │
│ □ Créer frontend/src/api/threads.api.ts                                    │
│ □ Setup interceptors (JWT refresh)                                         │
│                                                                             │
│ OUTPUT: Client API prêt à consommer le backend                             │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 2 — AUTH SYSTEM

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-003: Auth Service complet                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter backend/services/auth_service.py                               │
│   - register(email, password, name)                                        │
│   - login(email, password) → JWT + refresh                                 │
│   - refresh_token(refresh_token) → new JWT                                 │
│   - logout(user_id)                                                        │
│   - get_current_user(token)                                                │
│ □ Password hashing (bcrypt)                                                │
│ □ JWT avec expiration (15min access, 7d refresh)                           │
│ □ Créer modèle User en DB                                                  │
│                                                                             │
│ OUTPUT: Service auth fonctionnel                                           │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-004: Auth Routes                                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ POST /api/v2/auth/register                                               │
│ □ POST /api/v2/auth/login                                                  │
│ □ POST /api/v2/auth/refresh                                                │
│ □ POST /api/v2/auth/logout                                                 │
│ □ GET  /api/v2/auth/me                                                     │
│ □ Tests pytest pour chaque endpoint                                        │
│ □ Mettre à jour /shared/api-contracts/auth.yaml                            │
│                                                                             │
│ OUTPUT: Endpoints auth testés                                              │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-005: Identity Boundary Middleware                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer middleware identity_boundary.py                                    │
│ □ Vérifier que user ne peut accéder qu'à ses données                       │
│ □ Injecter identity_id dans le context                                     │
│ □ HTTP 403 si violation                                                    │
│ □ Tests isolation                                                          │
│                                                                             │
│ OUTPUT: Isolation identity garantie                                        │
│ TEMPS:  1-2 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-003: Auth Store                                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/stores/auth.store.ts                              │
│   - user: User | null                                                      │
│   - token: string | null                                                   │
│   - isAuthenticated: boolean                                               │
│   - login(email, password)                                                 │
│   - register(email, password, name)                                        │
│   - logout()                                                               │
│   - refreshToken()                                                         │
│ □ Persist token dans localStorage                                          │
│ □ Auto-refresh avant expiration                                            │
│                                                                             │
│ OUTPUT: Store auth Zustand                                                 │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-004: Login Page                                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer/compléter frontend/src/pages/LoginPage.tsx                         │
│   - Form email + password                                                  │
│   - Validation                                                             │
│   - Error handling                                                         │
│   - Loading state                                                          │
│   - Link vers Register                                                     │
│ □ Redirect vers Dashboard si success                                       │
│                                                                             │
│ OUTPUT: Page login fonctionnelle                                           │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-005: Register Page + Protected Routes                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/pages/RegisterPage.tsx                                │
│ □ Créer frontend/src/components/auth/ProtectedRoute.tsx                    │
│ □ Wrapper routes qui nécessitent auth                                      │
│ □ Redirect vers /login si non authentifié                                  │
│                                                                             │
│ OUTPUT: Auth flow complet côté frontend                                    │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

**🔄 SYNC JOUR 2:** Tester login end-to-end (Frontend → Backend)

---

## JOUR 3 — SPHÈRES & BUREAU

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-006: Sphere & Bureau Services                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer backend/services/sphere_service.py                                 │
│   - get_all_spheres(identity_id)                                           │
│   - get_sphere(sphere_id, identity_id)                                     │
│   - Les 9 sphères sont fixes (seed data)                                   │
│ □ Créer backend/services/bureau_service.py                                 │
│   - get_bureau_sections(sphere_id)                                         │
│   - Les 6 sections sont fixes                                              │
│ □ Créer modèles Sphere, Bureau en DB                                       │
│ □ Script seed pour créer les 9 sphères + 6 sections                        │
│                                                                             │
│ OUTPUT: Services sphères/bureau                                            │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-007: Sphere & Bureau Routes                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET  /api/v2/spheres                                                     │
│ □ GET  /api/v2/spheres/{sphere_id}                                         │
│ □ GET  /api/v2/spheres/{sphere_id}/bureaus                                 │
│ □ GET  /api/v2/bureaus/{bureau_id}                                         │
│ □ Tests + update API contracts                                             │
│                                                                             │
│ OUTPUT: API sphères/bureau                                                 │
│ TEMPS:  1-2 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-006: Dashboard avec 9 Sphères                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/pages/Dashboard.tsx                               │
│ □ Créer frontend/src/components/sphere/SphereGrid.tsx                      │
│ □ Créer frontend/src/components/sphere/SphereCard.tsx                      │
│ □ Afficher les 9 sphères avec icônes                                       │
│ □ Click → navigate vers SpherePage                                         │
│                                                                             │
│ OUTPUT: Dashboard avec grille sphères                                      │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-007: SpherePage avec 6 Bureau Sections                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/pages/SpherePage.tsx                              │
│ □ Créer frontend/src/components/bureau/BureauTabs.tsx                      │
│ □ Créer frontend/src/components/bureau/BureauSection.tsx                   │
│ □ 6 tabs: QuickCapture, ResumeWorkspace, Threads, DataFiles,               │
│          ActiveAgents, Meetings                                            │
│ □ Chaque section affiche placeholder content                               │
│                                                                             │
│ OUTPUT: Navigation sphère → bureau complète                                │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

**🔄 SYNC JOUR 3:** Navigation Dashboard → Sphere → Bureau fonctionne

---

# 📅 SPRINT 2: THREADS & NOVA (Jours 4-6)

## JOUR 4 — THREAD SYSTEM V2

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-008: Thread Service V2                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Refactor backend/services/thread_service.py                              │
│   - create_thread(sphere_id, founding_intent, created_by)                  │
│   - get_thread(thread_id, identity_id)                                     │
│   - list_threads(sphere_id, identity_id)                                   │
│   - append_event(thread_id, event_type, payload, created_by)               │
│   - append_correction(thread_id, original_event_id, correction)            │
│   - get_events(thread_id)                                                  │
│ □ AUCUNE modification/suppression d'événements                             │
│ □ Modèle Thread + ThreadEvent en DB                                        │
│                                                                             │
│ OUTPUT: Thread service append-only                                         │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-009: Thread Routes                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ POST /api/v2/threads                                                     │
│ □ GET  /api/v2/threads                                                     │
│ □ GET  /api/v2/threads/{thread_id}                                         │
│ □ POST /api/v2/threads/{thread_id}/events                                  │
│ □ GET  /api/v2/threads/{thread_id}/events                                  │
│ □ POST /api/v2/threads/{thread_id}/corrections                             │
│ □ Tests + API contracts                                                    │
│                                                                             │
│ OUTPUT: API threads complète                                               │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-008: Thread Store                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/stores/thread.store.ts                            │
│   - threads: Thread[]                                                      │
│   - currentThread: Thread | null                                           │
│   - events: ThreadEvent[]                                                  │
│   - createThread(sphereId, foundingIntent)                                 │
│   - fetchThreads(sphereId)                                                 │
│   - fetchThread(threadId)                                                  │
│   - appendEvent(threadId, eventType, payload)                              │
│                                                                             │
│ OUTPUT: Store thread Zustand                                               │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-009: Thread Components                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/components/thread/ThreadList.tsx                      │
│ □ Créer frontend/src/components/thread/ThreadCard.tsx                      │
│ □ Créer frontend/src/components/thread/ThreadCreateModal.tsx               │
│ □ Créer frontend/src/components/thread/EventTimeline.tsx                   │
│ □ Créer frontend/src/pages/ThreadPage.tsx                                  │
│                                                                             │
│ OUTPUT: UI threads complète                                                │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 5 — NOVA PIPELINE

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-010: Nova Pipeline Service                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter backend/services/nova_pipeline_service.py                      │
│   - chat(thread_id, message, user_id) → response                           │
│   - Intégration Claude API (streaming)                                     │
│   - 7 lanes: Parse, Route, Govern, Execute, Verify, Log, Respond           │
│   - Créer checkpoint si action sensible → HTTP 423                         │
│   - get_history(thread_id)                                                 │
│                                                                             │
│ OUTPUT: Pipeline Nova fonctionnel                                          │
│ TEMPS:  4 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-011: Nova Routes + Checkpoints                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ POST /api/v2/nova/chat (streaming response)                              │
│ □ GET  /api/v2/nova/history/{thread_id}                                    │
│ □ GET  /api/v2/checkpoints                                                 │
│ □ GET  /api/v2/checkpoints/{checkpoint_id}                                 │
│ □ POST /api/v2/checkpoints/{checkpoint_id}/approve                         │
│ □ POST /api/v2/checkpoints/{checkpoint_id}/reject                          │
│                                                                             │
│ OUTPUT: API Nova + checkpoints                                             │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-010: Nova Store                                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/stores/nova.store.ts                              │
│   - messages: Message[]                                                    │
│   - isLoading: boolean                                                     │
│   - pendingCheckpoint: Checkpoint | null                                   │
│   - sendMessage(threadId, message)                                         │
│   - approveCheckpoint(checkpointId)                                        │
│   - rejectCheckpoint(checkpointId)                                         │
│ □ Handle streaming response                                                │
│                                                                             │
│ OUTPUT: Store Nova                                                         │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-011: Nova Chat Interface                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/components/nova/NovaChat.tsx                          │
│ □ Créer frontend/src/components/nova/MessageBubble.tsx                     │
│ □ Créer frontend/src/components/nova/ChatInput.tsx                         │
│ □ Créer frontend/src/components/nova/StreamingResponse.tsx                 │
│ □ Créer frontend/src/components/nova/CheckpointModal.tsx                   │
│ □ Compléter frontend/src/pages/NovaPage.tsx                                │
│                                                                             │
│ OUTPUT: Interface chat Nova complète                                       │
│ TEMPS:  4 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

**🔄 SYNC JOUR 5:** Chat avec Nova fonctionne end-to-end

---

## JOUR 6 — AGENTS SYSTEM

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-012: Agent Service                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter backend/services/agent_service.py                              │
│   - list_agents(identity_id)                                               │
│   - get_agent(agent_id)                                                    │
│   - hire_agent(agent_id, identity_id)                                      │
│   - fire_agent(agent_id, identity_id)                                      │
│   - get_capabilities(agent_id)                                             │
│ □ Hierarchy L0 (Nova) → L3 (Specialist)                                    │
│ □ Seed agents par défaut                                                   │
│                                                                             │
│ OUTPUT: Service agents                                                     │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-013: Agent Routes                                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET  /api/v2/agents                                                      │
│ □ GET  /api/v2/agents/{agent_id}                                           │
│ □ POST /api/v2/agents/{agent_id}/hire                                      │
│ □ POST /api/v2/agents/{agent_id}/fire                                      │
│ □ GET  /api/v2/agents/{agent_id}/capabilities                              │
│                                                                             │
│ OUTPUT: API agents                                                         │
│ TEMPS:  1-2 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-012: Agent Store & Components                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/stores/agent.store.ts                             │
│ □ Créer frontend/src/components/agents/AgentCard.tsx                       │
│ □ Créer frontend/src/components/agents/AgentPanel.tsx                      │
│ □ Créer frontend/src/components/agents/HireAgentModal.tsx                  │
│ □ Compléter frontend/src/pages/AgentsPage.tsx                              │
│                                                                             │
│ OUTPUT: UI agents complète                                                 │
│ TEMPS:  3-4 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📅 SPRINT 3: GOVERNANCE (Jours 7-9)

## JOUR 7 — CEA & ORCHESTRATOR

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-014: CEA Service Integration                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/governance/cea_service.py                      │
│ □ Configurer les 6 CEAs:                                                   │
│   - CanonGuardCEA                                                          │
│   - SchemaGuardCEA                                                         │
│   - SecurityGuardCEA                                                       │
│   - CoherenceGuardCEA                                                      │
│   - BudgetGuardCEA                                                         │
│   - LegalComplianceCEA                                                     │
│ □ Hook CEAs dans le pipeline Nova                                          │
│                                                                             │
│ OUTPUT: CEAs actifs dans pipeline                                          │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-015: Orchestrator Service Integration                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/governance/orchestrator_service.py             │
│ □ Configurer QCT (Quality/Cost Targeting)                                  │
│ □ Configurer SES (Selective Escalation)                                    │
│ □ Configurer RDC (Reactive Decision Cascade)                               │
│ □ Hook orchestrator dans pipeline Nova                                     │
│                                                                             │
│ OUTPUT: Orchestrator décide sur signaux                                    │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-016: Governance Routes                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ POST /api/v2/governance/evaluate                                         │
│ □ GET  /api/v2/governance/signals                                          │
│ □ GET  /api/v2/governance/signals/{thread_id}                              │
│                                                                             │
│ OUTPUT: API governance                                                     │
│ TEMPS:  1 heure                                                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-013: Governance Store                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Compléter frontend/src/stores/governance.store.ts                        │
│   - signals: GovernanceSignal[]                                            │
│   - fetchSignals(threadId)                                                 │
│   - subscribeToSignals(threadId)                                           │
│                                                                             │
│ OUTPUT: Store governance                                                   │
│ TEMPS:  1-2 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-014: Governance Signal Components                                   │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Copier frontend/src/components/governance/GovernanceSignalCard.tsx       │
│ □ Créer frontend/src/components/governance/SignalsList.tsx                 │
│ □ Créer frontend/src/components/governance/SignalToast.tsx                 │
│ □ Intégrer signals dans NovaChat                                           │
│                                                                             │
│ OUTPUT: Affichage signaux temps réel                                       │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 8 — DECISION POINTS ⭐

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-017: Decision Point Service                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/governance/decision_point_service.py           │
│ □ Implémenter aging system:                                                │
│   - GREEN (0-24h)                                                          │
│   - YELLOW (24h-3d)                                                        │
│   - RED (3-7d)                                                             │
│   - BLINK (7-10d)                                                          │
│   - ARCHIVE (>10d)                                                         │
│ □ AI Suggestion generator (mock ou Claude)                                 │
│ □ Background job pour update aging                                         │
│                                                                             │
│ OUTPUT: Service decision points                                            │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-018: Decision Point Routes                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET  /api/v2/decision-points                                             │
│ □ GET  /api/v2/decision-points/{id}                                        │
│ □ POST /api/v2/decision-points                                             │
│ □ POST /api/v2/decision-points/{id}/respond                                │
│ □ POST /api/v2/decision-points/{id}/defer                                  │
│ □ POST /api/v2/decision-points/{id}/archive                                │
│ □ GET  /api/v2/decision-points/summary                                     │
│                                                                             │
│ OUTPUT: API decision points                                                │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-015: Decision Points Store                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Créer frontend/src/stores/decision.store.ts                              │
│   - points: DecisionPoint[]                                                │
│   - summary: { green, yellow, red, blink }                                 │
│   - fetchPoints(filters)                                                   │
│   - respondToPoint(id, response)                                           │
│   - deferPoint(id)                                                         │
│                                                                             │
│ OUTPUT: Store decision points                                              │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-016: Decision Points UI                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Copier frontend/src/components/decision-points/DecisionPointCard.tsx     │
│ □ Créer frontend/src/components/decision-points/AgingBadge.tsx             │
│   - Animation blink pour BLINK level                                       │
│ □ Créer frontend/src/components/decision-points/ResponseActions.tsx        │
│ □ Créer frontend/src/components/decision-points/FilterPanel.tsx            │
│ □ Créer frontend/src/pages/DecisionPointsPage.tsx                          │
│                                                                             │
│ OUTPUT: Dashboard decision points complet                                  │
│ TEMPS:  4 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 9 — BACKLOG & ANALYTICS

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-019: Backlog Service                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/governance/backlog_service.py                  │
│ □ Capture automatique des backlogs:                                        │
│   - ERROR: défaut échappé                                                  │
│   - SIGNAL: faux positif                                                   │
│   - DECISION: outcome décision                                             │
│   - COST: spike de coût                                                    │
│ □ Analytics computation                                                    │
│                                                                             │
│ OUTPUT: Service backlog                                                    │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-020: Governance Analytics Routes                                    │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET  /api/v2/governance/backlog                                          │
│ □ POST /api/v2/governance/backlog/{id}/resolve                             │
│ □ GET  /api/v2/governance/metrics                                          │
│ □ GET  /api/v2/governance/analytics                                        │
│                                                                             │
│ OUTPUT: API analytics governance                                           │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-017: Governance Dashboard                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Copier frontend/src/components/governance/BacklogItemCard.tsx            │
│ □ Créer frontend/src/components/governance/MetricsChart.tsx                │
│ □ Créer frontend/src/components/governance/EscapeRateGraph.tsx             │
│ □ Créer frontend/src/pages/GovernanceDashboardPage.tsx                     │
│                                                                             │
│ OUTPUT: Dashboard analytics gouvernance                                    │
│ TEMPS:  4 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📅 SPRINT 4: XR & FINITIONS (Jours 10-12)

## JOUR 10 — THREAD LOBBY & MATURITY

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-021: Maturity Service                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/xr/maturity_service.py                         │
│ □ Compute score (0-100) basé sur signals                                   │
│ □ Map score → level (SEED, SPROUT, WORKSHOP, STUDIO, ORG, ECOSYSTEM)       │
│                                                                             │
│ OUTPUT: Service maturité                                                   │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-022: Thread Lobby Routes                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET /api/v2/threads/{id}/maturity                                        │
│ □ GET /api/v2/threads/{id}/lobby                                           │
│                                                                             │
│ OUTPUT: API lobby                                                          │
│ TEMPS:  1 heure                                                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-018: Thread Lobby Components                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Copier frontend/src/components/thread-lobby/ThreadLobby.tsx              │
│ □ Copier frontend/src/components/thread-lobby/ModeSelector.tsx             │
│ □ Copier frontend/src/components/thread-lobby/MaturityBadge.tsx            │
│ □ Copier frontend/src/components/thread-lobby/LiveIndicator.tsx            │
│ □ Intégrer dans navigation avant ThreadPage                                │
│                                                                             │
│ OUTPUT: Lobby avant entrée thread                                          │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 11 — XR BLUEPRINT

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-023: XR Renderer Service                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Intégrer backend/services/xr/xr_renderer_service.py                      │
│ □ Blueprint generation avec 7 zones                                        │
│ □ Redaction par role (owner, admin, member, guest)                         │
│ □ Template selection                                                       │
│                                                                             │
│ OUTPUT: Service XR renderer                                                │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-024: XR Routes                                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ GET /api/v2/xr/preflight/{thread_id}                                     │
│ □ GET /api/v2/xr/blueprint/{thread_id}                                     │
│                                                                             │
│ OUTPUT: API XR                                                             │
│ TEMPS:  1 heure                                                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-019: XR Components                                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Copier frontend/src/components/xr/XRPreflightModal.tsx                   │
│ □ Créer frontend/src/components/xr/XRViewer.tsx (Three.js basic)           │
│ □ Créer frontend/src/components/xr/XRZone.tsx                              │
│ □ Créer frontend/src/components/xr/BlueprintItem.tsx                       │
│ □ Créer frontend/src/pages/XRViewerPage.tsx                                │
│                                                                             │
│ OUTPUT: Viewer XR basique                                                  │
│ TEMPS:  4-5 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 12 — INTÉGRATION & POLISH

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-025: WebSocket Realtime                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Setup WebSocket pour signals temps réel                                  │
│ □ Push signals CEA                                                         │
│ □ Push decision points updates                                             │
│ □ Push aging changes                                                       │
│                                                                             │
│ OUTPUT: Updates temps réel                                                 │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-026: Background Jobs                                                │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Job aging update (every minute)                                          │
│ □ Job auto-archive (every hour)                                            │
│ □ Job metrics computation (every 5 min)                                    │
│                                                                             │
│ OUTPUT: Jobs background fonctionnels                                       │
│ TEMPS:  2 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-020: UI Polish                                                      │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Responsive design (mobile)                                               │
│ □ Dark/Light theme toggle                                                  │
│ □ Loading states partout                                                   │
│ □ Error boundaries                                                         │
│ □ Toast notifications                                                      │
│ □ Skeleton loaders                                                         │
│                                                                             │
│ OUTPUT: UX polish                                                          │
│ TEMPS:  4-5 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-021: WebSocket Client                                               │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Setup WebSocket client                                                   │
│ □ Subscribe to signals                                                     │
│ □ Subscribe to decision points                                             │
│ □ Update stores on push                                                    │
│                                                                             │
│ OUTPUT: Realtime updates côté client                                       │
│ TEMPS:  2-3 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📅 SPRINT 5: TESTS & DEPLOY (Jours 13-14)

## JOUR 13 — TESTS

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-027: Tests Backend Complets                                         │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Tests auth (register, login, refresh, logout)                            │
│ □ Tests threads (create, events, corrections)                              │
│ □ Tests governance (CEA, orchestrator, signals)                            │
│ □ Tests decision points (create, respond, aging)                           │
│ □ Tests XR (maturity, blueprint)                                           │
│ □ Coverage > 80%                                                           │
│                                                                             │
│ OUTPUT: Suite tests backend                                                │
│ TEMPS:  4-5 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-022: Tests Frontend + E2E                                           │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Unit tests composants (vitest)                                           │
│ □ E2E Cypress:                                                             │
│   - Login flow                                                             │
│   - Create thread                                                          │
│   - Chat with Nova                                                         │
│   - Approve checkpoint                                                     │
│   - Decision point respond                                                 │
│ □ Storybook stories                                                        │
│                                                                             │
│ OUTPUT: Suite tests frontend                                               │
│ TEMPS:  4-5 heures                                                         │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## JOUR 14 — DEPLOY

### AGENT-A (Backend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-A-028: Deployment Backend                                             │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Dockerfile.backend final                                                 │
│ □ docker-compose.yml complet                                               │
│ □ K8s manifests (staging + prod)                                           │
│ □ Database migrations                                                      │
│ □ Seed data                                                                │
│ □ Health checks                                                            │
│ □ CI/CD pipeline (GitHub Actions)                                          │
│                                                                             │
│ OUTPUT: Backend déployable                                                 │
│ TEMPS:  4 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

### AGENT-B (Frontend)
```
┌─────────────────────────────────────────────────────────────────────────────┐
│ TASK-B-023: Deployment Frontend                                            │
├─────────────────────────────────────────────────────────────────────────────┤
│ ACTIONS:                                                                    │
│ □ Build production (vite build)                                            │
│ □ Dockerfile frontend final                                                │
│ □ nginx.conf optimisé                                                      │
│ □ Environment variables                                                    │
│ □ README usage                                                             │
│                                                                             │
│ OUTPUT: Frontend déployable                                                │
│ TEMPS:  3 heures                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 📊 RÉCAPITULATIF DES TÂCHES

## AGENT-A (Backend) — 28 Tâches

| ID | Tâche | Jour | Temps |
|----|-------|------|-------|
| A-001 | Intégrer packages Codex | 1 | 2-3h |
| A-002 | Créer API Contract v1 | 1 | 1h |
| A-003 | Auth Service | 2 | 2h |
| A-004 | Auth Routes | 2 | 2h |
| A-005 | Identity Boundary Middleware | 2 | 1-2h |
| A-006 | Sphere & Bureau Services | 3 | 2h |
| A-007 | Sphere & Bureau Routes | 3 | 1-2h |
| A-008 | Thread Service V2 | 4 | 3h |
| A-009 | Thread Routes | 4 | 2h |
| A-010 | Nova Pipeline Service | 5 | 4h |
| A-011 | Nova Routes + Checkpoints | 5 | 2h |
| A-012 | Agent Service | 6 | 2-3h |
| A-013 | Agent Routes | 6 | 1-2h |
| A-014 | CEA Service Integration | 7 | 3h |
| A-015 | Orchestrator Service | 7 | 2h |
| A-016 | Governance Routes | 7 | 1h |
| A-017 | Decision Point Service | 8 | 3h |
| A-018 | Decision Point Routes | 8 | 2h |
| A-019 | Backlog Service | 9 | 2h |
| A-020 | Governance Analytics Routes | 9 | 2h |
| A-021 | Maturity Service | 10 | 2h |
| A-022 | Thread Lobby Routes | 10 | 1h |
| A-023 | XR Renderer Service | 11 | 2-3h |
| A-024 | XR Routes | 11 | 1h |
| A-025 | WebSocket Realtime | 12 | 3h |
| A-026 | Background Jobs | 12 | 2h |
| A-027 | Tests Backend | 13 | 4-5h |
| A-028 | Deployment Backend | 14 | 4h |

**Total estimé: ~60-70 heures**

---

## AGENT-B (Frontend) — 23 Tâches

| ID | Tâche | Jour | Temps |
|----|-------|------|-------|
| B-001 | Setup structure features | 1 | 1-2h |
| B-002 | API Client base | 1 | 2h |
| B-003 | Auth Store | 2 | 2h |
| B-004 | Login Page | 2 | 2h |
| B-005 | Register + Protected Routes | 2 | 2h |
| B-006 | Dashboard 9 Sphères | 3 | 2-3h |
| B-007 | SpherePage 6 Bureau | 3 | 2-3h |
| B-008 | Thread Store | 4 | 2h |
| B-009 | Thread Components | 4 | 3h |
| B-010 | Nova Store | 5 | 2h |
| B-011 | Nova Chat Interface | 5 | 4h |
| B-012 | Agent Store & Components | 6 | 3-4h |
| B-013 | Governance Store | 7 | 1-2h |
| B-014 | Governance Signal Components | 7 | 2-3h |
| B-015 | Decision Points Store | 8 | 2h |
| B-016 | Decision Points UI | 8 | 4h |
| B-017 | Governance Dashboard | 9 | 4h |
| B-018 | Thread Lobby Components | 10 | 3h |
| B-019 | XR Components | 11 | 4-5h |
| B-020 | UI Polish | 12 | 4-5h |
| B-021 | WebSocket Client | 12 | 2-3h |
| B-022 | Tests Frontend + E2E | 13 | 4-5h |
| B-023 | Deployment Frontend | 14 | 3h |

**Total estimé: ~60-70 heures**

---

# 📄 PROMPTS DE BRIEFING

## PROMPT AGENT-A (Backend)

```markdown
# 🤖 AGENT-A BRIEFING — BACKEND CHE·NU V72

Tu es AGENT-A, responsable du BACKEND CHE·NU V72.

## TON SCOPE
- backend/** (Python/FastAPI)
- /shared/api-contracts/** (OpenAPI specs)
- database migrations
- tests backend (pytest)

## TU NE TOUCHES PAS
- frontend/** (c'est AGENT-B)
- Ne crée PAS de composants React

## RÈGLES
1. GOUVERNANCE > EXÉCUTION
2. Thread = append-only, JAMAIS de delete/update
3. Identity boundary = isolation stricte
4. HTTP 423 pour checkpoints
5. Tous les services dans backend/services/
6. Toutes les routes dans backend/api/

## CONTRAT D'INTERFACE
Après chaque endpoint créé, tu DOIS:
1. Mettre à jour /shared/api-contracts/{module}.yaml
2. Documenter request/response schemas
3. Écrire au moins 1 test pytest

## PREMIÈRE TÂCHE
TASK-A-001: Intégrer packages Codex dans V71
(voir plan détaillé)

## FICHIERS DISPONIBLES
- /mnt/project/ (documentation canonique)
- governance_xr_decision.zip (packages Codex)
- AT-OM-main (V71 actuel)
```

---

## PROMPT AGENT-B (Frontend)

```markdown
# 🤖 AGENT-B BRIEFING — FRONTEND CHE·NU V72

Tu es AGENT-B, responsable du FRONTEND CHE·NU V72.

## TON SCOPE
- frontend/src/** (React/TypeScript)
- components, pages, stores, hooks
- tests frontend (vitest + cypress)
- storybook stories

## TU NE TOUCHES PAS
- backend/** (c'est AGENT-A)
- Ne crée PAS de services Python

## RÈGLES
1. Utilise les contrats API de /shared/api-contracts/
2. Stores avec Zustand
3. Types stricts TypeScript
4. Composants dans frontend/src/components/{feature}/
5. Pages dans frontend/src/pages/

## DÉPENDANCES
Tu DOIS attendre les API contracts de AGENT-A avant:
- Créer les API clients
- Implémenter les stores qui appellent le backend

## MOCK EN ATTENDANT
Si le backend n'est pas prêt, utilise des mocks:
```typescript
// frontend/src/api/mock/auth.mock.ts
export const mockLogin = async (email: string, password: string) => {
  return { token: 'mock-token', user: { id: '1', email } };
};
```

## PREMIÈRE TÂCHE
TASK-B-001: Setup structure features
(voir plan détaillé)

## FICHIERS DISPONIBLES
- /mnt/project/ (documentation canonique)
- governance-xr.types.ts (types Codex)
- AT-OM-main/frontend (V71 actuel)
```

---

# 🚀 COMMANDES DE LANCEMENT

## Pour démarrer AGENT-A:
```
Copie le PROMPT AGENT-A ci-dessus + ce fichier de plan + commence par TASK-A-001
```

## Pour démarrer AGENT-B:
```
Copie le PROMPT AGENT-B ci-dessus + ce fichier de plan + commence par TASK-B-001
```

---

**GOUVERNANCE > EXÉCUTION**  
**ON CONTINUE!** 🚀

*© 2026 CHE·NU™*
