# Code
Executable implementations override specs.
