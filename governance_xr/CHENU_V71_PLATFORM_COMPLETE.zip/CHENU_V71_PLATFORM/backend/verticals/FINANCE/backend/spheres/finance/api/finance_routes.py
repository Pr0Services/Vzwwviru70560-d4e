"""
CHE·NU™ Finance API Routes V68

RESTful API for personal & business finance management.

CANON Compliance:
- HTTP 423 for checkpoint blocking (Rule #1)
- All responses include traceability (Rule #6)
"""

from decimal import Decimal
from datetime import datetime, timezone
from typing import Optional, List
from uuid import UUID

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

# Import agent
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from spheres.finance.agents.finance_agent import (
    FinanceAgent,
    AccountType,
    TransactionType,
    TransactionStatus
)


router = APIRouter(prefix="/api/v2/finance", tags=["Finance"])

# Global agent instance
agent = FinanceAgent()


# ═══════════════════════════════════════════════════════════════════════════════
# PYDANTIC MODELS
# ═══════════════════════════════════════════════════════════════════════════════

class AccountCreate(BaseModel):
    """Create account request."""
    name: str
    account_type: str
    currency: str = "CAD"
    initial_balance: float = 0.0
    institution: Optional[str] = None


class AccountResponse(BaseModel):
    """Account response."""
    id: str
    name: str
    account_type: str
    currency: str
    balance: float
    institution: Optional[str]
    created_by: str
    created_at: str
    is_active: bool


class TransactionCreate(BaseModel):
    """Create transaction request."""
    account_id: str
    amount: float
    transaction_type: str
    description: str
    category_id: Optional[str] = None
    to_account_id: Optional[str] = None
    tags: List[str] = []
    notes: str = ""


class TransactionResponse(BaseModel):
    """Transaction response."""
    id: str
    account_id: str
    amount: float
    transaction_type: str
    description: str
    status: str
    created_by: str
    created_at: str
    approved_by: Optional[str] = None


class BudgetCreate(BaseModel):
    """Create budget request."""
    name: str
    amount: float
    period: str
    category_id: Optional[str] = None
    alert_threshold: float = 0.8


class GoalCreate(BaseModel):
    """Create goal request."""
    name: str
    target_amount: float
    target_date: Optional[str] = None
    account_id: Optional[str] = None
    initial_amount: float = 0.0


class InvestmentAnalysisRequest(BaseModel):
    """Investment analysis request."""
    symbol: str
    amount: float


class InvestmentCreate(BaseModel):
    """Create investment request."""
    symbol: str
    name: str
    quantity: float
    price: float
    account_id: str


class CheckpointResponse(BaseModel):
    """Checkpoint response for HTTP 423."""
    checkpoint_id: str
    checkpoint_type: str
    entity_id: str
    entity_type: str
    reason: str
    requires_approval: bool
    message: str = "Action requires human approval"


# ═══════════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_user_id() -> str:
    """Get user ID from request (placeholder)."""
    return "user_001"  # TODO: Extract from auth token


def account_to_response(account) -> AccountResponse:
    """Convert account to response."""
    return AccountResponse(
        id=str(account.id),
        name=account.name,
        account_type=account.account_type.value,
        currency=account.currency,
        balance=float(account.balance),
        institution=account.institution,
        created_by=account.created_by,
        created_at=account.created_at.isoformat(),
        is_active=account.is_active
    )


def transaction_to_response(tx) -> TransactionResponse:
    """Convert transaction to response."""
    return TransactionResponse(
        id=str(tx.id),
        account_id=str(tx.account_id),
        amount=float(tx.amount),
        transaction_type=tx.transaction_type.value,
        description=tx.description,
        status=tx.status.value,
        created_by=tx.created_by,
        created_at=tx.created_at.isoformat(),
        approved_by=tx.approved_by
    )


# ═══════════════════════════════════════════════════════════════════════════════
# ACCOUNT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/accounts", response_model=AccountResponse, status_code=201)
async def create_account(data: AccountCreate):
    """Create a new financial account."""
    user_id = get_user_id()
    
    try:
        account_type = AccountType(data.account_type)
    except ValueError:
        raise HTTPException(400, f"Invalid account type: {data.account_type}")
    
    account = await agent.create_account(
        name=data.name,
        account_type=account_type,
        currency=data.currency,
        user_id=user_id,
        initial_balance=Decimal(str(data.initial_balance)),
        institution=data.institution
    )
    
    return account_to_response(account)


@router.get("/accounts", response_model=List[AccountResponse])
async def get_accounts():
    """Get all accounts for user."""
    user_id = get_user_id()
    accounts = await agent.get_accounts(user_id)
    return [account_to_response(a) for a in accounts]


@router.get("/accounts/{account_id}", response_model=AccountResponse)
async def get_account(account_id: str):
    """Get account by ID."""
    account = await agent.get_account(UUID(account_id))
    if not account:
        raise HTTPException(404, "Account not found")
    return account_to_response(account)


# ═══════════════════════════════════════════════════════════════════════════════
# TRANSACTION ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/transactions", response_model=TransactionResponse, status_code=201)
async def create_transaction(data: TransactionCreate):
    """
    Create a transaction in DRAFT status.
    
    CANON Rule #1: Transactions start as DRAFT.
    """
    user_id = get_user_id()
    
    try:
        tx_type = TransactionType(data.transaction_type)
    except ValueError:
        raise HTTPException(400, f"Invalid transaction type: {data.transaction_type}")
    
    tx = await agent.create_transaction(
        account_id=UUID(data.account_id),
        amount=Decimal(str(data.amount)),
        transaction_type=tx_type,
        description=data.description,
        user_id=user_id,
        category_id=UUID(data.category_id) if data.category_id else None,
        to_account_id=UUID(data.to_account_id) if data.to_account_id else None,
        tags=data.tags,
        notes=data.notes
    )
    
    return transaction_to_response(tx)


@router.get("/transactions", response_model=List[TransactionResponse])
async def get_transactions(
    account_id: Optional[str] = None,
    limit: int = 50
):
    """
    Get transactions.
    
    CANON Rule #5: Chronological order only.
    """
    user_id = get_user_id()
    transactions = await agent.get_transactions(
        user_id,
        account_id=UUID(account_id) if account_id else None,
        limit=limit
    )
    return [transaction_to_response(t) for t in transactions]


@router.post("/transactions/{transaction_id}/submit")
async def submit_transaction(transaction_id: str):
    """
    Submit transaction for approval.
    
    CANON Rule #1: May return HTTP 423 if checkpoint required.
    """
    user_id = get_user_id()
    
    try:
        tx, checkpoint = await agent.submit_transaction_for_approval(
            UUID(transaction_id), user_id
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    
    # HTTP 423 LOCKED if checkpoint required
    if checkpoint:
        raise HTTPException(
            status_code=423,  # LOCKED
            detail={
                "checkpoint_id": str(checkpoint.id),
                "checkpoint_type": checkpoint.checkpoint_type.value,
                "entity_id": str(checkpoint.entity_id),
                "reason": checkpoint.reason,
                "requires_approval": True,
                "message": "Large transaction requires approval"
            }
        )
    
    return transaction_to_response(tx)


@router.post("/transactions/{transaction_id}/approve", response_model=TransactionResponse)
async def approve_transaction(transaction_id: str):
    """
    Approve a pending transaction.
    
    CANON Rule #1: Human approval required.
    """
    user_id = get_user_id()
    
    try:
        tx = await agent.approve_transaction(UUID(transaction_id), user_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    
    return transaction_to_response(tx)


@router.post("/transactions/{transaction_id}/reject", response_model=TransactionResponse)
async def reject_transaction(transaction_id: str, reason: str = ""):
    """Reject a pending transaction."""
    user_id = get_user_id()
    
    try:
        tx = await agent.reject_transaction(UUID(transaction_id), user_id, reason)
    except ValueError as e:
        raise HTTPException(400, str(e))
    
    return transaction_to_response(tx)


@router.post("/transactions/{transaction_id}/execute", response_model=TransactionResponse)
async def execute_transaction(transaction_id: str):
    """
    Execute an approved transaction.
    
    CANON Rule #1: Only executes if APPROVED.
    """
    user_id = get_user_id()
    
    try:
        tx = await agent.execute_transaction(UUID(transaction_id), user_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    
    return transaction_to_response(tx)


# ═══════════════════════════════════════════════════════════════════════════════
# BUDGET ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/budgets", status_code=201)
async def create_budget(data: BudgetCreate):
    """Create a budget in DRAFT status."""
    user_id = get_user_id()
    
    budget = await agent.create_budget(
        name=data.name,
        amount=Decimal(str(data.amount)),
        period=data.period,
        user_id=user_id,
        category_id=UUID(data.category_id) if data.category_id else None,
        alert_threshold=data.alert_threshold
    )
    
    return {
        "id": str(budget.id),
        "name": budget.name,
        "amount": float(budget.amount),
        "period": budget.period,
        "status": budget.status.value,
        "created_at": budget.created_at.isoformat()
    }


@router.get("/budgets")
async def get_budgets():
    """Get all budgets."""
    user_id = get_user_id()
    budgets = await agent.get_budgets(user_id)
    
    return [{
        "id": str(b.id),
        "name": b.name,
        "amount": float(b.amount),
        "spent": float(b.spent),
        "period": b.period,
        "status": b.status.value
    } for b in budgets]


@router.post("/budgets/{budget_id}/activate")
async def activate_budget(budget_id: str):
    """Activate a draft budget."""
    user_id = get_user_id()
    
    try:
        budget = await agent.activate_budget(UUID(budget_id), user_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    
    return {"status": budget.status.value, "message": "Budget activated"}


@router.get("/budgets/{budget_id}/status")
async def get_budget_status(budget_id: str):
    """Get budget spending status."""
    try:
        status = await agent.get_budget_status(UUID(budget_id))
    except ValueError as e:
        raise HTTPException(404, str(e))
    
    return status


# ═══════════════════════════════════════════════════════════════════════════════
# GOAL ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/goals", status_code=201)
async def create_goal(data: GoalCreate):
    """Create a financial goal."""
    user_id = get_user_id()
    
    target_date = None
    if data.target_date:
        target_date = datetime.fromisoformat(data.target_date)
    
    goal = await agent.create_goal(
        name=data.name,
        target_amount=Decimal(str(data.target_amount)),
        user_id=user_id,
        target_date=target_date,
        account_id=UUID(data.account_id) if data.account_id else None,
        initial_amount=Decimal(str(data.initial_amount))
    )
    
    return {
        "id": str(goal.id),
        "name": goal.name,
        "target_amount": float(goal.target_amount),
        "current_amount": float(goal.current_amount),
        "is_achieved": goal.is_achieved
    }


@router.get("/goals")
async def get_goals():
    """Get all goals."""
    user_id = get_user_id()
    goals = await agent.get_goals(user_id)
    
    return [{
        "id": str(g.id),
        "name": g.name,
        "target_amount": float(g.target_amount),
        "current_amount": float(g.current_amount),
        "is_achieved": g.is_achieved
    } for g in goals]


@router.put("/goals/{goal_id}/progress")
async def update_goal_progress(goal_id: str, amount: float):
    """Update goal progress."""
    user_id = get_user_id()
    
    try:
        goal = await agent.update_goal_progress(
            UUID(goal_id), Decimal(str(amount)), user_id
        )
    except ValueError as e:
        raise HTTPException(404, str(e))
    
    return {
        "id": str(goal.id),
        "current_amount": float(goal.current_amount),
        "is_achieved": goal.is_achieved
    }


# ═══════════════════════════════════════════════════════════════════════════════
# INVESTMENT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/investments/analyze")
async def analyze_investment(data: InvestmentAnalysisRequest):
    """
    Analyze investment opportunity.
    
    CANON Rule #2: Read-only sandbox analysis.
    """
    user_id = get_user_id()
    
    analysis = await agent.analyze_investment_opportunity(
        symbol=data.symbol,
        amount=Decimal(str(data.amount)),
        user_id=user_id
    )
    
    return analysis


@router.post("/investments", status_code=423)
async def create_investment(data: InvestmentCreate):
    """
    Create investment with mandatory checkpoint.
    
    CANON Rule #1: Always returns HTTP 423 requiring approval.
    """
    user_id = get_user_id()
    
    investment, checkpoint = await agent.create_investment_with_approval(
        symbol=data.symbol,
        name=data.name,
        quantity=Decimal(str(data.quantity)),
        price=Decimal(str(data.price)),
        account_id=UUID(data.account_id),
        user_id=user_id
    )
    
    # Always return 423 for investments
    raise HTTPException(
        status_code=423,
        detail={
            "investment_id": str(investment.id),
            "checkpoint_id": str(checkpoint.id),
            "checkpoint_type": checkpoint.checkpoint_type.value,
            "reason": checkpoint.reason,
            "requires_approval": True,
            "message": "Investment requires human approval before execution"
        }
    )


@router.get("/investments")
async def get_investments():
    """Get all investments."""
    user_id = get_user_id()
    investments = await agent.get_investments(user_id)
    
    return [{
        "id": str(i.id),
        "symbol": i.symbol,
        "name": i.name,
        "quantity": float(i.quantity),
        "purchase_price": float(i.purchase_price),
        "current_price": float(i.current_price) if i.current_price else None
    } for i in investments]


# ═══════════════════════════════════════════════════════════════════════════════
# CHECKPOINT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/checkpoints/pending")
async def get_pending_checkpoints():
    """Get all pending checkpoints."""
    user_id = get_user_id()
    checkpoints = await agent.get_pending_checkpoints(user_id)
    
    return [{
        "id": str(c.id),
        "type": c.checkpoint_type.value,
        "entity_id": str(c.entity_id),
        "entity_type": c.entity_type,
        "reason": c.reason,
        "created_at": c.created_at.isoformat()
    } for c in checkpoints]


@router.post("/checkpoints/{checkpoint_id}/approve")
async def approve_checkpoint(checkpoint_id: str):
    """Approve a checkpoint."""
    user_id = get_user_id()
    
    try:
        checkpoint = await agent.approve_checkpoint(UUID(checkpoint_id), user_id)
    except ValueError as e:
        raise HTTPException(404, str(e))
    
    return {"approved": True, "approved_by": checkpoint.approved_by}


@router.post("/checkpoints/{checkpoint_id}/reject")
async def reject_checkpoint(checkpoint_id: str):
    """Reject a checkpoint."""
    user_id = get_user_id()
    
    try:
        checkpoint = await agent.reject_checkpoint(UUID(checkpoint_id), user_id)
    except ValueError as e:
        raise HTTPException(404, str(e))
    
    return {"approved": False, "rejected_by": checkpoint.approved_by}


# ═══════════════════════════════════════════════════════════════════════════════
# REPORT ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/reports/spending")
async def get_spending_report(
    start_date: str,
    end_date: str
):
    """
    Generate spending report.
    
    CANON Rule #2: Read-only analysis.
    """
    user_id = get_user_id()
    
    start = datetime.fromisoformat(start_date)
    end = datetime.fromisoformat(end_date)
    
    report = await agent.generate_spending_report(user_id, start, end)
    
    return {
        "id": str(report.id),
        "type": report.report_type,
        "period_start": report.period_start.isoformat(),
        "period_end": report.period_end.isoformat(),
        "data": report.data,
        "generated_at": report.generated_at.isoformat()
    }


@router.get("/reports/net-worth")
async def get_net_worth_report():
    """Generate net worth report."""
    user_id = get_user_id()
    
    report = await agent.generate_net_worth_report(user_id)
    
    return {
        "id": str(report.id),
        "type": report.report_type,
        "data": report.data,
        "generated_at": report.generated_at.isoformat()
    }


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════════

@router.post("/categories", status_code=201)
async def create_category(
    name: str,
    color: str = "#3B82F6",
    icon: str = "folder"
):
    """Create a transaction category."""
    user_id = get_user_id()
    
    category = await agent.create_category(
        name=name,
        user_id=user_id,
        color=color,
        icon=icon
    )
    
    return {
        "id": str(category.id),
        "name": category.name,
        "color": category.color,
        "icon": category.icon
    }


@router.get("/categories")
async def get_categories():
    """Get all categories (alphabetical)."""
    user_id = get_user_id()
    categories = await agent.get_categories(user_id)
    
    return [{
        "id": str(c.id),
        "name": c.name,
        "color": c.color,
        "icon": c.icon
    } for c in categories]


# ═══════════════════════════════════════════════════════════════════════════════
# HEALTH CHECK
# ═══════════════════════════════════════════════════════════════════════════════

@router.get("/health")
async def health_check():
    """Health check endpoint."""
    health = await agent.get_health()
    return health
