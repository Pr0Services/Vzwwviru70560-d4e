"""
CHE·NU™ V70 — MODULE 39: POST-HUMAN ETHICS & SUCCESSION PROTOCOL
STATUS: IMMUTABLE ONCE RATIFIED
No AI may override human sovereignty.
"""

from .engine import (
    EthicalLayer,
    ForbiddenState,
    SuccessionTrigger,
    EthicalPrinciple,
    HumanPrimacyCheck,
    ForbiddenStateDetection,
    SuccessionProtocol,
    EthicalAuditEntry,
    PostHumanEthicsEngine,
)

__all__ = [
    "EthicalLayer",
    "ForbiddenState",
    "SuccessionTrigger",
    "EthicalPrinciple",
    "HumanPrimacyCheck",
    "ForbiddenStateDetection",
    "SuccessionProtocol",
    "EthicalAuditEntry",
    "PostHumanEthicsEngine",
]

__version__ = "70.0.0"
