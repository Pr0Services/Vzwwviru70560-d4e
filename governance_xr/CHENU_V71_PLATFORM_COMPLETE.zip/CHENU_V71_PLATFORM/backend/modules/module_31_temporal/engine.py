"""
CHE·NU™ V70 — MODULE 31: TEMPORAL RHYTHM & SUSTAINABILITY ENGINE
=================================================================
Régule le tempo et la durabilité dans CHE·NU™.

Canon Rule: Un système qui ne pause jamais finira par casser.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.module_31")


class FatigueLevel(str, Enum):
    """Niveaux de fatigue d'accélération."""
    NONE = "none"
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class CycleType(str, Enum):
    """Types de cycles."""
    REST = "rest"
    ACTIVE = "active"
    RECOVERY = "recovery"
    MAINTENANCE = "maintenance"


@dataclass
class TemporalState:
    """État temporel d'une entité."""
    entity_id: str = ""
    entity_type: str = ""  # user, agent, system
    
    # Rhythm metrics
    active_hours_today: float = 0.0
    rest_hours_today: float = 0.0
    consecutive_active_days: int = 0
    last_rest_cycle: Optional[datetime] = None
    
    # Fatigue
    fatigue_level: FatigueLevel = FatigueLevel.NONE
    fatigue_score: float = 0.0  # 0-1
    
    # Sync
    human_system_sync: float = 1.0  # 1 = perfect sync


@dataclass
class RestCycle:
    """Cycle de repos enforced."""
    cycle_id: str = field(default_factory=lambda: f"REST_{uuid4().hex[:8]}")
    entity_id: str = ""
    
    # Timing
    start_time: datetime = field(default_factory=datetime.utcnow)
    duration_hours: float = 8.0
    end_time: Optional[datetime] = None
    
    # Status
    enforced: bool = True
    completed: bool = False
    interrupted: bool = False


class TemporalRhythmEngine:
    """
    Module 31 — Temporal Rhythm & Sustainability Engine
    
    Core Functions:
    - Detect acceleration fatigue
    - Enforce rest cycles
    - Synchronize human and system time
    
    Canon Rule: A system that never pauses will eventually break.
    """
    
    # Thresholds
    FATIGUE_THRESHOLD_LOW = 0.3
    FATIGUE_THRESHOLD_MODERATE = 0.5
    FATIGUE_THRESHOLD_HIGH = 0.7
    FATIGUE_THRESHOLD_CRITICAL = 0.9
    
    MAX_CONSECUTIVE_ACTIVE_DAYS = 5
    MIN_REST_HOURS_DAILY = 6
    
    def __init__(self):
        self.engine_id = f"TEMPORAL_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        self._states: dict[str, TemporalState] = {}
        self._rest_cycles: dict[str, RestCycle] = {}
        
        logger.info(f"Temporal Rhythm Engine initialized: {self.engine_id}")
    
    def track_activity(
        self,
        entity_id: str,
        entity_type: str,
        hours_active: float,
    ) -> TemporalState:
        """Track activity and update temporal state."""
        state = self._states.get(entity_id, TemporalState(
            entity_id=entity_id,
            entity_type=entity_type,
        ))
        
        state.active_hours_today += hours_active
        
        # Calculate fatigue
        state.fatigue_score = self._calculate_fatigue(state)
        state.fatigue_level = self._get_fatigue_level(state.fatigue_score)
        
        self._states[entity_id] = state
        
        # Auto-enforce rest if critical
        if state.fatigue_level == FatigueLevel.CRITICAL:
            self.enforce_rest_cycle(entity_id)
        
        return state
    
    def _calculate_fatigue(self, state: TemporalState) -> float:
        """Calculate fatigue score."""
        fatigue = 0.0
        
        # Active hours contribution
        if state.active_hours_today > 8:
            fatigue += 0.3 * (state.active_hours_today - 8) / 8
        
        # Lack of rest
        if state.rest_hours_today < self.MIN_REST_HOURS_DAILY:
            fatigue += 0.3 * (1 - state.rest_hours_today / self.MIN_REST_HOURS_DAILY)
        
        # Consecutive days
        if state.consecutive_active_days > self.MAX_CONSECUTIVE_ACTIVE_DAYS:
            fatigue += 0.4
        
        return min(fatigue, 1.0)
    
    def _get_fatigue_level(self, score: float) -> FatigueLevel:
        """Get fatigue level from score."""
        if score >= self.FATIGUE_THRESHOLD_CRITICAL:
            return FatigueLevel.CRITICAL
        elif score >= self.FATIGUE_THRESHOLD_HIGH:
            return FatigueLevel.HIGH
        elif score >= self.FATIGUE_THRESHOLD_MODERATE:
            return FatigueLevel.MODERATE
        elif score >= self.FATIGUE_THRESHOLD_LOW:
            return FatigueLevel.LOW
        return FatigueLevel.NONE
    
    def enforce_rest_cycle(
        self,
        entity_id: str,
        duration_hours: float = 8.0,
    ) -> RestCycle:
        """Enforce a rest cycle."""
        cycle = RestCycle(
            entity_id=entity_id,
            duration_hours=duration_hours,
            end_time=datetime.utcnow() + timedelta(hours=duration_hours),
        )
        
        self._rest_cycles[cycle.cycle_id] = cycle
        
        # Update state
        if entity_id in self._states:
            self._states[entity_id].last_rest_cycle = datetime.utcnow()
        
        logger.info(f"Rest cycle enforced: {cycle.cycle_id} for {entity_id}")
        return cycle
    
    def complete_rest_cycle(self, cycle_id: str) -> RestCycle:
        """Complete a rest cycle."""
        cycle = self._rest_cycles.get(cycle_id)
        if not cycle:
            raise ValueError(f"Cycle not found: {cycle_id}")
        
        cycle.completed = True
        cycle.end_time = datetime.utcnow()
        
        # Reset fatigue
        if cycle.entity_id in self._states:
            state = self._states[cycle.entity_id]
            state.fatigue_score = max(0, state.fatigue_score - 0.5)
            state.fatigue_level = self._get_fatigue_level(state.fatigue_score)
            state.rest_hours_today += cycle.duration_hours
            state.consecutive_active_days = 0
        
        return cycle
    
    def check_sync(self, entity_id: str) -> float:
        """Check human-system time synchronization."""
        state = self._states.get(entity_id)
        if not state:
            return 1.0
        
        # Simple sync calculation
        if state.fatigue_level in [FatigueLevel.HIGH, FatigueLevel.CRITICAL]:
            return 0.5
        elif state.fatigue_level == FatigueLevel.MODERATE:
            return 0.7
        return 1.0
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        critical_count = sum(
            1 for s in self._states.values()
            if s.fatigue_level == FatigueLevel.CRITICAL
        )
        return {
            "engine_id": self.engine_id,
            "tracked_entities": len(self._states),
            "active_rest_cycles": sum(
                1 for c in self._rest_cycles.values() if not c.completed
            ),
            "critical_fatigue_count": critical_count,
        }
