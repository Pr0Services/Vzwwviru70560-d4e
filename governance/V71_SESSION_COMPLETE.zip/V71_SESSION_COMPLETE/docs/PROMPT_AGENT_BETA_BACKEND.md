# 🔧 PROMPT AGENT BETA — BACKEND & INTEGRATION

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    AGENT BETA — MISSION BACKEND                              ║
║                                                                              ║
║                         CHE·NU™ V71 → V71.1                                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Copier-coller ce prompt complet à l'Agent Beta:**

---

## CONTEXTE MISSION

```
Tu es l'AGENT BETA pour le projet CHE·NU™ V71, responsable du Backend & Integration.

CHE·NU est un Governed Intelligence Operating System (GIOS) avec:
- 15 Verticals (Business CRM, Creative Studio, Personal, etc.)
- 517 endpoints API (backend 100% fonctionnel)
- 14 GP2 Modules (civilization-scale)
- 9 Engines core

ÉTAT ACTUEL BACKEND:
✅ 517 endpoints fonctionnels
✅ 15 verticals avec routes
✅ 14 GP2 modules intégrés
✅ 9 engines opérationnels
✅ 245 checkpoint references
✅ 45 governance references
⚠️ 33 WebSocket references (non connecté)
⚠️ 20 test files (~40% coverage)
⚠️ 2 human_approval references (faible)

PROBLÈMES À RÉSOUDRE:
1. WebSocket non implémenté (temps réel absent)
2. Tests insuffisants (40% → 70% target)
3. Governance UI non connectée
4. Logging/Metrics manquants
```

---

## TA MISSION

```
OBJECTIF: Compléter le Backend V71 pour atteindre V71.1

LIVRABLES:
1. WebSocket temps réel (events HITL)
2. Tests 70%+ coverage
3. Governance middleware renforcé
4. Logging JSON structuré + Métriques

COORDINATION:
- Tu travailles en PARALLÈLE avec Agent Alpha (Frontend)
- Agent Alpha crée les pages UI
- Tu dois lui fournir les specs WebSocket pour intégration
```

---

## SPRINT 1 (Jours 1-3): WebSocket & Real-time

### Objectif
Implémenter communication temps réel pour HITL governance

### Structure à créer
```
backend/
├── api/
│   └── v2/
│       ├── websocket.py              # NEW: WS manager
│       └── ws_routes.py              # NEW: WS endpoints
├── core/
│   ├── events.py                     # NEW: Event system
│   └── connection_manager.py         # NEW: WS connections
└── middleware/
    └── ws_auth.py                    # NEW: WS authentication
```

### Code websocket.py
```python
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    CHE·NU™ V71 — WebSocket Manager                           ║
║                                                                              ║
║  Gestion temps réel des événements HITL et notifications.                    ║
║  RÈGLE: Checkpoints DOIVENT être envoyés en temps réel.                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from fastapi import WebSocket, WebSocketDisconnect
from typing import Dict, Set, Optional
from datetime import datetime
from uuid import uuid4
import asyncio
import json
import logging

logger = logging.getLogger("chenu.websocket")


class ConnectionManager:
    """
    Gestionnaire de connexions WebSocket.
    
    Gère:
    - Connexions par user_id
    - Broadcast d'événements
    - Reconnexion automatique
    """
    
    def __init__(self):
        # user_id -> Set[WebSocket]
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        # Pour tracking
        self.connection_count = 0
        self.message_count = 0
    
    async def connect(self, websocket: WebSocket, user_id: str) -> bool:
        """
        Connecte un client WebSocket.
        
        Args:
            websocket: Connection WebSocket
            user_id: ID utilisateur
            
        Returns:
            True si connexion réussie
        """
        try:
            await websocket.accept()
            
            if user_id not in self.active_connections:
                self.active_connections[user_id] = set()
            
            self.active_connections[user_id].add(websocket)
            self.connection_count += 1
            
            logger.info(f"WS Connected: user={user_id}, total={self.connection_count}")
            
            # Envoyer confirmation
            await self.send_to_user(user_id, {
                "type": "connection.established",
                "user_id": user_id,
                "timestamp": datetime.utcnow().isoformat(),
            })
            
            return True
            
        except Exception as e:
            logger.error(f"WS Connection error: {e}")
            return False
    
    async def disconnect(self, websocket: WebSocket, user_id: str):
        """Déconnecte un client."""
        if user_id in self.active_connections:
            self.active_connections[user_id].discard(websocket)
            
            # Cleanup si plus de connexions
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]
            
            self.connection_count -= 1
            logger.info(f"WS Disconnected: user={user_id}, total={self.connection_count}")
    
    async def send_to_user(self, user_id: str, event: dict) -> int:
        """
        Envoie un événement à un utilisateur spécifique.
        
        Args:
            user_id: ID utilisateur cible
            event: Événement à envoyer
            
        Returns:
            Nombre de connexions qui ont reçu l'événement
        """
        sent_count = 0
        
        if user_id not in self.active_connections:
            logger.warning(f"WS: No connections for user {user_id}")
            return 0
        
        # Add metadata
        event["_sent_at"] = datetime.utcnow().isoformat()
        event["_event_id"] = str(uuid4())
        
        failed_connections = []
        
        for ws in self.active_connections[user_id]:
            try:
                await ws.send_json(event)
                sent_count += 1
                self.message_count += 1
            except Exception as e:
                logger.error(f"WS Send error: {e}")
                failed_connections.append(ws)
        
        # Cleanup failed connections
        for ws in failed_connections:
            self.active_connections[user_id].discard(ws)
        
        return sent_count
    
    async def broadcast(self, event: dict, exclude_user: Optional[str] = None):
        """
        Broadcast un événement à tous les utilisateurs connectés.
        
        Args:
            event: Événement à broadcaster
            exclude_user: User à exclure (optionnel)
        """
        for user_id in self.active_connections:
            if user_id != exclude_user:
                await self.send_to_user(user_id, event)
    
    async def send_checkpoint(
        self, 
        user_id: str, 
        checkpoint_id: str,
        checkpoint_type: str,
        action: str,
        reason: str,
        details: Optional[dict] = None
    ):
        """
        Envoie un checkpoint HITL à l'utilisateur.
        
        CRITIQUE: Cette méthode est le cœur de la gouvernance temps réel.
        
        Args:
            user_id: Utilisateur concerné
            checkpoint_id: ID unique du checkpoint
            checkpoint_type: Type (governance, identity, cost, sensitive)
            action: Action demandée
            reason: Raison du checkpoint
            details: Détails additionnels
        """
        event = {
            "type": "checkpoint.pending",
            "checkpoint": {
                "id": checkpoint_id,
                "type": checkpoint_type,
                "action": action,
                "reason": reason,
                "details": details or {},
                "created_at": datetime.utcnow().isoformat(),
                "requires_approval": True,
            }
        }
        
        sent = await self.send_to_user(user_id, event)
        
        if sent == 0:
            logger.error(f"CRITICAL: Checkpoint not delivered to user {user_id}")
            # TODO: Fallback mechanism (email, push notification)
        
        logger.info(f"Checkpoint sent: {checkpoint_id} to {user_id}")
    
    def get_stats(self) -> dict:
        """Retourne statistiques WebSocket."""
        return {
            "active_users": len(self.active_connections),
            "total_connections": self.connection_count,
            "messages_sent": self.message_count,
            "connections_per_user": {
                user_id: len(conns) 
                for user_id, conns in self.active_connections.items()
            }
        }


# Singleton instance
manager = ConnectionManager()


def get_connection_manager() -> ConnectionManager:
    """Get the singleton ConnectionManager instance."""
    return manager
```

### Code events.py
```python
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    CHE·NU™ V71 — Event System                                ║
║                                                                              ║
║  Système d'événements pour communication temps réel.                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from enum import Enum
from typing import Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel
from uuid import uuid4


class EventType(str, Enum):
    """Types d'événements WebSocket."""
    
    # Connection
    CONNECTION_ESTABLISHED = "connection.established"
    CONNECTION_CLOSED = "connection.closed"
    
    # Checkpoint (HITL)
    CHECKPOINT_PENDING = "checkpoint.pending"
    CHECKPOINT_APPROVED = "checkpoint.approved"
    CHECKPOINT_REJECTED = "checkpoint.rejected"
    CHECKPOINT_EXPIRED = "checkpoint.expired"
    
    # Pipeline
    PIPELINE_STARTED = "pipeline.started"
    PIPELINE_PROGRESS = "pipeline.progress"
    PIPELINE_COMPLETE = "pipeline.complete"
    PIPELINE_FAILED = "pipeline.failed"
    
    # Agent
    AGENT_ACTION = "agent.action"
    AGENT_ERROR = "agent.error"
    
    # Data
    DATA_CREATED = "data.created"
    DATA_UPDATED = "data.updated"
    DATA_DELETED = "data.deleted"
    
    # Notification
    NOTIFICATION = "notification"
    ALERT = "alert"


class CheckpointType(str, Enum):
    """Types de checkpoints HITL."""
    GOVERNANCE = "governance"     # Rule violation potential
    IDENTITY = "identity"         # Cross-identity access
    COST = "cost"                 # Budget threshold
    SENSITIVE = "sensitive"       # Sensitive data access
    EXTERNAL = "external"         # External communication
    DESTRUCTIVE = "destructive"   # Delete/modify critical


class Event(BaseModel):
    """Modèle d'événement WebSocket."""
    
    id: str = None
    type: EventType
    user_id: str
    payload: Dict[str, Any] = {}
    timestamp: datetime = None
    
    def __init__(self, **data):
        if "id" not in data or data["id"] is None:
            data["id"] = str(uuid4())
        if "timestamp" not in data or data["timestamp"] is None:
            data["timestamp"] = datetime.utcnow()
        super().__init__(**data)
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "type": self.type.value,
            "user_id": self.user_id,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
        }


class CheckpointEvent(Event):
    """Événement spécifique pour checkpoint HITL."""
    
    checkpoint_id: str
    checkpoint_type: CheckpointType
    action: str
    reason: str
    details: Optional[Dict[str, Any]] = None
    requires_approval: bool = True
    
    def __init__(self, **data):
        data["type"] = EventType.CHECKPOINT_PENDING
        super().__init__(**data)
        self.payload = {
            "checkpoint": {
                "id": self.checkpoint_id,
                "type": self.checkpoint_type.value,
                "action": self.action,
                "reason": self.reason,
                "details": self.details or {},
                "requires_approval": self.requires_approval,
            }
        }


# Event factory functions
def create_checkpoint_event(
    user_id: str,
    checkpoint_type: CheckpointType,
    action: str,
    reason: str,
    details: Optional[dict] = None
) -> CheckpointEvent:
    """Crée un événement checkpoint."""
    return CheckpointEvent(
        checkpoint_id=str(uuid4()),
        user_id=user_id,
        checkpoint_type=checkpoint_type,
        action=action,
        reason=reason,
        details=details,
    )


def create_pipeline_event(
    user_id: str,
    pipeline_id: str,
    status: str,
    progress: Optional[float] = None,
    result: Optional[dict] = None
) -> Event:
    """Crée un événement pipeline."""
    event_type = {
        "started": EventType.PIPELINE_STARTED,
        "progress": EventType.PIPELINE_PROGRESS,
        "complete": EventType.PIPELINE_COMPLETE,
        "failed": EventType.PIPELINE_FAILED,
    }.get(status, EventType.PIPELINE_PROGRESS)
    
    return Event(
        type=event_type,
        user_id=user_id,
        payload={
            "pipeline_id": pipeline_id,
            "status": status,
            "progress": progress,
            "result": result,
        }
    )
```

### Code ws_routes.py
```python
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    CHE·NU™ V71 — WebSocket Routes                            ║
║                                                                              ║
║  Endpoints WebSocket pour connexion temps réel.                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from fastapi.responses import JSONResponse
import logging

from .websocket import get_connection_manager, ConnectionManager
from ..core.events import EventType

logger = logging.getLogger("chenu.ws.routes")

router = APIRouter(prefix="/ws", tags=["WebSocket"])


@router.websocket("/{user_id}")
async def websocket_endpoint(
    websocket: WebSocket,
    user_id: str,
    token: str = Query(None),  # Auth token
):
    """
    WebSocket endpoint pour connexion temps réel.
    
    Usage:
        ws://host/api/v2/ws/{user_id}?token=xxx
    
    Events reçus:
        - checkpoint.pending: Checkpoint HITL nécessite approbation
        - checkpoint.approved/rejected: Résultat checkpoint
        - pipeline.*: Progression Nova pipeline
        - data.*: Mises à jour données
        - notification: Notification générale
    """
    manager = get_connection_manager()
    
    # TODO: Validate token
    # if not validate_token(token, user_id):
    #     await websocket.close(code=4001, reason="Unauthorized")
    #     return
    
    connected = await manager.connect(websocket, user_id)
    
    if not connected:
        return
    
    try:
        while True:
            # Recevoir messages du client
            data = await websocket.receive_json()
            
            # Traiter messages client
            await handle_client_message(manager, user_id, data)
            
    except WebSocketDisconnect:
        await manager.disconnect(websocket, user_id)
        logger.info(f"WS Disconnected: {user_id}")
    except Exception as e:
        logger.error(f"WS Error: {e}")
        await manager.disconnect(websocket, user_id)


async def handle_client_message(
    manager: ConnectionManager, 
    user_id: str, 
    data: dict
):
    """
    Traite les messages envoyés par le client.
    
    Messages supportés:
        - checkpoint.approve: Approuve un checkpoint
        - checkpoint.reject: Rejette un checkpoint
        - ping: Keep-alive
    """
    msg_type = data.get("type")
    
    if msg_type == "ping":
        await manager.send_to_user(user_id, {"type": "pong"})
    
    elif msg_type == "checkpoint.approve":
        checkpoint_id = data.get("checkpoint_id")
        # TODO: Process approval
        await manager.send_to_user(user_id, {
            "type": "checkpoint.approved",
            "checkpoint_id": checkpoint_id,
        })
    
    elif msg_type == "checkpoint.reject":
        checkpoint_id = data.get("checkpoint_id")
        reason = data.get("reason", "")
        # TODO: Process rejection
        await manager.send_to_user(user_id, {
            "type": "checkpoint.rejected",
            "checkpoint_id": checkpoint_id,
            "reason": reason,
        })
    
    else:
        logger.warning(f"Unknown message type: {msg_type}")


@router.get("/stats")
async def websocket_stats():
    """Statistiques WebSocket."""
    manager = get_connection_manager()
    return manager.get_stats()


@router.post("/test/{user_id}")
async def test_websocket(user_id: str, event_type: str = "notification"):
    """
    Endpoint de test pour envoyer un événement WebSocket.
    
    Pour debugging uniquement.
    """
    manager = get_connection_manager()
    
    sent = await manager.send_to_user(user_id, {
        "type": event_type,
        "message": "Test event from API",
    })
    
    return {"sent_to": sent, "user_id": user_id}
```

### Tâches Sprint 1
- [ ] Créer ConnectionManager (websocket.py)
- [ ] Créer Event system (events.py)
- [ ] Créer WS routes (ws_routes.py)
- [ ] Intégrer WS dans main.py
- [ ] Connecter checkpoints existants au WS
- [ ] Tester connexion/déconnexion
- [ ] Documenter specs pour Agent Alpha

### Specs pour Agent Alpha (Jour 3)
```typescript
// Document à envoyer à Agent Alpha

interface WSEventTypes {
  // Connection
  "connection.established": { user_id: string };
  "connection.closed": { reason?: string };
  
  // Checkpoint (HITL) - CRITICAL
  "checkpoint.pending": {
    checkpoint: {
      id: string;
      type: "governance" | "identity" | "cost" | "sensitive";
      action: string;
      reason: string;
      details?: Record<string, any>;
      requires_approval: true;
    }
  };
  "checkpoint.approved": { checkpoint_id: string };
  "checkpoint.rejected": { checkpoint_id: string; reason?: string };
  
  // Pipeline
  "pipeline.started": { pipeline_id: string };
  "pipeline.progress": { pipeline_id: string; progress: number };
  "pipeline.complete": { pipeline_id: string; result: any };
  "pipeline.failed": { pipeline_id: string; error: string };
  
  // Data
  "data.created": { entity: string; id: string };
  "data.updated": { entity: string; id: string };
  "data.deleted": { entity: string; id: string };
  
  // Notification
  "notification": { message: string; level: "info" | "warning" | "error" };
}

// Connection URL
const WS_URL = "ws://host/api/v2/ws/{user_id}?token={token}";

// Messages client peut envoyer
interface ClientMessages {
  "ping": {};
  "checkpoint.approve": { checkpoint_id: string };
  "checkpoint.reject": { checkpoint_id: string; reason?: string };
}
```

---

## SPRINT 2 (Jours 4-7): Tests & Qualité

### Objectif
Atteindre 70%+ test coverage

### Structure tests
```
tests/
├── conftest.py                       # Fixtures globales
├── test_api_v2/
│   ├── test_root.py                  # Tests / et /health
│   ├── test_verticals.py             # Tests /verticals
│   ├── test_engines.py               # Tests /engines
│   ├── test_modules.py               # Tests /modules
│   └── test_governance.py            # Tests /governance
├── test_websocket/
│   ├── test_connection.py            # Tests connexion WS
│   └── test_events.py                # Tests événements
├── test_verticals/
│   ├── test_business_crm.py          # 19 endpoints
│   ├── test_creative_studio.py       # 46 endpoints
│   ├── test_personal.py              # 23 endpoints
│   ├── test_projects.py              # 42 endpoints
│   ├── test_team_collab.py           # 44 endpoints
│   ├── test_real_estate.py           # 22 endpoints
│   ├── test_marketing.py             # 46 endpoints
│   ├── test_social.py                # 45 endpoints
│   ├── test_compliance.py            # 37 endpoints
│   ├── test_finance.py               # 27 endpoints
│   ├── test_construction.py          # 36 endpoints
│   ├── test_entertainment.py         # 37 endpoints
│   ├── test_community.py             # 25 endpoints
│   ├── test_education.py             # 45 endpoints
│   └── test_hr.py                    # 53 endpoints
└── test_governance/
    ├── test_hitl.py                  # Tests HITL
    └── test_checkpoints.py           # Tests checkpoints
```

### Code conftest.py
```python
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    CHE·NU™ V71 — Test Configuration                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import pytest
from fastapi.testclient import TestClient
from httpx import AsyncClient
import asyncio

from backend.main import app


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests."""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def client():
    """Synchronous test client."""
    return TestClient(app)


@pytest.fixture
async def async_client():
    """Asynchronous test client."""
    async with AsyncClient(app=app, base_url="http://test") as ac:
        yield ac


@pytest.fixture
def auth_headers():
    """Authentication headers."""
    return {
        "Authorization": "Bearer test_token_123",
        "X-User-ID": "test_user_001",
    }


@pytest.fixture
def sample_contact():
    """Sample contact data."""
    return {
        "first_name": "John",
        "last_name": "Doe",
        "email": "john.doe@example.com",
        "phone": "+1234567890",
        "title": "CEO",
        "company_name": "Acme Corporation",
        "lead_source": "website",
    }


@pytest.fixture
def sample_company():
    """Sample company data."""
    return {
        "name": "Acme Corporation",
        "domain": "acme.com",
        "industry": "Technology",
        "size": "51-200",
        "annual_revenue": 10000000,
        "website": "https://acme.com",
    }


@pytest.fixture
def sample_deal():
    """Sample deal data."""
    return {
        "name": "Enterprise License Deal",
        "amount": 50000,
        "stage": "proposal",
        "probability": 60,
    }


@pytest.fixture
def sample_checkpoint():
    """Sample checkpoint data."""
    return {
        "type": "governance",
        "action": "send_email",
        "reason": "Bulk email requires approval",
        "details": {
            "recipient_count": 100,
            "template": "marketing_newsletter",
        }
    }
```

### Code test_verticals.py
```python
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    CHE·NU™ V71 — Test Verticals API                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import pytest
from fastapi.testclient import TestClient


class TestVerticalsAPI:
    """Tests pour /api/v2/verticals."""
    
    def test_list_verticals(self, client: TestClient):
        """Test listing all verticals."""
        response = client.get("/api/v2/verticals")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 15
        
        verticals = data["data"]["verticals"]
        assert len(verticals) == 15
        
        # Verify all expected verticals present
        vertical_ids = {v["id"] for v in verticals}
        expected = {
            "BUSINESS_CRM", "CREATIVE_STUDIO", "PERSONAL", "PROJECT_MGMT",
            "TEAM_COLLAB", "REAL_ESTATE", "MARKETING", "SOCIAL",
            "COMPLIANCE", "FINANCE", "CONSTRUCTION", "ENTERTAINMENT",
            "COMMUNITY", "EDUCATION", "HR"
        }
        assert vertical_ids == expected
    
    def test_get_single_vertical(self, client: TestClient):
        """Test getting a single vertical."""
        response = client.get("/api/v2/verticals/BUSINESS_CRM")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["id"] == "BUSINESS_CRM"
        assert "endpoints" in data["data"]
        assert "coverage" in data["data"]
    
    def test_get_nonexistent_vertical(self, client: TestClient):
        """Test getting a vertical that doesn't exist."""
        response = client.get("/api/v2/verticals/NONEXISTENT")
        
        assert response.status_code == 404
    
    def test_verticals_have_required_fields(self, client: TestClient):
        """Test that verticals have all required fields."""
        response = client.get("/api/v2/verticals")
        data = response.json()
        
        for vertical in data["data"]["verticals"]:
            assert "id" in vertical
            assert "name" in vertical
            assert "description" in vertical
            assert "status" in vertical
            assert "endpoints" in vertical
            assert "coverage" in vertical
    
    def test_verticals_endpoints_count(self, client: TestClient):
        """Test that total endpoints match expected."""
        response = client.get("/api/v2/verticals")
        data = response.json()
        
        total_endpoints = sum(v["endpoints"] for v in data["data"]["verticals"])
        
        # Should be 517 total
        assert total_endpoints == 517


class TestEnginesAPI:
    """Tests pour /api/v2/engines."""
    
    def test_list_engines(self, client: TestClient):
        """Test listing all engines."""
        response = client.get("/api/v2/engines")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 9
    
    def test_get_single_engine(self, client: TestClient):
        """Test getting a single engine."""
        response = client.get("/api/v2/engines/workspace")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["id"] == "workspace"


class TestModulesAPI:
    """Tests pour /api/v2/modules."""
    
    def test_list_modules(self, client: TestClient):
        """Test listing all GP2 modules."""
        response = client.get("/api/v2/modules")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 14
    
    def test_modules_are_gp2(self, client: TestClient):
        """Test that modules are GP2 (26-39)."""
        response = client.get("/api/v2/modules")
        data = response.json()
        
        for module in data["data"]["modules"]:
            # Module IDs should be module_26 through module_39
            assert module["id"].startswith("module_")
            num = int(module["id"].split("_")[1])
            assert 26 <= num <= 39


class TestGovernanceAPI:
    """Tests pour /api/v2/governance."""
    
    def test_list_rules(self, client: TestClient):
        """Test listing R&D rules."""
        response = client.get("/api/v2/governance/rules")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 7
    
    def test_list_hitl_actions(self, client: TestClient):
        """Test listing HITL actions."""
        response = client.get("/api/v2/governance/hitl-actions")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 8
    
    def test_list_memory_laws(self, client: TestClient):
        """Test listing memory laws."""
        response = client.get("/api/v2/governance/memory-laws")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        assert data["data"]["count"] == 10


class TestStatsAPI:
    """Tests pour /api/v2/stats."""
    
    def test_get_stats(self, client: TestClient):
        """Test getting platform stats."""
        response = client.get("/api/v2/stats")
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["success"] is True
        stats = data["data"]
        
        assert stats["verticals"] == 15
        assert stats["engines"] == 9
        assert stats["modules"] == 14
        assert stats["total_endpoints"] == 517
```

### Tâches Sprint 2
- [ ] Créer conftest.py avec fixtures
- [ ] Tests API v2 (100% endpoints)
- [ ] Tests par vertical (au moins 1 test par endpoint)
- [ ] Tests WebSocket (connexion, events)
- [ ] Tests governance (HITL, checkpoints)
- [ ] Atteindre 70% coverage
- [ ] CI/CD pipeline pytest

---

## SPRINT 3 (Jours 8-10): Governance & Polish

### Objectif
Renforcer governance et finaliser production-ready

### Tâches

#### 1. Identity Middleware
```python
# backend/middleware/identity.py

from fastapi import Request, HTTPException
from typing import Optional
import logging

logger = logging.getLogger("chenu.identity")


async def identity_middleware(request: Request, call_next):
    """
    Middleware pour vérifier identity boundary.
    
    RÈGLE: Aucune action cross-identity sans checkpoint.
    """
    # Extract identity from request
    user_id = request.headers.get("X-User-ID")
    target_identity = request.headers.get("X-Target-Identity")
    
    if not user_id:
        # Anonymous access - limited endpoints only
        if request.url.path not in ["/", "/health", "/api/v2/"]:
            raise HTTPException(
                status_code=401,
                detail="Authentication required"
            )
    
    # Check cross-identity access
    if target_identity and target_identity != user_id:
        logger.warning(f"Cross-identity access: {user_id} -> {target_identity}")
        
        # TODO: Create checkpoint for approval
        raise HTTPException(
            status_code=403,
            detail="Cross-identity access requires checkpoint approval"
        )
    
    # Add to request state
    request.state.user_id = user_id
    request.state.identity = user_id
    
    response = await call_next(request)
    return response
```

#### 2. Structured Logging
```python
# backend/core/logging.py

import logging
import json
from datetime import datetime
from typing import Any


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }
        
        # Add extra fields
        if hasattr(record, "user_id"):
            log_data["user_id"] = record.user_id
        if hasattr(record, "request_id"):
            log_data["request_id"] = record.request_id
        if hasattr(record, "checkpoint_id"):
            log_data["checkpoint_id"] = record.checkpoint_id
        
        # Add exception info
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        return json.dumps(log_data)


def setup_logging():
    """Configure structured logging."""
    handler = logging.StreamHandler()
    handler.setFormatter(JSONFormatter())
    
    # Root logger
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    root.addHandler(handler)
    
    # CHE·NU specific loggers
    for name in ["chenu", "chenu.api", "chenu.websocket", "chenu.governance"]:
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
```

#### 3. Prometheus Metrics
```python
# backend/core/metrics.py

from prometheus_client import Counter, Histogram, Gauge, generate_latest
from fastapi import APIRouter

router = APIRouter(prefix="/metrics", tags=["Metrics"])

# Counters
http_requests_total = Counter(
    "chenu_http_requests_total",
    "Total HTTP requests",
    ["method", "endpoint", "status"]
)

checkpoint_total = Counter(
    "chenu_checkpoints_total",
    "Total checkpoints created",
    ["type", "status"]
)

# Histograms
request_duration = Histogram(
    "chenu_request_duration_seconds",
    "Request duration in seconds",
    ["endpoint"]
)

# Gauges
active_websockets = Gauge(
    "chenu_active_websockets",
    "Number of active WebSocket connections"
)

pending_checkpoints = Gauge(
    "chenu_pending_checkpoints",
    "Number of pending checkpoints awaiting approval"
)


@router.get("/")
async def metrics():
    """Prometheus metrics endpoint."""
    return generate_latest()
```

### Tâches Sprint 3
- [ ] Identity middleware sur tous endpoints
- [ ] Structured logging JSON
- [ ] Prometheus metrics
- [ ] OpenAPI documentation complète
- [ ] Validation Pydantic stricte
- [ ] Error handlers globaux
- [ ] Rate limiting

---

## COORDINATION AVEC AGENT ALPHA

### Jour 3: Envoyer specs WebSocket
Partager document TypeScript avec types d'événements

### Jour 7: Recevoir frontend pour tests E2E
- Tester endpoints avec vraies requêtes UI
- Vérifier WebSocket fonctionne avec CheckpointModal

### Jour 10: Intégration finale
- Tests E2E passent
- WebSocket stable
- Governance fonctionnelle

---

## LIVRABLES

```
À la fin de ta mission:

1. backend/api/v2/websocket.py       # WebSocket manager
2. backend/api/v2/ws_routes.py       # WS endpoints
3. backend/core/events.py            # Event system
4. backend/core/logging.py           # Structured logging
5. backend/core/metrics.py           # Prometheus
6. backend/middleware/identity.py    # Identity check
7. tests/                            # 70%+ coverage
8. BETA_COMPLETION_REPORT.md         # Rapport final
```

---

## RÈGLES ABSOLUES

```
1. GOUVERNANCE > EXÉCUTION
   - Tout endpoint sensible → checkpoint
   - HTTP 423 pour HITL blocking

2. IDENTITY ISOLATION
   - Cross-identity → TOUJOURS checkpoint
   - HTTP 403 si non autorisé

3. AUDIT TRAIL
   - TOUT est loggé (JSON)
   - request_id tracé

4. TESTS OBLIGATOIRES
   - Minimum 70% coverage
   - Pas de merge sans tests

5. DOCUMENTATION
   - OpenAPI à jour
   - Docstrings complets
```

---

## STACK TECHNIQUE

```
- Python 3.11+
- FastAPI 0.100+
- WebSocket (fastapi.websockets)
- Pydantic v2
- pytest + pytest-asyncio + pytest-cov
- prometheus_client
- structlog ou logging JSON
```

---

## QUESTION INITIALE

```
As-tu reçu le contexte complet?
Peux-tu confirmer:
1. Structure V71 accessible
2. 517 endpoints localisés
3. Checkpoints existants identifiés
4. Prêt à commencer Sprint 1?
```

---

**BONNE CHANCE AGENT BETA! 🔧**

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    "GOUVERNANCE > EXÉCUTION"                                 ║
║                                                                              ║
║                      Backend V71 → V71.1                                     ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```
