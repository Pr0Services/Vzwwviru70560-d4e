"""
CHE·NU™ V70 — API ROUTERS
=========================
All API routers for the CHE·NU system.

Based on: CHENU_API_SPECS_v29.md
"""

from .core import (
    identity_router,
    dataspace_router,
    thread_router,
    APIResponse,
    APIError,
)
from .engines import (
    workspace_router,
    oneclick_router,
    backstage_router,
)
from .memory_agents import (
    memory_router,
    governance_router,
    agent_router,
)
from .meeting_immobilier import (
    meeting_router,
    immobilier_router,
)

__all__ = [
    # Core
    "identity_router",
    "dataspace_router",
    "thread_router",
    "APIResponse",
    "APIError",
    # Engines
    "workspace_router",
    "oneclick_router",
    "backstage_router",
    # Memory & Agents
    "memory_router",
    "governance_router",
    "agent_router",
    # Meeting & Immobilier
    "meeting_router",
    "immobilier_router",
]
