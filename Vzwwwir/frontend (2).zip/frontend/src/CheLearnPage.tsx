import React from 'react';
export default function CheLearnPage() {
  return <div style={{ color: '#e8e4dc' }}><h1>CheLearn</h1></div>;
}
