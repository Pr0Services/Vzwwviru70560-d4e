"""
CHE·NU™ Query Optimizer — Database Query Optimization
======================================================

Query optimization utilities including:
- Query analysis and profiling
- Index recommendations
- Query plan caching
- N+1 query detection
- Batch loading utilities
- Query statistics

Author: CHE·NU Backend Team
Version: 1.0.0
"""

from typing import Optional, Dict, Any, List, Type, TypeVar, Generic, Callable, Set
from datetime import datetime, timedelta
from uuid import UUID
import time
import logging
import functools
import asyncio
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from contextlib import asynccontextmanager

from sqlalchemy import text, inspect, event
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Query, selectinload, joinedload, Session
from sqlalchemy.engine import Engine

logger = logging.getLogger(__name__)

T = TypeVar('T')


class QueryComplexity(str, Enum):
    """Query complexity levels."""
    SIMPLE = "simple"       # Single table, indexed lookup
    MODERATE = "moderate"   # Joins, filtered queries
    COMPLEX = "complex"     # Multiple joins, aggregations
    EXPENSIVE = "expensive" # Full scans, heavy aggregations


@dataclass
class QueryProfile:
    """Profile of a database query."""
    query: str
    params: Dict[str, Any]
    execution_time_ms: float
    rows_affected: int
    complexity: QueryComplexity
    uses_index: bool
    timestamp: datetime = field(default_factory=datetime.utcnow)
    stack_trace: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query[:500],  # Truncate for safety
            "execution_time_ms": round(self.execution_time_ms, 2),
            "rows_affected": self.rows_affected,
            "complexity": self.complexity.value,
            "uses_index": self.uses_index,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class QueryStats:
    """Aggregated query statistics."""
    total_queries: int = 0
    total_time_ms: float = 0.0
    slow_queries: int = 0
    n_plus_1_detected: int = 0
    full_scans: int = 0
    queries_by_complexity: Dict[str, int] = field(default_factory=dict)
    slowest_queries: List[QueryProfile] = field(default_factory=list)
    most_frequent: Dict[str, int] = field(default_factory=dict)
    
    def record(self, profile: QueryProfile, slow_threshold_ms: float = 100) -> None:
        """Record a query profile."""
        self.total_queries += 1
        self.total_time_ms += profile.execution_time_ms
        
        # Track complexity
        complexity = profile.complexity.value
        self.queries_by_complexity[complexity] = (
            self.queries_by_complexity.get(complexity, 0) + 1
        )
        
        # Track slow queries
        if profile.execution_time_ms > slow_threshold_ms:
            self.slow_queries += 1
            self.slowest_queries.append(profile)
            self.slowest_queries.sort(key=lambda p: -p.execution_time_ms)
            self.slowest_queries = self.slowest_queries[:10]  # Keep top 10
        
        # Track full scans
        if not profile.uses_index:
            self.full_scans += 1
        
        # Track frequency
        query_pattern = self._normalize_query(profile.query)
        self.most_frequent[query_pattern] = (
            self.most_frequent.get(query_pattern, 0) + 1
        )
    
    def _normalize_query(self, query: str) -> str:
        """Normalize query for pattern matching."""
        # Replace values with placeholders
        import re
        normalized = re.sub(r"'[^']*'", "'?'", query)
        normalized = re.sub(r"\b\d+\b", "?", normalized)
        normalized = re.sub(r"\s+", " ", normalized)
        return normalized[:200]  # Truncate
    
    @property
    def avg_query_time_ms(self) -> float:
        if self.total_queries == 0:
            return 0.0
        return self.total_time_ms / self.total_queries
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_queries": self.total_queries,
            "total_time_ms": round(self.total_time_ms, 2),
            "avg_query_time_ms": round(self.avg_query_time_ms, 2),
            "slow_queries": self.slow_queries,
            "n_plus_1_detected": self.n_plus_1_detected,
            "full_scans": self.full_scans,
            "queries_by_complexity": self.queries_by_complexity,
            "slowest_queries": [q.to_dict() for q in self.slowest_queries[:5]],
            "most_frequent_patterns": dict(
                sorted(
                    self.most_frequent.items(),
                    key=lambda x: -x[1]
                )[:10]
            ),
        }


class NPlusOneDetector:
    """
    Detects N+1 query patterns.
    
    N+1 occurs when:
    1. A query fetches N records
    2. Then N additional queries fetch related data
    """
    
    def __init__(self, threshold: int = 5, window_ms: float = 1000):
        """
        Initialize detector.
        
        Args:
            threshold: Number of similar queries to trigger detection
            window_ms: Time window in milliseconds
        """
        self.threshold = threshold
        self.window_ms = window_ms
        self._query_window: List[tuple] = []  # (timestamp, normalized_query)
        self._detected: List[Dict[str, Any]] = []
    
    def record(self, query: str) -> Optional[Dict[str, Any]]:
        """
        Record a query and check for N+1 pattern.
        
        Returns detection info if N+1 detected, None otherwise.
        """
        now = time.time() * 1000
        normalized = self._normalize(query)
        
        # Clean old entries
        self._query_window = [
            (ts, q) for ts, q in self._query_window
            if now - ts < self.window_ms
        ]
        
        # Add new query
        self._query_window.append((now, normalized))
        
        # Count similar queries
        count = sum(1 for _, q in self._query_window if q == normalized)
        
        if count >= self.threshold:
            detection = {
                "pattern": normalized,
                "count": count,
                "window_ms": self.window_ms,
                "detected_at": datetime.utcnow().isoformat(),
            }
            self._detected.append(detection)
            logger.warning(
                f"N+1 query pattern detected: {count} similar queries in {self.window_ms}ms"
            )
            return detection
        
        return None
    
    def _normalize(self, query: str) -> str:
        """Normalize query for comparison."""
        import re
        # Remove specific values
        normalized = re.sub(r"'[^']*'", "'?'", query)
        normalized = re.sub(r"\b[0-9a-f-]{36}\b", "?uuid?", normalized)
        normalized = re.sub(r"\b\d+\b", "?", normalized)
        normalized = re.sub(r"\s+", " ", normalized).strip()
        return normalized[:300]
    
    def get_detections(self) -> List[Dict[str, Any]]:
        """Get all detections."""
        return self._detected[-20:]  # Last 20
    
    def clear(self) -> None:
        """Clear detection history."""
        self._query_window.clear()
        self._detected.clear()


class QueryProfiler:
    """
    Profiles and analyzes database queries.
    """
    
    def __init__(
        self,
        slow_threshold_ms: float = 100,
        enable_n_plus_1: bool = True,
        enable_explain: bool = False,
    ):
        """
        Initialize profiler.
        
        Args:
            slow_threshold_ms: Threshold for slow query detection
            enable_n_plus_1: Enable N+1 detection
            enable_explain: Run EXPLAIN on queries (expensive)
        """
        self.slow_threshold_ms = slow_threshold_ms
        self.enable_n_plus_1 = enable_n_plus_1
        self.enable_explain = enable_explain
        self.stats = QueryStats()
        self.n_plus_1 = NPlusOneDetector() if enable_n_plus_1 else None
        self._enabled = True
    
    def enable(self) -> None:
        """Enable profiling."""
        self._enabled = True
    
    def disable(self) -> None:
        """Disable profiling."""
        self._enabled = False
    
    @asynccontextmanager
    async def profile_query(
        self,
        session: AsyncSession,
        query: str,
        params: Optional[Dict[str, Any]] = None,
    ):
        """
        Context manager for profiling a query.
        
        Usage:
            async with profiler.profile_query(session, "SELECT ...") as profile:
                result = await session.execute(...)
        """
        if not self._enabled:
            yield None
            return
        
        start_time = time.time()
        profile = None
        
        try:
            yield profile
        finally:
            execution_time = (time.time() - start_time) * 1000
            
            # Analyze query
            complexity = self._analyze_complexity(query)
            uses_index = await self._check_index_usage(session, query) if self.enable_explain else True
            
            profile = QueryProfile(
                query=query,
                params=params or {},
                execution_time_ms=execution_time,
                rows_affected=0,  # Would need to track from result
                complexity=complexity,
                uses_index=uses_index,
            )
            
            # Record stats
            self.stats.record(profile, self.slow_threshold_ms)
            
            # Check N+1
            if self.n_plus_1:
                detection = self.n_plus_1.record(query)
                if detection:
                    self.stats.n_plus_1_detected += 1
            
            # Log slow queries
            if execution_time > self.slow_threshold_ms:
                logger.warning(
                    f"Slow query ({execution_time:.2f}ms): {query[:200]}..."
                )
    
    def _analyze_complexity(self, query: str) -> QueryComplexity:
        """Analyze query complexity."""
        query_upper = query.upper()
        
        # Count operations
        join_count = query_upper.count(" JOIN ")
        has_aggregation = any(
            op in query_upper 
            for op in ["GROUP BY", "HAVING", "COUNT(", "SUM(", "AVG("]
        )
        has_subquery = "SELECT" in query_upper[10:]  # After initial SELECT
        has_order = "ORDER BY" in query_upper
        has_like = " LIKE " in query_upper
        
        # Determine complexity
        if has_subquery or join_count > 3 or (has_aggregation and join_count > 1):
            return QueryComplexity.EXPENSIVE
        elif join_count > 1 or has_aggregation:
            return QueryComplexity.COMPLEX
        elif join_count > 0 or has_order or has_like:
            return QueryComplexity.MODERATE
        else:
            return QueryComplexity.SIMPLE
    
    async def _check_index_usage(
        self,
        session: AsyncSession,
        query: str,
    ) -> bool:
        """Check if query uses indexes (via EXPLAIN)."""
        if not query.strip().upper().startswith("SELECT"):
            return True
        
        try:
            result = await session.execute(text(f"EXPLAIN {query}"))
            plan = result.fetchall()
            plan_text = " ".join(str(row) for row in plan)
            
            # Check for sequential scan (bad)
            if "Seq Scan" in plan_text and "Index" not in plan_text:
                return False
            return True
            
        except Exception as e:
            logger.debug(f"EXPLAIN failed: {e}")
            return True  # Assume good if EXPLAIN fails
    
    def get_stats(self) -> Dict[str, Any]:
        """Get profiling statistics."""
        result = self.stats.to_dict()
        if self.n_plus_1:
            result["n_plus_1_detections"] = self.n_plus_1.get_detections()
        return result
    
    def reset(self) -> None:
        """Reset all statistics."""
        self.stats = QueryStats()
        if self.n_plus_1:
            self.n_plus_1.clear()


# Singleton profiler
query_profiler = QueryProfiler()


# ==========================================================================
# Batch Loading Utilities
# ==========================================================================

class BatchLoader(Generic[T]):
    """
    Batches and deduplicates data loading to prevent N+1 queries.
    
    Usage:
        loader = BatchLoader(
            load_fn=lambda ids: db.query(User).filter(User.id.in_(ids)).all(),
            key_fn=lambda user: user.id
        )
        
        # These will be batched
        user1 = await loader.load(user_id_1)
        user2 = await loader.load(user_id_2)
        
        # Execute batch
        await loader.flush()
    """
    
    def __init__(
        self,
        load_fn: Callable[[List[Any]], List[T]],
        key_fn: Callable[[T], Any],
        max_batch_size: int = 100,
    ):
        """
        Initialize batch loader.
        
        Args:
            load_fn: Function to load items by list of keys
            key_fn: Function to extract key from loaded item
            max_batch_size: Maximum items per batch
        """
        self.load_fn = load_fn
        self.key_fn = key_fn
        self.max_batch_size = max_batch_size
        self._pending: Set[Any] = set()
        self._cache: Dict[Any, T] = {}
        self._futures: Dict[Any, asyncio.Future] = {}
    
    async def load(self, key: Any) -> T:
        """
        Load a single item (will be batched).
        
        Args:
            key: Key to load
            
        Returns:
            Loaded item
        """
        # Check cache
        if key in self._cache:
            return self._cache[key]
        
        # Check if already pending
        if key in self._futures:
            return await self._futures[key]
        
        # Create future
        future = asyncio.get_event_loop().create_future()
        self._futures[key] = future
        self._pending.add(key)
        
        # Auto-flush if batch is full
        if len(self._pending) >= self.max_batch_size:
            await self.flush()
        
        return await future
    
    async def load_many(self, keys: List[Any]) -> List[T]:
        """Load multiple items."""
        return await asyncio.gather(*[self.load(k) for k in keys])
    
    async def flush(self) -> None:
        """Execute pending batch load."""
        if not self._pending:
            return
        
        keys = list(self._pending)
        self._pending.clear()
        
        try:
            # Load items
            if asyncio.iscoroutinefunction(self.load_fn):
                items = await self.load_fn(keys)
            else:
                items = self.load_fn(keys)
            
            # Index by key
            items_by_key = {self.key_fn(item): item for item in items}
            
            # Resolve futures
            for key in keys:
                future = self._futures.pop(key, None)
                if future and not future.done():
                    item = items_by_key.get(key)
                    if item:
                        self._cache[key] = item
                        future.set_result(item)
                    else:
                        future.set_exception(KeyError(f"Item not found: {key}"))
                        
        except Exception as e:
            # Reject all pending futures
            for key in keys:
                future = self._futures.pop(key, None)
                if future and not future.done():
                    future.set_exception(e)
    
    def clear_cache(self) -> None:
        """Clear the item cache."""
        self._cache.clear()
    
    def prime(self, key: Any, item: T) -> None:
        """Prime the cache with an item."""
        self._cache[key] = item


# ==========================================================================
# Query Optimization Decorators
# ==========================================================================

def optimized_query(
    eager_load: Optional[List[str]] = None,
    use_cache: bool = False,
    cache_ttl: int = 300,
):
    """
    Decorator for optimized database queries.
    
    Args:
        eager_load: Relationships to eagerly load
        use_cache: Enable result caching
        cache_ttl: Cache TTL in seconds
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            from ..core.cache import cache_service, CacheKeyBuilder
            
            # Build cache key if caching enabled
            cache_key = None
            if use_cache:
                cache_key = CacheKeyBuilder.build(
                    "query",
                    func.__name__,
                    *[str(a) for a in args[1:]],  # Skip self
                    **kwargs
                )
                
                # Try cache
                cached = await cache_service.get(cache_key)
                if cached is not None:
                    return cached
            
            # Execute query
            result = await func(*args, **kwargs)
            
            # Cache result
            if use_cache and cache_key and result is not None:
                await cache_service.set(cache_key, result, ttl=cache_ttl)
            
            return result
        
        return wrapper
    return decorator


def with_eager_loading(*relationships: str):
    """
    Decorator to add eager loading to a query function.
    
    Usage:
        @with_eager_loading("sphere", "events")
        async def get_thread(session, thread_id):
            return await session.get(Thread, thread_id)
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            # Add options to kwargs
            options = kwargs.get("options", [])
            for rel in relationships:
                options.append(selectinload(rel))
            kwargs["options"] = options
            
            return await func(*args, **kwargs)
        
        return wrapper
    return decorator


# ==========================================================================
# Index Recommendations
# ==========================================================================

@dataclass
class IndexRecommendation:
    """Recommended database index."""
    table: str
    columns: List[str]
    reason: str
    estimated_improvement: str
    create_statement: str
    priority: str  # high, medium, low


class IndexAnalyzer:
    """Analyzes queries and recommends indexes."""
    
    COMMON_PATTERNS = {
        # Pattern -> (columns, reason)
        r"WHERE\s+(\w+)\s*=": ("exact_match", "Equality lookup"),
        r"WHERE\s+(\w+)\s+IN\s*\(": ("in_list", "IN clause lookup"),
        r"ORDER BY\s+(\w+)": ("sort", "Sorting optimization"),
        r"WHERE\s+(\w+)\s+LIKE\s*'[^%]": ("prefix_like", "Prefix LIKE search"),
        r"JOIN\s+\w+\s+ON\s+\w+\.(\w+)\s*=": ("join", "Join optimization"),
    }
    
    def __init__(self):
        self._query_patterns: Dict[str, int] = defaultdict(int)
        self._column_usage: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
    
    def analyze(self, query: str) -> None:
        """Analyze a query for index opportunities."""
        import re
        
        # Extract table name (simplified)
        table_match = re.search(r"FROM\s+(\w+)", query, re.IGNORECASE)
        if not table_match:
            return
        
        table = table_match.group(1)
        
        for pattern, (usage_type, reason) in self.COMMON_PATTERNS.items():
            matches = re.finditer(pattern, query, re.IGNORECASE)
            for match in matches:
                column = match.group(1)
                self._column_usage[table][column] += 1
    
    def get_recommendations(
        self,
        min_usage: int = 5,
    ) -> List[IndexRecommendation]:
        """
        Get index recommendations based on query analysis.
        
        Args:
            min_usage: Minimum column usage to recommend index
        """
        recommendations = []
        
        for table, columns in self._column_usage.items():
            for column, usage in columns.items():
                if usage >= min_usage:
                    rec = IndexRecommendation(
                        table=table,
                        columns=[column],
                        reason=f"Column used in {usage} queries",
                        estimated_improvement="10-50% query speedup",
                        create_statement=f"CREATE INDEX idx_{table}_{column} ON {table}({column})",
                        priority="high" if usage > 20 else "medium",
                    )
                    recommendations.append(rec)
        
        return sorted(recommendations, key=lambda r: -self._column_usage[r.table][r.columns[0]])
    
    def clear(self) -> None:
        """Clear analysis data."""
        self._query_patterns.clear()
        self._column_usage.clear()


# Singleton
index_analyzer = IndexAnalyzer()


# ==========================================================================
# SQLAlchemy Event Listeners
# ==========================================================================

def setup_query_profiling(engine: Engine) -> None:
    """
    Set up SQLAlchemy event listeners for query profiling.
    
    Call this with your database engine to enable automatic profiling.
    """
    
    @event.listens_for(engine, "before_cursor_execute")
    def receive_before_cursor_execute(
        conn, cursor, statement, parameters, context, executemany
    ):
        conn.info.setdefault("query_start_time", []).append(time.time())
    
    @event.listens_for(engine, "after_cursor_execute")
    def receive_after_cursor_execute(
        conn, cursor, statement, parameters, context, executemany
    ):
        start_time = conn.info.get("query_start_time", []).pop()
        execution_time = (time.time() - start_time) * 1000
        
        # Record in profiler
        complexity = query_profiler._analyze_complexity(statement)
        profile = QueryProfile(
            query=statement,
            params=dict(parameters) if parameters else {},
            execution_time_ms=execution_time,
            rows_affected=cursor.rowcount or 0,
            complexity=complexity,
            uses_index=True,  # Would need EXPLAIN to determine
        )
        
        query_profiler.stats.record(profile, query_profiler.slow_threshold_ms)
        
        # Analyze for indexes
        index_analyzer.analyze(statement)
        
        # Check N+1
        if query_profiler.n_plus_1:
            detection = query_profiler.n_plus_1.record(statement)
            if detection:
                query_profiler.stats.n_plus_1_detected += 1


# ==========================================================================
# Exports
# ==========================================================================

__all__ = [
    "QueryProfiler",
    "QueryProfile",
    "QueryStats",
    "QueryComplexity",
    "NPlusOneDetector",
    "BatchLoader",
    "IndexAnalyzer",
    "IndexRecommendation",
    "query_profiler",
    "index_analyzer",
    "optimized_query",
    "with_eager_loading",
    "setup_query_profiling",
]
