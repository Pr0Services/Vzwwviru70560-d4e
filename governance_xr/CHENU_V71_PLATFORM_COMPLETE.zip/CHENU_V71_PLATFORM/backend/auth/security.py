"""
CHE·NU™ V70 — AUTHENTICATION & AUTHORIZATION
=============================================
Security layer for GP2 system.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import hashlib
import hmac
import base64
import json
import logging

logger = logging.getLogger("chenu.auth")


class Permission(str, Enum):
    """System permissions."""
    # Read permissions
    READ_DECISIONS = "read:decisions"
    READ_SIMULATIONS = "read:simulations"
    READ_XR_SCENES = "read:xr_scenes"
    READ_AUDIT = "read:audit"
    
    # Write permissions (governed)
    SUBMIT_DECISIONS = "submit:decisions"
    APPROVE_HITL = "approve:hitl"
    TRIGGER_SIMULATIONS = "trigger:simulations"
    
    # Admin permissions
    ADMIN_USERS = "admin:users"
    ADMIN_SYSTEM = "admin:system"
    ADMIN_GOVERNANCE = "admin:governance"
    
    # Special
    BYPASS_RATE_LIMIT = "bypass:rate_limit"


class Role(str, Enum):
    """User roles with predefined permissions."""
    VIEWER = "viewer"
    OPERATOR = "operator"
    APPROVER = "approver"
    ADMIN = "admin"
    SYSTEM = "system"


# Role -> Permissions mapping
ROLE_PERMISSIONS: dict[Role, list[Permission]] = {
    Role.VIEWER: [
        Permission.READ_DECISIONS,
        Permission.READ_SIMULATIONS,
        Permission.READ_XR_SCENES,
    ],
    Role.OPERATOR: [
        Permission.READ_DECISIONS,
        Permission.READ_SIMULATIONS,
        Permission.READ_XR_SCENES,
        Permission.SUBMIT_DECISIONS,
        Permission.TRIGGER_SIMULATIONS,
    ],
    Role.APPROVER: [
        Permission.READ_DECISIONS,
        Permission.READ_SIMULATIONS,
        Permission.READ_XR_SCENES,
        Permission.READ_AUDIT,
        Permission.SUBMIT_DECISIONS,
        Permission.TRIGGER_SIMULATIONS,
        Permission.APPROVE_HITL,
    ],
    Role.ADMIN: [
        Permission.READ_DECISIONS,
        Permission.READ_SIMULATIONS,
        Permission.READ_XR_SCENES,
        Permission.READ_AUDIT,
        Permission.SUBMIT_DECISIONS,
        Permission.TRIGGER_SIMULATIONS,
        Permission.APPROVE_HITL,
        Permission.ADMIN_USERS,
        Permission.ADMIN_SYSTEM,
    ],
    Role.SYSTEM: [
        # System has all permissions
        *list(Permission),
    ],
}


@dataclass
class User:
    """User entity."""
    user_id: str = field(default_factory=lambda: f"USER_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Identity
    username: str = ""
    email: str = ""
    
    # Auth
    password_hash: str = ""
    
    # Roles & Permissions
    roles: list[Role] = field(default_factory=lambda: [Role.VIEWER])
    extra_permissions: list[Permission] = field(default_factory=list)
    
    # Status
    is_active: bool = True
    is_verified: bool = False
    
    # Metadata
    metadata: dict = field(default_factory=dict)
    
    @property
    def permissions(self) -> set[Permission]:
        """Get all user permissions."""
        perms = set()
        for role in self.roles:
            perms.update(ROLE_PERMISSIONS.get(role, []))
        perms.update(self.extra_permissions)
        return perms
    
    def has_permission(self, permission: Permission) -> bool:
        """Check if user has permission."""
        return permission in self.permissions
    
    def has_any_permission(self, permissions: list[Permission]) -> bool:
        """Check if user has any of the permissions."""
        return bool(self.permissions & set(permissions))
    
    def has_all_permissions(self, permissions: list[Permission]) -> bool:
        """Check if user has all permissions."""
        return set(permissions) <= self.permissions


@dataclass
class Token:
    """Authentication token."""
    token_id: str = field(default_factory=lambda: f"TOK_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Token data
    user_id: str = ""
    token_type: str = "access"  # access, refresh, api_key
    
    # Expiry
    expires_at: Optional[datetime] = None
    
    # Scope
    scopes: list[str] = field(default_factory=list)
    
    # Status
    is_revoked: bool = False
    
    @property
    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at
    
    @property
    def is_valid(self) -> bool:
        return not self.is_revoked and not self.is_expired


class AuthManager:
    """
    Authentication manager for GP2 system.
    
    Features:
    - Token-based authentication
    - Role-based access control
    - Permission checking
    - Session management
    """
    
    def __init__(self, secret_key: str = "chenu-gp2-secret-key"):
        self.manager_id = f"AUTH_{uuid4().hex[:8]}"
        self._secret_key = secret_key.encode()
        self._users: dict[str, User] = {}
        self._tokens: dict[str, Token] = {}
        self._sessions: dict[str, dict] = {}
        
        # Create system user
        self._create_system_user()
        
        logger.info(f"Auth Manager initialized: {self.manager_id}")
    
    def _create_system_user(self):
        """Create system user."""
        system_user = User(
            user_id="SYSTEM",
            username="system",
            email="system@chenu.local",
            roles=[Role.SYSTEM],
            is_active=True,
            is_verified=True,
        )
        self._users["SYSTEM"] = system_user
    
    # =========================================================================
    # PASSWORD HASHING
    # =========================================================================
    
    def hash_password(self, password: str) -> str:
        """Hash password using PBKDF2."""
        salt = uuid4().hex[:16]
        dk = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode(),
            salt.encode(),
            100000,
        )
        return f"{salt}${dk.hex()}"
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against hash."""
        try:
            salt, hash_value = password_hash.split('$')
            dk = hashlib.pbkdf2_hmac(
                'sha256',
                password.encode(),
                salt.encode(),
                100000,
            )
            return dk.hex() == hash_value
        except Exception:
            return False
    
    # =========================================================================
    # USER MANAGEMENT
    # =========================================================================
    
    def create_user(
        self,
        username: str,
        email: str,
        password: str,
        roles: list[Role] = None,
    ) -> User:
        """Create new user."""
        user = User(
            username=username,
            email=email,
            password_hash=self.hash_password(password),
            roles=roles or [Role.VIEWER],
        )
        
        self._users[user.user_id] = user
        logger.info(f"User created: {user.user_id} ({username})")
        
        return user
    
    def get_user(self, user_id: str) -> Optional[User]:
        """Get user by ID."""
        return self._users.get(user_id)
    
    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username."""
        for user in self._users.values():
            if user.username == username:
                return user
        return None
    
    def authenticate(self, username: str, password: str) -> Optional[User]:
        """Authenticate user with credentials."""
        user = self.get_user_by_username(username)
        
        if user is None:
            return None
        
        if not user.is_active:
            return None
        
        if not self.verify_password(password, user.password_hash):
            return None
        
        return user
    
    # =========================================================================
    # TOKEN MANAGEMENT
    # =========================================================================
    
    def create_access_token(
        self,
        user: User,
        expires_in: int = 3600,  # 1 hour
    ) -> str:
        """Create access token."""
        token = Token(
            user_id=user.user_id,
            token_type="access",
            expires_at=datetime.utcnow() + timedelta(seconds=expires_in),
            scopes=[p.value for p in user.permissions],
        )
        
        self._tokens[token.token_id] = token
        
        # Encode token
        encoded = self._encode_token(token)
        
        logger.debug(f"Access token created for user: {user.user_id}")
        return encoded
    
    def create_refresh_token(
        self,
        user: User,
        expires_in: int = 604800,  # 7 days
    ) -> str:
        """Create refresh token."""
        token = Token(
            user_id=user.user_id,
            token_type="refresh",
            expires_at=datetime.utcnow() + timedelta(seconds=expires_in),
        )
        
        self._tokens[token.token_id] = token
        encoded = self._encode_token(token)
        
        return encoded
    
    def create_api_key(
        self,
        user: User,
        scopes: list[str] = None,
    ) -> str:
        """Create API key (no expiry)."""
        token = Token(
            user_id=user.user_id,
            token_type="api_key",
            expires_at=None,  # No expiry
            scopes=scopes or [p.value for p in user.permissions],
        )
        
        self._tokens[token.token_id] = token
        encoded = self._encode_token(token)
        
        logger.info(f"API key created for user: {user.user_id}")
        return encoded
    
    def _encode_token(self, token: Token) -> str:
        """Encode token to string."""
        payload = {
            "token_id": token.token_id,
            "user_id": token.user_id,
            "type": token.token_type,
            "exp": token.expires_at.isoformat() if token.expires_at else None,
            "scopes": token.scopes,
        }
        
        data = json.dumps(payload).encode()
        signature = hmac.new(self._secret_key, data, hashlib.sha256).digest()
        
        return base64.urlsafe_b64encode(
            data + b'.' + signature
        ).decode()
    
    def _decode_token(self, encoded: str) -> Optional[dict]:
        """Decode token from string."""
        try:
            decoded = base64.urlsafe_b64decode(encoded.encode())
            data, signature = decoded.rsplit(b'.', 1)
            
            # Verify signature
            expected_sig = hmac.new(self._secret_key, data, hashlib.sha256).digest()
            if not hmac.compare_digest(signature, expected_sig):
                return None
            
            return json.loads(data.decode())
        except Exception:
            return None
    
    def validate_token(self, encoded: str) -> Optional[Token]:
        """Validate and get token."""
        payload = self._decode_token(encoded)
        if payload is None:
            return None
        
        token_id = payload.get("token_id")
        token = self._tokens.get(token_id)
        
        if token is None:
            return None
        
        if not token.is_valid:
            return None
        
        return token
    
    def revoke_token(self, token_id: str):
        """Revoke a token."""
        token = self._tokens.get(token_id)
        if token:
            token.is_revoked = True
            logger.info(f"Token revoked: {token_id}")
    
    # =========================================================================
    # AUTHORIZATION
    # =========================================================================
    
    def check_permission(
        self,
        user_or_token: User | Token | str,
        permission: Permission,
    ) -> bool:
        """Check if user/token has permission."""
        if isinstance(user_or_token, str):
            token = self.validate_token(user_or_token)
            if token is None:
                return False
            return permission.value in token.scopes
        
        if isinstance(user_or_token, Token):
            return permission.value in user_or_token.scopes
        
        if isinstance(user_or_token, User):
            return user_or_token.has_permission(permission)
        
        return False
    
    def require_permission(
        self,
        user_or_token: User | Token | str,
        permission: Permission,
    ):
        """Require permission or raise error."""
        if not self.check_permission(user_or_token, permission):
            raise PermissionError(f"Permission denied: {permission.value}")
    
    # =========================================================================
    # SESSION
    # =========================================================================
    
    def create_session(self, user: User) -> str:
        """Create user session."""
        session_id = f"SESSION_{uuid4().hex}"
        
        self._sessions[session_id] = {
            "user_id": user.user_id,
            "created_at": datetime.utcnow().isoformat(),
            "last_activity": datetime.utcnow().isoformat(),
        }
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[dict]:
        """Get session data."""
        return self._sessions.get(session_id)
    
    def invalidate_session(self, session_id: str):
        """Invalidate session."""
        self._sessions.pop(session_id, None)
    
    # =========================================================================
    # STATS
    # =========================================================================
    
    def get_stats(self) -> dict:
        """Get auth manager statistics."""
        return {
            "manager_id": self.manager_id,
            "total_users": len(self._users),
            "active_users": sum(1 for u in self._users.values() if u.is_active),
            "total_tokens": len(self._tokens),
            "valid_tokens": sum(1 for t in self._tokens.values() if t.is_valid),
            "active_sessions": len(self._sessions),
        }


# =============================================================================
# FASTAPI INTEGRATION
# =============================================================================

def create_auth_dependencies(auth_manager: AuthManager):
    """Create FastAPI authentication dependencies."""
    from fastapi import Depends, HTTPException, Header, status
    
    async def get_current_token(
        authorization: str = Header(..., alias="Authorization"),
    ) -> Token:
        """Get and validate current token."""
        if not authorization.startswith("Bearer "):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authorization header",
            )
        
        token_str = authorization[7:]
        token = auth_manager.validate_token(token_str)
        
        if token is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid or expired token",
            )
        
        return token
    
    async def get_current_user(
        token: Token = Depends(get_current_token),
    ) -> User:
        """Get current user from token."""
        user = auth_manager.get_user(token.user_id)
        
        if user is None or not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive",
            )
        
        return user
    
    def require_permission(permission: Permission):
        """Require specific permission."""
        async def checker(token: Token = Depends(get_current_token)):
            if permission.value not in token.scopes:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Permission denied: {permission.value}",
                )
            return token
        return checker
    
    return {
        "get_current_token": get_current_token,
        "get_current_user": get_current_user,
        "require_permission": require_permission,
    }


# =============================================================================
# SINGLETON
# =============================================================================

_auth_manager: Optional[AuthManager] = None


def get_auth_manager() -> AuthManager:
    """Get the auth manager singleton."""
    global _auth_manager
    if _auth_manager is None:
        import os
        secret_key = os.getenv("AUTH_SECRET_KEY", "chenu-gp2-secret-key")
        _auth_manager = AuthManager(secret_key)
    return _auth_manager
