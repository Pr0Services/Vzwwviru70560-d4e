# CHE-NU — Reconciled Canon v1
Date: 2026-01-07

This package is a **reconciled view** of the CHE‑NU system.
It does NOT rewrite history. It **declares authority, status, and paths**.

Principles:
- Code > Canon Docs > Legacy Docs > Archive
- No deletion. Only classification.

Purpose:
- unblock real-world testing
- align contributors
- freeze Canon v1
