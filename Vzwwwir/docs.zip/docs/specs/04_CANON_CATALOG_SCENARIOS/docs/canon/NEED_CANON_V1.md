# Need Canon v1

This is the human/system need taxonomy used to map modules, scenarios, and simulations.

See: `catalog/need_canon.v1.yaml`
