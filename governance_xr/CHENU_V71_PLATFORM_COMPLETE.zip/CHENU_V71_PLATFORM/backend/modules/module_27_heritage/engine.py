"""
CHE·NU™ V70 — MODULE 27: HERITAGE & IDENTITY ENGINE
====================================================
Le moteur qui préserve et transmet les valeurs, récits, identités 
et principes fondateurs d'une communauté.

Si le Module 26 transmet les compétences, le Module 27 transmet le SENS.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import hashlib
import json
import logging

logger = logging.getLogger("chenu.module_27")


class IdentityEvolutionType(str, Enum):
    """Types d'évolution de l'identité."""
    DECISION = "decision"  # Évolue par décision collective
    REINFORCEMENT = "reinforcement"  # Renforcée par réussite
    CORRECTION = "correction"  # Auto-corrigée par causalité
    CRISIS = "crisis"  # Transformée par crise


class TransmissionMode(str, Enum):
    """Modes de transmission identitaire."""
    NARRATIVE = "narrative"  # Récits vérifiés
    MONUMENT = "monument"  # Monuments numériques
    RITUAL = "ritual"  # Rituels civiques
    EXCHANGE = "exchange"  # Échange inter-civilisationnel


@dataclass
class IdentityGraph:
    """
    Graph identitaire d'une communauté.
    L'identité est un système vivant qui évolue.
    """
    graph_id: str = field(default_factory=lambda: f"IDENTITY_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_updated: datetime = field(default_factory=datetime.utcnow)
    
    # Core identity
    core_values: list[str] = field(default_factory=list)
    founding_principles: list[str] = field(default_factory=list)
    cultural_markers: list[str] = field(default_factory=list)
    
    # Historical decisions that shaped identity
    historical_decisions: list[dict[str, Any]] = field(default_factory=list)
    
    # Trust and validation
    trust_signature: str = ""
    heritage_score: float = 0.0
    
    # Version control
    version: int = 1
    previous_versions: list[str] = field(default_factory=list)


@dataclass
class IdentityArtifact:
    """
    Artifact d'identité transmissible.
    Versionné, signé, et transmissible.
    """
    artifact_id: str = field(default_factory=lambda: f"ID_ART_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Content
    core_values: list[str] = field(default_factory=list)
    historical_decisions: list[str] = field(default_factory=list)
    
    # Validation
    trust_signature: str = "OPA_VALIDATED"
    heritage_score: float = 0.0
    
    # Versioning
    version: str = "1.0"
    signatures: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary format."""
        return {
            "community_id": self.community_id,
            "core_values": self.core_values,
            "historical_decisions": self.historical_decisions,
            "trust_signature": self.trust_signature,
            "heritage_score": self.heritage_score,
        }


@dataclass
class VerifiedNarrative:
    """
    Récit vérifié - pas seulement des faits, mais le contexte.
    Lié aux simulations du WorldEngine.
    """
    narrative_id: str = field(default_factory=lambda: f"NARR_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Decision context
    decision_id: str = ""
    decision_summary: str = ""
    
    # Why the decision was made
    reasoning: str = ""
    sacrifices_made: list[str] = field(default_factory=list)
    principles_respected: list[str] = field(default_factory=list)
    
    # WorldEngine link
    worldengine_simulation_id: Optional[str] = None
    causal_trace_id: Optional[str] = None
    
    # Verification
    verified: bool = False
    verifier_signatures: list[str] = field(default_factory=list)


@dataclass
class DigitalMonument:
    """
    Monument numérique pour un moment fondateur.
    Accessible en XR dans la Chambre des Origines.
    """
    monument_id: str = field(default_factory=lambda: f"MON_{uuid4().hex[:8]}")
    community_id: str = ""
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Monument content
    title: str = ""
    description: str = ""
    founding_moment: str = ""
    date_commemorated: datetime = field(default_factory=datetime.utcnow)
    
    # Associated artifacts
    narrative_ids: list[str] = field(default_factory=list)
    artifact_ids: list[str] = field(default_factory=list)
    
    # XR representation
    xr_scene_id: str = ""
    xr_model_type: str = "interactive_fresco"  # tree, fresco, obelisk, etc.
    
    # Access
    is_public: bool = True
    requires_community_membership: bool = False


@dataclass
class IdentityDriftAlert:
    """
    Alerte en cas de dérive identitaire.
    Déclenché si une décision future viole l'identité historique.
    """
    alert_id: str = field(default_factory=lambda: f"DRIFT_{uuid4().hex[:8]}")
    community_id: str = ""
    detected_at: datetime = field(default_factory=datetime.utcnow)
    
    # Drift details
    proposed_action: str = ""
    violated_value: str = ""
    historical_reference: str = ""
    
    # Severity
    severity: int = 1  # 1-5
    
    # Resolution
    simulation_comparison_id: Optional[str] = None
    requires_collective_arbitration: bool = False
    resolved: bool = False


@dataclass
class CulturalExchange:
    """
    Échange culturel inter-civilisationnel.
    Permet l'échange de valeurs entre communautés.
    """
    exchange_id: str = field(default_factory=lambda: f"EXCH_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Participants
    community_a_id: str = ""
    community_b_id: str = ""
    
    # Exchanged content
    values_shared_a_to_b: list[str] = field(default_factory=list)
    values_shared_b_to_a: list[str] = field(default_factory=list)
    
    # Outcome
    compatibility_score: float = 0.0
    lessons_learned: list[str] = field(default_factory=list)
    
    # Status
    status: str = "proposed"  # proposed, active, completed, terminated


class HeritageIdentityEngine:
    """
    Module 27 — Heritage & Identity Engine
    
    Préserve et transmet les valeurs, récits, identités et principes
    fondateurs d'une communauté au-delà des individus et des crises.
    """
    
    def __init__(
        self,
        opa_client: Optional[Any] = None,
        worldengine: Optional[Any] = None,
        causal_engine: Optional[Any] = None,
    ):
        self.engine_id = f"HERITAGE_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        # Dependencies
        self.opa_client = opa_client
        self.worldengine = worldengine
        self.causal_engine = causal_engine
        
        # Storage
        self._identity_graphs: dict[str, IdentityGraph] = {}
        self._artifacts: dict[str, IdentityArtifact] = {}
        self._narratives: dict[str, VerifiedNarrative] = {}
        self._monuments: dict[str, DigitalMonument] = {}
        self._drift_alerts: dict[str, IdentityDriftAlert] = {}
        self._exchanges: dict[str, CulturalExchange] = {}
        
        logger.info(f"Heritage & Identity Engine initialized: {self.engine_id}")
    
    # =========================================================================
    # IDENTITY GRAPH
    # =========================================================================
    
    def create_identity_graph(
        self,
        community_id: str,
        core_values: list[str],
        founding_principles: list[str],
    ) -> IdentityGraph:
        """
        Create an identity graph for a community.
        """
        graph = IdentityGraph(
            community_id=community_id,
            core_values=core_values,
            founding_principles=founding_principles,
        )
        
        # Calculate heritage score
        graph.heritage_score = self._calculate_heritage_score(graph)
        
        # Sign with OPA
        graph.trust_signature = self._sign_with_opa(graph)
        
        self._identity_graphs[graph.graph_id] = graph
        logger.info(f"Identity graph created: {graph.graph_id}")
        
        return graph
    
    def evolve_identity(
        self,
        graph_id: str,
        evolution_type: IdentityEvolutionType,
        change_description: str,
        decision_context: Optional[dict[str, Any]] = None,
    ) -> IdentityGraph:
        """
        Evolve an identity graph based on collective decisions.
        
        L'identité évolue avec:
        - Décisions collectives
        - Réussites
        - Auto-correction causale
        """
        graph = self._identity_graphs.get(graph_id)
        if not graph:
            raise ValueError(f"Identity graph not found: {graph_id}")
        
        # Store previous version
        graph.previous_versions.append(f"v{graph.version}")
        graph.version += 1
        
        # Record evolution
        evolution_record = {
            "type": evolution_type.value,
            "description": change_description,
            "context": decision_context,
            "timestamp": datetime.utcnow().isoformat(),
        }
        graph.historical_decisions.append(evolution_record)
        
        # Update heritage score
        graph.heritage_score = self._calculate_heritage_score(graph)
        graph.last_updated = datetime.utcnow()
        
        # Re-sign
        graph.trust_signature = self._sign_with_opa(graph)
        
        logger.info(f"Identity evolved: {graph_id} v{graph.version}")
        return graph
    
    def _calculate_heritage_score(self, graph: IdentityGraph) -> float:
        """Calculate heritage score based on completeness and coherence."""
        score = 0.0
        
        # Core values present
        if graph.core_values:
            score += 0.3 * min(len(graph.core_values) / 5, 1.0)
        
        # Founding principles
        if graph.founding_principles:
            score += 0.3 * min(len(graph.founding_principles) / 3, 1.0)
        
        # Historical depth
        if graph.historical_decisions:
            score += 0.2 * min(len(graph.historical_decisions) / 10, 1.0)
        
        # Cultural markers
        if graph.cultural_markers:
            score += 0.2 * min(len(graph.cultural_markers) / 5, 1.0)
        
        return round(score, 2)
    
    def _sign_with_opa(self, graph: IdentityGraph) -> str:
        """Sign identity graph with OPA validation."""
        if self.opa_client:
            try:
                result = self.opa_client.query(
                    policy_path="chenu/heritage/identity",
                    input_data={"community_id": graph.community_id},
                )
                if result.get("allow"):
                    return "OPA_VALIDATED"
            except Exception as e:
                logger.error(f"OPA signing error: {e}")
        return "UNSIGNED"
    
    # =========================================================================
    # VERIFIED NARRATIVES
    # =========================================================================
    
    def create_verified_narrative(
        self,
        community_id: str,
        decision_id: str,
        decision_summary: str,
        reasoning: str,
        sacrifices: list[str] = None,
        principles: list[str] = None,
    ) -> VerifiedNarrative:
        """
        Create a verified narrative.
        
        Stores not just facts, but:
        - Why a decision was made
        - What sacrifices were made
        - What principles were respected
        """
        narrative = VerifiedNarrative(
            community_id=community_id,
            decision_id=decision_id,
            decision_summary=decision_summary,
            reasoning=reasoning,
            sacrifices_made=sacrifices or [],
            principles_respected=principles or [],
        )
        
        # Link to WorldEngine simulation if available
        if self.worldengine:
            simulation = self._link_to_worldengine(narrative)
            narrative.worldengine_simulation_id = simulation.get("id")
            narrative.causal_trace_id = simulation.get("causal_trace")
        
        # Verify and sign
        narrative.verified = True
        narrative.verifier_signatures = [self._sign_narrative(narrative)]
        
        self._narratives[narrative.narrative_id] = narrative
        logger.info(f"Verified narrative created: {narrative.narrative_id}")
        
        return narrative
    
    def _link_to_worldengine(self, narrative: VerifiedNarrative) -> dict[str, Any]:
        """Link narrative to WorldEngine simulation."""
        try:
            return self.worldengine.get_simulation_for_decision(
                decision_id=narrative.decision_id
            )
        except Exception:
            return {}
    
    def _sign_narrative(self, narrative: VerifiedNarrative) -> str:
        """Sign a narrative."""
        content = json.dumps({
            "id": narrative.narrative_id,
            "decision": narrative.decision_summary,
        }, sort_keys=True)
        return f"NARR_SIG:{hashlib.sha256(content.encode()).hexdigest()[:16]}"
    
    # =========================================================================
    # DIGITAL MONUMENTS
    # =========================================================================
    
    def create_monument(
        self,
        community_id: str,
        title: str,
        founding_moment: str,
        xr_model_type: str = "interactive_fresco",
    ) -> DigitalMonument:
        """
        Create a digital monument for a founding moment.
        """
        monument = DigitalMonument(
            community_id=community_id,
            title=title,
            founding_moment=founding_moment,
            xr_model_type=xr_model_type,
        )
        
        # Generate XR scene
        monument.xr_scene_id = f"XR_MON_{monument.monument_id}"
        
        self._monuments[monument.monument_id] = monument
        logger.info(f"Digital monument created: {monument.monument_id}")
        
        return monument
    
    # =========================================================================
    # DRIFT DETECTION
    # =========================================================================
    
    def check_identity_drift(
        self,
        community_id: str,
        proposed_action: str,
        action_context: Optional[dict[str, Any]] = None,
    ) -> Optional[IdentityDriftAlert]:
        """
        Check if a proposed action violates the community's identity.
        
        Si une décision future viole l'identité historique:
        - Alerte
        - Simulation comparative
        - Arbitrage collectif
        """
        graph = None
        for g in self._identity_graphs.values():
            if g.community_id == community_id:
                graph = g
                break
        
        if not graph:
            return None
        
        # Check against core values
        violated_value = self._detect_value_violation(
            graph.core_values, 
            proposed_action
        )
        
        if violated_value:
            alert = IdentityDriftAlert(
                community_id=community_id,
                proposed_action=proposed_action,
                violated_value=violated_value,
                severity=3,
                requires_collective_arbitration=True,
            )
            
            # Create comparative simulation
            if self.worldengine:
                alert.simulation_comparison_id = self._create_comparison_simulation(
                    graph, proposed_action
                )
            
            self._drift_alerts[alert.alert_id] = alert
            logger.warning(f"Identity drift detected: {alert.alert_id}")
            
            return alert
        
        return None
    
    def _detect_value_violation(
        self, 
        core_values: list[str], 
        action: str
    ) -> Optional[str]:
        """Detect if an action violates core values."""
        action_lower = action.lower()
        
        # Simple keyword-based detection (real impl would be more sophisticated)
        violation_keywords = {
            "solidarity": ["exclude", "isolate", "abandon"],
            "resilience": ["fragile", "dependent", "vulnerable"],
            "ecology": ["pollute", "destroy", "waste"],
            "transparency": ["hide", "conceal", "secret"],
        }
        
        for value in core_values:
            value_lower = value.lower()
            if value_lower in violation_keywords:
                for keyword in violation_keywords[value_lower]:
                    if keyword in action_lower:
                        return value
        
        return None
    
    def _create_comparison_simulation(
        self, 
        graph: IdentityGraph, 
        action: str
    ) -> str:
        """Create a WorldEngine simulation for comparison."""
        try:
            sim = self.worldengine.simulate_identity_impact(
                community_id=graph.community_id,
                action=action,
            )
            return sim.get("simulation_id", "")
        except Exception:
            return ""
    
    # =========================================================================
    # CULTURAL EXCHANGE
    # =========================================================================
    
    def initiate_cultural_exchange(
        self,
        community_a_id: str,
        community_b_id: str,
    ) -> CulturalExchange:
        """
        Initiate a cultural exchange between two communities.
        
        Permet:
        - Échange de valeurs
        - Diplomatie culturelle
        - Apprentissage civilisationnel croisé
        """
        exchange = CulturalExchange(
            community_a_id=community_a_id,
            community_b_id=community_b_id,
            status="proposed",
        )
        
        # Calculate compatibility
        graph_a = next(
            (g for g in self._identity_graphs.values() 
             if g.community_id == community_a_id), 
            None
        )
        graph_b = next(
            (g for g in self._identity_graphs.values() 
             if g.community_id == community_b_id), 
            None
        )
        
        if graph_a and graph_b:
            exchange.compatibility_score = self._calculate_compatibility(
                graph_a, graph_b
            )
        
        self._exchanges[exchange.exchange_id] = exchange
        logger.info(f"Cultural exchange initiated: {exchange.exchange_id}")
        
        return exchange
    
    def _calculate_compatibility(
        self, 
        graph_a: IdentityGraph, 
        graph_b: IdentityGraph
    ) -> float:
        """Calculate compatibility between two identity graphs."""
        shared_values = set(graph_a.core_values) & set(graph_b.core_values)
        all_values = set(graph_a.core_values) | set(graph_b.core_values)
        
        if not all_values:
            return 0.0
        
        return len(shared_values) / len(all_values)
    
    # =========================================================================
    # XR INTERFACE
    # =========================================================================
    
    def get_xr_origins_chamber_config(
        self, 
        community_id: str
    ) -> dict[str, Any]:
        """
        Get XR configuration for La Chambre des Origines.
        
        Features:
        - Arbres généalogiques de décisions
        - Fresques causales interactives
        - Monuments numériques aux moments fondateurs
        
        Un citoyen peut revivre une décision clé de sa communauté.
        """
        # Get community monuments
        community_monuments = [
            m for m in self._monuments.values()
            if m.community_id == community_id
        ]
        
        return {
            "scene_type": "ORIGINS_CHAMBER",
            "read_only": True,  # XR = READ ONLY
            "community_id": community_id,
            "components": [
                {
                    "type": "decision_tree",
                    "visualization": "genealogical_tree",
                    "data_source": "historical_decisions",
                    "interactive": True,
                },
                {
                    "type": "causal_fresco",
                    "visualization": "interactive_timeline",
                    "linked_narratives": True,
                },
                {
                    "type": "monument_gallery",
                    "monuments": [m.monument_id for m in community_monuments],
                    "visualization": "3d_walkthrough",
                },
            ],
            "interactions": [
                "relive_decision",
                "explore_causality",
                "view_monument",
            ],
            "governance": {
                "opa_policy_id": "OPA_XR_HERITAGE_V1",
                "hitl_required": False,
            },
        }
    
    # =========================================================================
    # EXPORT
    # =========================================================================
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        return {
            "engine_id": self.engine_id,
            "identity_graphs": len(self._identity_graphs),
            "artifacts": len(self._artifacts),
            "verified_narratives": len(self._narratives),
            "monuments": len(self._monuments),
            "active_drift_alerts": sum(
                1 for a in self._drift_alerts.values() if not a.resolved
            ),
            "cultural_exchanges": len(self._exchanges),
        }
    
    def export_identity_artifact(
        self, 
        community_id: str
    ) -> IdentityArtifact:
        """Export community identity as transmissible artifact."""
        graph = next(
            (g for g in self._identity_graphs.values() 
             if g.community_id == community_id),
            None
        )
        
        if not graph:
            raise ValueError(f"No identity graph for community: {community_id}")
        
        artifact = IdentityArtifact(
            community_id=community_id,
            core_values=graph.core_values,
            historical_decisions=[
                d["description"] for d in graph.historical_decisions
            ],
            heritage_score=graph.heritage_score,
            trust_signature=graph.trust_signature,
        )
        
        # Sign artifact
        artifact.signatures = [
            f"HERITAGE_SIG:{hashlib.sha256(community_id.encode()).hexdigest()[:16]}"
        ]
        
        self._artifacts[artifact.artifact_id] = artifact
        return artifact
