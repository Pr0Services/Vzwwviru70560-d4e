# Testing Entry Point

Recommended Test #1:
- Local-first single user
- Orchestrator + Stagiaire end-of-conversation
- No Professor intervention
Goal: coherence validation.
