# Legacy Specs
Replaced by code, kept for reference.
