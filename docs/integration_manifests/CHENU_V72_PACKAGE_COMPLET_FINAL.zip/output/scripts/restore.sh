#!/bin/bash
# ============================================================================
# CHE·NU Restore Script
# 
# Restores from backups created by backup.sh
# 
# R&D COMPLIANCE: ✅
# - Rule #1: Requires human confirmation before restore
# - Rule #6: Full audit trail of restore operations
# ============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Configuration
BACKUP_DIR="${BACKUP_DIR:-/var/backups/chenu}"
POSTGRES_HOST="${POSTGRES_HOST:-localhost}"
POSTGRES_PORT="${POSTGRES_PORT:-5432}"
POSTGRES_USER="${POSTGRES_USER:-chenu}"
POSTGRES_DB="${POSTGRES_DB:-chenu}"

# Logging
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="$BACKUP_DIR/logs/restore_${TIMESTAMP}.log"
mkdir -p "$BACKUP_DIR/logs"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

error() {
    log "ERROR: $1"
    echo -e "${RED}ERROR: $1${NC}"
    exit 1
}

warn() {
    log "WARNING: $1"
    echo -e "${YELLOW}WARNING: $1${NC}"
}

success() {
    log "SUCCESS: $1"
    echo -e "${GREEN}✓ $1${NC}"
}

# ============================================================================
# Human Gate - R&D Rule #1 Compliance
# ============================================================================

require_confirmation() {
    echo -e "${YELLOW}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                  ║"
    echo "║  ⚠️  WARNING: DESTRUCTIVE OPERATION                             ║"
    echo "║                                                                  ║"
    echo "║  This will REPLACE current data with backup data.               ║"
    echo "║  This action cannot be undone!                                  ║"
    echo "║                                                                  ║"
    echo "║  R&D COMPLIANCE: Human confirmation required (Rule #1)          ║"
    echo "║                                                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "Backup to restore: ${BLUE}$1${NC}"
    echo ""
    
    read -p "Type 'RESTORE' to confirm: " CONFIRM
    
    if [ "$CONFIRM" != "RESTORE" ]; then
        log "Restore cancelled by user"
        echo -e "${YELLOW}Restore cancelled.${NC}"
        exit 0
    fi
    
    log "Human confirmation received for restore"
}

# ============================================================================
# List Available Backups
# ============================================================================

list_backups() {
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Available Backups${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [ ! -d "$BACKUP_DIR" ]; then
        error "Backup directory not found: $BACKUP_DIR"
    fi
    
    # Find manifest files
    MANIFESTS=$(ls "$BACKUP_DIR"/*_manifest.json 2>/dev/null || true)
    
    if [ -z "$MANIFESTS" ]; then
        echo "No backups found in $BACKUP_DIR"
        exit 0
    fi
    
    echo "ID | Date                | Size    | Components"
    echo "---|---------------------|---------|------------------"
    
    for MANIFEST in $MANIFESTS; do
        BACKUP_ID=$(basename "$MANIFEST" | sed 's/_manifest.json//')
        
        if [ -f "$MANIFEST" ]; then
            CREATED=$(jq -r '.created_at // "unknown"' "$MANIFEST" 2>/dev/null | cut -d'T' -f1,2 | tr 'T' ' ')
            SIZE=$(jq -r '.total_size // "?"' "$MANIFEST" 2>/dev/null)
            DB=$(jq -r '.components.database' "$MANIFEST" 2>/dev/null)
            REDIS=$(jq -r '.components.redis' "$MANIFEST" 2>/dev/null)
            
            COMPONENTS=""
            [ "$DB" = "true" ] && COMPONENTS="DB"
            [ "$REDIS" = "true" ] && COMPONENTS="$COMPONENTS,Redis"
            COMPONENTS=$(echo "$COMPONENTS" | sed 's/^,//')
            
            printf "%-20s | %-19s | %-7s | %s\n" "$BACKUP_ID" "$CREATED" "$SIZE" "$COMPONENTS"
        fi
    done
    
    echo ""
    echo "Usage: $0 restore <backup_id>"
}

# ============================================================================
# Verify Backup
# ============================================================================

verify_backup() {
    BACKUP_ID="$1"
    MANIFEST="$BACKUP_DIR/${BACKUP_ID}_manifest.json"
    
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Verifying Backup: $BACKUP_ID${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo ""
    
    if [ ! -f "$MANIFEST" ]; then
        error "Manifest not found: $MANIFEST"
    fi
    
    log "Verifying backup: $BACKUP_ID"
    
    # Check database backup
    DB_FILE="$BACKUP_DIR/${BACKUP_ID}_database.sql.gz"
    if [ -f "$DB_FILE" ]; then
        # Verify checksum
        DB_META="$BACKUP_DIR/${BACKUP_ID}_database.meta.json"
        if [ -f "$DB_META" ]; then
            EXPECTED_CHECKSUM=$(jq -r '.checksum' "$DB_META" 2>/dev/null)
            ACTUAL_CHECKSUM=$(sha256sum "$DB_FILE" | cut -d' ' -f1)
            
            if [ "$EXPECTED_CHECKSUM" = "$ACTUAL_CHECKSUM" ]; then
                success "Database backup checksum verified"
            else
                error "Database backup checksum mismatch!"
            fi
        fi
        
        # Check if it's valid gzip
        if gzip -t "$DB_FILE" 2>/dev/null; then
            success "Database backup file is valid"
        else
            error "Database backup file is corrupted"
        fi
    else
        warn "No database backup found"
    fi
    
    # Check Redis backup
    REDIS_FILE="$BACKUP_DIR/${BACKUP_ID}_redis.rdb"
    if [ -f "$REDIS_FILE" ]; then
        success "Redis backup found: $(du -h "$REDIS_FILE" | cut -f1)"
    else
        log "No Redis backup in this backup set"
    fi
    
    # Check app data backup
    APP_FILE="$BACKUP_DIR/${BACKUP_ID}_app_data.tar.gz"
    if [ -f "$APP_FILE" ]; then
        if tar -tzf "$APP_FILE" > /dev/null 2>&1; then
            success "Application data backup is valid"
        else
            warn "Application data backup may be corrupted"
        fi
    fi
    
    success "Backup verification complete"
}

# ============================================================================
# Restore Database
# ============================================================================

restore_database() {
    BACKUP_ID="$1"
    DB_FILE="$BACKUP_DIR/${BACKUP_ID}_database.sql.gz"
    
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Restoring Database${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    
    if [ ! -f "$DB_FILE" ]; then
        warn "No database backup found, skipping database restore"
        return
    fi
    
    log "Restoring database from: $DB_FILE"
    
    # Check if using Docker
    if docker ps | grep -q chenu-postgres; then
        log "Using Docker container for restore..."
        
        # Drop existing connections and restore
        docker exec chenu-postgres psql -U "$POSTGRES_USER" -d postgres -c \
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$POSTGRES_DB' AND pid <> pg_backend_pid();" 2>/dev/null || true
        
        docker exec chenu-postgres dropdb -U "$POSTGRES_USER" --if-exists "$POSTGRES_DB" 2>/dev/null || true
        docker exec chenu-postgres createdb -U "$POSTGRES_USER" "$POSTGRES_DB"
        
        gunzip -c "$DB_FILE" | docker exec -i chenu-postgres psql -U "$POSTGRES_USER" "$POSTGRES_DB"
    else
        # Direct connection
        log "Using direct connection for restore..."
        
        PGPASSWORD="${POSTGRES_PASSWORD}" psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" -d postgres -c \
            "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$POSTGRES_DB' AND pid <> pg_backend_pid();" 2>/dev/null || true
        
        PGPASSWORD="${POSTGRES_PASSWORD}" dropdb -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" --if-exists "$POSTGRES_DB" 2>/dev/null || true
        PGPASSWORD="${POSTGRES_PASSWORD}" createdb -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" "$POSTGRES_DB"
        
        gunzip -c "$DB_FILE" | PGPASSWORD="${POSTGRES_PASSWORD}" psql -h "$POSTGRES_HOST" -p "$POSTGRES_PORT" -U "$POSTGRES_USER" "$POSTGRES_DB"
    fi
    
    success "Database restored successfully"
    log "Database restore completed"
}

# ============================================================================
# Restore Redis
# ============================================================================

restore_redis() {
    BACKUP_ID="$1"
    REDIS_FILE="$BACKUP_DIR/${BACKUP_ID}_redis.rdb"
    
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Restoring Redis${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    
    if [ ! -f "$REDIS_FILE" ]; then
        warn "No Redis backup found, skipping Redis restore"
        return
    fi
    
    log "Restoring Redis from: $REDIS_FILE"
    
    if docker ps | grep -q chenu-redis; then
        # Stop Redis, replace RDB, restart
        docker exec chenu-redis redis-cli SHUTDOWN NOSAVE || true
        sleep 2
        docker cp "$REDIS_FILE" chenu-redis:/data/dump.rdb
        docker start chenu-redis
        sleep 2
    else
        warn "Redis restore requires manual intervention for non-Docker setup"
        log "Manual Redis restore required"
    fi
    
    success "Redis restore completed"
}

# ============================================================================
# Restore Application Data
# ============================================================================

restore_app_data() {
    BACKUP_ID="$1"
    APP_FILE="$BACKUP_DIR/${BACKUP_ID}_app_data.tar.gz"
    
    echo -e "\n${BLUE}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${BLUE}  Restoring Application Data${NC}"
    echo -e "${BLUE}═══════════════════════════════════════════════════════════${NC}"
    
    if [ ! -f "$APP_FILE" ]; then
        warn "No application data backup found, skipping"
        return
    fi
    
    log "Restoring application data from: $APP_FILE"
    
    # Extract to root (paths are absolute in tar)
    tar -xzf "$APP_FILE" -C / 2>/dev/null || tar -xzf "$APP_FILE" -C /app 2>/dev/null || true
    
    success "Application data restored"
    log "Application data restore completed"
}

# ============================================================================
# Main Restore Function
# ============================================================================

do_restore() {
    BACKUP_ID="$1"
    
    if [ -z "$BACKUP_ID" ]; then
        error "Usage: $0 restore <backup_id>"
    fi
    
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════════╗"
    echo "║                                                                  ║"
    echo "║              CHE·NU™ Restore System                             ║"
    echo "║                                                                  ║"
    echo "║              Governed Intelligence Operating System             ║"
    echo "║                                                                  ║"
    echo "╚══════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    log "=========================================="
    log "Starting CHE·NU restore: $BACKUP_ID"
    log "=========================================="
    
    # Verify backup exists and is valid
    verify_backup "$BACKUP_ID"
    
    # R&D Rule #1: Require human confirmation
    require_confirmation "$BACKUP_ID"
    
    START_TIME=$(date +%s)
    
    # Perform restore
    restore_database "$BACKUP_ID"
    restore_redis "$BACKUP_ID"
    restore_app_data "$BACKUP_ID"
    
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    
    echo -e "\n${GREEN}═══════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}  Restore Complete${NC}"
    echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"
    
    echo -e "Restored from:    ${BLUE}$BACKUP_ID${NC}"
    echo -e "Duration:         ${BLUE}${DURATION}s${NC}"
    echo -e "Log file:         ${BLUE}$LOG_FILE${NC}"
    
    log "Restore completed in ${DURATION}s"
    
    echo ""
    echo -e "${YELLOW}⚠️  Please restart the application to apply changes${NC}"
}

# ============================================================================
# Main
# ============================================================================

case "${1:-list}" in
    list)
        list_backups
        ;;
    verify)
        if [ -z "$2" ]; then
            error "Usage: $0 verify <backup_id>"
        fi
        verify_backup "$2"
        ;;
    restore)
        do_restore "$2"
        ;;
    *)
        echo "Usage: $0 [list|verify|restore] [backup_id]"
        echo ""
        echo "Commands:"
        echo "  list              List available backups"
        echo "  verify <id>       Verify backup integrity"
        echo "  restore <id>      Restore from backup (requires confirmation)"
        exit 1
        ;;
esac
