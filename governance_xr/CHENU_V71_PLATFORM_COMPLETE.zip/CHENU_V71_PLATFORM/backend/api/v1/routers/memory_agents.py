"""
CHE·NU™ V70 — API ROUTERS (Memory & Agents)
============================================
Memory, Governance, Agent APIs

Based on: CHENU_API_SPECS_v29.md

GOUVERNANCE > EXÉCUTION
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import Any, Dict, List, Optional
from datetime import datetime
from uuid import uuid4
from enum import Enum

from .core import APIResponse


# =============================================================================
# MEMORY & GOVERNANCE API
# =============================================================================

class MemoryType(str, Enum):
    SHORT_TERM = "short_term"
    MID_TERM = "mid_term"
    LONG_TERM = "long_term"


class MemoryCategory(str, Enum):
    PREFERENCE = "preference"
    INSTRUCTION = "instruction"
    FACT = "fact"
    CONTEXT = "context"
    RULE = "rule"


class MemoryStatus(str, Enum):
    ACTIVE = "active"
    PINNED = "pinned"
    ARCHIVED = "archived"


class MemoryCreate(BaseModel):
    memory_type: MemoryType
    memory_category: MemoryCategory
    content: str
    dataspace_id: Optional[str] = None
    expires_at: Optional[datetime] = None


class MemoryUpdate(BaseModel):
    content: Optional[str] = None
    memory_category: Optional[MemoryCategory] = None
    expires_at: Optional[datetime] = None


class ElevationRequest(BaseModel):
    requested_action: str
    resource_type: str
    resource_id: str
    reason: str


memory_router = APIRouter(prefix="/memory", tags=["Memory"])
governance_router = APIRouter(prefix="/governance", tags=["Governance"])


@memory_router.post("", response_model=APIResponse)
async def store_memory(memory: MemoryCreate):
    """
    Store memory.
    
    GOVERNANCE: All memory is visible to user (Law 1: No Hidden Memory)
    Long-term requires explicit approval (Law 2)
    """
    requires_approval = memory.memory_type == MemoryType.LONG_TERM
    
    return APIResponse(data={
        "memory_id": str(uuid4()),
        "memory_type": memory.memory_type,
        "memory_category": memory.memory_category,
        "content": memory.content,
        "visible_to_user": True,  # GOVERNANCE: Law 1
        "requires_approval": requires_approval,  # GOVERNANCE: Law 2
        "user_deletable": True,  # GOVERNANCE: Law 5
        "created_at": datetime.utcnow().isoformat(),
        "synthetic": True
    })


@memory_router.get("", response_model=APIResponse)
async def list_memory(
    type: Optional[MemoryType] = Query(None),
    category: Optional[MemoryCategory] = Query(None),
    status: MemoryStatus = Query(MemoryStatus.ACTIVE),
    page: int = Query(1),
    limit: int = Query(20)
):
    """List all memory (user can see everything - Law 1)."""
    return APIResponse(data={
        "memories": [],
        "total": 0,
        "page": page,
        "limit": limit,
        "governance": {
            "all_visible": True,  # Law 1
            "user_controlled": True  # Law 10
        }
    })


@memory_router.get("/{memory_id}", response_model=APIResponse)
async def get_memory(memory_id: str):
    """Get memory item."""
    return APIResponse(data={
        "memory_id": memory_id,
        "content": "Sample memory",
        "visible_to_user": True
    })


@memory_router.patch("/{memory_id}", response_model=APIResponse)
async def update_memory(memory_id: str, updates: MemoryUpdate):
    """Update memory."""
    return APIResponse(data={
        "memory_id": memory_id,
        "updated": True,
        "updated_at": datetime.utcnow().isoformat()
    })


@memory_router.delete("/{memory_id}", response_model=APIResponse)
async def delete_memory(memory_id: str):
    """
    Delete memory (true deletion).
    
    GOVERNANCE: Law 5 - Reversibility (user can delete)
    No residual patterns kept
    """
    return APIResponse(data={
        "memory_id": memory_id,
        "deleted": True,
        "true_deletion": True,  # GOVERNANCE: No residual patterns
        "deleted_at": datetime.utcnow().isoformat()
    })


@memory_router.post("/{memory_id}/pin", response_model=APIResponse)
async def pin_memory(memory_id: str):
    """Pin memory."""
    return APIResponse(data={
        "memory_id": memory_id,
        "pinned": True,
        "pinned_at": datetime.utcnow().isoformat()
    })


@memory_router.post("/{memory_id}/archive", response_model=APIResponse)
async def archive_memory(memory_id: str):
    """Archive memory."""
    return APIResponse(data={
        "memory_id": memory_id,
        "archived": True,
        "archived_at": datetime.utcnow().isoformat()
    })


# Governance endpoints
@governance_router.get("/audit", response_model=APIResponse)
async def get_audit_log(
    resource_type: Optional[str] = Query(None),
    action_type: Optional[str] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    page: int = Query(1),
    limit: int = Query(50)
):
    """
    Get audit log.
    
    GOVERNANCE: Law 6 - All operations are logged
    """
    return APIResponse(data={
        "audit_entries": [],
        "total": 0,
        "page": page,
        "limit": limit,
        "governance": {
            "complete_log": True,  # Law 6
            "immutable": True
        }
    })


@governance_router.post("/elevate", response_model=APIResponse)
async def request_elevation(request: ElevationRequest):
    """
    Request permission elevation (HITL).
    
    GOVERNANCE: Sensitive actions require human approval
    """
    return APIResponse(data={
        "elevation_id": str(uuid4()),
        "requested_action": request.requested_action,
        "resource_type": request.resource_type,
        "resource_id": request.resource_id,
        "reason": request.reason,
        "status": "pending_approval",
        "requires_hitl": True,  # GOVERNANCE
        "created_at": datetime.utcnow().isoformat()
    })


@governance_router.post("/elevate/{request_id}/approve", response_model=APIResponse)
async def approve_elevation(request_id: str):
    """Approve elevation request."""
    return APIResponse(data={
        "elevation_id": request_id,
        "status": "approved",
        "approved_at": datetime.utcnow().isoformat(),
        "hitl_confirmed": True
    })


@governance_router.post("/elevate/{request_id}/deny", response_model=APIResponse)
async def deny_elevation(request_id: str):
    """Deny elevation request."""
    return APIResponse(data={
        "elevation_id": request_id,
        "status": "denied",
        "denied_at": datetime.utcnow().isoformat()
    })


# =============================================================================
# AGENT API
# =============================================================================

class AgentLevel(str, Enum):
    L0 = "L0"
    L1 = "L1"
    L2 = "L2"
    L3 = "L3"


class AgentExecuteRequest(BaseModel):
    input: Dict[str, Any]
    context: Dict[str, Any] = Field(default_factory=dict)
    options: Dict[str, Any] = Field(default_factory=lambda: {
        "stream": False,
        "max_tokens": 4096
    })


class AgentConfigureRequest(BaseModel):
    config_key: str
    config_value: Any


agent_router = APIRouter(prefix="/agents", tags=["Agents"])


@agent_router.get("", response_model=APIResponse)
async def list_agents(
    level: Optional[AgentLevel] = Query(None),
    sphere_id: Optional[str] = Query(None),
    domain_id: Optional[str] = Query(None),
    active: bool = Query(True)
):
    """List available agents."""
    # Import from agent system
    agents_sample = [
        {"id": "AGT_NOVA_L0", "name": "Nova Intelligence", "level": "L0", "hireable": False},
        {"id": "AGT_ORCHESTRATOR_L1", "name": "User Orchestrator", "level": "L1", "hireable": True},
        {"id": "AGT_CONSTRUCTION_CHIEF_L2", "name": "Construction Chief", "level": "L2", "hireable": True},
        {"id": "AGT_IMMOBILIER_CHIEF_L2", "name": "Immobilier Chief", "level": "L2", "hireable": True},
        {"id": "AGT_FINANCE_CHIEF_L2", "name": "Finance Chief", "level": "L2", "hireable": True},
    ]
    
    # Filter by level if specified
    if level:
        agents_sample = [a for a in agents_sample if a["level"] == level.value]
    
    return APIResponse(data={
        "agents": agents_sample,
        "total": len(agents_sample),
        "governance": {
            "l0_never_hired": True,  # GOVERNANCE
            "scope_enforced": True
        }
    })


@agent_router.get("/{agent_id}", response_model=APIResponse)
async def get_agent_details(agent_id: str):
    """Get agent details."""
    return APIResponse(data={
        "agent_id": agent_id,
        "name": "Sample Agent",
        "level": "L2",
        "sphere": "business",
        "capabilities": ["analyze", "suggest", "draft"],
        "scope": {
            "read_spheres": ["business"],
            "write_spheres": ["business"],
            "requires_approval": ["send", "publish"]
        },
        "cost_per_exec": 5,
        "status": "active"
    })


@agent_router.post("/{agent_id}/execute", response_model=APIResponse)
async def execute_agent(agent_id: str, request: AgentExecuteRequest):
    """
    Execute agent.
    
    GOVERNANCE: L0 agents cannot be executed directly
    Scope is enforced
    """
    # Check if L0 (forbidden)
    if agent_id.endswith("_L0"):
        raise HTTPException(
            status_code=403,
            detail="L0 system agents cannot be executed directly"
        )
    
    return APIResponse(data={
        "execution_id": str(uuid4()),
        "agent_id": agent_id,
        "status": "completed",
        "output": {
            "result": "Agent execution completed",
            "synthetic": True  # GOVERNANCE
        },
        "tokens_used": 5,
        "executed_at": datetime.utcnow().isoformat(),
        "governance": {
            "scope_checked": True,
            "synthetic": True
        }
    })


@agent_router.post("/{agent_id}/execute/stream", response_model=APIResponse)
async def execute_agent_stream(agent_id: str, request: AgentExecuteRequest):
    """Execute agent with streaming (SSE)."""
    # In real implementation, this would return SSE
    return APIResponse(data={
        "execution_id": str(uuid4()),
        "agent_id": agent_id,
        "stream_url": f"/agents/{agent_id}/stream/{uuid4()}",
        "status": "streaming"
    })


@agent_router.get("/{agent_id}/executions", response_model=APIResponse)
async def get_agent_executions(
    agent_id: str,
    page: int = Query(1),
    limit: int = Query(20)
):
    """Get agent execution history."""
    return APIResponse(data={
        "agent_id": agent_id,
        "executions": [],
        "total": 0,
        "page": page,
        "limit": limit
    })


@agent_router.post("/{agent_id}/configure", response_model=APIResponse)
async def configure_agent(agent_id: str, config: AgentConfigureRequest):
    """Configure agent (user-specific)."""
    return APIResponse(data={
        "agent_id": agent_id,
        "config_key": config.config_key,
        "configured": True,
        "configured_at": datetime.utcnow().isoformat()
    })


@agent_router.post("/{agent_id}/hire", response_model=APIResponse)
async def hire_agent(agent_id: str):
    """
    Hire an agent.
    
    GOVERNANCE: L0 agents cannot be hired
    """
    if agent_id.endswith("_L0"):
        raise HTTPException(
            status_code=403,
            detail="L0 system agents cannot be hired"
        )
    
    return APIResponse(data={
        "hire_id": str(uuid4()),
        "agent_id": agent_id,
        "hired": True,
        "hired_at": datetime.utcnow().isoformat()
    })


@agent_router.post("/{agent_id}/fire", response_model=APIResponse)
async def fire_agent(agent_id: str):
    """Fire (remove) an agent."""
    return APIResponse(data={
        "agent_id": agent_id,
        "fired": True,
        "fired_at": datetime.utcnow().isoformat()
    })
