"""
CHE·NU V68 - Entertainment & Media Tests
20 tests covering governance workflows
"""
import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from spheres.entertainment.agents.entertainment_agent import (
    EntertainmentAgent,
    MediaType, ContentStatus, ContentRating, PlaybackStatus, ModerationAction
)

@pytest.fixture
def agent():
    return EntertainmentAgent()


class TestContentManagement:
    
    @pytest.mark.asyncio
    async def test_add_content_creates_draft(self, agent):
        """Content starts as draft"""
        content = await agent.add_content(
            title="New Movie",
            media_type=MediaType.MOVIE,
            description="Description",
            duration_seconds=5400,
            rating=ContentRating.PG,
            genres=["Comedy"],
            user_id="user_001"
        )
        assert content.status == ContentStatus.DRAFT
        assert content.title == "New Movie"
        
    @pytest.mark.asyncio
    async def test_submit_for_review(self, agent):
        """Content can be submitted for review"""
        content = await agent.add_content(
            title="Test Movie",
            media_type=MediaType.MOVIE,
            description="A test movie",
            duration_seconds=7200,
            user_id="user_001"
        )
        result = await agent.submit_for_review(content.id, "user_001")
        assert result.status == ContentStatus.UNDER_REVIEW
        
    @pytest.mark.asyncio
    async def test_content_moderation_governance(self, agent):
        """GOVERNANCE: Content requires moderation before publishing"""
        content = await agent.add_content(
            title="Test Movie",
            media_type=MediaType.MOVIE,
            description="A test movie",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        result = await agent.moderate_content(
            content_id=content.id, 
            action=ModerationAction.APPROVE, 
            moderator_id="mod_001", 
            reason="Good"
        )
        assert result.status == ContentStatus.PUBLISHED
        
    @pytest.mark.asyncio
    async def test_content_rejection(self, agent):
        """Content can be rejected"""
        content = await agent.add_content(
            title="Test Movie",
            media_type=MediaType.MOVIE,
            description="A test movie",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        result = await agent.moderate_content(
            content_id=content.id,
            action=ModerationAction.REJECT, 
            moderator_id="mod_001", 
            reason="Bad"
        )
        assert result.status == ContentStatus.DRAFT


class TestTVShows:
    
    @pytest.mark.asyncio
    async def test_create_show(self, agent):
        """Can create TV show"""
        show = await agent.create_show(
            title="Test Series",
            description="A test TV series",
            rating=ContentRating.PG13,
            genres=["Drama"],
            user_id="user_001"
        )
        assert show.title == "Test Series"
        
    @pytest.mark.asyncio
    async def test_add_season(self, agent):
        """Can add seasons to show"""
        show = await agent.create_show(
            title="Test Show",
            description="Desc",
            rating=ContentRating.PG,
            genres=["Drama"],
            
        )
        season = await agent.add_season(
            show_id=show.id,
            season_number=1,
            title="Season One",
            
        )
        assert season.season_number == 1


class TestPlaylists:
    
    @pytest.mark.asyncio
    async def test_create_playlist(self, agent):
        """Can create playlist"""
        playlist = await agent.create_playlist(
            name="Favorites",
            description="Best movies",
            owner_id="user_001",
            is_public=False
        )
        assert playlist.name == "Favorites"
        assert playlist.is_public == False
        
    @pytest.mark.asyncio
    async def test_playlists_alphabetical_rule5(self, agent):
        """RULE 5: Playlists listed alphabetically"""
        await agent.create_playlist(name="Zebra", description="Desc", owner_id="user_001", is_public=True)
        await agent.create_playlist(name="Alpha", description="Desc", owner_id="user_001", is_public=True)
        await agent.create_playlist(name="Mango", description="Desc", owner_id="user_001", is_public=True)
        
        playlists = await agent.get_public_playlists()
        names = [p.name for p in playlists]
        assert names == sorted(names), "Playlists must be alphabetical (Rule #5)"


class TestWatchHistory:
    
    @pytest.mark.asyncio
    async def test_record_watch_progress(self, agent):
        """Can record watch progress"""
        content = await agent.add_content(
            title="Test", media_type=MediaType.MOVIE, 
            description="Test", duration_seconds=7200, user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        history = await agent.record_watch_progress(
            user_id="user_001",
            
            content_id=content.id,
            progress_seconds=1800
        )
        assert history.progress_seconds == 1800


class TestWatchlist:
    
    @pytest.mark.asyncio
    async def test_add_to_watchlist(self, agent):
        """Can add content to watchlist"""
        content = await agent.add_content(
            title="Test", media_type=MediaType.MOVIE,
            description="Test", duration_seconds=7200, user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        result = await agent.add_to_watchlist(user_id="user_001", content_id=content.id)
        assert result is not None


class TestWatchParty:
    
    @pytest.mark.asyncio
    async def test_create_watch_party(self, agent):
        """Can create watch party"""
        content = await agent.add_content(
            title="Test", media_type=MediaType.MOVIE,
            description="Test", duration_seconds=7200, user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        party = await agent.create_watch_party(
            content_id=content.id,
            host_id="user_001",
            
            max_participants=10
        )
        assert party.host_id == "user_001"


class TestReviews:
    
    @pytest.mark.asyncio
    async def test_submit_review_pending(self, agent):
        """Reviews start as pending moderation"""
        content = await agent.add_content(
            title="Test", media_type=MediaType.MOVIE,
            description="Test", duration_seconds=7200, user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        review = await agent.submit_review(
            user_id="user_001",
            user_name="Test User",
            content_id=content.id,
            rating=4,
            title="Great!",
            text="Text"
        )
        assert review.status == ContentStatus.UNDER_REVIEW


class TestChannels:
    
    @pytest.mark.asyncio
    async def test_create_channel(self, agent):
        """Can create channel"""
        channel = await agent.create_channel(
            name="My Channel",
            description="Test channel",
            owner_id="user_001"
        )
        assert channel.name == "My Channel"
        
    @pytest.mark.asyncio
    async def test_channels_alphabetical_rule5(self, agent):
        """RULE 5: Channels alphabetical"""
        await agent.create_channel("Zebra Channel", "Desc", "user_001")
        await agent.create_channel("Alpha Channel", "Desc", "user_002")
        await agent.create_channel("Beta Channel", "Desc", "user_003")
        
        channels = await agent.get_channels()
        names = [c.name for c in channels]
        assert names == sorted(names), "Channels must be alphabetical (Rule #5)"


class TestLibraryAndSearch:
    
    @pytest.mark.asyncio
    async def test_search_chronological_rule5(self, agent):
        """RULE 5: Search results chronological"""
        content = await agent.add_content(
            title="Test Movie", media_type=MediaType.MOVIE,
            description="Test", duration_seconds=7200, user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        results = await agent.search_content("Test")
        assert isinstance(results, list)


class TestAnalytics:
    
    @pytest.mark.asyncio
    async def test_get_library_stats(self, agent):
        """Can get library statistics"""
        stats = await agent.get_library_stats()
        assert "total_content" in stats


class TestHealthCheck:
    
    @pytest.mark.asyncio
    async def test_health_check(self, agent):
        """Agent health check passes"""
        health = await agent.get_health()
        assert health["status"] == "healthy"


# ============================================================================
# NEW TESTS - V71 Coverage Expansion
# ============================================================================

class TestEpisodes:
    """Tests for TV show episodes management."""
    
    @pytest.mark.asyncio
    async def test_add_episode(self, agent):
        """Can add episodes to a season"""
        show = await agent.create_show(
            title="Test Show",
            description="A test show",
            rating=ContentRating.PG,
            genres=["Drama"]
        )
        season = await agent.add_season(
            show_id=show.id,
            season_number=1,
            title="Season One"
        )
        episode = await agent.add_episode(
            show_id=show.id,
            season_id=season.id,
            episode_number=1,
            title="Pilot",
            description="First episode",
            duration_seconds=2700
        )
        assert episode.episode_number == 1
        assert episode.title == "Pilot"
        
    @pytest.mark.asyncio
    async def test_get_show_episodes(self, agent):
        """Can retrieve episodes for a show"""
        show = await agent.create_show(
            title="Episode Test Show",
            description="Show for testing episodes",
            rating=ContentRating.PG13,
            genres=["Comedy"]
        )
        season = await agent.add_season(
            show_id=show.id,
            season_number=1,
            title="Season One"
        )
        await agent.add_episode(
            show_id=show.id,
            season_id=season.id,
            episode_number=1,
            title="Episode 1",
            description="First",
            duration_seconds=1800
        )
        await agent.add_episode(
            show_id=show.id,
            season_id=season.id,
            episode_number=2,
            title="Episode 2",
            description="Second",
            duration_seconds=1800
        )
        episodes = await agent.get_show_episodes(show.id)
        assert len(episodes) >= 2


class TestPlaylistOperations:
    """Tests for playlist item management."""
    
    @pytest.mark.asyncio
    async def test_add_to_playlist(self, agent):
        """Can add content to playlist"""
        # Create and publish content
        content = await agent.add_content(
            title="Playlist Test Movie",
            media_type=MediaType.MOVIE,
            description="For playlist test",
            duration_seconds=5400,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        # Create playlist and add content
        playlist = await agent.create_playlist(
            name="Test Playlist",
            description="Test",
            owner_id="user_001",
            is_public=False
        )
        updated = await agent.add_to_playlist(playlist.id, content.id, "user_001")
        assert content.id in updated.items
        
    @pytest.mark.asyncio
    async def test_remove_from_playlist(self, agent):
        """Can remove content from playlist"""
        content = await agent.add_content(
            title="Remove Test Movie",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        playlist = await agent.create_playlist(
            name="Remove Test",
            description="Test",
            owner_id="user_001",
            is_public=False
        )
        await agent.add_to_playlist(playlist.id, content.id, "user_001")
        updated = await agent.remove_from_playlist(playlist.id, content.id, "user_001")
        assert content.id not in updated.items
        
    @pytest.mark.asyncio
    async def test_get_user_playlists(self, agent):
        """Can get user's playlists - RULE #5 alphabetical"""
        await agent.create_playlist(name="Zebra List", description="Z", owner_id="user_playlist_001", is_public=False)
        await agent.create_playlist(name="Alpha List", description="A", owner_id="user_playlist_001", is_public=False)
        
        playlists = await agent.get_user_playlists("user_playlist_001")
        names = [p.name for p in playlists]
        assert names == sorted(names), "User playlists must be alphabetical (Rule #5)"


class TestWatchHistoryOperations:
    """Tests for watch history operations."""
    
    @pytest.mark.asyncio
    async def test_get_watch_history(self, agent):
        """Can get watch history - CHRONOLOGICAL"""
        content = await agent.add_content(
            title="History Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        await agent.record_watch_progress("history_user", content.id, 1800)
        
        history = await agent.get_watch_history("history_user")
        assert isinstance(history, list)
        
    @pytest.mark.asyncio
    async def test_get_continue_watching(self, agent):
        """Can get in-progress content"""
        content = await agent.add_content(
            title="Continue Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        await agent.record_watch_progress("continue_user", content.id, 3600)  # 50% progress
        
        continue_watching = await agent.get_continue_watching("continue_user")
        assert isinstance(continue_watching, list)


class TestWatchlistOperations:
    """Tests for watchlist management."""
    
    @pytest.mark.asyncio
    async def test_remove_from_watchlist(self, agent):
        """Can remove content from watchlist"""
        content = await agent.add_content(
            title="Watchlist Remove Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        await agent.add_to_watchlist("wl_user", content.id)
        watchlist = await agent.remove_from_watchlist("wl_user", content.id)
        assert content.id not in watchlist.content_ids
        
    @pytest.mark.asyncio
    async def test_get_watchlist(self, agent):
        """Can get watchlist contents"""
        content = await agent.add_content(
            title="Watchlist Get Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        await agent.add_to_watchlist("wl_get_user", content.id)
        
        items = await agent.get_watchlist("wl_get_user")
        assert len(items) >= 1


class TestWatchPartyOperations:
    """Tests for watch party operations."""
    
    @pytest.mark.asyncio
    async def test_join_watch_party(self, agent):
        """Can join a watch party"""
        content = await agent.add_content(
            title="Party Join Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        party = await agent.create_watch_party(
            content_id=content.id,
            host_id="host_001",
            max_participants=5
        )
        updated = await agent.join_watch_party(party.id, "guest_001")
        assert "guest_001" in updated.participants
        
    @pytest.mark.asyncio
    async def test_leave_watch_party(self, agent):
        """Can leave a watch party"""
        content = await agent.add_content(
            title="Party Leave Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        party = await agent.create_watch_party(
            content_id=content.id,
            host_id="host_002",
            max_participants=5
        )
        await agent.join_watch_party(party.id, "guest_002")
        updated = await agent.leave_watch_party(party.id, "guest_002")
        assert "guest_002" not in updated.participants
        
    @pytest.mark.asyncio
    async def test_control_watch_party(self, agent):
        """Host can control watch party playback"""
        content = await agent.add_content(
            title="Party Control Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        party = await agent.create_watch_party(
            content_id=content.id,
            host_id="host_003",
            max_participants=5
        )
        updated = await agent.control_watch_party(party.id, "host_003", "play")
        assert updated.is_playing == True
        
    @pytest.mark.asyncio
    async def test_get_active_watch_parties(self, agent):
        """Can get active watch parties - CHRONOLOGICAL"""
        content = await agent.add_content(
            title="Active Party Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        await agent.create_watch_party(content_id=content.id, host_id="host_004", max_participants=10)
        
        parties = await agent.get_active_watch_parties()
        assert isinstance(parties, list)


class TestReviewModeration:
    """Tests for review moderation workflow."""
    
    @pytest.mark.asyncio
    async def test_moderate_review_approve(self, agent):
        """GOVERNANCE: Reviews require moderation before publishing"""
        content = await agent.add_content(
            title="Review Mod Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        review = await agent.submit_review(
            user_id="reviewer_001",
            user_name="Test Reviewer",
            content_id=content.id,
            rating=5,
            title="Great!",
            text="Amazing movie"
        )
        moderated = await agent.moderate_review(review.id, ModerationAction.APPROVE, "mod_002")
        assert moderated.status == ContentStatus.PUBLISHED
        
    @pytest.mark.asyncio
    async def test_get_content_reviews(self, agent):
        """Can get reviews for content - CHRONOLOGICAL (Rule #5)"""
        content = await agent.add_content(
            title="Review List Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        await agent.submit_review(
            user_id="rev_001",
            user_name="Reviewer 1",
            content_id=content.id,
            rating=4,
            title="Good",
            text="Nice"
        )
        reviews = await agent.get_content_reviews(content.id)
        assert isinstance(reviews, list)
        
    @pytest.mark.asyncio
    async def test_get_pending_moderation(self, agent):
        """Can get pending moderation requests"""
        requests = await agent.get_pending_moderation()
        assert isinstance(requests, list)


class TestContentLibrary:
    """Tests for content library operations."""
    
    @pytest.mark.asyncio
    async def test_get_content_by_id(self, agent):
        """Can get single content item"""
        content = await agent.add_content(
            title="Get Content Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            user_id="user_001"
        )
        retrieved = await agent.get_content(content.id)
        assert retrieved.id == content.id
        
    @pytest.mark.asyncio
    async def test_get_content_library(self, agent):
        """Can get content library - CHRONOLOGICAL (Rule #5)"""
        await agent.add_content(
            title="Library Test 1",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            user_id="user_001"
        )
        library = await agent.get_content_library()
        assert isinstance(library, list)
        
    @pytest.mark.asyncio
    async def test_get_recommendations_chronological_rule5(self, agent):
        """RULE #5: Recommendations are chronological, NOT engagement-based"""
        content = await agent.add_content(
            title="Reco Test",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=7200,
            user_id="user_001"
        )
        await agent.submit_for_review(content.id, "user_001")
        await agent.moderate_content(content.id, ModerationAction.APPROVE, "mod_001")
        
        recommendations = await agent.get_recommendations("reco_user")
        # Should return chronological list, not personalized by engagement
        assert isinstance(recommendations, list)
        
    @pytest.mark.asyncio
    async def test_get_new_releases(self, agent):
        """Can get new releases"""
        releases = await agent.get_new_releases()
        assert isinstance(releases, list)
        
    @pytest.mark.asyncio
    async def test_get_genre_content(self, agent):
        """Can get content by genre - CHRONOLOGICAL"""
        await agent.add_content(
            title="Genre Test Movie",
            media_type=MediaType.MOVIE,
            description="Test",
            duration_seconds=5400,
            genres=["Action"],
            user_id="user_001"
        )
        content = await agent.get_genre_content("Action")
        assert isinstance(content, list)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
