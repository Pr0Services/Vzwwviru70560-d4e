"""
CHE·NU™ V70 — MODULE 32: COLLAPSE PREVENTION ENGINE (CPE)
=========================================================
Détecte l'effondrement silencieux avant l'échec visible.

Types d'effondrement:
- Cognitive
- Social  
- Symbolic

Canon Rule: Un système qui ignore le silence s'effondre déjà.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.module_32")


class CollapseType(str, Enum):
    """Types d'effondrement."""
    COGNITIVE = "cognitive"  # Mental overload
    SOCIAL = "social"  # Community fragmentation
    SYMBOLIC = "symbolic"  # Loss of meaning


class CollapseStage(str, Enum):
    """Stades d'effondrement."""
    HEALTHY = "healthy"
    EARLY_WARNING = "early_warning"
    DEVELOPING = "developing"
    CRITICAL = "critical"
    COLLAPSE = "collapse"


class ActionType(str, Enum):
    """Types d'actions préventives."""
    SLOW_EXPANSION = "slow_expansion"
    MEANING_REALIGNMENT = "meaning_realignment"
    COHESION_PROTECTION = "cohesion_protection"
    EMERGENCY_STABILIZATION = "emergency_stabilization"


@dataclass
class CollapseIndicator:
    """Indicateur d'effondrement."""
    indicator_id: str = field(default_factory=lambda: f"IND_{uuid4().hex[:8]}")
    collapse_type: CollapseType = CollapseType.COGNITIVE
    
    # Metrics
    current_value: float = 0.0
    threshold_warning: float = 0.5
    threshold_critical: float = 0.8
    
    # Trend
    trend_direction: str = "stable"  # improving, stable, degrading
    trend_velocity: float = 0.0


@dataclass
class CollapseAlert:
    """Alerte d'effondrement."""
    alert_id: str = field(default_factory=lambda: f"COLLAPSE_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Alert details
    entity_id: str = ""  # Community, user, system
    collapse_type: CollapseType = CollapseType.COGNITIVE
    stage: CollapseStage = CollapseStage.EARLY_WARNING
    
    # Cause
    triggered_by: list[str] = field(default_factory=list)
    root_cause_analysis: str = ""
    
    # Response
    recommended_actions: list[ActionType] = field(default_factory=list)
    action_taken: Optional[ActionType] = None
    resolved: bool = False


@dataclass
class PreventiveAction:
    """Action préventive."""
    action_id: str = field(default_factory=lambda: f"PREVENT_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    action_type: ActionType = ActionType.SLOW_EXPANSION
    target_entity: str = ""
    alert_id: str = ""
    
    # Execution
    executed: bool = False
    executed_at: Optional[datetime] = None
    effectiveness: float = 0.0  # 0-1


class CollapsePreventionEngine:
    """
    Module 32 — Collapse Prevention Engine
    
    Détecte l'effondrement silencieux avant l'échec visible.
    
    Action Logic:
    - Slow expansion
    - Trigger meaning re-alignment
    - Protect cohesion
    
    Canon Rule: A system that ignores silence is already collapsing.
    """
    
    # Detection thresholds
    COGNITIVE_OVERLOAD_THRESHOLD = 0.7
    SOCIAL_FRAGMENTATION_THRESHOLD = 0.6
    SYMBOLIC_VOID_THRESHOLD = 0.5
    
    def __init__(self, meaning_engine: Optional[Any] = None):
        self.engine_id = f"CPE_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        self.meaning_engine = meaning_engine
        
        self._indicators: dict[str, CollapseIndicator] = {}
        self._alerts: dict[str, CollapseAlert] = {}
        self._actions: dict[str, PreventiveAction] = {}
        
        logger.info(f"Collapse Prevention Engine initialized: {self.engine_id}")
    
    def monitor_entity(
        self,
        entity_id: str,
        cognitive_load: float,
        social_cohesion: float,
        symbolic_meaning: float,
    ) -> list[CollapseAlert]:
        """
        Monitor an entity for collapse indicators.
        Returns alerts if any threshold is breached.
        """
        alerts = []
        
        # Cognitive collapse check
        if cognitive_load > self.COGNITIVE_OVERLOAD_THRESHOLD:
            alert = self._create_alert(
                entity_id,
                CollapseType.COGNITIVE,
                cognitive_load,
                self.COGNITIVE_OVERLOAD_THRESHOLD,
            )
            alerts.append(alert)
        
        # Social collapse check (inverted - low cohesion is bad)
        if social_cohesion < self.SOCIAL_FRAGMENTATION_THRESHOLD:
            alert = self._create_alert(
                entity_id,
                CollapseType.SOCIAL,
                1 - social_cohesion,  # Invert for consistency
                1 - self.SOCIAL_FRAGMENTATION_THRESHOLD,
            )
            alerts.append(alert)
        
        # Symbolic collapse check (inverted - low meaning is bad)
        if symbolic_meaning < self.SYMBOLIC_VOID_THRESHOLD:
            alert = self._create_alert(
                entity_id,
                CollapseType.SYMBOLIC,
                1 - symbolic_meaning,
                1 - self.SYMBOLIC_VOID_THRESHOLD,
            )
            alerts.append(alert)
        
        return alerts
    
    def _create_alert(
        self,
        entity_id: str,
        collapse_type: CollapseType,
        value: float,
        threshold: float,
    ) -> CollapseAlert:
        """Create a collapse alert."""
        # Determine stage
        if value >= 0.9:
            stage = CollapseStage.COLLAPSE
        elif value >= 0.8:
            stage = CollapseStage.CRITICAL
        elif value >= 0.7:
            stage = CollapseStage.DEVELOPING
        else:
            stage = CollapseStage.EARLY_WARNING
        
        # Determine recommended actions
        actions = self._recommend_actions(collapse_type, stage)
        
        alert = CollapseAlert(
            entity_id=entity_id,
            collapse_type=collapse_type,
            stage=stage,
            triggered_by=[f"{collapse_type.value}_threshold_breached"],
            recommended_actions=actions,
        )
        
        self._alerts[alert.alert_id] = alert
        logger.warning(f"Collapse alert: {alert.alert_id} - {collapse_type.value} - {stage.value}")
        
        return alert
    
    def _recommend_actions(
        self, 
        collapse_type: CollapseType, 
        stage: CollapseStage
    ) -> list[ActionType]:
        """Recommend preventive actions."""
        actions = []
        
        # All collapses benefit from slowing
        if stage in [CollapseStage.CRITICAL, CollapseStage.COLLAPSE]:
            actions.append(ActionType.EMERGENCY_STABILIZATION)
        
        actions.append(ActionType.SLOW_EXPANSION)
        
        # Type-specific actions
        if collapse_type == CollapseType.COGNITIVE:
            pass  # Slow expansion handles this
        elif collapse_type == CollapseType.SOCIAL:
            actions.append(ActionType.COHESION_PROTECTION)
        elif collapse_type == CollapseType.SYMBOLIC:
            actions.append(ActionType.MEANING_REALIGNMENT)
        
        return actions
    
    def execute_action(
        self,
        alert_id: str,
        action_type: ActionType,
    ) -> PreventiveAction:
        """Execute a preventive action."""
        alert = self._alerts.get(alert_id)
        if not alert:
            raise ValueError(f"Alert not found: {alert_id}")
        
        action = PreventiveAction(
            action_type=action_type,
            target_entity=alert.entity_id,
            alert_id=alert_id,
            executed=True,
            executed_at=datetime.utcnow(),
        )
        
        # Execute based on type
        if action_type == ActionType.SLOW_EXPANSION:
            action.effectiveness = 0.6
        elif action_type == ActionType.MEANING_REALIGNMENT:
            action.effectiveness = self._trigger_meaning_realignment(alert.entity_id)
        elif action_type == ActionType.COHESION_PROTECTION:
            action.effectiveness = 0.7
        elif action_type == ActionType.EMERGENCY_STABILIZATION:
            action.effectiveness = 0.8
        
        # Update alert
        alert.action_taken = action_type
        if action.effectiveness > 0.5:
            alert.resolved = True
        
        self._actions[action.action_id] = action
        logger.info(f"Preventive action executed: {action.action_id}")
        
        return action
    
    def _trigger_meaning_realignment(self, entity_id: str) -> float:
        """Trigger meaning realignment via Module 33."""
        if self.meaning_engine:
            try:
                result = self.meaning_engine.realign_meaning(entity_id)
                return result.get("effectiveness", 0.5)
            except Exception as e:
                logger.error(f"Meaning realignment error: {e}")
        return 0.5
    
    def detect_silent_collapse(self, entity_id: str) -> Optional[CollapseAlert]:
        """
        Detect SILENT collapse - the most dangerous kind.
        This occurs when metrics look fine but underlying health is degrading.
        """
        # Check for absence of activity (silence)
        # This is a heuristic - real impl would have more sophisticated detection
        
        recent_alerts = [
            a for a in self._alerts.values()
            if a.entity_id == entity_id and not a.resolved
        ]
        
        if not recent_alerts:
            # No alerts might mean silence - check deeper
            # For now, return None (no silent collapse detected)
            return None
        
        return None
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        critical_alerts = sum(
            1 for a in self._alerts.values()
            if a.stage == CollapseStage.CRITICAL and not a.resolved
        )
        return {
            "engine_id": self.engine_id,
            "total_alerts": len(self._alerts),
            "active_alerts": sum(1 for a in self._alerts.values() if not a.resolved),
            "critical_alerts": critical_alerts,
            "actions_executed": len(self._actions),
        }
