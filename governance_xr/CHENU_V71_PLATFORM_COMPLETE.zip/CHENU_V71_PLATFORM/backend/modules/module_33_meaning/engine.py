"""
CHE·NU™ V70 — MODULE 33: MEANING & PURPOSE MAPPING (MPM)
========================================================
Mappe les actions au sens.

Axes:
- Purpose individuel
- Narrative collectif
- Héritage temporel

Canon Rule: Ce qui manque de sens aujourd'hui devient dette demain.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.module_33")


class MeaningAxis(str, Enum):
    """Axes de sens."""
    INDIVIDUAL_PURPOSE = "individual_purpose"
    COLLECTIVE_NARRATIVE = "collective_narrative"
    TEMPORAL_LEGACY = "temporal_legacy"


class MeaningLevel(str, Enum):
    """Niveaux de sens."""
    HIGH = "high"
    MODERATE = "moderate"
    LOW = "low"
    VOID = "void"


@dataclass
class MeaningMap:
    """Carte de sens pour une entité ou projet."""
    map_id: str = field(default_factory=lambda: f"MEANING_{uuid4().hex[:8]}")
    entity_id: str = ""
    entity_type: str = ""  # project, action, community
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Axis scores (0-1)
    individual_purpose_score: float = 0.0
    collective_narrative_score: float = 0.0
    temporal_legacy_score: float = 0.0
    
    # Overall
    overall_meaning_score: float = 0.0
    meaning_level: MeaningLevel = MeaningLevel.LOW
    
    # Details
    purpose_description: str = ""
    narrative_link: str = ""
    legacy_projection: str = ""
    
    # Validation
    validated: bool = False


@dataclass
class MeaningDebt:
    """Dette de sens - quand une action manque de sens."""
    debt_id: str = field(default_factory=lambda: f"DEBT_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    entity_id: str = ""
    missing_axis: MeaningAxis = MeaningAxis.INDIVIDUAL_PURPOSE
    debt_severity: float = 0.0  # 0-1
    
    # Resolution
    resolved: bool = False
    resolution_path: Optional[str] = None


@dataclass
class ScalabilityCheck:
    """Vérification de scalabilité basée sur le sens."""
    check_id: str = field(default_factory=lambda: f"SCALE_{uuid4().hex[:8]}")
    project_id: str = ""
    
    # Results
    can_scale: bool = False
    blocking_reason: Optional[str] = None
    meaning_score_required: float = 0.6
    current_score: float = 0.0


class MeaningPurposeMappingEngine:
    """
    Module 33 — Meaning & Purpose Mapping
    
    Maps actions to meaning across three axes:
    - Individual purpose
    - Collective narrative
    - Temporal legacy
    
    Enforcement: Projects without meaning cannot scale.
    
    Canon Rule: What lacks meaning today becomes debt tomorrow.
    """
    
    # Thresholds
    HIGH_MEANING_THRESHOLD = 0.8
    MODERATE_MEANING_THRESHOLD = 0.5
    LOW_MEANING_THRESHOLD = 0.3
    SCALE_MINIMUM_SCORE = 0.6
    
    def __init__(self):
        self.engine_id = f"MPM_{uuid4().hex[:8]}"
        self.created_at = datetime.utcnow()
        
        self._meaning_maps: dict[str, MeaningMap] = {}
        self._debts: dict[str, MeaningDebt] = {}
        
        logger.info(f"Meaning & Purpose Mapping Engine initialized: {self.engine_id}")
    
    def map_meaning(
        self,
        entity_id: str,
        entity_type: str,
        individual_purpose: float,
        collective_narrative: float,
        temporal_legacy: float,
        purpose_description: str = "",
    ) -> MeaningMap:
        """
        Create a meaning map for an entity.
        """
        meaning_map = MeaningMap(
            entity_id=entity_id,
            entity_type=entity_type,
            individual_purpose_score=individual_purpose,
            collective_narrative_score=collective_narrative,
            temporal_legacy_score=temporal_legacy,
            purpose_description=purpose_description,
        )
        
        # Calculate overall score
        meaning_map.overall_meaning_score = (
            individual_purpose * 0.3 +
            collective_narrative * 0.4 +
            temporal_legacy * 0.3
        )
        
        # Determine level
        meaning_map.meaning_level = self._get_meaning_level(
            meaning_map.overall_meaning_score
        )
        
        # Check for meaning debt
        self._check_meaning_debt(meaning_map)
        
        self._meaning_maps[meaning_map.map_id] = meaning_map
        logger.info(f"Meaning mapped: {meaning_map.map_id} - {meaning_map.meaning_level.value}")
        
        return meaning_map
    
    def _get_meaning_level(self, score: float) -> MeaningLevel:
        """Get meaning level from score."""
        if score >= self.HIGH_MEANING_THRESHOLD:
            return MeaningLevel.HIGH
        elif score >= self.MODERATE_MEANING_THRESHOLD:
            return MeaningLevel.MODERATE
        elif score >= self.LOW_MEANING_THRESHOLD:
            return MeaningLevel.LOW
        return MeaningLevel.VOID
    
    def _check_meaning_debt(self, meaning_map: MeaningMap) -> None:
        """Check for meaning debt on any axis."""
        axes = [
            (MeaningAxis.INDIVIDUAL_PURPOSE, meaning_map.individual_purpose_score),
            (MeaningAxis.COLLECTIVE_NARRATIVE, meaning_map.collective_narrative_score),
            (MeaningAxis.TEMPORAL_LEGACY, meaning_map.temporal_legacy_score),
        ]
        
        for axis, score in axes:
            if score < self.LOW_MEANING_THRESHOLD:
                debt = MeaningDebt(
                    entity_id=meaning_map.entity_id,
                    missing_axis=axis,
                    debt_severity=1 - score,
                )
                self._debts[debt.debt_id] = debt
                logger.warning(f"Meaning debt created: {debt.debt_id} - {axis.value}")
    
    def check_scalability(self, project_id: str) -> ScalabilityCheck:
        """
        Check if a project can scale based on meaning.
        
        Enforcement: Projects without meaning cannot scale.
        """
        check = ScalabilityCheck(project_id=project_id)
        
        # Find project's meaning map
        project_map = None
        for m in self._meaning_maps.values():
            if m.entity_id == project_id:
                project_map = m
                break
        
        if not project_map:
            check.can_scale = False
            check.blocking_reason = "No meaning map found for project"
            return check
        
        check.current_score = project_map.overall_meaning_score
        check.meaning_score_required = self.SCALE_MINIMUM_SCORE
        
        if project_map.overall_meaning_score >= self.SCALE_MINIMUM_SCORE:
            check.can_scale = True
        else:
            check.can_scale = False
            check.blocking_reason = (
                f"Meaning score {project_map.overall_meaning_score:.2f} "
                f"below minimum {self.SCALE_MINIMUM_SCORE}"
            )
        
        return check
    
    def realign_meaning(
        self,
        entity_id: str,
        enhancement_suggestions: dict[str, str] = None,
    ) -> dict[str, Any]:
        """
        Realign meaning for an entity (called by Collapse Prevention).
        """
        # Find entity's meaning map
        entity_map = None
        for m in self._meaning_maps.values():
            if m.entity_id == entity_id:
                entity_map = m
                break
        
        if not entity_map:
            return {"effectiveness": 0.0, "error": "No meaning map found"}
        
        # Simulate realignment
        effectiveness = 0.0
        
        # Boost lowest score
        scores = [
            ("individual", entity_map.individual_purpose_score),
            ("collective", entity_map.collective_narrative_score),
            ("temporal", entity_map.temporal_legacy_score),
        ]
        lowest = min(scores, key=lambda x: x[1])
        
        if lowest[1] < 0.5:
            # There's room for improvement
            effectiveness = 0.3 + (0.5 - lowest[1])
        else:
            effectiveness = 0.2
        
        # Resolve related debts
        for debt in self._debts.values():
            if debt.entity_id == entity_id and not debt.resolved:
                debt.resolved = True
                debt.resolution_path = "realignment"
                effectiveness += 0.1
        
        return {
            "effectiveness": min(effectiveness, 1.0),
            "entity_id": entity_id,
            "lowest_axis": lowest[0],
        }
    
    def get_meaning_debts(self, entity_id: str = None) -> list[MeaningDebt]:
        """Get meaning debts, optionally filtered by entity."""
        if entity_id:
            return [d for d in self._debts.values() if d.entity_id == entity_id and not d.resolved]
        return [d for d in self._debts.values() if not d.resolved]
    
    def get_stats(self) -> dict[str, Any]:
        """Get engine statistics."""
        void_maps = sum(
            1 for m in self._meaning_maps.values()
            if m.meaning_level == MeaningLevel.VOID
        )
        return {
            "engine_id": self.engine_id,
            "meaning_maps": len(self._meaning_maps),
            "void_meaning_count": void_maps,
            "active_debts": sum(1 for d in self._debts.values() if not d.resolved),
            "average_meaning_score": (
                sum(m.overall_meaning_score for m in self._meaning_maps.values()) /
                len(self._meaning_maps) if self._meaning_maps else 0
            ),
        }
