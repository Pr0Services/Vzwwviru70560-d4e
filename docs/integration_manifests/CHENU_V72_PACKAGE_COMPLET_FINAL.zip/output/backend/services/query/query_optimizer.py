"""
CHE·NU™ V72 — Query Optimization Utilities

SQLAlchemy query optimization patterns for performance:
- Cursor-based pagination (no offset)
- Eager loading strategies
- Query result caching
- N+1 query prevention
- Performance monitoring

R&D Compliance:
- Rule #3: All queries scoped by identity
- Rule #6: Query performance logged
"""

from typing import (
    Optional, Any, Dict, List, Type, TypeVar, Generic,
    Callable, Tuple, Union, Sequence
)
from datetime import datetime
from uuid import UUID
import time
import logging
from dataclasses import dataclass, field
from enum import Enum
from contextlib import asynccontextmanager

from sqlalchemy import select, func, and_, or_, desc, asc, text
from sqlalchemy.orm import (
    selectinload, joinedload, subqueryload,
    Load, contains_eager
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import Select

logger = logging.getLogger(__name__)

# Type variable for generic model
T = TypeVar('T')


# ==================== Pagination ====================

class PaginationStrategy(str, Enum):
    """Pagination strategies."""
    CURSOR = "cursor"      # Recommended - O(1) for any page
    OFFSET = "offset"      # Simple but O(n) for deep pages
    KEYSET = "keyset"      # Cursor with multiple sort columns


@dataclass
class PaginationParams:
    """Pagination parameters."""
    limit: int = 20
    cursor: Optional[str] = None  # Cursor for CURSOR/KEYSET
    offset: Optional[int] = None  # Offset for OFFSET
    strategy: PaginationStrategy = PaginationStrategy.CURSOR
    
    @classmethod
    def from_request(
        cls,
        limit: int = 20,
        cursor: Optional[str] = None,
        offset: Optional[int] = None,
        page: Optional[int] = None
    ) -> 'PaginationParams':
        """Create from request parameters."""
        # Convert page to offset if provided
        if page is not None and offset is None:
            offset = (page - 1) * limit
        
        # Determine strategy
        if cursor:
            strategy = PaginationStrategy.CURSOR
        elif offset is not None:
            strategy = PaginationStrategy.OFFSET
        else:
            strategy = PaginationStrategy.CURSOR
        
        return cls(
            limit=min(limit, 100),  # Max 100 per page
            cursor=cursor,
            offset=offset,
            strategy=strategy
        )


@dataclass
class PaginatedResult(Generic[T]):
    """Paginated query result."""
    items: List[T]
    total: Optional[int] = None
    next_cursor: Optional[str] = None
    prev_cursor: Optional[str] = None
    has_more: bool = False
    page_info: Dict[str, Any] = field(default_factory=dict)


class CursorPaginator:
    """
    Cursor-based pagination using created_at + id.
    
    Benefits over offset:
    - O(1) performance for any page
    - Stable results during concurrent inserts
    - No page drift issues
    """
    
    @staticmethod
    def encode_cursor(created_at: datetime, id: UUID) -> str:
        """Encode cursor from datetime and id."""
        import base64
        cursor_data = f"{created_at.isoformat()}|{id}"
        return base64.urlsafe_b64encode(cursor_data.encode()).decode()
    
    @staticmethod
    def decode_cursor(cursor: str) -> Tuple[datetime, UUID]:
        """Decode cursor to datetime and id."""
        import base64
        cursor_data = base64.urlsafe_b64decode(cursor.encode()).decode()
        created_at_str, id_str = cursor_data.split("|")
        return datetime.fromisoformat(created_at_str), UUID(id_str)
    
    @classmethod
    def apply_cursor(
        cls,
        query: Select,
        model: Type[T],
        cursor: Optional[str] = None,
        descending: bool = True
    ) -> Select:
        """Apply cursor-based pagination to query."""
        if cursor:
            created_at, id = cls.decode_cursor(cursor)
            
            if descending:
                # For descending: get items older than cursor
                query = query.where(
                    or_(
                        model.created_at < created_at,
                        and_(
                            model.created_at == created_at,
                            model.id < id
                        )
                    )
                )
            else:
                # For ascending: get items newer than cursor
                query = query.where(
                    or_(
                        model.created_at > created_at,
                        and_(
                            model.created_at == created_at,
                            model.id > id
                        )
                    )
                )
        
        # Apply ordering
        if descending:
            query = query.order_by(desc(model.created_at), desc(model.id))
        else:
            query = query.order_by(asc(model.created_at), asc(model.id))
        
        return query
    
    @classmethod
    def get_next_cursor(cls, items: List[T]) -> Optional[str]:
        """Get cursor for next page from last item."""
        if not items:
            return None
        
        last = items[-1]
        if hasattr(last, 'created_at') and hasattr(last, 'id'):
            return cls.encode_cursor(last.created_at, last.id)
        return None


# ==================== Eager Loading ====================

class EagerLoadingStrategy(str, Enum):
    """SQLAlchemy eager loading strategies."""
    SELECTIN = "selectinload"    # Separate IN query - best for collections
    JOINED = "joinedload"        # JOIN in main query - best for single relations
    SUBQUERY = "subqueryload"    # Subquery - good for nested collections
    LAZY = "lazy"                # No eager loading


@dataclass
class RelationshipLoad:
    """Configuration for relationship loading."""
    name: str
    strategy: EagerLoadingStrategy = EagerLoadingStrategy.SELECTIN
    nested: Optional[List['RelationshipLoad']] = None


class EagerLoader:
    """
    Helper for applying eager loading patterns to prevent N+1 queries.
    """
    
    @classmethod
    def apply_loading(
        cls,
        query: Select,
        model: Type[T],
        relationships: List[RelationshipLoad]
    ) -> Select:
        """Apply eager loading options to query."""
        options = []
        
        for rel in relationships:
            option = cls._build_loading_option(model, rel)
            if option is not None:
                options.append(option)
        
        if options:
            query = query.options(*options)
        
        return query
    
    @classmethod
    def _build_loading_option(
        cls,
        model: Type[T],
        rel: RelationshipLoad
    ) -> Optional[Load]:
        """Build a single loading option, possibly nested."""
        # Get the relationship attribute
        if not hasattr(model, rel.name):
            logger.warning(f"Relationship {rel.name} not found on {model}")
            return None
        
        attr = getattr(model, rel.name)
        
        # Select loading strategy
        if rel.strategy == EagerLoadingStrategy.SELECTIN:
            option = selectinload(attr)
        elif rel.strategy == EagerLoadingStrategy.JOINED:
            option = joinedload(attr)
        elif rel.strategy == EagerLoadingStrategy.SUBQUERY:
            option = subqueryload(attr)
        else:
            return None  # Lazy loading, no option needed
        
        # Apply nested relationships
        if rel.nested:
            for nested_rel in rel.nested:
                nested_attr = getattr(attr.property.mapper.class_, nested_rel.name, None)
                if nested_attr:
                    if nested_rel.strategy == EagerLoadingStrategy.SELECTIN:
                        option = option.selectinload(nested_attr)
                    elif nested_rel.strategy == EagerLoadingStrategy.JOINED:
                        option = option.joinedload(nested_attr)
        
        return option


# ==================== Common Query Patterns ====================

# Thread with events (prevent N+1)
THREAD_WITH_EVENTS = [
    RelationshipLoad("events", EagerLoadingStrategy.SELECTIN),
    RelationshipLoad("actions", EagerLoadingStrategy.SELECTIN),
    RelationshipLoad("decisions", EagerLoadingStrategy.SELECTIN),
]

# Thread with latest snapshot only
THREAD_WITH_SNAPSHOT = [
    RelationshipLoad("latest_snapshot", EagerLoadingStrategy.JOINED),
]

# Sphere with sections
SPHERE_WITH_SECTIONS = [
    RelationshipLoad("sections", EagerLoadingStrategy.SELECTIN),
]

# Agent execution with results
EXECUTION_WITH_RESULTS = [
    RelationshipLoad("results", EagerLoadingStrategy.SELECTIN),
]


# ==================== Identity-Scoped Queries ====================

class IdentityScopedQuery:
    """
    Base class for identity-scoped queries (R&D Rule #3).
    
    All queries are automatically scoped to the current user's identity.
    """
    
    def __init__(self, session: AsyncSession, identity_id: UUID):
        self.session = session
        self.identity_id = identity_id
    
    def scope_query(self, query: Select, model: Type[T]) -> Select:
        """Add identity scope to query."""
        # Check for different identity field names
        if hasattr(model, 'owner_identity_id'):
            return query.where(model.owner_identity_id == self.identity_id)
        elif hasattr(model, 'identity_id'):
            return query.where(model.identity_id == self.identity_id)
        elif hasattr(model, 'user_id'):
            return query.where(model.user_id == self.identity_id)
        else:
            logger.warning(f"No identity field found on {model.__name__}")
            return query
    
    async def get_by_id(
        self,
        model: Type[T],
        id: UUID,
        relationships: Optional[List[RelationshipLoad]] = None
    ) -> Optional[T]:
        """Get a single entity by ID with identity scope."""
        query = select(model).where(model.id == id)
        query = self.scope_query(query, model)
        
        if relationships:
            query = EagerLoader.apply_loading(query, model, relationships)
        
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def list_paginated(
        self,
        model: Type[T],
        pagination: PaginationParams,
        filters: Optional[List[Any]] = None,
        relationships: Optional[List[RelationshipLoad]] = None,
        include_total: bool = False
    ) -> PaginatedResult[T]:
        """List entities with pagination and identity scope."""
        query = select(model)
        query = self.scope_query(query, model)
        
        # Apply filters
        if filters:
            for f in filters:
                query = query.where(f)
        
        # Apply eager loading
        if relationships:
            query = EagerLoader.apply_loading(query, model, relationships)
        
        # Get total count if requested
        total = None
        if include_total:
            count_query = select(func.count()).select_from(model)
            count_query = self.scope_query(count_query, model)
            if filters:
                for f in filters:
                    count_query = count_query.where(f)
            total = await self.session.scalar(count_query)
        
        # Apply pagination
        if pagination.strategy == PaginationStrategy.CURSOR:
            query = CursorPaginator.apply_cursor(
                query, model, pagination.cursor, descending=True
            )
        else:
            query = query.order_by(desc(model.created_at))
            if pagination.offset:
                query = query.offset(pagination.offset)
        
        # Fetch one extra to check has_more
        query = query.limit(pagination.limit + 1)
        
        result = await self.session.execute(query)
        items = list(result.scalars().all())
        
        # Determine has_more and trim to limit
        has_more = len(items) > pagination.limit
        if has_more:
            items = items[:pagination.limit]
        
        # Get next cursor
        next_cursor = CursorPaginator.get_next_cursor(items) if has_more else None
        
        return PaginatedResult(
            items=items,
            total=total,
            next_cursor=next_cursor,
            has_more=has_more,
            page_info={
                "limit": pagination.limit,
                "strategy": pagination.strategy.value
            }
        )


# ==================== Query Performance Monitoring ====================

@dataclass
class QueryMetrics:
    """Metrics for a single query execution."""
    query_type: str
    model: str
    duration_ms: float
    rows_returned: int
    timestamp: datetime = field(default_factory=datetime.utcnow)
    identity_id: Optional[str] = None
    cache_hit: bool = False


class QueryPerformanceMonitor:
    """
    Monitor and log query performance.
    
    Tracks slow queries and provides insights for optimization.
    """
    
    SLOW_QUERY_THRESHOLD_MS = 100
    
    def __init__(self):
        self._metrics: List[QueryMetrics] = []
        self._slow_queries: List[QueryMetrics] = []
        self._max_metrics = 1000
    
    def record(self, metrics: QueryMetrics) -> None:
        """Record query metrics."""
        self._metrics.append(metrics)
        
        # Track slow queries
        if metrics.duration_ms > self.SLOW_QUERY_THRESHOLD_MS:
            self._slow_queries.append(metrics)
            logger.warning(
                f"Slow query detected: {metrics.model}.{metrics.query_type} "
                f"took {metrics.duration_ms:.2f}ms"
            )
        
        # Limit stored metrics
        if len(self._metrics) > self._max_metrics:
            self._metrics = self._metrics[-self._max_metrics:]
        if len(self._slow_queries) > 100:
            self._slow_queries = self._slow_queries[-100:]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get aggregated query statistics."""
        if not self._metrics:
            return {"total_queries": 0}
        
        durations = [m.duration_ms for m in self._metrics]
        
        return {
            "total_queries": len(self._metrics),
            "slow_queries": len(self._slow_queries),
            "avg_duration_ms": sum(durations) / len(durations),
            "max_duration_ms": max(durations),
            "min_duration_ms": min(durations),
            "cache_hit_rate": sum(1 for m in self._metrics if m.cache_hit) / len(self._metrics) * 100,
            "queries_by_model": self._count_by_model(),
            "slow_query_threshold_ms": self.SLOW_QUERY_THRESHOLD_MS
        }
    
    def _count_by_model(self) -> Dict[str, int]:
        """Count queries by model."""
        counts: Dict[str, int] = {}
        for m in self._metrics:
            counts[m.model] = counts.get(m.model, 0) + 1
        return counts
    
    def get_slow_queries(self) -> List[Dict[str, Any]]:
        """Get list of slow queries for analysis."""
        return [
            {
                "query_type": m.query_type,
                "model": m.model,
                "duration_ms": m.duration_ms,
                "timestamp": m.timestamp.isoformat()
            }
            for m in self._slow_queries[-20:]  # Last 20
        ]
    
    def clear(self) -> None:
        """Clear all metrics."""
        self._metrics.clear()
        self._slow_queries.clear()


# Singleton monitor
_performance_monitor = QueryPerformanceMonitor()


def get_performance_monitor() -> QueryPerformanceMonitor:
    """Get the singleton performance monitor."""
    return _performance_monitor


@asynccontextmanager
async def monitored_query(
    query_type: str,
    model_name: str,
    identity_id: Optional[UUID] = None
):
    """
    Context manager for monitoring query performance.
    
    Usage:
        async with monitored_query("list", "Thread", user_id) as ctx:
            result = await session.execute(query)
            ctx.set_rows(len(result.all()))
    """
    start_time = time.perf_counter()
    rows = 0
    cache_hit = False
    
    class QueryContext:
        def set_rows(self, count: int):
            nonlocal rows
            rows = count
        
        def set_cache_hit(self, hit: bool):
            nonlocal cache_hit
            cache_hit = hit
    
    ctx = QueryContext()
    
    try:
        yield ctx
    finally:
        duration_ms = (time.perf_counter() - start_time) * 1000
        
        metrics = QueryMetrics(
            query_type=query_type,
            model=model_name,
            duration_ms=duration_ms,
            rows_returned=rows,
            identity_id=str(identity_id) if identity_id else None,
            cache_hit=cache_hit
        )
        
        _performance_monitor.record(metrics)


# ==================== Batch Operations ====================

class BatchLoader:
    """
    Batch loading utilities to prevent N+1 queries in loops.
    """
    
    @classmethod
    async def load_by_ids(
        cls,
        session: AsyncSession,
        model: Type[T],
        ids: List[UUID],
        identity_id: Optional[UUID] = None,
        relationships: Optional[List[RelationshipLoad]] = None
    ) -> Dict[UUID, T]:
        """Load multiple entities by ID in a single query."""
        if not ids:
            return {}
        
        query = select(model).where(model.id.in_(ids))
        
        # Apply identity scope if provided
        if identity_id:
            if hasattr(model, 'owner_identity_id'):
                query = query.where(model.owner_identity_id == identity_id)
            elif hasattr(model, 'user_id'):
                query = query.where(model.user_id == identity_id)
        
        # Apply eager loading
        if relationships:
            query = EagerLoader.apply_loading(query, model, relationships)
        
        result = await session.execute(query)
        items = result.scalars().all()
        
        return {item.id: item for item in items}
    
    @classmethod
    async def load_related(
        cls,
        session: AsyncSession,
        model: Type[T],
        parent_model: Type,
        parent_id: UUID,
        relationship_name: str,
        identity_id: Optional[UUID] = None
    ) -> List[T]:
        """Load related entities for a parent."""
        # Get the foreign key name
        fk_name = f"{parent_model.__tablename__}_id"
        
        query = select(model)
        
        if hasattr(model, fk_name):
            query = query.where(getattr(model, fk_name) == parent_id)
        
        # Apply identity scope
        if identity_id:
            if hasattr(model, 'owner_identity_id'):
                query = query.where(model.owner_identity_id == identity_id)
        
        result = await session.execute(query)
        return list(result.scalars().all())


# ==================== Common Query Filters ====================

class QueryFilters:
    """Common query filter builders."""
    
    @staticmethod
    def date_range(
        model: Type[T],
        field_name: str,
        start: Optional[datetime] = None,
        end: Optional[datetime] = None
    ) -> List[Any]:
        """Build date range filter."""
        filters = []
        field = getattr(model, field_name, None)
        
        if field is not None:
            if start:
                filters.append(field >= start)
            if end:
                filters.append(field <= end)
        
        return filters
    
    @staticmethod
    def status_filter(
        model: Type[T],
        status: Optional[Union[str, List[str]]] = None,
        exclude_status: Optional[Union[str, List[str]]] = None
    ) -> List[Any]:
        """Build status filter."""
        filters = []
        
        if hasattr(model, 'status'):
            if status:
                if isinstance(status, list):
                    filters.append(model.status.in_(status))
                else:
                    filters.append(model.status == status)
            
            if exclude_status:
                if isinstance(exclude_status, list):
                    filters.append(model.status.notin_(exclude_status))
                else:
                    filters.append(model.status != exclude_status)
        
        return filters
    
    @staticmethod
    def search_filter(
        model: Type[T],
        search_term: str,
        fields: List[str]
    ) -> Any:
        """Build full-text search filter across multiple fields."""
        if not search_term:
            return None
        
        conditions = []
        search_pattern = f"%{search_term}%"
        
        for field_name in fields:
            field = getattr(model, field_name, None)
            if field is not None:
                conditions.append(field.ilike(search_pattern))
        
        if conditions:
            return or_(*conditions)
        return None


# ==================== Exports ====================

__all__ = [
    # Pagination
    'PaginationStrategy',
    'PaginationParams',
    'PaginatedResult',
    'CursorPaginator',
    
    # Eager Loading
    'EagerLoadingStrategy',
    'RelationshipLoad',
    'EagerLoader',
    'THREAD_WITH_EVENTS',
    'THREAD_WITH_SNAPSHOT',
    'SPHERE_WITH_SECTIONS',
    'EXECUTION_WITH_RESULTS',
    
    # Identity-Scoped
    'IdentityScopedQuery',
    
    # Performance
    'QueryMetrics',
    'QueryPerformanceMonitor',
    'get_performance_monitor',
    'monitored_query',
    
    # Batch
    'BatchLoader',
    
    # Filters
    'QueryFilters'
]
