# MANIFEST — Module Video Scripts
# AT-OM / CHE·NU™ Integration Package
# Date: 2026-01-07
# Version: V1.0

## 📦 MODULE OVERVIEW

| Propriété | Valeur |
|-----------|--------|
| Module ID | `content.video_scripts` |
| Nom | AT-OM Video & Manifest Scripts |
| Version | 1.0.0 |
| Status | READY |
| Type | Content / Marketing |

## 🎯 MISSION

Scripts pour vidéos de présentation AT-OM:
- Voice-over video
- XR onboarding narration
- Manifest excerpts

**Ton:** Calme, lucide, non-blâmant, urgent.

## 📁 STRUCTURE DES FICHIERS

```
video/
├── docs/
│   ├── README.md
│   └── scripts/
│       ├── 01_surcharge_invisible.md
│       ├── 02_ia_surchargee.md
│       ├── 03_virage_at_om.md
│       └── 04_urgence_invitation.md
└── MANIFEST.md
```

## 📊 STATISTIQUES

| Type | Fichiers | Lignes |
|------|----------|--------|
| Scripts MD | 4 | ~150 |
| Documentation | 2 | ~50 |
| **TOTAL** | **6** | **~200** |

## 🎬 SCRIPTS INCLUS

### 1. La Surcharge Invisible
**Thème:** Problem framing - Le poids invisible du numérique
**Métaphore:** Voiture avec remorque de béton invisible

### 2. L'IA Surchargée
**Thème:** AI memory fragmentation - L'IA qui oublie tout
**Message:** Chaque conversation repart de zéro

### 3. Le Virage AT-OM
**Thème:** Paradigm shift - Une nouvelle approche
**Message:** Ne plus remplir, mais vider. Ne plus chercher, mais retrouver.

### 4. Urgence et Invitation
**Thème:** Call to action - Rejoindre le mouvement
**Message:** Le temps de changer, c'est maintenant.

## 🎨 UTILISATION PRÉVUE

| Support | Script |
|---------|--------|
| Vidéo d'intro | #1 + #2 |
| Présentation AT-OM | #3 |
| Landing page | #4 |
| XR Entry Room | #1 ou #3 |
| Manifeste | Tous |

## 🌍 PROCHAINES ÉTAPES

- [ ] Storyboard pour chaque script
- [ ] Script pour XR entry room
- [ ] Versions multilingues (EN, ES)
- [ ] Voice-over recordings
- [ ] Animation / Motion design

## 📋 CHECKLIST D'INTÉGRATION

- [ ] Intégrer dans système de content management
- [ ] Créer assets visuels correspondants
- [ ] Produire voice-over
- [ ] Intégrer dans XR onboarding
- [ ] Tests utilisateurs
