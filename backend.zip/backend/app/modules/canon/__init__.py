"""
CHE·NU Canon Module
- Need Canon (15 fundamental needs)
- Module Catalog (15+ modules)
- Scenario Lock (simulation system)
"""
from .need_canon import *
from .module_catalog import *
from .scenario_lock import *
