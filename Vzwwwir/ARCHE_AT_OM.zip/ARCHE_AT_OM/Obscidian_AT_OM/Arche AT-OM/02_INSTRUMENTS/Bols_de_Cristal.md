# Bols de Cristal

Calibration d’attention (repère stable). Mesures: bruit (0–10), clarté (0–10).
