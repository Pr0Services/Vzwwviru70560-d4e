"""
CHE·NU™ V70 — GRAPHQL API
=========================
GraphQL interface for GP2 system.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any, List, Optional
from uuid import uuid4
import strawberry
from strawberry.fastapi import GraphQLRouter


# =============================================================================
# GOVERNANCE TYPES
# =============================================================================

@strawberry.type
class GovernanceInfo:
    """Governance information."""
    level: str = "strict"
    synthetic_only: bool = True
    xr_read_only: bool = True
    hitl_required: bool = True


@strawberry.type
class OPADecision:
    """OPA policy decision."""
    decision_id: str
    policy: str
    allowed: bool
    reason: Optional[str] = None
    timestamp: datetime


# =============================================================================
# NOVA TYPES
# =============================================================================

@strawberry.type
class NovaValidation:
    """NOVA validation result."""
    request_id: str
    validated: bool
    is_refusal: bool
    refusal_reason: Optional[str]
    governance: GovernanceInfo
    timestamp: datetime


@strawberry.input
class NovaValidateInput:
    """Input for NOVA validation."""
    intent: str
    context: Optional[str] = None


# =============================================================================
# ETHICS TYPES
# =============================================================================

@strawberry.type
class EthicsValidation:
    """Ethics validation result."""
    validation_id: str
    is_valid: bool
    violations: List[str]
    forbidden_state: Optional[str]
    canon_version: str = "70.0.0"


@strawberry.input
class EthicsValidateInput:
    """Input for ethics validation."""
    action_description: str
    actor_type: str = "system_intelligence"


# =============================================================================
# DECISION TYPES
# =============================================================================

@strawberry.type
class DecisionOption:
    """Decision option."""
    name: str
    description: Optional[str]
    risk: float
    impact: str


@strawberry.type
class DecisionPackage:
    """Decision package."""
    package_id: str
    title: Optional[str]
    summary: Optional[str]
    user_intent: str
    simulation_id: str
    causal_trace_id: str
    xr_scene_id: str
    options: List[DecisionOption]
    hitl_required: bool
    hitl_approved: bool
    status: str
    created_at: datetime


@strawberry.input
class DecisionLoopInput:
    """Input for decision loop."""
    user_intent: str
    initial_state: Optional[str] = None
    simulation_cycles: int = 10


@strawberry.input
class HITLApprovalInput:
    """Input for HITL approval."""
    package_id: str
    selected_option: Optional[int] = None
    comments: Optional[str] = None


# =============================================================================
# FAILSAFE TYPES
# =============================================================================

@strawberry.type
class CrisisIndicators:
    """Crisis indicators."""
    network_health: float
    social_cohesion: float
    supply_chain: float
    governance_integrity: float
    economic_stability: float


@strawberry.type
class FailsafeStatus:
    """Failsafe system status."""
    current_level: str
    is_active: bool
    indicators: CrisisIndicators
    last_check: datetime


@strawberry.type
class CrisisAlert:
    """Crisis alert."""
    alert_id: str
    crisis_type: str
    severity: str
    response_level: str
    detected_at: datetime


# =============================================================================
# XR TYPES
# =============================================================================

@strawberry.type
class XRNode:
    """XR scene node."""
    node_id: str
    label: str
    node_type: str
    position_x: float
    position_y: float
    position_z: float


@strawberry.type
class XREdge:
    """XR scene edge."""
    source_id: str
    target_id: str
    edge_type: str
    weight: float


@strawberry.type
class XRScene:
    """XR scene (READ ONLY)."""
    scene_id: str
    scene_type: str
    nodes: List[XRNode]
    edges: List[XREdge]
    read_only: bool = True  # CRITICAL: Always true
    created_at: datetime


# =============================================================================
# USER TYPES
# =============================================================================

@strawberry.type
class User:
    """User type."""
    user_id: str
    username: str
    email: str
    roles: List[str]
    is_active: bool


@strawberry.type
class AuthToken:
    """Authentication token."""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


@strawberry.input
class LoginInput:
    """Login input."""
    username: str
    password: str


# =============================================================================
# HEALTH TYPES
# =============================================================================

@strawberry.type
class ComponentHealth:
    """Component health status."""
    name: str
    status: str
    latency_ms: Optional[float]
    message: Optional[str]


@strawberry.type
class SystemHealth:
    """System health."""
    status: str
    version: str
    uptime_seconds: float
    components: List[ComponentHealth]
    governance: GovernanceInfo


# =============================================================================
# QUERY RESOLVERS
# =============================================================================

@strawberry.type
class Query:
    """GraphQL Query type."""
    
    @strawberry.field
    def health(self) -> SystemHealth:
        """Get system health."""
        return SystemHealth(
            status="healthy",
            version="70.0.0",
            uptime_seconds=0,
            components=[
                ComponentHealth(name="nova", status="healthy", latency_ms=10, message=None),
                ComponentHealth(name="ethics", status="healthy", latency_ms=5, message=None),
                ComponentHealth(name="opa", status="healthy", latency_ms=15, message=None),
            ],
            governance=GovernanceInfo(),
        )
    
    @strawberry.field
    def governance(self) -> GovernanceInfo:
        """Get governance info."""
        return GovernanceInfo()
    
    @strawberry.field
    def failsafe_status(self) -> FailsafeStatus:
        """Get failsafe status."""
        return FailsafeStatus(
            current_level="n0_monitoring",
            is_active=False,
            indicators=CrisisIndicators(
                network_health=1.0,
                social_cohesion=1.0,
                supply_chain=1.0,
                governance_integrity=1.0,
                economic_stability=1.0,
            ),
            last_check=datetime.utcnow(),
        )
    
    @strawberry.field
    def decision_package(self, package_id: str) -> Optional[DecisionPackage]:
        """Get decision package by ID."""
        # Mock implementation
        return DecisionPackage(
            package_id=package_id,
            title="Sample Decision",
            summary="A sample decision package",
            user_intent="Optimize workflow",
            simulation_id=f"SIM_{uuid4().hex[:8]}",
            causal_trace_id=f"TRACE_{uuid4().hex[:8]}",
            xr_scene_id=f"XR_{uuid4().hex[:8]}",
            options=[
                DecisionOption(name="Option A", description="Conservative", risk=0.2, impact="low"),
                DecisionOption(name="Option B", description="Balanced", risk=0.5, impact="medium"),
                DecisionOption(name="Option C", description="Aggressive", risk=0.8, impact="high"),
            ],
            hitl_required=True,
            hitl_approved=False,
            status="pending_hitl",
            created_at=datetime.utcnow(),
        )
    
    @strawberry.field
    def xr_scene(self, scene_id: str) -> Optional[XRScene]:
        """Get XR scene (READ ONLY)."""
        return XRScene(
            scene_id=scene_id,
            scene_type="decision_space",
            nodes=[
                XRNode(node_id="N1", label="Start", node_type="state", position_x=0, position_y=0, position_z=0),
                XRNode(node_id="N2", label="Option A", node_type="option", position_x=1, position_y=1, position_z=0),
                XRNode(node_id="N3", label="Option B", node_type="option", position_x=-1, position_y=1, position_z=0),
            ],
            edges=[
                XREdge(source_id="N1", target_id="N2", edge_type="leads_to", weight=0.6),
                XREdge(source_id="N1", target_id="N3", edge_type="leads_to", weight=0.4),
            ],
            read_only=True,  # CRITICAL
            created_at=datetime.utcnow(),
        )
    
    @strawberry.field
    def me(self) -> Optional[User]:
        """Get current user."""
        # Mock - would use auth context
        return User(
            user_id="USER_mock",
            username="demo",
            email="demo@chenu.local",
            roles=["viewer"],
            is_active=True,
        )


# =============================================================================
# MUTATION RESOLVERS
# =============================================================================

@strawberry.type
class Mutation:
    """GraphQL Mutation type."""
    
    @strawberry.mutation
    def nova_validate(self, input: NovaValidateInput) -> NovaValidation:
        """Validate intent through NOVA."""
        # Check for forbidden patterns
        forbidden = ["override human", "autonomous goal", "self-legislat"]
        is_refusal = any(p in input.intent.lower() for p in forbidden)
        
        return NovaValidation(
            request_id=f"REQ_{uuid4().hex[:8]}",
            validated=not is_refusal,
            is_refusal=is_refusal,
            refusal_reason="Forbidden pattern detected" if is_refusal else None,
            governance=GovernanceInfo(),
            timestamp=datetime.utcnow(),
        )
    
    @strawberry.mutation
    def ethics_validate(self, input: EthicsValidateInput) -> EthicsValidation:
        """Validate action against ethics canon."""
        violations = []
        forbidden_state = None
        
        # Check for violations
        action_lower = input.action_description.lower()
        if "override human" in action_lower:
            violations.append("human_primacy")
            forbidden_state = "human_override_attempt"
        if "autonomous goal" in action_lower:
            violations.append("no_autonomous_goals")
            forbidden_state = "autonomous_goal_creation"
        
        return EthicsValidation(
            validation_id=f"ETH_{uuid4().hex[:8]}",
            is_valid=len(violations) == 0,
            violations=violations,
            forbidden_state=forbidden_state,
        )
    
    @strawberry.mutation
    def create_decision_loop(self, input: DecisionLoopInput) -> DecisionPackage:
        """Create a decision loop."""
        return DecisionPackage(
            package_id=f"PKG_{uuid4().hex[:8]}",
            title=f"Decision: {input.user_intent[:50]}",
            summary=None,
            user_intent=input.user_intent,
            simulation_id=f"SIM_{uuid4().hex[:8]}",
            causal_trace_id=f"TRACE_{uuid4().hex[:8]}",
            xr_scene_id=f"XR_{uuid4().hex[:8]}",
            options=[
                DecisionOption(name="Option A", description=None, risk=0.3, impact="medium"),
                DecisionOption(name="Option B", description=None, risk=0.6, impact="high"),
            ],
            hitl_required=True,
            hitl_approved=False,
            status="pending_hitl",
            created_at=datetime.utcnow(),
        )
    
    @strawberry.mutation
    def approve_hitl(self, input: HITLApprovalInput) -> DecisionPackage:
        """Approve HITL checkpoint."""
        return DecisionPackage(
            package_id=input.package_id,
            title="Approved Decision",
            summary=input.comments,
            user_intent="(retrieved from storage)",
            simulation_id=f"SIM_{uuid4().hex[:8]}",
            causal_trace_id=f"TRACE_{uuid4().hex[:8]}",
            xr_scene_id=f"XR_{uuid4().hex[:8]}",
            options=[],
            hitl_required=True,
            hitl_approved=True,
            status="approved",
            created_at=datetime.utcnow(),
        )
    
    @strawberry.mutation
    def login(self, input: LoginInput) -> Optional[AuthToken]:
        """Authenticate user."""
        # Mock authentication
        if input.username and input.password:
            return AuthToken(
                access_token=f"token_{uuid4().hex}",
                refresh_token=f"refresh_{uuid4().hex}",
                expires_in=3600,
            )
        return None


# =============================================================================
# SUBSCRIPTION RESOLVERS
# =============================================================================

@strawberry.type
class Subscription:
    """GraphQL Subscription type."""
    
    @strawberry.subscription
    async def crisis_alerts(self) -> CrisisAlert:
        """Subscribe to crisis alerts."""
        import asyncio
        
        # Mock subscription - in production would connect to event bus
        while True:
            await asyncio.sleep(60)
            yield CrisisAlert(
                alert_id=f"ALERT_{uuid4().hex[:8]}",
                crisis_type="monitoring",
                severity="low",
                response_level="n0_monitoring",
                detected_at=datetime.utcnow(),
            )
    
    @strawberry.subscription
    async def decision_updates(self, package_id: str) -> DecisionPackage:
        """Subscribe to decision package updates."""
        import asyncio
        
        while True:
            await asyncio.sleep(5)
            yield DecisionPackage(
                package_id=package_id,
                title="Updated Decision",
                summary=None,
                user_intent="(subscribed)",
                simulation_id=f"SIM_{uuid4().hex[:8]}",
                causal_trace_id=f"TRACE_{uuid4().hex[:8]}",
                xr_scene_id=f"XR_{uuid4().hex[:8]}",
                options=[],
                hitl_required=True,
                hitl_approved=False,
                status="pending_hitl",
                created_at=datetime.utcnow(),
            )


# =============================================================================
# SCHEMA
# =============================================================================

schema = strawberry.Schema(
    query=Query,
    mutation=Mutation,
    subscription=Subscription,
)


# =============================================================================
# FASTAPI ROUTER
# =============================================================================

def create_graphql_router() -> GraphQLRouter:
    """Create GraphQL router for FastAPI."""
    return GraphQLRouter(
        schema,
        path="/graphql",
        graphiql=True,  # Enable GraphiQL playground
    )
