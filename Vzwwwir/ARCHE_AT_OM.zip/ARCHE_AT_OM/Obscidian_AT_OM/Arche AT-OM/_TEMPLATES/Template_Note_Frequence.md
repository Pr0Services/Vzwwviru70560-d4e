---
status: draft
octave:
sphere:
frequency_hz:
agent_id:
---

# {{title}}

## Intention
-

## Contexte (faits)
-

## Décision(s)
1.

## Prochain pas
-
