"""
CHE·NU™ V70 — METRICS PACKAGE
=============================
Prometheus metrics for GP2.
"""

from .prometheus import (
    MetricsCollector,
    get_metrics_collector,
    track_request,
    track_task,
)

__all__ = [
    "MetricsCollector",
    "get_metrics_collector",
    "track_request",
    "track_task",
]

__version__ = "70.0.0"
