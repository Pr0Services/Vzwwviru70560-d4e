# 📊 CHE·NU™ — BESOINS INFORMATIONNELS PAR SECTION BUREAU

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║           📊 BESOINS INFO PAR SECTION — LE DÉTAIL COMPLET                   ║
║                                                                              ║
║     "Chaque section a ses questions — Chaque réponse débloque"              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Version**: 1.0
**Date**: 23 Décembre 2025

---

# RAPPEL: STRUCTURE BUREAU (6 SECTIONS)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STRUCTURE BUREAU UNIVERSELLE                        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Chaque SPHÈRE contient un BUREAU avec ces 6 SECTIONS:                     │
│                                                                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐                        │
│  │ 1. DASHBOARD │ │  2. NOTES    │ │  3. TASKS    │                        │
│  │   (Vue)      │ │  (Capture)   │ │  (Actions)   │                        │
│  └──────────────┘ └──────────────┘ └──────────────┘                        │
│                                                                             │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐                        │
│  │ 4. PROJECTS  │ │ 5. THREADS   │ │ 6. MEETINGS  │                        │
│  │  (Complexe)  │ │   (.chenu)   │ │  (Temps)     │                        │
│  └──────────────┘ └──────────────┘ └──────────────┘                        │
│                                                                             │
│  + TRANSVERSAL: Data/Database, Agents, Reports, Budget & Governance        │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 1. SECTION DASHBOARD — Besoins Informationnels

## 1.1 But de la Section
Le Dashboard est la **vue d'ensemble contextuelle** de la sphère. Il s'adapte selon les informations connues sur l'utilisateur.

## 1.2 Pièces Requises pour Personnalisation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DASHBOARD — PIÈCES DU PUZZLE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL (Change l'affichage)                                      │
│  ─────────────────────────────────────                                      │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT SUR DASHBOARD         │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-001            │ Détection   │ Affiche widgets selon        │    │
│  │ Modules actifs        │             │ modules utilisés             │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-002            │ Détection   │ Met en avant les tâches      │    │
│  │ Tâches prioritaires   │             │ urgentes/importantes         │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-003            │ Question    │ Affiche KPIs pertinents      │    │
│  │ KPIs préférés         │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-004            │ Détection   │ Adapte densité info          │    │
│  │ Niveau expertise      │             │ (simple→détaillé)            │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE (Améliore l'expérience)                                       │
│  ────────────────────────────────────                                       │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-DASH-010            │ Détection   │ Pré-calcule prévisions       │    │
│  │ Patterns temporels    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-011            │ Question    │ Affiche/masque notifications │    │
│  │ Préf. notifications   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DASH-012            │ Détection   │ Layout adapté                │    │
│  │ Device principal      │             │ (desktop/mobile)             │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 1.3 Questions Nova pour Dashboard

```typescript
const DASHBOARD_QUESTIONS = [
  {
    id: 'q-dash-kpis',
    pieceId: 'P-DASH-003',
    trigger: 'dashboard_visited_5x',
    question: {
      fr: "Quelles informations voulez-vous voir en priorité sur votre tableau de bord?",
      en: "What information do you want to see first on your dashboard?",
    },
    type: 'multiple',
    options: [
      { value: 'tasks', label: { fr: 'Tâches à faire', en: 'Tasks to do' } },
      { value: 'calendar', label: { fr: 'Événements à venir', en: 'Upcoming events' } },
      { value: 'finances', label: { fr: 'Situation financière', en: 'Financial status' } },
      { value: 'projects', label: { fr: 'Avancement projets', en: 'Project progress' } },
      { value: 'messages', label: { fr: 'Messages récents', en: 'Recent messages' } },
    ],
    maxSelections: 3,
    skippable: true,
    timing: 'after_action',
  },
  {
    id: 'q-dash-density',
    pieceId: 'P-DASH-004',
    trigger: 'after_30_days_usage',
    question: {
      fr: "Préférez-vous un tableau de bord simple ou détaillé?",
      en: "Do you prefer a simple or detailed dashboard?",
    },
    type: 'single',
    options: [
      { value: 'minimal', label: { fr: 'Simple - Essentiel seulement', en: 'Simple - Essentials only' } },
      { value: 'balanced', label: { fr: 'Équilibré', en: 'Balanced' } },
      { value: 'detailed', label: { fr: 'Détaillé - Maximum d\'infos', en: 'Detailed - Maximum info' } },
    ],
    skippable: true,
    timing: 'session_end',
  },
];
```

## 1.4 Tutoriels Dashboard

```typescript
const DASHBOARD_TUTORIALS = {
  intro: {
    id: 'tut-dash-intro',
    title: { fr: 'Votre Tableau de Bord', en: 'Your Dashboard' },
    duration: '1min',
    unlockCondition: 'first_dashboard_visit',
    steps: [
      {
        id: 'step-1',
        title: { fr: 'Vue d\'ensemble', en: 'Overview' },
        content: {
          fr: "Votre tableau de bord affiche les informations importantes de cette sphère.",
          en: "Your dashboard displays important information for this sphere.",
        },
        highlight: '.dashboard-main',
      },
      {
        id: 'step-2',
        title: { fr: 'Widgets personnalisables', en: 'Customizable widgets' },
        content: {
          fr: "Chaque widget peut être déplacé ou masqué selon vos préférences.",
          en: "Each widget can be moved or hidden according to your preferences.",
        },
        highlight: '.widget-container',
      },
    ],
  },
  customization: {
    id: 'tut-dash-custom',
    title: { fr: 'Personnaliser le Dashboard', en: 'Customize Dashboard' },
    duration: '2min',
    unlockCondition: { piece: 'P-DASH-003', collected: true },
    steps: [/* ... */],
  },
};
```

---

# 2. SECTION NOTES — Besoins Informationnels

## 2.1 But de la Section
Notes est l'espace de **capture rapide** — pensées, idées, informations à ne pas oublier.

## 2.2 Pièces Requises

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       NOTES — PIÈCES DU PUZZLE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-NOTE-001            │ Détection   │ Suggère templates            │    │
│  │ Types notes fréquents │             │ appropriés                   │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-NOTE-002            │ Détection   │ Organisation auto            │    │
│  │ Tags utilisés         │             │ par tags                     │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-NOTE-003            │ Question    │ Active/désactive             │    │
│  │ Préf. organisation    │             │ auto-categorisation          │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE                                                               │
│  ────────────                                                               │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-NOTE-010            │ Détection   │ Liens automatiques           │    │
│  │ Connexions fréquentes │             │ entre notes                  │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-NOTE-011            │ Question    │ Format d'export              │    │
│  │ Usage export          │             │ par défaut                   │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 2.3 Questions Nova pour Notes

```typescript
const NOTES_QUESTIONS = [
  {
    id: 'q-note-org',
    pieceId: 'P-NOTE-003',
    trigger: 'notes_count_10',
    question: {
      fr: "Comment préférez-vous organiser vos notes?",
      en: "How do you prefer to organize your notes?",
    },
    type: 'single',
    options: [
      { value: 'manual', label: { fr: 'Manuellement (dossiers)', en: 'Manually (folders)' } },
      { value: 'tags', label: { fr: 'Par tags', en: 'By tags' } },
      { value: 'auto', label: { fr: 'Auto-organisation IA', en: 'AI auto-organization' } },
      { value: 'chrono', label: { fr: 'Chronologique', en: 'Chronological' } },
    ],
    skippable: true,
    timing: 'after_action',
  },
];
```

## 2.4 Tutoriels Notes

```typescript
const NOTES_TUTORIALS = {
  intro: {
    id: 'tut-notes-intro',
    title: { fr: 'Capture Rapide', en: 'Quick Capture' },
    duration: '1min',
    unlockCondition: 'first_note_created',
    steps: [
      {
        id: 'step-1',
        title: { fr: 'Notez tout', en: 'Note everything' },
        content: {
          fr: "Capturez vos idées rapidement. L'organisation vient après.",
          en: "Capture your ideas quickly. Organization comes later.",
        },
      },
      {
        id: 'step-2',
        title: { fr: 'Tags intelligents', en: 'Smart tags' },
        content: {
          fr: "Utilisez #tags pour retrouver vos notes facilement.",
          en: "Use #tags to find your notes easily.",
        },
        highlight: '.note-tags',
      },
    ],
  },
  advanced: {
    id: 'tut-notes-advanced',
    title: { fr: 'Notes Connectées', en: 'Connected Notes' },
    duration: '2min',
    unlockCondition: { piece: 'P-NOTE-010', collected: true },
    steps: [/* ... */],
  },
};
```

---

# 3. SECTION TASKS — Besoins Informationnels

## 3.1 But de la Section
Tasks gère les **actions à accomplir** — des plus simples aux plus complexes.

## 3.2 Pièces Requises

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       TASKS — PIÈCES DU PUZZLE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-001            │ Détection   │ Vue par défaut               │    │
│  │ Style gestion tâches  │             │ (liste/kanban/calendar)      │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-002            │ Détection   │ Activer récurrence           │    │
│  │ Tâches récurrentes    │             │ intelligente                 │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-003            │ Question    │ Rappels config               │    │
│  │ Préf. rappels         │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-004            │ Détection   │ Priorisation auto            │    │
│  │ Méthode priorité      │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE                                                               │
│  ────────────                                                               │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-TASK-010            │ Détection   │ Estimation durée             │    │
│  │ Temps moyen tâche     │             │ automatique                  │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-011            │ Question    │ Assignation équipe           │    │
│  │ Délégation active     │ (si équipe) │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-TASK-012            │ Détection   │ Suggestions blocage          │    │
│  │ Tâches bloquées freq  │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU OPTIONNEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-TASK-020            │ Question    │ Gamification                 │    │
│  │ Motivation style      │             │ (si souhaité)                │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3.3 Questions Nova pour Tasks

```typescript
const TASKS_QUESTIONS = [
  {
    id: 'q-task-view',
    pieceId: 'P-TASK-001',
    trigger: 'tasks_count_5',
    question: {
      fr: "Comment préférez-vous voir vos tâches?",
      en: "How do you prefer to view your tasks?",
    },
    type: 'single',
    options: [
      { value: 'list', label: { fr: 'Liste simple', en: 'Simple list' } },
      { value: 'kanban', label: { fr: 'Tableau Kanban', en: 'Kanban board' } },
      { value: 'calendar', label: { fr: 'Vue calendrier', en: 'Calendar view' } },
      { value: 'priority', label: { fr: 'Par priorité', en: 'By priority' } },
    ],
    skippable: true,
    timing: 'after_action',
  },
  {
    id: 'q-task-reminders',
    pieceId: 'P-TASK-003',
    trigger: 'task_with_deadline_created',
    question: {
      fr: "Quand souhaitez-vous être rappelé pour les échéances?",
      en: "When would you like to be reminded about deadlines?",
    },
    type: 'multiple',
    options: [
      { value: '1d', label: { fr: '1 jour avant', en: '1 day before' } },
      { value: '3d', label: { fr: '3 jours avant', en: '3 days before' } },
      { value: '1w', label: { fr: '1 semaine avant', en: '1 week before' } },
      { value: 'morning', label: { fr: 'Le matin même', en: 'Same morning' } },
    ],
    maxSelections: 2,
    skippable: true,
    timing: 'after_action',
  },
  {
    id: 'q-task-delegation',
    pieceId: 'P-TASK-011',
    trigger: 'team_member_added',
    condition: { piece: 'P-BUS-001b', value: true }, // Si équipe
    question: {
      fr: "Souhaitez-vous pouvoir assigner des tâches à votre équipe?",
      en: "Would you like to assign tasks to your team?",
    },
    type: 'boolean',
    skippable: true,
    timing: 'immediate',
    onAnswer: {
      'true': {
        unlocksTutorials: ['tut-task-delegation'],
        unlocksFeatures: ['feature-task-assignment'],
      },
    },
  },
];
```

## 3.4 Tutoriels Tasks

```typescript
const TASKS_TUTORIALS = {
  intro: {
    id: 'tut-tasks-intro',
    title: { fr: 'Gérer vos Tâches', en: 'Manage your Tasks' },
    duration: '1min',
    unlockCondition: 'first_task_created',
    steps: [/* ... */],
  },
  recurring: {
    id: 'tut-tasks-recurring',
    title: { fr: 'Tâches Récurrentes', en: 'Recurring Tasks' },
    duration: '1min',
    unlockCondition: { piece: 'P-TASK-002', collected: true },
    steps: [/* ... */],
  },
  delegation: {
    id: 'tut-task-delegation',
    title: { fr: 'Déléguer des Tâches', en: 'Delegate Tasks' },
    duration: '2min',
    unlockCondition: { piece: 'P-TASK-011', value: true },
    steps: [/* ... */],
  },
  kanban: {
    id: 'tut-tasks-kanban',
    title: { fr: 'Vue Kanban', en: 'Kanban View' },
    duration: '2min',
    unlockCondition: { piece: 'P-TASK-001', value: 'kanban' },
    steps: [/* ... */],
  },
};
```

---

# 4. SECTION PROJECTS — Besoins Informationnels

## 4.1 But de la Section
Projects gère les **initiatives complexes** avec plusieurs tâches, ressources et timeline.

## 4.2 Pièces Requises

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      PROJECTS — PIÈCES DU PUZZLE                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-001            │ Détection   │ Templates proposés           │    │
│  │ Type projets          │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-002            │ Question    │ Vue timeline/board           │    │
│  │ Style gestion         │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-003            │ Détection   │ Ressources affichées         │    │
│  │ Ressources trackées   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-004            │ Question    │ Méthodo intégrée             │    │
│  │ Méthodologie          │ (si expert) │ (Agile, Waterfall)           │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE                                                               │
│  ────────────                                                               │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-PROJ-010            │ Détection   │ Suivi budgétaire             │    │
│  │ Budget projet         │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-011            │ Détection   │ Dépendances visuelles        │    │
│  │ Dépendances tâches    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-012            │ Question    │ Reports auto                 │    │
│  │ Reporting besoin      │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU SPÉCIALISATION (Selon domaine)                                      │
│  ──────────────────────────────────────                                     │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-PROJ-C01            │ Si Constr.  │ Features chantier            │    │
│  │ Projet construction   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-I01            │ Si Immo     │ Features rénovation          │    │
│  │ Projet immobilier     │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-PROJ-CR01           │ Si Créatif  │ Features production          │    │
│  │ Projet créatif        │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 4.3 Questions Nova pour Projects

```typescript
const PROJECTS_QUESTIONS = [
  {
    id: 'q-proj-style',
    pieceId: 'P-PROJ-002',
    trigger: 'first_project_created',
    question: {
      fr: "Comment préférez-vous visualiser vos projets?",
      en: "How do you prefer to visualize your projects?",
    },
    type: 'single',
    options: [
      { value: 'timeline', label: { fr: 'Timeline (Gantt)', en: 'Timeline (Gantt)' } },
      { value: 'board', label: { fr: 'Tableau (Kanban)', en: 'Board (Kanban)' } },
      { value: 'list', label: { fr: 'Liste structurée', en: 'Structured list' } },
      { value: 'calendar', label: { fr: 'Calendrier', en: 'Calendar' } },
    ],
    skippable: true,
    timing: 'after_action',
  },
  {
    id: 'q-proj-method',
    pieceId: 'P-PROJ-004',
    trigger: 'projects_count_3',
    condition: { piece: 'P-DASH-004', value: 'expert' }, // Si utilisateur expert
    question: {
      fr: "Utilisez-vous une méthodologie de gestion de projet?",
      en: "Do you use a project management methodology?",
    },
    type: 'single',
    options: [
      { value: 'agile', label: { fr: 'Agile/Scrum', en: 'Agile/Scrum' } },
      { value: 'waterfall', label: { fr: 'Cascade (Waterfall)', en: 'Waterfall' } },
      { value: 'hybrid', label: { fr: 'Hybride', en: 'Hybrid' } },
      { value: 'none', label: { fr: 'Pas de méthodo formelle', en: 'No formal methodology' } },
    ],
    skippable: true,
    timing: 'session_end',
    onAnswer: {
      'agile': { unlocksTutorials: ['tut-proj-agile'], unlocksFeatures: ['feature-sprints'] },
      'waterfall': { unlocksTutorials: ['tut-proj-waterfall'], unlocksFeatures: ['feature-phases'] },
    },
  },
];
```

---

# 5. SECTION THREADS — Besoins Informationnels

## 5.1 But de la Section
Threads (.chenu) sont les **lignes de pensée persistantes** — conversations, décisions, historique.

## 5.2 Pièces Requises

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      THREADS — PIÈCES DU PUZZLE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-THRD-001            │ Détection   │ Suggestion continuité        │    │
│  │ Usage threads         │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-THRD-002            │ Détection   │ Budget par défaut            │    │
│  │ Budget token moyen    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-THRD-003            │ Question    │ Niveau archivage             │    │
│  │ Préf. archivage       │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE                                                               │
│  ────────────                                                               │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-THRD-010            │ Détection   │ Synthèse auto                │    │
│  │ Threads longs freq    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-THRD-011            │ Question    │ Partage par défaut           │    │
│  │ Préf. partage         │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 5.3 Questions Nova pour Threads

```typescript
const THREADS_QUESTIONS = [
  {
    id: 'q-thrd-archive',
    pieceId: 'P-THRD-003',
    trigger: 'threads_count_10',
    question: {
      fr: "Que faire des threads terminés?",
      en: "What to do with completed threads?",
    },
    type: 'single',
    options: [
      { value: 'keep', label: { fr: 'Garder visibles', en: 'Keep visible' } },
      { value: 'archive_30', label: { fr: 'Archiver après 30 jours', en: 'Archive after 30 days' } },
      { value: 'archive_90', label: { fr: 'Archiver après 90 jours', en: 'Archive after 90 days' } },
      { value: 'manual', label: { fr: 'Archivage manuel', en: 'Manual archiving' } },
    ],
    skippable: true,
    timing: 'session_end',
  },
];
```

---

# 6. SECTION MEETINGS — Besoins Informationnels

## 6.1 But de la Section
Meetings gère les **événements temporels** — réunions, appels, rendez-vous.

## 6.2 Pièces Requises

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     MEETINGS — PIÈCES DU PUZZLE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  NIVEAU ESSENTIEL                                                           │
│  ─────────────────                                                          │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-001            │ Import      │ Sync calendrier              │    │
│  │ Calendrier externe    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-002            │ Question    │ Buffer entre réunions        │    │
│  │ Préf. espacement      │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-003            │ Détection   │ Templates réunion            │    │
│  │ Types réunions freq   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-004            │ Question    │ Rappels config               │    │
│  │ Préf. rappels         │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
│  NIVEAU UTILE                                                               │
│  ────────────                                                               │
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ P-MEET-010            │ Question    │ Feature disponibilités       │    │
│  │ Partage disponibilité │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-011            │ Question    │ Feature transcription        │    │
│  │ Notes réunion auto    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-MEET-012            │ Détection   │ XR meetings proposé          │    │
│  │ Participants distants │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 6.3 Questions Nova pour Meetings

```typescript
const MEETINGS_QUESTIONS = [
  {
    id: 'q-meet-calendar',
    pieceId: 'P-MEET-001',
    trigger: 'first_meeting_section_visit',
    question: {
      fr: "Souhaitez-vous connecter votre calendrier externe?",
      en: "Would you like to connect your external calendar?",
    },
    type: 'single',
    options: [
      { value: 'google', label: { fr: 'Google Calendar', en: 'Google Calendar' } },
      { value: 'outlook', label: { fr: 'Outlook/Microsoft', en: 'Outlook/Microsoft' } },
      { value: 'apple', label: { fr: 'Apple Calendar', en: 'Apple Calendar' } },
      { value: 'none', label: { fr: 'Pas maintenant', en: 'Not now' } },
    ],
    skippable: true,
    timing: 'immediate',
    onAnswer: {
      'google': { unlocksTutorials: ['tut-meet-google-sync'] },
      'outlook': { unlocksTutorials: ['tut-meet-outlook-sync'] },
      'apple': { unlocksTutorials: ['tut-meet-apple-sync'] },
    },
  },
  {
    id: 'q-meet-buffer',
    pieceId: 'P-MEET-002',
    trigger: 'meetings_same_day_2',
    question: {
      fr: "Souhaitez-vous un temps tampon entre vos réunions?",
      en: "Would you like buffer time between your meetings?",
    },
    type: 'single',
    options: [
      { value: 'none', label: { fr: 'Non, pas nécessaire', en: 'No, not needed' } },
      { value: '5min', label: { fr: '5 minutes', en: '5 minutes' } },
      { value: '15min', label: { fr: '15 minutes', en: '15 minutes' } },
      { value: '30min', label: { fr: '30 minutes', en: '30 minutes' } },
    ],
    skippable: true,
    timing: 'after_action',
  },
  {
    id: 'q-meet-notes',
    pieceId: 'P-MEET-011',
    trigger: 'meeting_completed_3x',
    question: {
      fr: "Voulez-vous que Nova prenne des notes pendant vos réunions?",
      en: "Would you like Nova to take notes during your meetings?",
    },
    type: 'boolean',
    skippable: true,
    timing: 'session_end',
    onAnswer: {
      'true': {
        unlocksTutorials: ['tut-meet-auto-notes'],
        unlocksFeatures: ['feature-meeting-transcription'],
        novaMessage: {
          fr: "Parfait! J'activerai les notes automatiques pour vos prochaines réunions.",
          en: "Perfect! I'll enable automatic notes for your next meetings.",
        },
      },
    },
  },
];
```

---

# 7. SECTIONS TRANSVERSALES — Besoins Informationnels

## 7.1 Data/Database

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DATA/DATABASE — PIÈCES DU PUZZLE                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DATA-001            │ Détection   │ Organisation auto            │    │
│  │ Types fichiers freq   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DATA-002            │ Question    │ Suggestions classement       │    │
│  │ Préf. organisation    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DATA-003            │ Détection   │ Alertes stockage             │    │
│  │ Volume stockage       │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-DATA-004            │ Question    │ Sources externes             │    │
│  │ Services cloud liés   │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 7.2 Agents

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       AGENTS — PIÈCES DU PUZZLE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-AGNT-001            │ Détection   │ Agents suggérés              │    │
│  │ Agents fréq. utilisés │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-AGNT-002            │ Question    │ Niveau autonomie             │    │
│  │ Préf. autonomie       │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-AGNT-003            │ Détection   │ Agents custom suggérés       │    │
│  │ Patterns répétitifs   │             │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 7.3 Budget & Governance

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                  BUDGET & GOVERNANCE — PIÈCES DU PUZZLE                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌────────────────────────────────────────────────────────────────────┐    │
│  │ PIÈCE                 │ SOURCE      │ IMPACT                       │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-GOVN-001            │ Question    │ Alertes budget               │    │
│  │ Seuil alerte tokens   │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-GOVN-002            │ Question    │ Niveau detail rapports       │    │
│  │ Préf. transparence    │             │                              │    │
│  ├────────────────────────────────────────────────────────────────────┤    │
│  │ P-GOVN-003            │ Question    │ Auto-approve config          │    │
│  │ Actions auto-approuvées│            │                              │    │
│  └────────────────────────────────────────────────────────────────────┘    │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

# 8. VARIANTES DE PARCOURS

## 8.1 Variantes par Profil Utilisateur

```typescript
const USER_PROFILE_VARIANTS = {
  // ═══════════════════════════════════════════════════════════════
  // PROFIL: DÉBUTANT ABSOLU
  // ═══════════════════════════════════════════════════════════════
  'absolute-beginner': {
    conditions: {
      'P-DASH-004': { value: 'beginner' },
      OR: {
        'sessions_count': { max: 5 },
        'first_week': true,
      },
    },
    adjustments: {
      // Nova plus présente
      novaProactivity: 'high',
      novaExplanations: 'detailed',
      
      // Tutoriels
      tutorialAutoStart: true,
      tutorialSpeed: 'slow',
      tutorialStepsDetailed: true,
      
      // Interface
      uiComplexity: 'minimal',
      featuresHidden: ['advanced-agents', 'xr-mode', 'custom-encoding'],
      tooltipsFrequency: 'high',
      
      // Questions
      questionFrequency: 'low', // Pas trop de questions au début
      questionComplexity: 'simple',
    },
    specificMessages: {
      firstLogin: {
        fr: "Bienvenue! Je vais vous guider pas à pas.",
        en: "Welcome! I'll guide you step by step.",
      },
      afterTutorial: {
        fr: "Très bien! Prêt pour la suite?",
        en: "Great! Ready for the next step?",
      },
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: UTILISATEUR INTERMÉDIAIRE
  // ═══════════════════════════════════════════════════════════════
  'intermediate': {
    conditions: {
      'sessions_count': { min: 10, max: 50 },
      'tutorials_completed': { min: 5 },
    },
    adjustments: {
      novaProactivity: 'medium',
      novaExplanations: 'concise',
      
      tutorialAutoStart: false,
      tutorialSpeed: 'normal',
      
      uiComplexity: 'standard',
      featuresHidden: ['enterprise-governance'],
      tooltipsFrequency: 'medium',
      
      questionFrequency: 'normal',
      questionComplexity: 'normal',
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: POWER USER
  // ═══════════════════════════════════════════════════════════════
  'power-user': {
    conditions: {
      'sessions_count': { min: 50 },
      'tutorials_completed': { min: 15 },
      'features_used': { min: 20 },
    },
    adjustments: {
      novaProactivity: 'low', // Nova moins intrusive
      novaExplanations: 'minimal',
      
      tutorialAutoStart: false,
      tutorialSpeed: 'fast',
      skipTutorialOption: 'prominent',
      
      uiComplexity: 'full',
      featuresHidden: [],
      tooltipsFrequency: 'low',
      
      questionFrequency: 'low',
      questionComplexity: 'advanced',
      
      // Features avancées
      showShortcuts: true,
      enableBetaFeatures: true,
      showPerformanceMetrics: true,
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: FREELANCE
  // ═══════════════════════════════════════════════════════════════
  'freelance': {
    conditions: {
      'P-BUS-001a': true, // Solo = true
    },
    adjustments: {
      defaultSphere: 'business',
      
      // Features mises en avant
      featuresPromoted: ['invoicing', 'client-management', 'time-tracking'],
      featuresHidden: ['team-management', 'enterprise-roles'],
      
      // Templates
      defaultTemplates: 'freelance',
      
      // Questions spécifiques
      additionalQuestions: ['q-freelance-services', 'q-freelance-pricing'],
      
      // Dashboard
      dashboardWidgets: ['upcoming-deadlines', 'unpaid-invoices', 'client-activity'],
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: ENTREPRISE PME
  // ═══════════════════════════════════════════════════════════════
  'sme-business': {
    conditions: {
      'P-BUS-001b': true, // Team = true
      'P-BUS-006a': true, // Petite équipe (2-5)
      OR: 'P-BUS-006b': true, // Moyenne équipe (6-20)
    },
    adjustments: {
      defaultSphere: 'business',
      
      featuresPromoted: ['team-collaboration', 'project-management', 'reporting'],
      
      defaultTemplates: 'sme',
      
      // Team features
      showTeamFeatures: true,
      showBasicPermissions: true,
      
      dashboardWidgets: ['team-activity', 'project-status', 'upcoming-meetings'],
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: CONSTRUCTION PRO
  // ═══════════════════════════════════════════════════════════════
  'construction-pro': {
    conditions: {
      'P-BUS-005a': 'construction',
    },
    adjustments: {
      // Modules activés
      modulesPromoted: ['mod-construction', 'mod-estimation'],
      
      // Templates métier
      defaultTemplates: 'construction',
      projectTemplates: ['renovation', 'new-build', 'commercial'],
      
      // Terminologie
      terminology: 'construction',
      
      // Questions spécifiques
      additionalQuestions: ['q-con-license', 'q-con-specialty'],
      
      // Features métier
      featuresPromoted: ['bid-management', 'subcontractor-tracking', 'site-safety'],
      
      // Dashboard
      dashboardWidgets: ['active-sites', 'pending-bids', 'compliance-status'],
      
      // Si Québec
      conditionalFeatures: {
        'P-CON-002': { // Si licence RBQ
          enable: ['rbq-tracking', 'cnesst-compliance', 'ccq-tools'],
        },
      },
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // PROFIL: IMMOBILIER PRO
  // ═══════════════════════════════════════════════════════════════
  'real-estate-pro': {
    conditions: {
      'P-BUS-005b': 'immobilier',
    },
    adjustments: {
      modulesPromoted: ['mod-immobilier-rental', 'mod-property-management'],
      
      defaultTemplates: 'real-estate',
      
      terminology: 'real-estate',
      
      additionalQuestions: ['q-imm-portfolio-size', 'q-imm-property-types'],
      
      featuresPromoted: ['tenant-management', 'lease-tracking', 'rent-collection'],
      
      dashboardWidgets: ['vacancy-rate', 'rent-due', 'maintenance-queue'],
      
      conditionalFeatures: {
        'P-IMM-002': { // Si Québec
          enable: ['tal-forms', 'regie-links', 'quebec-lease-templates'],
        },
      },
    },
  },
};
```

## 8.2 Variantes par Contexte

```typescript
const CONTEXT_VARIANTS = {
  // ═══════════════════════════════════════════════════════════════
  // CONTEXTE: PREMIÈRE SEMAINE
  // ═══════════════════════════════════════════════════════════════
  'first-week': {
    trigger: { daysFromSignup: { max: 7 } },
    adjustments: {
      // Mode découverte
      discoveryMode: true,
      
      // Nova guide
      novaWelcomeMessages: true,
      novaCheckIns: ['day-1', 'day-3', 'day-7'],
      
      // Tutoriels prioritaires
      tutorialPriority: ['tut-000', 'tut-001', 'tut-003'],
      
      // Limites
      maxQuestionsPerDay: 1,
      maxTutorialsPerSession: 2,
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // CONTEXTE: MOBILE
  // ═══════════════════════════════════════════════════════════════
  'mobile-context': {
    trigger: { device: 'mobile' },
    adjustments: {
      // UI adaptée
      uiDensity: 'compact',
      gesturesEnabled: true,
      
      // Features optimisées mobile
      featuresPromoted: ['quick-capture', 'voice-input', 'notifications'],
      featuresHidden: ['xr-mode', 'complex-reports'],
      
      // Tutoriels courts
      tutorialMaxDuration: '1min',
      
      // Questions simplifiées
      questionFormat: 'tap-to-answer',
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // CONTEXTE: HEURES DE TRAVAIL
  // ═══════════════════════════════════════════════════════════════
  'work-hours': {
    trigger: { 
      timeRange: { start: '08:00', end: '18:00' },
      weekday: true,
    },
    adjustments: {
      // Mode focus
      notificationsFiltered: true,
      distractionsMinimized: true,
      
      // Features pro
      featuresPromoted: ['focus-mode', 'task-management', 'calendar'],
      
      // Questions timing
      questionsPreferredTiming: 'lunch-break',
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // CONTEXTE: FIN DE JOURNÉE
  // ═══════════════════════════════════════════════════════════════
  'end-of-day': {
    trigger: {
      timeRange: { start: '17:00', end: '20:00' },
      weekday: true,
    },
    adjustments: {
      // Suggestions review
      suggestDailyReview: true,
      suggestTomorrowPlanning: true,
      
      // Questions OK
      questionsAllowed: true,
      questionsTiming: 'good',
      
      // Nova messages
      novaEndOfDayMessage: true,
    },
  },

  // ═══════════════════════════════════════════════════════════════
  // CONTEXTE: RETOUR APRÈS ABSENCE
  // ═══════════════════════════════════════════════════════════════
  'return-after-absence': {
    trigger: { daysSinceLastSession: { min: 7 } },
    adjustments: {
      // Re-onboarding léger
      showWelcomeBack: true,
      showWhatsNew: true,
      showPendingItems: true,
      
      // Nova catch-up
      novaCatchUpMessage: true,
      
      // Rappel tutoriels
      suggestReviewTutorials: true,
    },
  },
};
```

## 8.3 Système de Sélection de Variante

```typescript
// core/nova/variant-selector.ts

export class VariantSelector {
  
  /**
   * Sélectionne les variantes actives pour un utilisateur
   */
  selectActiveVariants(
    userId: string,
    puzzleState: UserPuzzleState,
    sessionContext: SessionContext
  ): ActiveVariants {
    
    const activeVariants: ActiveVariants = {
      userProfile: null,
      contexts: [],
      appliedAdjustments: {},
    };
    
    // 1. Sélectionner le profil utilisateur
    activeVariants.userProfile = this.selectUserProfile(puzzleState);
    
    // 2. Sélectionner les contextes actifs
    activeVariants.contexts = this.selectActiveContexts(sessionContext);
    
    // 3. Fusionner les ajustements (profil + contextes)
    activeVariants.appliedAdjustments = this.mergeAdjustments(
      activeVariants.userProfile,
      activeVariants.contexts
    );
    
    return activeVariants;
  }
  
  private selectUserProfile(puzzleState: UserPuzzleState): string | null {
    // Ordre de priorité pour les profils
    const profilePriority = [
      'construction-pro',
      'real-estate-pro',
      'sme-business',
      'freelance',
      'power-user',
      'intermediate',
      'absolute-beginner',
    ];
    
    for (const profileId of profilePriority) {
      const profile = USER_PROFILE_VARIANTS[profileId];
      if (this.matchesConditions(puzzleState, profile.conditions)) {
        return profileId;
      }
    }
    
    // Fallback: beginner
    return 'absolute-beginner';
  }
  
  private selectActiveContexts(sessionContext: SessionContext): string[] {
    const activeContexts: string[] = [];
    
    for (const [contextId, contextConfig] of Object.entries(CONTEXT_VARIANTS)) {
      if (this.matchesTrigger(sessionContext, contextConfig.trigger)) {
        activeContexts.push(contextId);
      }
    }
    
    return activeContexts;
  }
  
  private mergeAdjustments(
    profileId: string | null,
    contextIds: string[]
  ): MergedAdjustments {
    
    const merged: MergedAdjustments = {};
    
    // Appliquer profil de base
    if (profileId) {
      Object.assign(merged, USER_PROFILE_VARIANTS[profileId].adjustments);
    }
    
    // Overlay des contextes (dans l'ordre)
    for (const contextId of contextIds) {
      const contextAdjustments = CONTEXT_VARIANTS[contextId].adjustments;
      
      // Fusion intelligente
      for (const [key, value] of Object.entries(contextAdjustments)) {
        if (Array.isArray(value) && Array.isArray(merged[key])) {
          // Fusionner les arrays
          merged[key] = [...new Set([...merged[key], ...value])];
        } else if (typeof value === 'object' && typeof merged[key] === 'object') {
          // Fusionner les objets
          merged[key] = { ...merged[key], ...value };
        } else {
          // Écraser
          merged[key] = value;
        }
      }
    }
    
    return merged;
  }
  
  private matchesConditions(state: UserPuzzleState, conditions: any): boolean {
    // Logique de matching des conditions
    // ...
    return true;
  }
  
  private matchesTrigger(context: SessionContext, trigger: any): boolean {
    // Logique de matching des triggers
    // ...
    return true;
  }
}
```

---

# 9. RÉSUMÉ — TOUTES LES PIÈCES DU PUZZLE

## 9.1 Inventaire Complet par Section

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                    INVENTAIRE PIÈCES — PAR SECTION                           ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  SECTION          │ PIÈCES ESSENTIELLES │ PIÈCES UTILES │ TOTAL            ║
║  ─────────────────┼─────────────────────┼───────────────┼─────────         ║
║  Dashboard        │         4           │       3       │    7             ║
║  Notes            │         3           │       2       │    5             ║
║  Tasks            │         4           │       3       │    7             ║
║  Projects         │         4           │       3       │    7             ║
║  Threads          │         3           │       2       │    5             ║
║  Meetings         │         4           │       3       │    7             ║
║  Data/Database    │         4           │       -       │    4             ║
║  Agents           │         3           │       -       │    3             ║
║  Budget/Gov       │         3           │       -       │    3             ║
║  ─────────────────┼─────────────────────┼───────────────┼─────────         ║
║  TOTAL BUREAU     │        32           │      16       │   48             ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

## 9.2 Flux de Collecte Recommandé

```
JOUR 1-7: Pièces Fondamentales (10 pièces)
├── P-DASH-001 à 004 (Dashboard)
├── P-TASK-001, 003 (Tasks basiques)
├── P-NOTE-001 (Notes)
└── P-MEET-001, 004 (Meetings)

SEMAINE 2-4: Pièces Contextuelles (20 pièces)
├── Selon sphère principale
├── Selon actions détectées
└── Questions graduelles

MOIS 2+: Pièces Optimisation (18 pièces)
├── Pièces avancées selon usage
├── Pièces spécialisation domaine
└── Pièces intégrations
```

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║              BESOINS INFORMATIONNELS SECTIONS — COMPLET                      ║
║                                                                              ║
║     "Chaque section sait ce dont elle a besoin"                             ║
║     "Chaque pièce s'intègre dans le puzzle global"                          ║
║                                                                              ║
║                          ON CONTINUE! 💪🔥                                   ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```
