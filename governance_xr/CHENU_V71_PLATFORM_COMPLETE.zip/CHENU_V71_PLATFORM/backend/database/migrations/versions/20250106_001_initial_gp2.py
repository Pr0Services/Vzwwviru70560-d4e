"""
CHE·NU™ V70 — Initial GP2 Schema Migration

Revision ID: 001_initial_gp2
Revises: 
Create Date: 2025-01-06

GOUVERNANCE > EXÉCUTION
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers
revision = '001_initial_gp2'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Create initial GP2 tables."""
    
    # ==========================================================================
    # AUDIT LOG
    # ==========================================================================
    
    op.create_table(
        'gp2_audit_log',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('audit_id', sa.String(32), nullable=False),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('module', sa.String(64), nullable=False),
        sa.Column('action', sa.String(128), nullable=False),
        sa.Column('actor_id', sa.String(64), nullable=True),
        sa.Column('actor_type', sa.String(32), server_default='user', nullable=True),
        sa.Column('request_id', sa.String(32), nullable=True),
        sa.Column('session_id', sa.String(64), nullable=True),
        sa.Column('opa_validated', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('hitl_approved', sa.Boolean(), nullable=True),
        sa.Column('synthetic_only', sa.Boolean(), server_default='true', nullable=True),
        sa.Column('input_data', postgresql.JSONB(), nullable=True),
        sa.Column('output_data', postgresql.JSONB(), nullable=True),
        sa.Column('violations', postgresql.JSONB(), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('audit_id')
    )
    
    op.create_index('idx_audit_timestamp', 'gp2_audit_log', ['timestamp'], postgresql_using='btree')
    op.create_index('idx_audit_module', 'gp2_audit_log', ['module'], postgresql_using='btree')
    op.create_index('idx_audit_actor', 'gp2_audit_log', ['actor_id'], postgresql_using='btree')
    
    # ==========================================================================
    # OPA DECISIONS
    # ==========================================================================
    
    op.create_table(
        'gp2_opa_decisions',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('decision_id', sa.String(32), nullable=False),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('policy_path', sa.String(256), nullable=False),
        sa.Column('input_hash', sa.String(64), nullable=False),
        sa.Column('decision', sa.Boolean(), nullable=False),
        sa.Column('input_data', postgresql.JSONB(), nullable=True),
        sa.Column('output_data', postgresql.JSONB(), nullable=True),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('decision_id')
    )
    
    op.create_index('idx_opa_policy', 'gp2_opa_decisions', ['policy_path'], postgresql_using='btree')
    op.create_index('idx_opa_hash', 'gp2_opa_decisions', ['input_hash'], postgresql_using='btree')
    
    # ==========================================================================
    # NOVA REQUESTS
    # ==========================================================================
    
    op.create_table(
        'nova_requests',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('request_id', sa.String(32), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('intent', sa.Text(), nullable=False),
        sa.Column('context', postgresql.JSONB(), server_default='{}', nullable=True),
        sa.Column('user_id', sa.String(64), nullable=True),
        sa.Column('processed', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('processing_started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('processing_completed_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('is_refusal', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('refusal_reason', sa.Text(), nullable=True),
        sa.Column('response', postgresql.JSONB(), nullable=True),
        sa.Column('opa_validated', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('forbidden_action_detected', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('audit_trail', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('request_id')
    )
    
    op.create_index('idx_nova_user', 'nova_requests', ['user_id'], postgresql_using='btree')
    op.create_index('idx_nova_created', 'nova_requests', ['created_at'], postgresql_using='btree')
    
    # ==========================================================================
    # ETHICS VALIDATIONS
    # ==========================================================================
    
    op.create_table(
        'ethics_validations',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('validation_id', sa.String(32), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('action_description', sa.Text(), nullable=False),
        sa.Column('actor_type', sa.String(32), server_default='system_intelligence', nullable=True),
        sa.Column('is_valid', sa.Boolean(), nullable=False),
        sa.Column('violations', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.Column('forbidden_state', sa.String(64), nullable=True),
        sa.Column('rules_checked', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.Column('canon_version', sa.String(16), server_default='70.0.0', nullable=True),
        sa.Column('immutable', sa.Boolean(), server_default='true', nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('validation_id')
    )
    
    op.create_index('idx_ethics_valid', 'ethics_validations', ['is_valid'], postgresql_using='btree')
    op.create_index('idx_ethics_created', 'ethics_validations', ['created_at'], postgresql_using='btree')
    
    # ==========================================================================
    # DECISION PACKAGES
    # ==========================================================================
    
    op.create_table(
        'civilization_decision_packages',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('package_id', sa.String(32), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('title', sa.String(256), nullable=True),
        sa.Column('summary', sa.Text(), nullable=True),
        sa.Column('user_intent', sa.Text(), nullable=False),
        sa.Column('worldstate_id', sa.String(32), nullable=True),
        sa.Column('simulation_id', sa.String(32), nullable=True),
        sa.Column('causal_trace_id', sa.String(32), nullable=True),
        sa.Column('xr_scene_id', sa.String(32), nullable=True),
        sa.Column('options', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.Column('recommended_option', sa.Integer(), nullable=True),
        sa.Column('risk_assessment', postgresql.JSONB(), server_default='{}', nullable=True),
        sa.Column('opa_validated', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('hitl_required', sa.Boolean(), server_default='true', nullable=True),
        sa.Column('hitl_approved', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('approved_by', sa.String(64), nullable=True),
        sa.Column('approved_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('exported', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('export_format', sa.String(32), nullable=True),
        sa.Column('exported_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('signatures', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('package_id')
    )
    
    op.create_index('idx_decision_hitl', 'civilization_decision_packages', ['hitl_approved'], postgresql_using='btree')
    op.create_index('idx_decision_created', 'civilization_decision_packages', ['created_at'], postgresql_using='btree')
    
    # ==========================================================================
    # FAILSAFE ACTIVATIONS
    # ==========================================================================
    
    op.create_table(
        'failsafe_activations',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('activation_id', sa.String(32), nullable=False),
        sa.Column('activated_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('crisis_type', sa.String(64), nullable=False),
        sa.Column('response_level', sa.String(32), nullable=False),
        sa.Column('actions', postgresql.JSONB(), server_default='[]', nullable=True),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=True),
        sa.Column('deactivated_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('activation_id')
    )
    
    # ==========================================================================
    # USERS
    # ==========================================================================
    
    op.create_table(
        'users',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('user_id', sa.String(32), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('username', sa.String(64), nullable=False),
        sa.Column('email', sa.String(256), nullable=False),
        sa.Column('password_hash', sa.String(256), nullable=False),
        sa.Column('roles', postgresql.JSONB(), server_default='["viewer"]', nullable=True),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=True),
        sa.Column('is_verified', sa.Boolean(), server_default='false', nullable=True),
        sa.Column('last_login', sa.DateTime(timezone=True), nullable=True),
        sa.Column('metadata', postgresql.JSONB(), server_default='{}', nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('user_id'),
        sa.UniqueConstraint('username'),
        sa.UniqueConstraint('email')
    )
    
    op.create_index('idx_users_username', 'users', ['username'], postgresql_using='btree')
    op.create_index('idx_users_email', 'users', ['email'], postgresql_using='btree')
    
    # ==========================================================================
    # SESSIONS
    # ==========================================================================
    
    op.create_table(
        'sessions',
        sa.Column('id', sa.BigInteger(), autoincrement=True, nullable=False),
        sa.Column('session_id', sa.String(64), nullable=False),
        sa.Column('user_id', sa.String(32), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('NOW()'), nullable=False),
        sa.Column('expires_at', sa.DateTime(timezone=True), nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=True),
        sa.Column('ip_address', sa.String(45), nullable=True),
        sa.Column('user_agent', sa.String(512), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('session_id')
    )
    
    op.create_index('idx_sessions_user', 'sessions', ['user_id'], postgresql_using='btree')
    op.create_index('idx_sessions_expires', 'sessions', ['expires_at'], postgresql_using='btree')


def downgrade() -> None:
    """Drop all GP2 tables."""
    op.drop_table('sessions')
    op.drop_table('users')
    op.drop_table('failsafe_activations')
    op.drop_table('civilization_decision_packages')
    op.drop_table('ethics_validations')
    op.drop_table('nova_requests')
    op.drop_table('gp2_opa_decisions')
    op.drop_table('gp2_audit_log')
