"""
CHE·NU™ Finance V68 Tests

Comprehensive test suite validating CANON compliance.
"""

import pytest
import sys
import os
from decimal import Decimal
from datetime import datetime, timedelta, timezone
from uuid import uuid4

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from spheres.finance.agents.finance_agent import (
    FinanceAgent,
    AccountType,
    TransactionType,
    TransactionStatus,
    BudgetStatus,
    CheckpointType
)


@pytest.fixture
def agent():
    """Fresh agent for each test."""
    return FinanceAgent()


@pytest.fixture
def user_id():
    """Test user ID."""
    return "user_001"


# ═══════════════════════════════════════════════════════════════════════════════
# ACCOUNT TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestAccounts:
    """Account management tests."""
    
    @pytest.mark.asyncio
    async def test_create_account(self, agent, user_id):
        """Can create account."""
        account = await agent.create_account(
            name="Checking",
            account_type=AccountType.CHECKING,
            currency="CAD",
            user_id=user_id,
            initial_balance=Decimal("1000.00")
        )
        
        assert account.name == "Checking"
        assert account.account_type == AccountType.CHECKING
        assert account.balance == Decimal("1000.00")
        assert account.created_by == user_id
    
    @pytest.mark.asyncio
    async def test_account_traceability_rule6(self, agent, user_id):
        """RULE 6: Accounts have full traceability."""
        account = await agent.create_account(
            name="Savings",
            account_type=AccountType.SAVINGS,
            currency="CAD",
            user_id=user_id
        )
        
        # CANON Rule #6: All objects traceable
        assert account.id is not None
        assert account.created_by == user_id
        assert account.created_at is not None
    
    @pytest.mark.asyncio
    async def test_get_accounts_chronological_rule5(self, agent, user_id):
        """RULE 5: Accounts returned in chronological order."""
        await agent.create_account("First", AccountType.CHECKING, "CAD", user_id)
        await agent.create_account("Second", AccountType.SAVINGS, "CAD", user_id)
        await agent.create_account("Third", AccountType.CREDIT_CARD, "CAD", user_id)
        
        accounts = await agent.get_accounts(user_id)
        
        # CANON Rule #5: Chronological, NOT sorted by name or balance
        assert len(accounts) == 3
        for i in range(len(accounts) - 1):
            assert accounts[i].created_at <= accounts[i + 1].created_at


# ═══════════════════════════════════════════════════════════════════════════════
# TRANSACTION TESTS - CANON RULE #1 (Human Sovereignty)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTransactions:
    """Transaction workflow tests."""
    
    @pytest.mark.asyncio
    async def test_transaction_starts_as_draft_rule1(self, agent, user_id):
        """RULE 1: Transactions start as DRAFT."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("1000.00")
        )
        
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("50.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Test",
            user_id=user_id
        )
        
        # CANON Rule #1: Must start as DRAFT
        assert tx.status == TransactionStatus.DRAFT
    
    @pytest.mark.asyncio
    async def test_transaction_requires_approval_rule1(self, agent, user_id):
        """RULE 1: Cannot execute without approval."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("1000.00")
        )
        
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("50.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Test",
            user_id=user_id
        )
        
        # Try to execute without approval
        with pytest.raises(ValueError) as exc:
            await agent.execute_transaction(tx.id, user_id)
        
        assert "APPROVED" in str(exc.value)
    
    @pytest.mark.asyncio
    async def test_transaction_full_workflow(self, agent, user_id):
        """Full transaction workflow: DRAFT → PENDING → APPROVED → COMPLETED."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("1000.00")
        )
        
        # Step 1: Create (DRAFT)
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("100.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Groceries",
            user_id=user_id
        )
        assert tx.status == TransactionStatus.DRAFT
        
        # Step 2: Submit (PENDING)
        tx, _ = await agent.submit_transaction_for_approval(tx.id, user_id)
        assert tx.status == TransactionStatus.PENDING_APPROVAL
        
        # Step 3: Approve
        tx = await agent.approve_transaction(tx.id, user_id)
        assert tx.status == TransactionStatus.APPROVED
        assert tx.approved_by == user_id
        
        # Step 4: Execute (COMPLETED)
        tx = await agent.execute_transaction(tx.id, user_id)
        assert tx.status == TransactionStatus.COMPLETED
        
        # Verify balance updated
        account = await agent.get_account(account.id)
        assert account.balance == Decimal("900.00")
    
    @pytest.mark.asyncio
    async def test_transaction_can_be_rejected(self, agent, user_id):
        """Transactions can be rejected."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("1000.00")
        )
        
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("50.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Test",
            user_id=user_id
        )
        
        await agent.submit_transaction_for_approval(tx.id, user_id)
        tx = await agent.reject_transaction(tx.id, user_id, "Not approved")
        
        assert tx.status == TransactionStatus.REJECTED
    
    @pytest.mark.asyncio
    async def test_large_transaction_creates_checkpoint_rule1(self, agent, user_id):
        """RULE 1: Large transactions create checkpoint."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("10000.00")
        )
        
        # Large transaction (>$1000)
        tx = await agent.create_transaction(
            account_id=account.id,
            amount=Decimal("5000.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Large purchase",
            user_id=user_id
        )
        
        tx, checkpoint = await agent.submit_transaction_for_approval(tx.id, user_id)
        
        # CANON Rule #1: Checkpoint created for large transactions
        assert checkpoint is not None
        assert checkpoint.checkpoint_type == CheckpointType.LARGE_TRANSACTION
        assert checkpoint.requires_approval == True
    
    @pytest.mark.asyncio
    async def test_transactions_chronological_rule5(self, agent, user_id):
        """RULE 5: Transactions in chronological order."""
        account = await agent.create_account(
            "Test", AccountType.CHECKING, "CAD", user_id, Decimal("5000.00")
        )
        
        for i in range(5):
            await agent.create_transaction(
                account_id=account.id,
                amount=Decimal("10.00"),
                transaction_type=TransactionType.EXPENSE,
                description=f"Transaction {i}",
                user_id=user_id
            )
        
        transactions = await agent.get_transactions(user_id)
        
        # CANON Rule #5: Chronological order (most recent first)
        for i in range(len(transactions) - 1):
            assert transactions[i].date >= transactions[i + 1].date


# ═══════════════════════════════════════════════════════════════════════════════
# BUDGET TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestBudgets:
    """Budget management tests."""
    
    @pytest.mark.asyncio
    async def test_budget_starts_as_draft(self, agent, user_id):
        """Budgets start as DRAFT."""
        budget = await agent.create_budget(
            name="Groceries",
            amount=Decimal("500.00"),
            period="monthly",
            user_id=user_id
        )
        
        assert budget.status == BudgetStatus.DRAFT
    
    @pytest.mark.asyncio
    async def test_budget_activation(self, agent, user_id):
        """Budget can be activated."""
        budget = await agent.create_budget(
            name="Entertainment",
            amount=Decimal("200.00"),
            period="monthly",
            user_id=user_id
        )
        
        budget = await agent.activate_budget(budget.id, user_id)
        
        assert budget.status == BudgetStatus.ACTIVE
    
    @pytest.mark.asyncio
    async def test_budget_status_tracking(self, agent, user_id):
        """Budget tracks spending."""
        budget = await agent.create_budget(
            name="Test Budget",
            amount=Decimal("1000.00"),
            period="monthly",
            user_id=user_id
        )
        
        await agent.activate_budget(budget.id, user_id)
        
        status = await agent.get_budget_status(budget.id)
        
        assert status["amount"] == 1000.00
        assert status["spent"] == 0.0
        assert status["remaining"] == 1000.00
        assert status["is_over_budget"] == False
    
    @pytest.mark.asyncio
    async def test_budget_traceability_rule6(self, agent, user_id):
        """RULE 6: Budgets fully traceable."""
        budget = await agent.create_budget(
            name="Test",
            amount=Decimal("100.00"),
            period="weekly",
            user_id=user_id
        )
        
        assert budget.id is not None
        assert budget.created_by == user_id
        assert budget.created_at is not None


# ═══════════════════════════════════════════════════════════════════════════════
# GOAL TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestGoals:
    """Financial goal tests."""
    
    @pytest.mark.asyncio
    async def test_create_goal(self, agent, user_id):
        """Can create financial goal."""
        goal = await agent.create_goal(
            name="Emergency Fund",
            target_amount=Decimal("10000.00"),
            user_id=user_id
        )
        
        assert goal.name == "Emergency Fund"
        assert goal.target_amount == Decimal("10000.00")
        assert goal.is_achieved == False
    
    @pytest.mark.asyncio
    async def test_goal_achievement(self, agent, user_id):
        """Goal marked achieved when target reached."""
        goal = await agent.create_goal(
            name="Vacation",
            target_amount=Decimal("2000.00"),
            user_id=user_id,
            initial_amount=Decimal("500.00")
        )
        
        goal = await agent.update_goal_progress(goal.id, Decimal("2000.00"), user_id)
        
        assert goal.is_achieved == True
    
    @pytest.mark.asyncio
    async def test_goals_chronological_rule5(self, agent, user_id):
        """RULE 5: Goals in chronological order."""
        await agent.create_goal("Goal 1", Decimal("1000"), user_id)
        await agent.create_goal("Goal 2", Decimal("2000"), user_id)
        await agent.create_goal("Goal 3", Decimal("3000"), user_id)
        
        goals = await agent.get_goals(user_id)
        
        for i in range(len(goals) - 1):
            assert goals[i].created_at <= goals[i + 1].created_at


# ═══════════════════════════════════════════════════════════════════════════════
# INVESTMENT TESTS - CANON RULE #2 (Autonomy Isolation)
# ═══════════════════════════════════════════════════════════════════════════════

class TestInvestments:
    """Investment tests with sandbox analysis."""
    
    @pytest.mark.asyncio
    async def test_investment_analysis_is_sandbox_rule2(self, agent, user_id):
        """RULE 2: Investment analysis is sandbox-only."""
        analysis = await agent.analyze_investment_opportunity(
            symbol="AAPL",
            amount=Decimal("1000.00"),
            user_id=user_id
        )
        
        # CANON Rule #2: Clearly marked as sandbox/simulation
        assert analysis["analysis_type"] == "sandbox"
        assert analysis["is_simulation"] == True
        assert analysis["requires_human_approval"] == True
    
    @pytest.mark.asyncio
    async def test_investment_requires_checkpoint_rule1(self, agent, user_id):
        """RULE 1: Investments always require checkpoint."""
        account = await agent.create_account(
            "Investment", AccountType.INVESTMENT, "CAD", user_id, Decimal("50000.00")
        )
        
        investment, checkpoint = await agent.create_investment_with_approval(
            symbol="MSFT",
            name="Microsoft",
            quantity=Decimal("10"),
            price=Decimal("400.00"),
            account_id=account.id,
            user_id=user_id
        )
        
        # CANON Rule #1: Mandatory checkpoint
        assert checkpoint is not None
        assert checkpoint.checkpoint_type == CheckpointType.INVESTMENT_DECISION
        assert checkpoint.requires_approval == True
        assert checkpoint.approved is None  # Not yet approved


# ═══════════════════════════════════════════════════════════════════════════════
# CHECKPOINT TESTS - CANON RULE #1 (Human Sovereignty)
# ═══════════════════════════════════════════════════════════════════════════════

class TestCheckpoints:
    """Checkpoint governance tests."""
    
    @pytest.mark.asyncio
    async def test_checkpoint_approval(self, agent, user_id):
        """Checkpoints can be approved."""
        account = await agent.create_account(
            "Investment", AccountType.INVESTMENT, "CAD", user_id
        )
        
        _, checkpoint = await agent.create_investment_with_approval(
            "TEST", "Test Corp", Decimal("1"), Decimal("100"),
            account.id, user_id
        )
        
        checkpoint = await agent.approve_checkpoint(checkpoint.id, user_id)
        
        assert checkpoint.approved == True
        assert checkpoint.approved_by == user_id
        assert checkpoint.approved_at is not None
    
    @pytest.mark.asyncio
    async def test_checkpoint_rejection(self, agent, user_id):
        """Checkpoints can be rejected."""
        account = await agent.create_account(
            "Investment", AccountType.INVESTMENT, "CAD", user_id
        )
        
        _, checkpoint = await agent.create_investment_with_approval(
            "TEST", "Test Corp", Decimal("1"), Decimal("100"),
            account.id, user_id
        )
        
        checkpoint = await agent.reject_checkpoint(checkpoint.id, user_id)
        
        assert checkpoint.approved == False
    
    @pytest.mark.asyncio
    async def test_get_pending_checkpoints(self, agent, user_id):
        """Can get pending checkpoints."""
        account = await agent.create_account(
            "Investment", AccountType.INVESTMENT, "CAD", user_id
        )
        
        # Create multiple investments (each creates checkpoint)
        await agent.create_investment_with_approval(
            "AAPL", "Apple", Decimal("5"), Decimal("180"), account.id, user_id
        )
        await agent.create_investment_with_approval(
            "GOOGL", "Google", Decimal("2"), Decimal("140"), account.id, user_id
        )
        
        pending = await agent.get_pending_checkpoints(user_id)
        
        assert len(pending) == 2
        assert all(c.approved is None for c in pending)


# ═══════════════════════════════════════════════════════════════════════════════
# REPORT TESTS - CANON RULE #2 (Read-Only Analysis)
# ═══════════════════════════════════════════════════════════════════════════════

class TestReports:
    """Financial report tests."""
    
    @pytest.mark.asyncio
    async def test_spending_report_is_readonly_rule2(self, agent, user_id):
        """RULE 2: Reports are read-only."""
        start = datetime.now(timezone.utc) - timedelta(days=30)
        end = datetime.now(timezone.utc)
        
        report = await agent.generate_spending_report(user_id, start, end)
        
        # CANON Rule #2: Clearly marked as read-only
        assert report.data["is_read_only"] == True
        assert report.report_type == "spending"
    
    @pytest.mark.asyncio
    async def test_net_worth_report(self, agent, user_id):
        """Can generate net worth report."""
        # Create accounts
        await agent.create_account(
            "Checking", AccountType.CHECKING, "CAD", user_id, Decimal("5000.00")
        )
        await agent.create_account(
            "Savings", AccountType.SAVINGS, "CAD", user_id, Decimal("10000.00")
        )
        await agent.create_account(
            "Credit Card", AccountType.CREDIT_CARD, "CAD", user_id, Decimal("-2000.00")
        )
        
        report = await agent.generate_net_worth_report(user_id)
        
        assert report.data["assets"] == 15000.0
        assert report.data["liabilities"] == 2000.0
        assert report.data["net_worth"] == 13000.0
        assert report.data["is_read_only"] == True


# ═══════════════════════════════════════════════════════════════════════════════
# CATEGORY TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestCategories:
    """Category tests."""
    
    @pytest.mark.asyncio
    async def test_create_category(self, agent, user_id):
        """Can create category."""
        category = await agent.create_category(
            name="Food",
            user_id=user_id,
            color="#10B981"
        )
        
        assert category.name == "Food"
        assert category.color == "#10B981"
    
    @pytest.mark.asyncio
    async def test_categories_alphabetical_rule5(self, agent, user_id):
        """RULE 5: Categories alphabetical (user-controlled)."""
        await agent.create_category("Zebra", user_id)
        await agent.create_category("Alpha", user_id)
        await agent.create_category("Middle", user_id)
        
        categories = await agent.get_categories(user_id)
        names = [c.name for c in categories]
        
        # CANON Rule #5: Alphabetical (deterministic, not algorithmic ranking)
        assert names == sorted(names, key=str.lower)


# ═══════════════════════════════════════════════════════════════════════════════
# INTEGRATION TESTS
# ═══════════════════════════════════════════════════════════════════════════════

class TestIntegration:
    """Full workflow integration tests."""
    
    @pytest.mark.asyncio
    async def test_full_finance_workflow(self, agent, user_id):
        """Test complete finance workflow."""
        # 1. Create accounts
        checking = await agent.create_account(
            "Checking", AccountType.CHECKING, "CAD", user_id, Decimal("5000.00")
        )
        savings = await agent.create_account(
            "Savings", AccountType.SAVINGS, "CAD", user_id, Decimal("10000.00")
        )
        
        # 2. Create category
        groceries = await agent.create_category("Groceries", user_id)
        
        # 3. Create budget
        budget = await agent.create_budget(
            name="Monthly Groceries",
            amount=Decimal("500.00"),
            period="monthly",
            user_id=user_id,
            category_id=groceries.id
        )
        await agent.activate_budget(budget.id, user_id)
        
        # 4. Create and process transaction
        tx = await agent.create_transaction(
            account_id=checking.id,
            amount=Decimal("75.00"),
            transaction_type=TransactionType.EXPENSE,
            description="Weekly groceries",
            user_id=user_id,
            category_id=groceries.id
        )
        
        tx, _ = await agent.submit_transaction_for_approval(tx.id, user_id)
        tx = await agent.approve_transaction(tx.id, user_id)
        tx = await agent.execute_transaction(tx.id, user_id)
        
        # 5. Create goal
        goal = await agent.create_goal(
            name="Emergency Fund",
            target_amount=Decimal("15000.00"),
            user_id=user_id,
            initial_amount=savings.balance
        )
        
        # 6. Generate reports
        start = datetime.now(timezone.utc) - timedelta(days=30)
        end = datetime.now(timezone.utc)
        spending_report = await agent.generate_spending_report(user_id, start, end)
        net_worth_report = await agent.generate_net_worth_report(user_id)
        
        # Verify
        checking = await agent.get_account(checking.id)
        assert checking.balance == Decimal("4925.00")
        
        assert spending_report.data["total_expense"] == 75.0
        assert net_worth_report.data["net_worth"] == 14925.0


# ═══════════════════════════════════════════════════════════════════════════════
# HEALTH CHECK
# ═══════════════════════════════════════════════════════════════════════════════

class TestHealthCheck:
    """Health check tests."""
    
    @pytest.mark.asyncio
    async def test_health_check(self, agent):
        """Agent health check passes."""
        health = await agent.get_health()
        
        assert health["status"] == "healthy"
        assert health["agent"] == "FinanceAgent"
        assert health["canon_compliant"] == True


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
