"""
CHE·NU™ V70 — LAYOUT ENGINE
============================
Dynamic layout management for workspace surfaces.

Based on: LAYOUT_ENGINE_CHAPTER.md

The Layout Engine manages the visual arrangement of workspace
elements, enabling fluid transitions between layouts and
responsive adaptation to content.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.layout")


# =============================================================================
# ENUMS
# =============================================================================

class LayoutType(str, Enum):
    """Types of layouts."""
    SINGLE = "single"
    SPLIT_HORIZONTAL = "split_horizontal"
    SPLIT_VERTICAL = "split_vertical"
    GRID = "grid"
    STACK = "stack"
    FLOATING = "floating"
    TABBED = "tabbed"
    DASHBOARD = "dashboard"


class PanelPosition(str, Enum):
    """Panel positions."""
    TOP = "top"
    BOTTOM = "bottom"
    LEFT = "left"
    RIGHT = "right"
    CENTER = "center"
    FLOATING = "floating"


class ResponsiveBreakpoint(str, Enum):
    """Responsive breakpoints."""
    MOBILE = "mobile"      # < 640px
    TABLET = "tablet"      # 640-1024px
    DESKTOP = "desktop"    # 1024-1440px
    LARGE = "large"        # > 1440px
    XR = "xr"              # XR environment


# =============================================================================
# MODELS
# =============================================================================

@dataclass
class Panel:
    """Layout panel."""
    panel_id: str = field(default_factory=lambda: f"PNL_{uuid4().hex[:8]}")
    
    # Position
    position: PanelPosition = PanelPosition.CENTER
    
    # Size
    width: str = "100%"   # Can be px, %, or flex
    height: str = "100%"
    min_width: str = "200px"
    min_height: str = "100px"
    
    # Content
    content_type: str = ""  # workspace_mode, widget, tool, etc.
    content_id: Optional[str] = None
    
    # State
    is_visible: bool = True
    is_collapsed: bool = False
    is_maximized: bool = False
    
    # Order
    z_index: int = 0
    order: int = 0
    
    # Metadata
    title: str = ""


@dataclass
class LayoutZone:
    """Layout zone containing panels."""
    zone_id: str = field(default_factory=lambda: f"ZONE_{uuid4().hex[:8]}")
    
    # Position in parent
    position: str = "center"
    
    # Size
    size: str = "1fr"  # flex fraction
    
    # Panels
    panels: List[Panel] = field(default_factory=list)
    
    # Nested zones
    children: List["LayoutZone"] = field(default_factory=list)
    
    # Direction
    direction: str = "row"  # row or column


@dataclass
class Layout:
    """Complete layout definition."""
    layout_id: str = field(default_factory=lambda: f"LYT_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Type
    layout_type: LayoutType = LayoutType.SINGLE
    
    # Root zone
    root: LayoutZone = field(default_factory=LayoutZone)
    
    # Responsive variants
    responsive_overrides: Dict[ResponsiveBreakpoint, Dict[str, Any]] = field(default_factory=dict)
    
    # Current breakpoint
    current_breakpoint: ResponsiveBreakpoint = ResponsiveBreakpoint.DESKTOP
    
    # Metadata
    name: str = ""
    is_locked: bool = False


@dataclass
class LayoutTransition:
    """Layout transition effect."""
    transition_id: str = field(default_factory=lambda: f"TRANS_{uuid4().hex[:8]}")
    
    # From/To
    from_layout: str = ""
    to_layout: str = ""
    
    # Animation
    duration_ms: int = 300
    easing: str = "ease-in-out"
    
    # Status
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


# =============================================================================
# LAYOUT TEMPLATES
# =============================================================================

def create_single_layout() -> Layout:
    """Create single panel layout."""
    return Layout(
        layout_type=LayoutType.SINGLE,
        name="Single Panel",
        root=LayoutZone(
            panels=[Panel(position=PanelPosition.CENTER)]
        ),
    )


def create_split_layout(vertical: bool = True) -> Layout:
    """Create split layout."""
    return Layout(
        layout_type=LayoutType.SPLIT_VERTICAL if vertical else LayoutType.SPLIT_HORIZONTAL,
        name="Split" + (" Vertical" if vertical else " Horizontal"),
        root=LayoutZone(
            direction="column" if vertical else "row",
            children=[
                LayoutZone(
                    size="1fr",
                    panels=[Panel(position=PanelPosition.TOP if vertical else PanelPosition.LEFT)]
                ),
                LayoutZone(
                    size="1fr",
                    panels=[Panel(position=PanelPosition.BOTTOM if vertical else PanelPosition.RIGHT)]
                ),
            ],
        ),
    )


def create_dashboard_layout() -> Layout:
    """Create dashboard layout with grid."""
    return Layout(
        layout_type=LayoutType.DASHBOARD,
        name="Dashboard",
        root=LayoutZone(
            direction="column",
            children=[
                LayoutZone(
                    size="auto",
                    panels=[Panel(title="Header", height="60px")]
                ),
                LayoutZone(
                    size="1fr",
                    direction="row",
                    children=[
                        LayoutZone(size="250px", panels=[Panel(title="Sidebar")]),
                        LayoutZone(size="1fr", panels=[Panel(title="Main Content")]),
                    ],
                ),
            ],
        ),
    )


def create_three_column_layout() -> Layout:
    """Create three column layout."""
    return Layout(
        layout_type=LayoutType.GRID,
        name="Three Column",
        root=LayoutZone(
            direction="row",
            children=[
                LayoutZone(size="250px", panels=[Panel(title="Left Sidebar")]),
                LayoutZone(size="1fr", panels=[Panel(title="Main")]),
                LayoutZone(size="300px", panels=[Panel(title="Right Panel")]),
            ],
        ),
    )


# =============================================================================
# LAYOUT ENGINE
# =============================================================================

class LayoutEngine:
    """
    CHE·NU Layout Engine.
    
    Manages dynamic layout arrangement and transitions.
    
    Features:
    - Layout templates
    - Dynamic panel management
    - Responsive adaptation
    - Smooth transitions
    - Layout persistence
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        self._layouts: Dict[str, Layout] = {}
        self._active_layout: Optional[str] = None
        self._transitions: List[LayoutTransition] = []
        self._register_default_layouts()
        logger.info("LayoutEngine initialized")
    
    def _register_default_layouts(self):
        """Register default layout templates."""
        defaults = [
            create_single_layout(),
            create_split_layout(vertical=True),
            create_split_layout(vertical=False),
            create_dashboard_layout(),
            create_three_column_layout(),
        ]
        
        for layout in defaults:
            self._layouts[layout.layout_id] = layout
    
    # =========================================================================
    # LAYOUT MANAGEMENT
    # =========================================================================
    
    def create_layout(
        self,
        layout_type: LayoutType,
        name: str = "",
    ) -> Layout:
        """Create a new layout."""
        layout = Layout(
            layout_type=layout_type,
            name=name,
        )
        
        self._layouts[layout.layout_id] = layout
        return layout
    
    def get_layout(self, layout_id: str) -> Optional[Layout]:
        """Get layout by ID."""
        return self._layouts.get(layout_id)
    
    def list_layouts(self) -> List[Layout]:
        """List all layouts."""
        return list(self._layouts.values())
    
    def set_active_layout(self, layout_id: str) -> bool:
        """Set active layout."""
        if layout_id not in self._layouts:
            return False
        
        old_layout = self._active_layout
        self._active_layout = layout_id
        
        if old_layout:
            self._record_transition(old_layout, layout_id)
        
        logger.info(f"Active layout set to: {layout_id}")
        return True
    
    def get_active_layout(self) -> Optional[Layout]:
        """Get current active layout."""
        if self._active_layout:
            return self.get_layout(self._active_layout)
        return None
    
    # =========================================================================
    # PANEL MANAGEMENT
    # =========================================================================
    
    def add_panel(
        self,
        layout_id: str,
        panel: Panel,
        zone_id: Optional[str] = None,
    ) -> bool:
        """Add panel to layout."""
        layout = self.get_layout(layout_id)
        if not layout:
            return False
        
        # Add to specified zone or root
        if zone_id:
            zone = self._find_zone(layout.root, zone_id)
            if zone:
                zone.panels.append(panel)
        else:
            layout.root.panels.append(panel)
        
        return True
    
    def remove_panel(
        self,
        layout_id: str,
        panel_id: str,
    ) -> bool:
        """Remove panel from layout."""
        layout = self.get_layout(layout_id)
        if not layout:
            return False
        
        return self._remove_panel_recursive(layout.root, panel_id)
    
    def _find_zone(
        self,
        zone: LayoutZone,
        zone_id: str,
    ) -> Optional[LayoutZone]:
        """Find zone by ID recursively."""
        if zone.zone_id == zone_id:
            return zone
        
        for child in zone.children:
            found = self._find_zone(child, zone_id)
            if found:
                return found
        
        return None
    
    def _remove_panel_recursive(
        self,
        zone: LayoutZone,
        panel_id: str,
    ) -> bool:
        """Remove panel recursively."""
        for panel in zone.panels:
            if panel.panel_id == panel_id:
                zone.panels.remove(panel)
                return True
        
        for child in zone.children:
            if self._remove_panel_recursive(child, panel_id):
                return True
        
        return False
    
    # =========================================================================
    # RESPONSIVE
    # =========================================================================
    
    def set_breakpoint(
        self,
        layout_id: str,
        breakpoint: ResponsiveBreakpoint,
    ) -> bool:
        """Set current responsive breakpoint."""
        layout = self.get_layout(layout_id)
        if not layout:
            return False
        
        layout.current_breakpoint = breakpoint
        logger.debug(f"Breakpoint set to {breakpoint.value} for layout {layout_id}")
        return True
    
    def detect_breakpoint(self, width: int) -> ResponsiveBreakpoint:
        """Detect breakpoint from viewport width."""
        if width < 640:
            return ResponsiveBreakpoint.MOBILE
        elif width < 1024:
            return ResponsiveBreakpoint.TABLET
        elif width < 1440:
            return ResponsiveBreakpoint.DESKTOP
        else:
            return ResponsiveBreakpoint.LARGE
    
    # =========================================================================
    # TRANSITIONS
    # =========================================================================
    
    def _record_transition(
        self,
        from_layout: str,
        to_layout: str,
    ) -> LayoutTransition:
        """Record layout transition."""
        transition = LayoutTransition(
            from_layout=from_layout,
            to_layout=to_layout,
            started_at=datetime.utcnow(),
        )
        
        self._transitions.append(transition)
        return transition
    
    def transition_to(
        self,
        layout_id: str,
        duration_ms: int = 300,
    ) -> Optional[LayoutTransition]:
        """Transition to a new layout."""
        if layout_id not in self._layouts:
            return None
        
        transition = self._record_transition(
            self._active_layout or "",
            layout_id,
        )
        transition.duration_ms = duration_ms
        
        self._active_layout = layout_id
        transition.completed_at = datetime.utcnow()
        
        return transition
    
    # =========================================================================
    # PRESETS
    # =========================================================================
    
    def apply_preset(
        self,
        preset: str,
    ) -> Optional[Layout]:
        """Apply a layout preset."""
        presets = {
            "single": create_single_layout,
            "split_v": lambda: create_split_layout(True),
            "split_h": lambda: create_split_layout(False),
            "dashboard": create_dashboard_layout,
            "three_column": create_three_column_layout,
        }
        
        creator = presets.get(preset)
        if not creator:
            return None
        
        layout = creator()
        self._layouts[layout.layout_id] = layout
        self.set_active_layout(layout.layout_id)
        
        return layout
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        return {
            "layouts": len(self._layouts),
            "active_layout": self._active_layout,
            "transitions": len(self._transitions),
            "by_type": {
                t.value: sum(
                    1 for l in self._layouts.values()
                    if l.layout_type == t
                )
                for t in LayoutType
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_layout_engine: Optional[LayoutEngine] = None


def get_layout_engine() -> LayoutEngine:
    """Get the layout engine singleton."""
    global _layout_engine
    if _layout_engine is None:
        _layout_engine = LayoutEngine()
    return _layout_engine
