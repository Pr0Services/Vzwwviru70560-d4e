"""
CHE·NU™ V71 — API Package
=========================
FastAPI application and routes.
"""

from .main import app

__all__ = ["app"]
