# CHE·NU™ OpenAPI Configuration
# This module enhances FastAPI's automatic OpenAPI generation

"""
OpenAPI Configuration for CHE·NU API v2.0

This module provides:
1. Custom OpenAPI schema generation
2. API tags and descriptions
3. Security schemes
4. Common response models
5. Example payloads
"""

from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
from enum import Enum


# ============================================================================
# API TAGS
# ============================================================================

API_TAGS = [
    {
        "name": "Authentication",
        "description": "User authentication and session management. Register, login, logout, and token management.",
    },
    {
        "name": "Threads",
        "description": """
Thread V2 API - The source of truth in CHE·NU.

Threads are immutable event logs representing intentions, projects, or activities.

**Key Concepts:**
- **Founding Intent**: Immutable declaration of purpose
- **Events**: Append-only timeline of changes
- **Snapshots**: Derived state at a point in time
- **Tri-Layer Memory**: Hot (recent), Warm (indexed), Cold (archived)
        """,
    },
    {
        "name": "Spheres",
        "description": """
The 9 Spheres of CHE·NU.

CHE·NU organizes life into 9 distinct spheres:
- 🏠 Personal
- 💼 Business
- 🏛️ Government
- 🎨 Creative Studio
- 👥 Community
- 📱 Social & Media
- 🎬 Entertainment
- 🤝 My Team
- 📚 Scholar

Each sphere contains 6 Bureau Sections: QuickCapture, ResumeWorkspace, Threads, DataFiles, ActiveAgents, Meetings.
        """,
    },
    {
        "name": "Agents",
        "description": """
226 Specialized AI Agents.

Agents are governed AI assistants specialized for specific tasks.

**Key Rules (R&D Compliance):**
- Agents NEVER make autonomous decisions
- All executions require human approval (checkpoint)
- Token budgets enforced per agent
- Full audit trail for all actions
        """,
    },
    {
        "name": "Nova Pipeline",
        "description": """
Nova Multi-Lane AI Pipeline.

Nova is CHE·NU's 7-lane AI processing system:
- Lane A: Intent Analysis
- Lane B: Context Snapshot
- Lane C: Semantic Encoding
- Lane D: Governance Check
- Lane E: Checkpoint (HTTP 423)
- Lane F: Execution
- Lane G: Audit
        """,
    },
    {
        "name": "Governance",
        "description": """
Governance and Orchestration APIs.

Implements CHE·NU's core principle: **GOVERNANCE > EXECUTION**

Includes:
- Orchestrator decision making
- CEA (Contextual Ethics Assessment) checks
- Backlog management
- Decision Points system
- QCT (Quality-Cost-Time) computation
        """,
    },
    {
        "name": "Checkpoints",
        "description": """
Human Validation Checkpoints.

Implements Rule #1: Human Sovereignty.

**Checkpoint Types:**
- `governance`: Action requires approval
- `cost`: Budget exceeded
- `identity`: Cross-identity access
- `sensitive`: Sensitive operation

**HTTP 423 LOCKED** is returned when checkpoint is required.
        """,
    },
    {
        "name": "XR Environment",
        "description": """
XR (Mixed Reality) Environment Generation.

CHE·NU generates immersive XR environments from Thread state.

**Key Concepts:**
- **Maturity Levels**: SEED → SPROUT → WORKSHOP → STUDIO → ECOSYSTEM
- **Templates**: personal_room, business_room, cause_room, lab_room
- **Canonical Zones**: intent_wall, decision_wall, action_table, memory_kiosk, timeline_strip, resource_shelf

**Rule #3**: XR is PROJECTION only. Thread is source of truth.
        """,
    },
    {
        "name": "WebSocket",
        "description": """
Real-Time WebSocket API.

Subscribe to real-time updates for:
- Thread events
- Checkpoint notifications
- Agent execution status
- Sphere updates
        """,
    },
]


# ============================================================================
# SECURITY SCHEMES
# ============================================================================

SECURITY_SCHEMES = {
    "BearerAuth": {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
        "description": "JWT access token obtained from /auth/login",
    },
    "OAuth2": {
        "type": "oauth2",
        "flows": {
            "password": {
                "tokenUrl": "/api/v2/auth/login",
                "refreshUrl": "/api/v2/auth/refresh",
                "scopes": {
                    "read": "Read access to resources",
                    "write": "Write access to resources",
                    "admin": "Admin access",
                },
            }
        },
    },
}


# ============================================================================
# COMMON RESPONSE MODELS
# ============================================================================

class ErrorDetail(BaseModel):
    """Individual error detail."""
    field: Optional[str] = Field(None, description="Field that caused the error")
    message: str = Field(..., description="Error message")


class ErrorResponse(BaseModel):
    """Standard error response."""
    code: str = Field(..., description="Error code", example="VALIDATION_ERROR")
    message: str = Field(..., description="Human-readable error message")
    details: Optional[List[ErrorDetail]] = Field(None, description="Detailed error information")


class CheckpointResponse(BaseModel):
    """Checkpoint response for HTTP 423."""
    id: str = Field(..., description="Checkpoint ID")
    type: str = Field(..., description="Checkpoint type", example="governance")
    reason: str = Field(..., description="Reason for checkpoint")
    requires_approval: bool = Field(True, description="Whether approval is required")
    options: List[str] = Field(..., description="Available options", example=["approve", "reject"])


class LockedResponse(BaseModel):
    """HTTP 423 LOCKED response."""
    status: str = Field("checkpoint_pending", description="Status indicator")
    checkpoint: CheckpointResponse = Field(..., description="Checkpoint details")


class IdentityBoundaryResponse(BaseModel):
    """HTTP 403 Identity Boundary response."""
    error: str = Field("identity_boundary_violation", description="Error type")
    message: str = Field(..., description="Error message")
    requested_identity: str = Field(..., description="Identity that made the request")
    resource_identity: str = Field(..., description="Identity that owns the resource")


# ============================================================================
# COMMON RESPONSES
# ============================================================================

COMMON_RESPONSES = {
    400: {
        "description": "Bad Request - Invalid input",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                "example": {
                    "error": {
                        "code": "VALIDATION_ERROR",
                        "message": "Invalid input data",
                        "details": [{"field": "email", "message": "Invalid email format"}]
                    }
                }
            }
        }
    },
    401: {
        "description": "Unauthorized - Authentication required",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                "example": {
                    "error": {
                        "code": "AUTHENTICATION_ERROR",
                        "message": "Invalid or expired token"
                    }
                }
            }
        }
    },
    403: {
        "description": "Forbidden - Identity boundary violation",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/IdentityBoundaryResponse"},
                "example": {
                    "error": "identity_boundary_violation",
                    "message": "Access denied: resource belongs to different identity",
                    "requested_identity": "uuid_a",
                    "resource_identity": "uuid_b"
                }
            }
        }
    },
    404: {
        "description": "Not Found - Resource not found",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                "example": {
                    "error": {
                        "code": "RESOURCE_NOT_FOUND",
                        "message": "Thread not found"
                    }
                }
            }
        }
    },
    423: {
        "description": "Locked - Checkpoint required (Human approval needed)",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/LockedResponse"},
                "example": {
                    "status": "checkpoint_pending",
                    "checkpoint": {
                        "id": "uuid",
                        "type": "governance",
                        "reason": "Action requires human approval",
                        "requires_approval": True,
                        "options": ["approve", "reject"]
                    }
                }
            }
        }
    },
    429: {
        "description": "Too Many Requests - Rate limited",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                "example": {
                    "error": {
                        "code": "RATE_LIMIT_EXCEEDED",
                        "message": "Too many requests",
                        "retry_after": 30
                    }
                }
            }
        }
    },
    500: {
        "description": "Internal Server Error",
        "content": {
            "application/json": {
                "schema": {"$ref": "#/components/schemas/ErrorResponse"},
                "example": {
                    "error": {
                        "code": "INTERNAL_ERROR",
                        "message": "An unexpected error occurred"
                    }
                }
            }
        }
    },
}


# ============================================================================
# OPENAPI CUSTOMIZATION
# ============================================================================

def custom_openapi_schema(app) -> Dict[str, Any]:
    """
    Generate custom OpenAPI schema for CHE·NU API.
    
    Enhances FastAPI's automatic schema with:
    - Custom tags and descriptions
    - Security schemes
    - Common response models
    - Server information
    """
    from fastapi.openapi.utils import get_openapi
    
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title="CHE·NU™ API",
        version="2.0.0",
        description="""
# CHE·NU™ — Governed Intelligence Operating System

## Overview

CHE·NU is a comprehensive platform for managing intentions, data, AI agents, and costs with **human governance** at its core.

## Core Principles

1. **Governance > Execution** - Systems guide decisions; humans decide
2. **Human Sovereignty** - No action without human approval
3. **Thread = Source of Truth** - Immutable event logs
4. **9 Spheres** - Life organized into distinct domains
5. **226 Agents** - Specialized AI assistants

## Governance Responses

When an action requires human approval, the API returns:

- **HTTP 423 LOCKED** - Checkpoint required
- **HTTP 403 FORBIDDEN** - Identity boundary violation

## Authentication

All endpoints (except /auth/register, /auth/login) require Bearer token authentication.

```
Authorization: Bearer <access_token>
```

## Rate Limiting

- Read operations: 100 req/min
- Write operations: 30 req/min
- Agent execution: 10 req/min

## R&D Rules (7 Non-Negotiable Rules)

1. Human Sovereignty - No autonomous actions
2. Autonomy Isolation - AI operates in sandbox
3. Sphere Integrity - No implicit cross-sphere access
4. My Team Restrictions - No AI-to-AI orchestration
5. Social Restrictions - No ranking algorithms
6. Module Traceability - Full audit trail
7. R&D Continuity - Build on existing decisions
        """,
        routes=app.routes,
        tags=API_TAGS,
    )
    
    # Add security schemes
    openapi_schema["components"]["securitySchemes"] = SECURITY_SCHEMES
    
    # Add common response schemas
    openapi_schema["components"]["schemas"]["ErrorResponse"] = ErrorResponse.model_json_schema()
    openapi_schema["components"]["schemas"]["LockedResponse"] = LockedResponse.model_json_schema()
    openapi_schema["components"]["schemas"]["IdentityBoundaryResponse"] = IdentityBoundaryResponse.model_json_schema()
    
    # Add servers
    openapi_schema["servers"] = [
        {"url": "https://api.che-nu.com/api/v2", "description": "Production"},
        {"url": "http://localhost:8000/api/v2", "description": "Development"},
    ]
    
    # Add external docs
    openapi_schema["externalDocs"] = {
        "description": "CHE·NU Documentation",
        "url": "https://docs.che-nu.com",
    }
    
    # Add contact info
    openapi_schema["info"]["contact"] = {
        "name": "CHE·NU Support",
        "url": "https://che-nu.com/support",
        "email": "support@che-nu.com",
    }
    
    # Add license
    openapi_schema["info"]["license"] = {
        "name": "Proprietary",
        "url": "https://che-nu.com/license",
    }
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema


# ============================================================================
# ENDPOINT DECORATORS
# ============================================================================

def governance_endpoint(
    checkpoint_types: List[str] = None,
    requires_approval: bool = True
):
    """
    Decorator to mark endpoints that may return HTTP 423.
    
    Usage:
        @router.post("/execute")
        @governance_endpoint(checkpoint_types=["governance", "cost"])
        async def execute():
            ...
    """
    def decorator(func):
        func.__governance_endpoint__ = True
        func.__checkpoint_types__ = checkpoint_types or ["governance"]
        func.__requires_approval__ = requires_approval
        return func
    return decorator


def identity_boundary(require_ownership: bool = True):
    """
    Decorator to mark endpoints that enforce identity boundary.
    
    Usage:
        @router.get("/{resource_id}")
        @identity_boundary(require_ownership=True)
        async def get_resource():
            ...
    """
    def decorator(func):
        func.__identity_boundary__ = True
        func.__require_ownership__ = require_ownership
        return func
    return decorator


# ============================================================================
# EXAMPLE PAYLOADS
# ============================================================================

EXAMPLE_PAYLOADS = {
    "thread_create": {
        "founding_intent": "Build a personal finance tracker",
        "thread_type": "personal",
        "sphere_id": "123e4567-e89b-12d3-a456-426614174000",
        "visibility": "private",
        "initial_context": {
            "tags": ["finance", "personal"],
            "priority": "high"
        }
    },
    "event_append": {
        "event_type": "note.added",
        "data": {
            "content": "Researched React vs Vue comparison",
            "tags": ["research", "frontend"]
        }
    },
    "decision_record": {
        "decision": "Use PostgreSQL for database",
        "rationale": "ACID compliance and JSON support",
        "alternatives_considered": [
            "MongoDB - rejected due to consistency requirements",
            "MySQL - rejected due to JSON limitations"
        ]
    },
    "action_create": {
        "title": "Design database schema",
        "description": "Create ERD for expense tracker",
        "priority": "high",
        "due_date": "2026-01-10T17:00:00Z"
    },
    "agent_execute": {
        "thread_id": "123e4567-e89b-12d3-a456-426614174000",
        "input": {
            "content": "Organize these notes by topic",
            "notes": ["note1", "note2"]
        },
        "parameters": {
            "max_categories": 5
        }
    },
    "nova_process": {
        "input": "Help me organize my project notes",
        "context": {
            "thread_id": "123e4567-e89b-12d3-a456-426614174000",
            "sphere_id": "123e4567-e89b-12d3-a456-426614174001"
        },
        "options": {
            "max_tokens": 1000,
            "temperature": 0.7
        }
    },
    "checkpoint_approve": {
        "approval_note": "Approved for this specific task"
    },
    "checkpoint_reject": {
        "reason": "Not needed at this time"
    },
}


# ============================================================================
# API METRICS
# ============================================================================

class APIMetrics:
    """Track API usage metrics."""
    
    def __init__(self):
        self.total_requests = 0
        self.requests_by_endpoint = {}
        self.requests_by_status = {}
        self.checkpoints_triggered = 0
        self.identity_violations = 0
    
    def record_request(
        self,
        endpoint: str,
        method: str,
        status_code: int,
        latency_ms: float
    ):
        """Record a request."""
        self.total_requests += 1
        
        key = f"{method}:{endpoint}"
        if key not in self.requests_by_endpoint:
            self.requests_by_endpoint[key] = {"count": 0, "total_latency": 0}
        self.requests_by_endpoint[key]["count"] += 1
        self.requests_by_endpoint[key]["total_latency"] += latency_ms
        
        if status_code not in self.requests_by_status:
            self.requests_by_status[status_code] = 0
        self.requests_by_status[status_code] += 1
        
        if status_code == 423:
            self.checkpoints_triggered += 1
        elif status_code == 403:
            self.identity_violations += 1
    
    def get_stats(self) -> Dict[str, Any]:
        """Get API statistics."""
        return {
            "total_requests": self.total_requests,
            "requests_by_endpoint": self.requests_by_endpoint,
            "requests_by_status": self.requests_by_status,
            "checkpoints_triggered": self.checkpoints_triggered,
            "identity_violations": self.identity_violations,
        }


# Singleton metrics instance
api_metrics = APIMetrics()


# ============================================================================
# EXPORTS
# ============================================================================

__all__ = [
    # Tags and configuration
    "API_TAGS",
    "SECURITY_SCHEMES",
    "COMMON_RESPONSES",
    
    # Response models
    "ErrorDetail",
    "ErrorResponse",
    "CheckpointResponse",
    "LockedResponse",
    "IdentityBoundaryResponse",
    
    # Functions
    "custom_openapi_schema",
    
    # Decorators
    "governance_endpoint",
    "identity_boundary",
    
    # Examples
    "EXAMPLE_PAYLOADS",
    
    # Metrics
    "APIMetrics",
    "api_metrics",
]
