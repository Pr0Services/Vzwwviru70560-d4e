# MANIFEST — Module Canon & Simulation
# CHE·NU™ Integration Package
# Date: 2026-01-07
# Version: V1.0

## 📦 MODULE OVERVIEW

| Propriété | Valeur |
|-----------|--------|
| Module ID | `core.canon` + `simulation.scenario_lock` |
| Nom | Need Canon + Module Catalog + Scenario-Lock |
| Version | 1.0.0 |
| Status | BETA |
| Risque | LOW |
| Dépendances | Aucune |

## 🎯 MISSION

### Need Canon
Taxonomie stable et extensible des besoins humains/système utilisée pour:
- Mapper les modules aux besoins
- Générer des scénarios de simulation
- Prioriser le développement

### Module Catalog
Catalogue des modules CHE·NU avec:
- Besoins servis
- Dépendances
- Niveaux de risque et coûts
- Checkpoints de gouvernance

### Scenario-Lock Simulation
Chaque simulation est un cadenas combinatoire:
```
run = template × factors × module_set
```
On varie les facteurs, PAS la forme.

## 📁 STRUCTURE DES FICHIERS

```
canon/
├── backend/
│   ├── need_canon.py            # 400+ lignes - Need Canon + Module Catalog
│   ├── scenario_lock.py         # 550+ lignes - Simulation Engine
│   └── api_routes.py            # Routes FastAPI (partagé)
├── frontend/
│   └── CanonSimulationComponents.tsx  # 600+ lignes - React components
├── catalog/
│   ├── need_canon.v1.yaml
│   └── module_catalog.v1.yaml
├── scenarios/
│   ├── templates/
│   │   ├── template.onboarding_30d.v1.json
│   │   ├── template.project_assisted_30d.v1.json
│   │   └── template.incident_response_30d.v1.json
│   └── factors/
│       └── factor_library.v1.json
├── simulation/
│   ├── dsl/
│   │   ├── README_DSL.md
│   │   └── examples/
│   │       └── example.onboarding_30d.dsl
│   ├── generator/
│   │   └── GENERATOR_SPEC.md
│   └── outputs/
│       └── run_report.schema.json
├── docs/
│   ├── ALIGNMENT_NOTES.md
│   ├── catalog/
│   │   └── MODULE_CATALOG_V1.md
│   ├── simulation/
│   │   └── SCENARIO_LOCK_SYSTEM.md
│   └── canon/
│       └── NEED_CANON_V1.md
└── README.md
```

## 📊 STATISTIQUES

| Type | Fichiers | Lignes |
|------|----------|--------|
| Backend Python | 3 | ~1,400 |
| Frontend TSX | 1 | ~600 |
| YAML Configs | 2 | ~200 |
| JSON Templates | 5 | ~300 |
| Documentation | 6 | ~200 |
| **TOTAL** | **17** | **~2,700** |

## 🔌 API ENDPOINTS

### Canon
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/canon/needs` | Liste des besoins |
| GET | `/canon/needs/{id}` | Détail d'un besoin |
| GET | `/canon/modules` | Liste des modules |
| GET | `/canon/modules/{id}` | Détail d'un module |
| GET | `/canon/modules/{id}/dependencies` | Dépendances |
| GET | `/canon/modules/{id}/dependency-tree` | Arbre complet |
| GET | `/canon/modules/high-risk` | Modules à risque |
| GET | `/canon/needs/{id}/modules` | Modules pour besoin |
| GET | `/canon/export/yaml` | Export YAML |

### Simulation
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/simulation/templates` | Templates disponibles |
| GET | `/simulation/factors` | Facteurs configurables |
| POST | `/simulation/run` | Exécuter simulation complète |
| POST | `/simulation/run/create` | Créer run sans exécuter |
| POST | `/simulation/run/{id}/start` | Démarrer run |
| POST | `/simulation/run/{id}/day` | Exécuter un jour |
| GET | `/simulation/run/{id}/report` | Rapport du run |

## 📜 NEED CATEGORIES

| Catégorie | Description | Exemples |
|-----------|-------------|----------|
| `organize` | Organisation | Tâches, projets, agenda |
| `communicate` | Communication | Messages, réunions |
| `remember` | Mémoire | Préférences, décisions |
| `decide` | Décision | Comparaisons, recommandations |
| `create` | Création | Contenu, brainstorming |
| `protect` | Protection | Accès, audit, identité |
| `learn` | Apprentissage | Patterns, amélioration |
| `automate` | Automatisation | Batch, scheduling |
| `collaborate` | Collaboration | Partage, coordination |

## 🔐 DSL PRIMITIVES

```
DAY n:
  ACTION <type> <payload>
  CALL <channel> <duration_min> <topic>
  MEETING <duration_min> <agenda_ref>
  ACTIVATE <module_id> <mode>
  INTEGRATION <provider> <operation>
  DECISION_POINT <create|respond|defer|archive> <payload>
  EXPECT <metric> <target>
  INJECT <fault>
```

## 🧪 TESTS

```bash
cd backend
python -m need_canon      # Tests Need Canon + Module Catalog
python -m scenario_lock   # Tests Simulation Engine
```

Tests couverts:
- ✓ Need Canon initialisé avec 20+ besoins
- ✓ Catégories fonctionnent
- ✓ Module Catalog initialisé avec 10+ modules
- ✓ Mapping besoin → modules
- ✓ Dépendances fonctionnent
- ✓ Filtrage risque fonctionne
- ✓ Export YAML fonctionne
- ✓ Création de run
- ✓ Simulation complète
- ✓ Pas de violations de gouvernance

## 🔗 INTÉGRATION

### Backend (FastAPI)
```python
from canon.backend.need_canon import NeedCanon, ModuleCatalog
from canon.backend.scenario_lock import ScenarioLockEngine
from canon.backend.api_routes import router_canon, router_simulation

app.include_router(router_canon, prefix="/api/v1")
app.include_router(router_simulation, prefix="/api/v1")
```

### Frontend (React)
```tsx
import { 
  NeedCanonBrowser,
  ModuleCatalogBrowser,
  SimulationDashboard,
  SimulationRunReport 
} from './canon/frontend/CanonSimulationComponents';
```

## ⚠️ CE QUI RESTE MOCK/PLACEHOLDER

- Persistance des runs en base de données
- Génération automatique de runs (batch)
- Intégration avec métriques réelles
- Visualisation temps réel des runs
- Export des rapports en PDF

## 🔐 GOUVERNANCE

- Toutes les simulations sont `synthetic: true`
- Aucun lien avec données réelles
- Aucun effet réel
- Les checkpoints de gouvernance sont trackés mais simulés

## 📋 CHECKLIST D'INTÉGRATION

- [ ] Copier `backend/` vers `app/modules/canon/`
- [ ] Copier `frontend/` vers `src/modules/canon/`
- [ ] Copier `catalog/` vers `app/data/canon/`
- [ ] Copier `scenarios/` vers `app/data/scenarios/`
- [ ] Ajouter routes à FastAPI main
- [ ] Configurer base de données pour runs
- [ ] Implémenter générateur de runs batch
- [ ] Intégrer avec dashboard principal
- [ ] Tests E2E
