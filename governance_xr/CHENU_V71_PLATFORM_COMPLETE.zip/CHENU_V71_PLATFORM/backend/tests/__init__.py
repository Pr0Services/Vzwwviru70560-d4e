"""CHE·NU™ V70 — GP2 Tests Package"""
__version__ = "70.0.0"
