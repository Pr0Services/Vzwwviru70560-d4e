"""
CHE·NU™ FastAPI Dependencies

Reusable dependencies for authentication, authorization, and database access.
"""

from typing import Optional, Annotated
from uuid import UUID

from fastapi import Depends, Header, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from backend.core.database import get_db
from backend.core.security import (
    verify_access_token,
    TokenPayload,
    TokenVerificationError,
    is_token_blacklisted,
)
from backend.core.exceptions import (
    AuthenticationError,
    TokenExpiredError,
    TokenInvalidError,
    TokenBlacklistedError,
    IdentityBoundaryError,
)


# ═══════════════════════════════════════════════════════════════════════════════
# SECURITY SCHEME
# ═══════════════════════════════════════════════════════════════════════════════

security = HTTPBearer(auto_error=False)


# ═══════════════════════════════════════════════════════════════════════════════
# CURRENT USER
# ═══════════════════════════════════════════════════════════════════════════════

class CurrentUser:
    """Represents the authenticated user from JWT."""
    
    def __init__(self, token: TokenPayload):
        self.id = token.sub
        self.identity_id = token.identity_id
        self.email = token.email
        self.name = token.name
        self.roles = token.roles
        self.token_id = token.jti
    
    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        return role in self.roles
    
    def is_admin(self) -> bool:
        """Check if user is admin."""
        return self.has_role("admin")


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> CurrentUser:
    """
    Dependency to get current authenticated user.
    
    Usage:
        @router.get("/protected")
        async def protected_route(user: CurrentUser = Depends(get_current_user)):
            return {"user_id": user.id}
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    try:
        token = verify_access_token(credentials.credentials)
        
        # Check if token is blacklisted (logged out)
        if is_token_blacklisted(token.jti):
            raise TokenBlacklistedError("Token has been revoked")
        
        return CurrentUser(token)
        
    except TokenVerificationError as e:
        if "expired" in str(e).lower():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired",
                headers={"WWW-Authenticate": "Bearer"},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
            headers={"WWW-Authenticate": "Bearer"},
        )


async def get_optional_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[CurrentUser]:
    """
    Dependency for optional authentication.
    Returns None if no valid token provided.
    
    Usage:
        @router.get("/public")
        async def public_route(user: Optional[CurrentUser] = Depends(get_optional_user)):
            if user:
                return {"message": f"Hello {user.name}"}
            return {"message": "Hello guest"}
    """
    if not credentials:
        return None
    
    try:
        token = verify_access_token(credentials.credentials)
        if is_token_blacklisted(token.jti):
            return None
        return CurrentUser(token)
    except TokenVerificationError:
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# ROLE-BASED ACCESS
# ═══════════════════════════════════════════════════════════════════════════════

def require_role(role: str):
    """
    Dependency factory for role-based access.
    
    Usage:
        @router.get("/admin-only")
        async def admin_route(user: CurrentUser = Depends(require_role("admin"))):
            ...
    """
    async def role_checker(
        user: CurrentUser = Depends(get_current_user),
    ) -> CurrentUser:
        if not user.has_role(role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Role '{role}' required",
            )
        return user
    
    return role_checker


def require_admin():
    """Dependency for admin-only routes."""
    return require_role("admin")


# ═══════════════════════════════════════════════════════════════════════════════
# IDENTITY BOUNDARY ENFORCEMENT
# ═══════════════════════════════════════════════════════════════════════════════

class IdentityBoundaryChecker:
    """
    Enforces identity boundary on resources.
    
    R&D Rule: Each user only sees their own data.
    HTTP 403 if attempting to access another user's resources.
    """
    
    def __init__(self, user: CurrentUser):
        self.user = user
        self.identity_id = user.identity_id
    
    def check(
        self,
        resource_identity_id: str,
        resource_type: str = "resource",
    ) -> bool:
        """
        Check if access is within identity boundary.
        
        Raises IdentityBoundaryError (HTTP 403) if violation.
        """
        if self.identity_id != resource_identity_id:
            raise IdentityBoundaryError(
                requested_identity=self.identity_id,
                resource_identity=resource_identity_id,
                resource_type=resource_type,
            )
        return True


async def get_identity_checker(
    user: CurrentUser = Depends(get_current_user),
) -> IdentityBoundaryChecker:
    """Get identity boundary checker for current user."""
    return IdentityBoundaryChecker(user)


# ═══════════════════════════════════════════════════════════════════════════════
# DATABASE SESSION
# ═══════════════════════════════════════════════════════════════════════════════

# Type alias for cleaner dependency injection
DBSession = Annotated[AsyncSession, Depends(get_db)]


# ═══════════════════════════════════════════════════════════════════════════════
# PAGINATION
# ═══════════════════════════════════════════════════════════════════════════════

class PaginationParams:
    """Common pagination parameters."""
    
    def __init__(
        self,
        page: int = 1,
        page_size: int = 20,
        max_page_size: int = 100,
    ):
        self.page = max(1, page)
        self.page_size = min(max(1, page_size), max_page_size)
        self.offset = (self.page - 1) * self.page_size
    
    @property
    def limit(self) -> int:
        return self.page_size


async def get_pagination(
    page: int = 1,
    page_size: int = 20,
) -> PaginationParams:
    """Dependency for pagination parameters."""
    return PaginationParams(page=page, page_size=page_size)


# ═══════════════════════════════════════════════════════════════════════════════
# SPHERE CONTEXT
# ═══════════════════════════════════════════════════════════════════════════════

async def get_sphere_context(
    sphere_id: Optional[str] = Header(None, alias="X-Sphere-ID"),
) -> Optional[str]:
    """
    Get current sphere context from header.
    
    Used to scope operations to a specific sphere.
    """
    return sphere_id


# ═══════════════════════════════════════════════════════════════════════════════
# REQUEST ID
# ═══════════════════════════════════════════════════════════════════════════════

async def get_request_id(
    request_id: Optional[str] = Header(None, alias="X-Request-ID"),
) -> Optional[str]:
    """Get request ID from header for tracing."""
    return request_id
