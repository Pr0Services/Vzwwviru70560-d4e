"""
CHE·NU™ V70 — MEETING SYSTEM PACKAGE
====================================
Complete meeting lifecycle management.

Based on: MEETING_SYSTEM_CHAPTER.md (Chapters 71-80)

In CHE·NU's philosophy, meetings are not mere video calls—
they are knowledge events that generate structured, actionable,
and replayable artifacts.

GOUVERNANCE > EXÉCUTION
"""

from .engine import (
    # Enums
    MeetingType,
    MeetingStatus,
    ParticipantRole,
    DecisionStatus,
    # Models
    Participant,
    AgendaItem,
    MeetingAgenda,
    MeetingNote,
    MeetingNotes,
    MeetingTask,
    MeetingDecision,
    MeetingRecording,
    XRMeetingSession,
    Meeting,
    # Engine
    MeetingEngine,
    get_meeting_engine,
)

__all__ = [
    "MeetingType",
    "MeetingStatus",
    "ParticipantRole",
    "DecisionStatus",
    "Participant",
    "AgendaItem",
    "MeetingAgenda",
    "MeetingNote",
    "MeetingNotes",
    "MeetingTask",
    "MeetingDecision",
    "MeetingRecording",
    "XRMeetingSession",
    "Meeting",
    "MeetingEngine",
    "get_meeting_engine",
]

__version__ = "70.0.0"
