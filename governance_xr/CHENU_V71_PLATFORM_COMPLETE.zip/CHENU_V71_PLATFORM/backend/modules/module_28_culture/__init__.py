"""
CHE·NU™ V70 — MODULE 28: CULTURE & MYTH ENGINE
===============================================
Donne aux communautés une couche narrative partagée GOUVERNÉE.

Outcomes clés:
- Cultural Map d'une communauté
- Myth/Story Generator pour l'apprentissage civique
- Cultural Compatibility Score pour policies/projets
- Anti-propaganda safeguards

HARD BANS:
- Coercive persuasion
- Targeting vulnerabilities
- Hate or dehumanization
- "Us vs them" amplification
"""

from .engine import (
    StoryMode,
    MythReviewMode,
    CultureProfile,
    MythArtifact,
    CulturalFrictionPrediction,
    CultureSignalExtractor,
    NarrativeCompiler,
    CulturalFrictionPredictor,
    CultureMythEngine,
)

__all__ = [
    "StoryMode",
    "MythReviewMode",
    "CultureProfile",
    "MythArtifact",
    "CulturalFrictionPrediction",
    "CultureSignalExtractor",
    "NarrativeCompiler",
    "CulturalFrictionPredictor",
    "CultureMythEngine",
]

__version__ = "70.0.0"
