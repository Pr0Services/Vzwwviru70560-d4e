# Suggested commit messages (in order)

1) docs(xr): add thread→environment generator spec + invariants
2) feat(xr): add blueprint schema + validation utilities
3) feat(api): add xr generate + blueprint endpoints
4) feat(agent): add environment generator agent (on-demand)
5) feat(frontend): load blueprint + render minimal room zones
6) test(xr): add projection-only acceptance tests
