"""
CHE·NU™ V70 — ONECLICK ENGINE
=============================
Streamlined action execution system.

Based on: ONECLICK_ENGINE_CHAPTER.md

OneClick enables instant execution of complex workflows
through single-action triggers while maintaining full
governance compliance.

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Callable
from uuid import uuid4
import logging

logger = logging.getLogger("chenu.oneclick")


# =============================================================================
# ENUMS
# =============================================================================

class ActionType(str, Enum):
    """Types of OneClick actions."""
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"
    SEND = "send"
    EXPORT = "export"
    SCHEDULE = "schedule"
    ASSIGN = "assign"
    APPROVE = "approve"
    ARCHIVE = "archive"
    DUPLICATE = "duplicate"


class ActionStatus(str, Enum):
    """Action execution status."""
    PENDING = "pending"
    EXECUTING = "executing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    REQUIRES_HITL = "requires_hitl"


# =============================================================================
# MODELS
# =============================================================================

@dataclass
class OneClickAction:
    """Registered OneClick action."""
    action_id: str = field(default_factory=lambda: f"OCA_{uuid4().hex[:8]}")
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Definition
    name: str = ""
    description: str = ""
    action_type: ActionType = ActionType.CREATE
    
    # Target
    target_type: str = ""  # dataspace, document, task, meeting, etc.
    target_filter: Dict[str, Any] = field(default_factory=dict)
    
    # Workflow
    workflow_steps: List[Dict[str, Any]] = field(default_factory=list)
    
    # Parameters
    required_params: List[str] = field(default_factory=list)
    optional_params: List[str] = field(default_factory=list)
    default_values: Dict[str, Any] = field(default_factory=dict)
    
    # Governance
    requires_hitl: bool = False
    allowed_spheres: List[str] = field(default_factory=list)
    allowed_domains: List[str] = field(default_factory=list)
    
    # UI
    icon: str = "⚡"
    shortcut: Optional[str] = None
    visible_in_menu: bool = True


@dataclass
class ActionExecution:
    """Record of action execution."""
    execution_id: str = field(default_factory=lambda: f"EXEC_{uuid4().hex[:8]}")
    action_id: str = ""
    
    # Timing
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None
    
    # Context
    user_id: str = ""
    identity_id: str = ""
    sphere: str = ""
    domain: str = ""
    
    # Parameters
    parameters: Dict[str, Any] = field(default_factory=dict)
    
    # Status
    status: ActionStatus = ActionStatus.PENDING
    
    # Results
    result: Optional[Any] = None
    error: Optional[str] = None
    
    # Audit
    steps_completed: List[str] = field(default_factory=list)
    
    # Governance
    hitl_approved: bool = False
    synthetic: bool = True


# =============================================================================
# ONECLICK ENGINE
# =============================================================================

class OneClickEngine:
    """
    CHE·NU OneClick Engine.
    
    Enables instant execution of complex workflows through
    single-action triggers.
    
    Features:
    - Action registration
    - Parameter handling
    - Workflow execution
    - Governance enforcement
    - Execution history
    
    GOUVERNANCE > EXÉCUTION
    """
    
    def __init__(self):
        self._actions: Dict[str, OneClickAction] = {}
        self._executions: Dict[str, ActionExecution] = {}
        self._register_default_actions()
        logger.info("OneClickEngine initialized")
    
    def _register_default_actions(self):
        """Register default OneClick actions."""
        defaults = [
            OneClickAction(
                name="Quick Note",
                description="Create a quick note in current DataSpace",
                action_type=ActionType.CREATE,
                target_type="document",
                icon="📝",
            ),
            OneClickAction(
                name="Schedule Meeting",
                description="Schedule a meeting with current context",
                action_type=ActionType.SCHEDULE,
                target_type="meeting",
                icon="📅",
            ),
            OneClickAction(
                name="Create Task",
                description="Create a task from selection",
                action_type=ActionType.CREATE,
                target_type="task",
                icon="✅",
            ),
            OneClickAction(
                name="Export PDF",
                description="Export current document as PDF",
                action_type=ActionType.EXPORT,
                target_type="document",
                requires_hitl=True,  # GOVERNANCE
                icon="📄",
            ),
            OneClickAction(
                name="Archive DataSpace",
                description="Archive current DataSpace",
                action_type=ActionType.ARCHIVE,
                target_type="dataspace",
                requires_hitl=True,  # GOVERNANCE
                icon="📦",
            ),
        ]
        
        for action in defaults:
            self._actions[action.action_id] = action
    
    # =========================================================================
    # ACTION MANAGEMENT
    # =========================================================================
    
    def register_action(self, action: OneClickAction) -> str:
        """Register a new OneClick action."""
        self._actions[action.action_id] = action
        logger.info(f"Registered action: {action.name}")
        return action.action_id
    
    def get_action(self, action_id: str) -> Optional[OneClickAction]:
        """Get action by ID."""
        return self._actions.get(action_id)
    
    def list_actions(
        self,
        sphere: Optional[str] = None,
        domain: Optional[str] = None,
    ) -> List[OneClickAction]:
        """List available actions."""
        actions = list(self._actions.values())
        
        if sphere:
            actions = [
                a for a in actions
                if not a.allowed_spheres or sphere in a.allowed_spheres
            ]
        
        if domain:
            actions = [
                a for a in actions
                if not a.allowed_domains or domain in a.allowed_domains
            ]
        
        return [a for a in actions if a.visible_in_menu]
    
    # =========================================================================
    # EXECUTION
    # =========================================================================
    
    def execute(
        self,
        action_id: str,
        user_id: str,
        identity_id: str,
        parameters: Dict[str, Any] = None,
        sphere: str = "",
        domain: str = "",
    ) -> ActionExecution:
        """
        Execute a OneClick action.
        
        GOUVERNANCE: Enforces HITL when required.
        """
        action = self.get_action(action_id)
        if not action:
            raise ValueError(f"Action not found: {action_id}")
        
        # Create execution record
        execution = ActionExecution(
            action_id=action_id,
            user_id=user_id,
            identity_id=identity_id,
            parameters=parameters or {},
            sphere=sphere,
            domain=domain,
            synthetic=True,  # GOVERNANCE
        )
        
        # Check HITL requirement
        if action.requires_hitl:
            execution.status = ActionStatus.REQUIRES_HITL
            self._executions[execution.execution_id] = execution
            logger.info(f"Action {action.name} requires HITL approval")
            return execution
        
        # Execute
        execution.status = ActionStatus.EXECUTING
        
        try:
            result = self._execute_workflow(action, parameters or {})
            execution.result = result
            execution.status = ActionStatus.COMPLETED
            execution.completed_at = datetime.utcnow()
            logger.info(f"Action {action.name} completed successfully")
        except Exception as e:
            execution.error = str(e)
            execution.status = ActionStatus.FAILED
            logger.error(f"Action {action.name} failed: {e}")
        
        self._executions[execution.execution_id] = execution
        return execution
    
    def approve_and_execute(
        self,
        execution_id: str,
        approver_id: str,
    ) -> ActionExecution:
        """Approve and execute a HITL-required action."""
        execution = self._executions.get(execution_id)
        if not execution:
            raise ValueError(f"Execution not found: {execution_id}")
        
        if execution.status != ActionStatus.REQUIRES_HITL:
            raise ValueError("Execution does not require approval")
        
        action = self.get_action(execution.action_id)
        if not action:
            raise ValueError("Action not found")
        
        execution.hitl_approved = True
        execution.status = ActionStatus.EXECUTING
        
        try:
            result = self._execute_workflow(action, execution.parameters)
            execution.result = result
            execution.status = ActionStatus.COMPLETED
            execution.completed_at = datetime.utcnow()
        except Exception as e:
            execution.error = str(e)
            execution.status = ActionStatus.FAILED
        
        return execution
    
    def _execute_workflow(
        self,
        action: OneClickAction,
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute action workflow steps."""
        result = {
            "action": action.name,
            "type": action.action_type.value,
            "target": action.target_type,
            "parameters": parameters,
            "synthetic": True,  # GOVERNANCE
        }
        
        # Simulate workflow execution
        for step in action.workflow_steps:
            result.setdefault("steps_executed", []).append(step.get("name", "step"))
        
        return result
    
    # =========================================================================
    # STATISTICS
    # =========================================================================
    
    def get_stats(self) -> Dict[str, Any]:
        """Get engine statistics."""
        total = len(self._executions)
        completed = sum(
            1 for e in self._executions.values()
            if e.status == ActionStatus.COMPLETED
        )
        
        return {
            "registered_actions": len(self._actions),
            "total_executions": total,
            "completed_executions": completed,
            "pending_hitl": sum(
                1 for e in self._executions.values()
                if e.status == ActionStatus.REQUIRES_HITL
            ),
            "governance": {
                "hitl_enforced": True,
                "synthetic_only": True,
            },
        }


# =============================================================================
# SINGLETON
# =============================================================================

_oneclick_engine: Optional[OneClickEngine] = None


def get_oneclick_engine() -> OneClickEngine:
    """Get the OneClick engine singleton."""
    global _oneclick_engine
    if _oneclick_engine is None:
        _oneclick_engine = OneClickEngine()
    return _oneclick_engine
