# CHE·NU™ V70 — API DOCUMENTATION

## Complete REST API Reference

**Base URL:** `https://api.che-nu.com/v1`

---

## AUTHENTICATION

All requests require JWT authentication:

```http
Authorization: Bearer <jwt_token>
X-Identity-ID: <identity_uuid>
X-Request-ID: <unique_request_id>
```

---

## STANDARD RESPONSES

### Success Response
```json
{
  "success": true,
  "data": {},
  "meta": {
    "request_id": "uuid",
    "timestamp": "ISO8601",
    "version": "v1"
  }
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable message",
    "details": {}
  },
  "meta": {
    "request_id": "uuid",
    "timestamp": "ISO8601"
  }
}
```

---

## 1. IDENTITY API

### Create Identity
```http
POST /v1/identities
```

**Request:**
```json
{
  "identity_type": "personal|enterprise|creative|design|architecture|construction",
  "identity_name": "string",
  "config": {}
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "identity_id": "uuid",
    "identity_type": "enterprise",
    "identity_name": "My Company",
    "created_at": "2026-01-06T15:00:00Z"
  }
}
```

### List Identities
```http
GET /v1/identities
```

### Activate Identity
```http
POST /v1/identities/{identity_id}/activate
```

### Get Permissions
```http
GET /v1/identities/{identity_id}/permissions
```

---

## 2. DATASPACE API

### Create DataSpace
```http
POST /v1/dataspaces
```

**Request:**
```json
{
  "name": "Project Alpha",
  "description": "Construction project",
  "dataspace_type": "project|property|client|meeting|document|custom",
  "sphere_id": "uuid (optional)",
  "domain_id": "uuid (optional)",
  "parent_id": "uuid (optional)",
  "tags": ["construction", "2026"],
  "metadata": {}
}
```

### List DataSpaces
```http
GET /v1/dataspaces?sphere_id=&domain_id=&type=&status=active&search=&page=1&limit=20
```

### Get DataSpace
```http
GET /v1/dataspaces/{dataspace_id}
```

### Update DataSpace
```http
PATCH /v1/dataspaces/{dataspace_id}
```

### Archive DataSpace
```http
POST /v1/dataspaces/{dataspace_id}/archive
```

### Link DataSpaces
```http
POST /v1/dataspaces/{dataspace_id}/links
```

**Request:**
```json
{
  "target_dataspace_id": "uuid",
  "link_type": "reference|parent|related|derived"
}
```

---

## 3. THREAD API

### Create Thread
```http
POST /v1/threads
```

**Request:**
```json
{
  "dataspace_id": "uuid (optional)",
  "title": "Discussion Title",
  "thread_type": "conversation|decision|task|meeting|support",
  "participants": ["user_uuid"]
}
```

### List Threads
```http
GET /v1/threads?dataspace_id=&type=&page=1&limit=20
```

### Get Thread with Messages
```http
GET /v1/threads/{thread_id}
```

### Add Message
```http
POST /v1/threads/{thread_id}/messages
```

**Request:**
```json
{
  "message_type": "text|file|action|decision",
  "content": "Message content",
  "attachments": []
}
```

### Record Decision
```http
POST /v1/threads/{thread_id}/decisions
```

**Request:**
```json
{
  "decision_text": "We will proceed with option A",
  "decision_type": "approval|direction|assignment|policy",
  "affected_dataspaces": ["uuid"]
}
```

**Response includes HITL tracking:**
```json
{
  "decision_id": "uuid",
  "requires_hitl": true,
  "hitl_status": "pending"
}
```

---

## 4. WORKSPACE API

### Create Workspace
```http
POST /v1/workspaces
```

**Request:**
```json
{
  "name": "My Workspace",
  "workspace_mode": "document|board|timeline|spreadsheet|dashboard|diagram|whiteboard|xr|hybrid",
  "dataspace_id": "uuid (optional)",
  "layout_config": {}
}
```

### List Workspaces
```http
GET /v1/workspaces?dataspace_id=&mode=&page=1&limit=20
```

### Get Workspace State
```http
GET /v1/workspaces/{workspace_id}
```

### Transform Workspace Mode
```http
POST /v1/workspaces/{workspace_id}/transform
```

**Request:**
```json
{
  "target_mode": "dashboard",
  "preserve_data": true
}
```

### Save State
```http
POST /v1/workspaces/{workspace_id}/states
```

### Get State History
```http
GET /v1/workspaces/{workspace_id}/states
```

### Revert State
```http
POST /v1/workspaces/{workspace_id}/revert
```

**Request:**
```json
{
  "state_id": "uuid"
}
```

### Add Panel
```http
POST /v1/workspaces/{workspace_id}/panels
```

**Request:**
```json
{
  "panel_type": "editor|preview|chat|files|agents|timeline|canvas",
  "position": {"x": 0, "y": 0, "width": 400, "height": 300},
  "config": {}
}
```

---

## 5. 1-CLICK ASSISTANT API

### Execute Command
```http
POST /v1/oneclick/execute
```

**Request:**
```json
{
  "input": "Create a construction estimate for the renovation",
  "input_type": "prompt|file|context|dataspace",
  "context": {
    "dataspace_id": "uuid (optional)",
    "thread_id": "uuid (optional)",
    "workspace_id": "uuid (optional)"
  },
  "options": {
    "auto_approve": false,
    "output_format": "auto|document|dataspace|dashboard"
  }
}
```

**Response:**
```json
{
  "execution_id": "uuid",
  "status": "needs_approval",
  "workflow": {
    "id": "uuid",
    "name": "Construction Estimate",
    "steps": [
      {"index": 0, "action": "analyze_input", "status": "completed"},
      {"index": 1, "action": "generate_estimate", "status": "pending"},
      {"index": 2, "action": "format_output", "status": "pending"}
    ]
  },
  "requires_hitl": true,
  "estimated_time_seconds": 30
}
```

### Get Execution Status
```http
GET /v1/oneclick/executions/{execution_id}
```

### Approve Step (HITL)
```http
POST /v1/oneclick/executions/{execution_id}/approve
```

**Request:**
```json
{
  "step_index": 1,
  "modifications": {}
}
```

### Cancel Execution
```http
POST /v1/oneclick/executions/{execution_id}/cancel
```

### List Workflows
```http
GET /v1/oneclick/workflows?sphere_id=&domain_id=&search=
```

### List Templates
```http
GET /v1/oneclick/templates
```

---

## 6. BACKSTAGE INTELLIGENCE API

### Get Suggestions
```http
POST /v1/backstage/suggest
```

**Request:**
```json
{
  "context_type": "workspace|thread|meeting|workflow",
  "current_state": {},
  "user_intent": "string (optional)"
}
```

**Response:**
```json
{
  "suggestions": {
    "agents": ["AGT_CONSTRUCTION_CHIEF_L2"],
    "dataspaces": [],
    "templates": ["tpl_estimate"],
    "actions": ["create_estimate", "analyze_requirements"]
  },
  "detected_intent": {
    "primary": "construction_estimate",
    "confidence": 0.92
  },
  "synthetic": true
}
```

### Classify Content
```http
POST /v1/backstage/classify
```

**Request:**
```json
{
  "content": "string or base64",
  "content_type": "text|file|image|audio"
}
```

### Pre-process Input
```http
POST /v1/backstage/preprocess
```

---

## 7. MEMORY API

### Store Memory
```http
POST /v1/memory
```

**Request:**
```json
{
  "memory_type": "short_term|mid_term|long_term",
  "memory_category": "preference|instruction|fact|context|rule",
  "content": "User prefers detailed estimates",
  "dataspace_id": "uuid (optional)",
  "expires_at": "ISO8601 (optional)"
}
```

**Response includes governance:**
```json
{
  "memory_id": "uuid",
  "visible_to_user": true,
  "requires_approval": true,
  "user_deletable": true
}
```

### List Memory
```http
GET /v1/memory?type=&category=&status=active
```

### Get Memory Item
```http
GET /v1/memory/{memory_id}
```

### Update Memory
```http
PATCH /v1/memory/{memory_id}
```

### Delete Memory (True Deletion)
```http
DELETE /v1/memory/{memory_id}
```

**Response:**
```json
{
  "memory_id": "uuid",
  "deleted": true,
  "true_deletion": true
}
```

### Pin Memory
```http
POST /v1/memory/{memory_id}/pin
```

### Archive Memory
```http
POST /v1/memory/{memory_id}/archive
```

---

## 8. GOVERNANCE API

### Get Audit Log
```http
GET /v1/governance/audit?resource_type=&action_type=&start_date=&end_date=&page=1&limit=50
```

### Request Elevation (HITL)
```http
POST /v1/governance/elevate
```

**Request:**
```json
{
  "requested_action": "delete_dataspace",
  "resource_type": "dataspace",
  "resource_id": "uuid",
  "reason": "Project completed, need to archive"
}
```

**Response:**
```json
{
  "elevation_id": "uuid",
  "status": "pending_approval",
  "requires_hitl": true,
  "expires_at": "ISO8601"
}
```

### Approve Elevation
```http
POST /v1/governance/elevate/{request_id}/approve
```

### Deny Elevation
```http
POST /v1/governance/elevate/{request_id}/deny
```

---

## 9. AGENT API

### List Agents
```http
GET /v1/agents?level=L0|L1|L2|L3&sphere_id=&domain_id=&active=true
```

**Response includes governance:**
```json
{
  "agents": [
    {
      "id": "AGT_NOVA_L0",
      "name": "Nova Intelligence",
      "level": "L0",
      "hireable": false
    },
    {
      "id": "AGT_CONSTRUCTION_CHIEF_L2",
      "name": "Construction Chief",
      "level": "L2",
      "hireable": true
    }
  ],
  "governance": {
    "l0_never_hired": true,
    "scope_enforced": true
  }
}
```

### Get Agent Details
```http
GET /v1/agents/{agent_id}
```

### Execute Agent
```http
POST /v1/agents/{agent_id}/execute
```

**Request:**
```json
{
  "input": {"task": "analyze_document", "document_id": "uuid"},
  "context": {
    "thread_id": "uuid (optional)",
    "dataspace_id": "uuid (optional)"
  },
  "options": {
    "stream": false,
    "max_tokens": 4096
  }
}
```

**L0 agents return error:**
```json
{
  "success": false,
  "error": {
    "code": "L0_FORBIDDEN",
    "message": "L0 system agents cannot be executed directly"
  }
}
```

### Stream Execution (SSE)
```http
POST /v1/agents/{agent_id}/execute/stream
```

### Get Execution History
```http
GET /v1/agents/{agent_id}/executions?page=1&limit=20
```

### Configure Agent
```http
POST /v1/agents/{agent_id}/configure
```

### Hire Agent
```http
POST /v1/agents/{agent_id}/hire
```

### Fire Agent
```http
POST /v1/agents/{agent_id}/fire
```

---

## 10. MEETING API

### Create Meeting
```http
POST /v1/meetings
```

**Request:**
```json
{
  "title": "Project Kickoff",
  "description": "Initial planning meeting",
  "meeting_type": "standup|planning|review|brainstorm|decision|workshop",
  "scheduled_start": "2026-01-10T10:00:00Z",
  "scheduled_end": "2026-01-10T11:00:00Z",
  "location": "Conference Room A",
  "is_xr_meeting": false,
  "agenda": [
    {"title": "Introduction", "duration_minutes": 10},
    {"title": "Requirements Review", "duration_minutes": 30}
  ],
  "participants": ["user@example.com"]
}
```

**Response includes governance:**
```json
{
  "meeting_id": "uuid",
  "governance": {
    "recording_consent_required": true,
    "synthetic": true
  }
}
```

### List Meetings
```http
GET /v1/meetings?status=scheduled|active|completed&from=&to=&type=
```

### Get Meeting
```http
GET /v1/meetings/{meeting_id}
```

### Start Meeting
```http
POST /v1/meetings/{meeting_id}/start
```

**Response includes consent status:**
```json
{
  "meeting_id": "uuid",
  "status": "active",
  "governance": {
    "consent_required": true,
    "all_consents_obtained": false,
    "recording_active": false
  }
}
```

### End Meeting
```http
POST /v1/meetings/{meeting_id}/end
```

### Add Note
```http
POST /v1/meetings/{meeting_id}/notes
```

**Request:**
```json
{
  "note_type": "general|decision|action|question|idea",
  "content": "Decided to proceed with Phase 1"
}
```

### Create Task
```http
POST /v1/meetings/{meeting_id}/tasks
```

**Request:**
```json
{
  "title": "Prepare materials list",
  "description": "Complete list of all required materials",
  "assignee_id": "uuid",
  "due_date": "2026-01-15",
  "priority": "low|medium|high|urgent"
}
```

### Get Summary
```http
GET /v1/meetings/{meeting_id}/summary
```

---

## 11. IMMOBILIER API

### Create Property
```http
POST /v1/immobilier/properties
```

**Request:**
```json
{
  "property_type": "residential|commercial|industrial|land|mixed",
  "ownership_type": "personal|enterprise|investment",
  "address": {
    "line1": "123 Main Street",
    "line2": "Suite 100",
    "city": "Montreal",
    "province": "QC",
    "postal_code": "H2X 1A1"
  },
  "details": {
    "lot_size_sqft": 5000,
    "building_size_sqft": 3500,
    "year_built": 2010,
    "num_units": 6,
    "num_bedrooms": 12,
    "num_bathrooms": 6
  },
  "financial": {
    "purchase_price": 850000,
    "purchase_date": "2020-05-15",
    "current_value": 1050000
  }
}
```

**Response includes TAL compliance:**
```json
{
  "property_id": "uuid",
  "tal_compliant": true,
  "synthetic": true
}
```

### List Properties
```http
GET /v1/immobilier/properties?property_type=&ownership_type=&page=1&limit=20
```

### Get Property
```http
GET /v1/immobilier/properties/{property_id}
```

### Update Property
```http
PATCH /v1/immobilier/properties/{property_id}
```

### Add Unit
```http
POST /v1/immobilier/properties/{property_id}/units
```

**Request:**
```json
{
  "unit_number": "101",
  "floor": 1,
  "bedrooms": 2,
  "bathrooms": 1,
  "size_sqft": 850,
  "monthly_rent": 1400
}
```

### Create Tenant
```http
POST /v1/immobilier/properties/{property_id}/tenants
```

**Request:**
```json
{
  "unit_id": "uuid (optional)",
  "first_name": "Jean",
  "last_name": "Dupont",
  "email": "jean.dupont@email.com",
  "phone": "514-555-1234",
  "lease": {
    "start_date": "2026-02-01",
    "end_date": "2027-01-31",
    "monthly_rent": 1400,
    "security_deposit": 0
  }
}
```

**Response includes TAL governance:**
```json
{
  "tenant_id": "uuid",
  "lease": {
    "lease_id": "uuid",
    "tal_compliant": true,
    "section_g_provided": true
  }
}
```

### Record Payment
```http
POST /v1/immobilier/tenants/{tenant_id}/payments
```

**Request:**
```json
{
  "amount": 1400,
  "payment_date": "2026-02-01",
  "payment_method": "transfer",
  "period_start": "2026-02-01",
  "period_end": "2026-02-28"
}
```

### Create Maintenance Request
```http
POST /v1/immobilier/properties/{property_id}/maintenance
```

**Request:**
```json
{
  "unit_id": "uuid (optional)",
  "category": "plumbing|electrical|hvac|roofing|structure|appliances|exterior|other",
  "priority": "low|medium|high|urgent",
  "description": "Leaky faucet in bathroom",
  "reported_by": "tenant"
}
```

### List Maintenance Requests
```http
GET /v1/immobilier/properties/{property_id}/maintenance?status=&priority=
```

### Get Financial Summary
```http
GET /v1/immobilier/properties/{property_id}/financials?year=2026&month=1
```

### Calculate Rent Increase (TAL)
```http
POST /v1/immobilier/leases/{lease_id}/increase
```

**Response follows TAL guidelines:**
```json
{
  "lease_id": "uuid",
  "current_rent": 1200,
  "allowable_increase_percent": 2.9,
  "new_rent": 1234.80,
  "effective_date": "2026-07-01",
  "tal_calculation": {
    "taxes_factor": 0.5,
    "energy_factor": 0.7,
    "insurance_factor": 0.2,
    "maintenance_factor": 0.5,
    "improvements_factor": 0
  },
  "notice_required_by": "2026-04-01",
  "governance": {
    "tal_compliant": true,
    "section_g_required": true
  }
}
```

---

## ERROR CODES

| Code | Description |
|------|-------------|
| `AUTH_REQUIRED` | Missing or invalid authentication |
| `IDENTITY_REQUIRED` | Missing X-Identity-ID header |
| `PERMISSION_DENIED` | Insufficient permissions |
| `CROSS_IDENTITY_BLOCKED` | Cross-identity access denied (Law 4) |
| `L0_FORBIDDEN` | L0 agents cannot be hired/executed |
| `HITL_REQUIRED` | Human approval required |
| `ELEVATION_DENIED` | Elevation request denied |
| `NOT_FOUND` | Resource not found |
| `VALIDATION_ERROR` | Invalid request data |
| `CONSENT_REQUIRED` | Recording consent not obtained |

---

## GOVERNANCE HEADERS

All responses include governance tracking:

```http
X-Governance-Check: passed
X-Identity-Scoped: true
X-Synthetic: true
X-HITL-Required: false
X-Audit-Logged: true
```

---

*CHE·NU™ V70 API Documentation — January 2026*
*GOUVERNANCE > EXÉCUTION*
