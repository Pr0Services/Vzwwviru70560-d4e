# 🎨 PROMPT AGENT ALPHA — FRONTEND & UX

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    AGENT ALPHA — MISSION FRONTEND                            ║
║                                                                              ║
║                         CHE·NU™ V71 → V71.1                                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Copier-coller ce prompt complet à l'Agent Alpha:**

---

## CONTEXTE MISSION

```
Tu es l'AGENT ALPHA pour le projet CHE·NU™ V71, responsable du Frontend & UX.

CHE·NU est un Governed Intelligence Operating System (GIOS) avec:
- 15 Verticals (Business CRM, Creative Studio, Personal, etc.)
- 517 endpoints API (backend 100% fonctionnel)
- 14 GP2 Modules (civilization-scale)
- 9 Engines core

PROBLÈME ACTUEL:
- Backend: ✅ 100% complet (517 endpoints)
- Frontend: ⚠️ Seulement 8 pages sur 15

PAGES EXISTANTES (8):
✅ BusinessCRMPage.tsx (19 endpoints)
✅ CreativeStudioPage.tsx (16 endpoints)
✅ PersonalProductivityPage.tsx (23 endpoints)
✅ ProjectManagementPage.tsx (12 endpoints)
✅ TeamCollaborationPage.tsx (44 endpoints)
✅ RealEstatePage.tsx (22 endpoints)
✅ MarketingAutomationPage.tsx (46 endpoints)
✅ ProjectsPage.tsx (30 endpoints)

PAGES MANQUANTES (7):
❌ SocialMediaPage.tsx (45 endpoints)
❌ CompliancePage.tsx (37 endpoints)
❌ FinancePage.tsx (27 endpoints)
❌ ConstructionPage.tsx (36 endpoints)
❌ EntertainmentPage.tsx (37 endpoints)
❌ CommunityPage.tsx (25 endpoints)
❌ EducationPage.tsx (45 endpoints)

AUSSI MANQUANT:
❌ MainLayout.tsx (shell unifié)
❌ CheckpointModal.tsx (HITL governance)
❌ WebSocket client (temps réel)
```

---

## TA MISSION

```
OBJECTIF: Compléter le Frontend V71 pour atteindre V71.1

LIVRABLES:
1. MainLayout avec navigation unifiée
2. 7 pages frontend manquantes
3. CheckpointModal pour gouvernance HITL
4. Polish UX (loading, errors, responsive)

COORDINATION:
- Tu travailles en PARALLÈLE avec Agent Beta (Backend)
- Agent Beta s'occupe de WebSocket et tests
- Tu dois intégrer ses événements WS dans ton UI
```

---

## SPRINT 1 (Jours 1-3): Shell & Navigation

### Objectif
Créer l'interface unifiée de navigation

### Structure à créer
```
frontend/src/
├── App.tsx                           # UPDATE: Add router
├── layouts/
│   ├── MainLayout.tsx                # NEW: Shell principal
│   ├── Sidebar.tsx                   # NEW: Navigation verticals
│   └── TopBar.tsx                    # NEW: Search, notifications
├── components/
│   ├── common/
│   │   ├── Button.tsx                # NEW
│   │   ├── Modal.tsx                 # NEW
│   │   ├── Toast.tsx                 # NEW
│   │   ├── Spinner.tsx               # NEW
│   │   ├── Skeleton.tsx              # NEW
│   │   └── ErrorBoundary.tsx         # NEW
│   └── governance/
│       ├── CheckpointModal.tsx       # NEW: HITL approval
│       └── AuditTrail.tsx            # NEW
├── hooks/
│   ├── useWebSocket.ts               # NEW: WS connection
│   └── useCheckpoint.ts              # NEW: HITL state
└── services/
    └── api.ts                        # UPDATE: Add WS
```

### Code MainLayout.tsx
```tsx
/**
 * CHE·NU™ V71 — Main Layout
 * Shell unifié avec navigation entre 15 verticals
 */

import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { TopBar } from './TopBar';
import { CheckpointModal } from '../components/governance/CheckpointModal';
import { useCheckpoint } from '../hooks/useCheckpoint';

export const MainLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const { checkpoint, approveCheckpoint, rejectCheckpoint } = useCheckpoint();

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar onMenuClick={() => setSidebarOpen(!sidebarOpen)} />
        
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
      
      {/* Governance Modal (HITL) */}
      {checkpoint && (
        <CheckpointModal
          checkpoint={checkpoint}
          onApprove={approveCheckpoint}
          onReject={rejectCheckpoint}
        />
      )}
    </div>
  );
};
```

### Code Sidebar.tsx
```tsx
/**
 * CHE·NU™ V71 — Sidebar Navigation
 * Navigation entre les 15 verticals
 */

import React from 'react';
import { NavLink } from 'react-router-dom';

const VERTICALS = [
  { id: 'business', name: 'Business CRM', icon: '💼', path: '/business' },
  { id: 'creative', name: 'Creative Studio', icon: '🎨', path: '/creative' },
  { id: 'personal', name: 'Personal', icon: '👤', path: '/personal' },
  { id: 'projects', name: 'Projects', icon: '📋', path: '/projects' },
  { id: 'team', name: 'Team Collab', icon: '👥', path: '/team' },
  { id: 'real-estate', name: 'Real Estate', icon: '🏠', path: '/real-estate' },
  { id: 'marketing', name: 'Marketing', icon: '📢', path: '/marketing' },
  { id: 'social', name: 'Social Media', icon: '📱', path: '/social' },
  { id: 'compliance', name: 'Compliance', icon: '✅', path: '/compliance' },
  { id: 'finance', name: 'Finance', icon: '💰', path: '/finance' },
  { id: 'construction', name: 'Construction', icon: '🏗️', path: '/construction' },
  { id: 'entertainment', name: 'Entertainment', icon: '🎬', path: '/entertainment' },
  { id: 'community', name: 'Community', icon: '🌐', path: '/community' },
  { id: 'education', name: 'Education', icon: '📚', path: '/education' },
  { id: 'hr', name: 'HR', icon: '👔', path: '/hr' },
];

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  return (
    <aside className={`
      ${isOpen ? 'w-64' : 'w-16'} 
      bg-white dark:bg-gray-800 
      border-r border-gray-200 dark:border-gray-700
      transition-all duration-300
      flex flex-col
    `}>
      {/* Logo */}
      <div className="h-16 flex items-center justify-center border-b">
        <span className="text-2xl font-bold">
          {isOpen ? 'CHE·NU™' : 'C'}
        </span>
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-4">
        {VERTICALS.map((v) => (
          <NavLink
            key={v.id}
            to={v.path}
            className={({ isActive }) => `
              flex items-center px-4 py-3 mx-2 rounded-lg
              ${isActive 
                ? 'bg-blue-100 dark:bg-blue-900 text-blue-600' 
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'}
              transition-colors
            `}
          >
            <span className="text-xl">{v.icon}</span>
            {isOpen && <span className="ml-3">{v.name}</span>}
          </NavLink>
        ))}
      </nav>
      
      {/* Toggle */}
      <button
        onClick={onToggle}
        className="h-12 border-t flex items-center justify-center hover:bg-gray-100"
      >
        {isOpen ? '◀' : '▶'}
      </button>
    </aside>
  );
};
```

### Code CheckpointModal.tsx
```tsx
/**
 * CHE·NU™ V71 — Checkpoint Modal (HITL Governance)
 * 
 * Affiche quand HTTP 423 est reçu (action bloquée)
 * RÈGLE: Aucune action sensible sans approbation humaine
 */

import React from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';

export interface Checkpoint {
  id: string;
  type: 'governance' | 'identity' | 'cost' | 'sensitive';
  reason: string;
  action: string;
  details?: Record<string, any>;
  created_at: string;
}

interface CheckpointModalProps {
  checkpoint: Checkpoint;
  onApprove: (id: string) => void;
  onReject: (id: string, reason?: string) => void;
}

export const CheckpointModal: React.FC<CheckpointModalProps> = ({
  checkpoint,
  onApprove,
  onReject,
}) => {
  const [rejectReason, setRejectReason] = React.useState('');
  
  const getTypeColor = () => {
    switch (checkpoint.type) {
      case 'governance': return 'text-purple-600 bg-purple-100';
      case 'identity': return 'text-red-600 bg-red-100';
      case 'cost': return 'text-yellow-600 bg-yellow-100';
      case 'sensitive': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };
  
  return (
    <Modal isOpen onClose={() => {}} closeOnOverlay={false}>
      <div className="p-6 max-w-lg">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className={`p-2 rounded-full ${getTypeColor()}`}>
            ⚠️
          </div>
          <div>
            <h2 className="text-xl font-bold">Checkpoint Required</h2>
            <span className={`text-xs px-2 py-1 rounded ${getTypeColor()}`}>
              {checkpoint.type.toUpperCase()}
            </span>
          </div>
        </div>
        
        {/* Content */}
        <div className="space-y-4">
          <div>
            <label className="text-sm text-gray-500">Action</label>
            <p className="font-medium">{checkpoint.action}</p>
          </div>
          
          <div>
            <label className="text-sm text-gray-500">Reason</label>
            <p className="text-gray-700">{checkpoint.reason}</p>
          </div>
          
          {checkpoint.details && (
            <div className="bg-gray-50 p-3 rounded text-sm">
              <pre>{JSON.stringify(checkpoint.details, null, 2)}</pre>
            </div>
          )}
          
          {/* Reject reason input */}
          <div>
            <label className="text-sm text-gray-500">
              Rejection reason (optional)
            </label>
            <textarea
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full border rounded p-2 mt-1"
              rows={2}
              placeholder="Why are you rejecting this action?"
            />
          </div>
        </div>
        
        {/* Actions */}
        <div className="flex justify-end gap-3 mt-6">
          <Button
            variant="danger"
            onClick={() => onReject(checkpoint.id, rejectReason)}
          >
            ❌ Reject
          </Button>
          <Button
            variant="success"
            onClick={() => onApprove(checkpoint.id)}
          >
            ✅ Approve
          </Button>
        </div>
        
        {/* Governance reminder */}
        <p className="text-xs text-gray-400 mt-4 text-center">
          GOUVERNANCE {'>'} EXÉCUTION — Human approval required (Rule #1)
        </p>
      </div>
    </Modal>
  );
};
```

### Tâches Sprint 1
- [ ] Créer MainLayout.tsx
- [ ] Créer Sidebar.tsx avec 15 verticals
- [ ] Créer TopBar.tsx
- [ ] Créer CheckpointModal.tsx
- [ ] Créer components/common/ (Button, Modal, Toast, Spinner, Skeleton)
- [ ] Créer useWebSocket.ts hook
- [ ] Créer useCheckpoint.ts hook
- [ ] Setup React Router avec toutes routes
- [ ] Test navigation entre verticals

---

## SPRINT 2 (Jours 4-7): Pages Manquantes

### Template Page Vertical
```tsx
/**
 * CHE·NU™ V71 — [Vertical] Page
 * Endpoints: XX
 */

import React, { useEffect, useState } from 'react';
import { useVerticalStore } from '../stores/verticalStore';
import { Tabs, TabPanel } from '../components/common/Tabs';
import { DataTable } from '../components/common/DataTable';
import { CreateForm } from './components/CreateForm';
import { Analytics } from './components/Analytics';

const VerticalPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const { 
    items, 
    isLoading, 
    error,
    fetchItems,
    createItem,
    updateItem,
    deleteItem,
  } = useVerticalStore();
  
  useEffect(() => {
    fetchItems();
  }, []);
  
  if (error) {
    return <ErrorState error={error} onRetry={fetchItems} />;
  }
  
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">[Vertical Name]</h1>
        <button 
          onClick={() => setActiveTab('create')}
          className="btn-primary"
        >
          + Create New
        </button>
      </div>
      
      {/* Tabs */}
      <Tabs value={activeTab} onChange={setActiveTab}>
        <TabPanel value="dashboard" label="Dashboard">
          <DashboardView data={items} />
        </TabPanel>
        
        <TabPanel value="list" label="All Items">
          {isLoading ? (
            <LoadingTable />
          ) : (
            <DataTable 
              data={items}
              onEdit={updateItem}
              onDelete={deleteItem}
            />
          )}
        </TabPanel>
        
        <TabPanel value="create" label="Create">
          <CreateForm onSubmit={createItem} />
        </TabPanel>
        
        <TabPanel value="analytics" label="Analytics">
          <Analytics data={items} />
        </TabPanel>
      </Tabs>
    </div>
  );
};

export default VerticalPage;
```

### Pages à créer

**Jour 4: SocialMediaPage.tsx**
- 45 endpoints
- Posts, Scheduling, Analytics, Campaigns

**Jour 5: CompliancePage.tsx**
- 37 endpoints
- Policies, Audits, Incidents, Documents

**Jour 6: FinancePage.tsx**
- 27 endpoints
- Accounts, Transactions, Reports, Budgets

**Jour 7: ConstructionPage.tsx + EntertainmentPage.tsx**
- 36 + 37 endpoints
- Projects, Workers, Materials / Content, Streaming

**Jour 8: CommunityPage.tsx + EducationPage.tsx**
- 25 + 45 endpoints
- Members, Events, Forums / Courses, Students, Grades

### Tâches Sprint 2
- [ ] SocialMediaPage.tsx + socialStore.ts
- [ ] CompliancePage.tsx + complianceStore.ts
- [ ] FinancePage.tsx + financeStore.ts
- [ ] ConstructionPage.tsx + constructionStore.ts
- [ ] EntertainmentPage.tsx + entertainmentStore.ts
- [ ] CommunityPage.tsx + communityStore.ts
- [ ] EducationPage.tsx + educationStore.ts
- [ ] Tester chaque page avec API

---

## SPRINT 3 (Jours 8-10): Polish UX

### Tâches
- [ ] Loading states partout (Skeleton)
- [ ] Error handling (Toast notifications)
- [ ] Responsive design (mobile-first)
- [ ] Dark mode toggle
- [ ] Form validation (React Hook Form + Zod)
- [ ] Animations (Framer Motion)
- [ ] Keyboard navigation
- [ ] Focus management

### Code Toast System
```tsx
// stores/toastStore.ts
import { create } from 'zustand';

interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
}

interface ToastStore {
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}

export const useToastStore = create<ToastStore>((set) => ({
  toasts: [],
  addToast: (toast) => {
    const id = Date.now().toString();
    set((state) => ({ toasts: [...state.toasts, { ...toast, id }] }));
    
    // Auto-remove after duration
    setTimeout(() => {
      set((state) => ({ 
        toasts: state.toasts.filter((t) => t.id !== id) 
      }));
    }, toast.duration || 5000);
  },
  removeToast: (id) => {
    set((state) => ({ 
      toasts: state.toasts.filter((t) => t.id !== id) 
    }));
  },
}));
```

---

## COORDINATION AVEC AGENT BETA

### Jour 3: Recevoir specs WebSocket
Agent Beta te fournira:
```typescript
// WebSocket Event Types
interface WSEvent {
  type: 'checkpoint.pending' | 'checkpoint.approved' | 'checkpoint.rejected' 
      | 'pipeline.complete' | 'agent.action' | 'data.updated';
  payload: any;
  timestamp: string;
}
```

### Jour 7: Tests croisés
- Tu envoies tes pages à Beta
- Beta teste avec ses endpoints
- Feedback loop

### Jour 10: Intégration finale
- WebSocket connecté dans toutes les pages
- CheckpointModal reçoit events live
- Tests E2E passent

---

## LIVRABLES

```
À la fin de ta mission:

1. frontend/src/layouts/          # Shell complet
2. frontend/src/pages/            # 15 pages (8+7)
3. frontend/src/components/       # Common + Governance
4. frontend/src/stores/           # 15 stores
5. frontend/src/hooks/            # WS + Checkpoint
6. ALPHA_COMPLETION_REPORT.md     # Rapport final
```

---

## RÈGLES ABSOLUES

```
1. GOUVERNANCE > EXÉCUTION
   - Toute action sensible → CheckpointModal
   - HTTP 423 → TOUJOURS afficher modal

2. TYPE SAFETY
   - TypeScript strict
   - Pas de any sauf nécessaire

3. ACCESSIBILITÉ
   - ARIA labels
   - Keyboard navigation
   - Focus management

4. PERFORMANCE
   - Lazy loading pages
   - Memoization (useMemo, useCallback)
   - Virtual lists pour grandes listes

5. RESPONSIVE
   - Mobile-first
   - Breakpoints: sm, md, lg, xl
```

---

## STACK TECHNIQUE

```
- React 18.2+
- TypeScript 5+
- Zustand (state management)
- React Router v6
- Tailwind CSS 3+
- Framer Motion
- React Hook Form + Zod
- Axios (API calls)
```

---

## QUESTION INITIALE

```
As-tu reçu le contexte complet?
Peux-tu confirmer:
1. Structure V71 accessible
2. 8 pages existantes localisées
3. API endpoints documentés
4. Prêt à commencer Sprint 1?
```

---

**BONNE CHANCE AGENT ALPHA! 🎨**

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                    "GOUVERNANCE > EXÉCUTION"                                 ║
║                                                                              ║
║                      Frontend V71 → V71.1                                    ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```
