# 🏠 CHE·NU™ V71 PLATFORM

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                          CHE·NU™ V71 PLATFORM                                ║
║                                                                              ║
║                  Governed Intelligence Operating System                       ║
║                                                                              ║
║                        GOUVERNANCE > EXÉCUTION                               ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```

**Version:** 71.0.0  
**Date:** January 2026  
**Status:** Production Ready

---

## 📋 Table des Matières

1. [Vue d'Ensemble](#-vue-densemble)
2. [Architecture](#-architecture)
3. [Verticals (15)](#-verticals-15)
4. [GP2 Modules (14)](#-gp2-modules-14)
5. [Engines (9)](#-engines-9)
6. [Structure des Dossiers](#-structure-des-dossiers)
7. [Installation](#-installation)
8. [Démarrage Rapide](#-démarrage-rapide)
9. [API Reference](#-api-reference)
10. [Gouvernance](#-gouvernance)
11. [Tests](#-tests)
12. [Déploiement](#-déploiement)

---

## 🎯 Vue d'Ensemble

CHE·NU™ (Chez Nous) est un **Governed Intelligence Operating System** — une plateforme complète de gestion d'intelligence gouvernée comprenant:

| Composant | Quantité | Description |
|-----------|----------|-------------|
| **Verticals** | 15 | Solutions métier spécialisées |
| **GP2 Modules** | 14 | Modules avancés (26-39) |
| **Engines** | 9 | Moteurs de traitement core |
| **API Endpoints** | 500+ | Points d'entrée REST |
| **Tests** | 578+ | Tests unitaires et intégration |

### Principes Fondamentaux

```
1. GOUVERNANCE > EXÉCUTION
2. HUMAN-IN-THE-LOOP (HITL) pour actions sensibles
3. IDENTITY ISOLATION stricte
4. AUDIT TRAIL complet
5. NO RANKING ALGORITHMS (Rule #5)
```

---

## 🏗 Architecture

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           FRONTEND (React/TS)                           │
├─────────────────────────────────────────────────────────────────────────┤
│                            API GATEWAY                                  │
│                         (FastAPI + NGINX)                               │
├───────────────┬───────────────┬───────────────┬─────────────────────────┤
│   API V1      │    API V2     │   GraphQL     │      WebSocket          │
│  (Legacy)     │  (Current)    │  (Optional)   │     (Real-time)         │
├───────────────┴───────────────┴───────────────┴─────────────────────────┤
│                        GOVERNANCE LAYER                                 │
│              (OPA Policies + Ethics Canon + HITL)                       │
├───────────────┬───────────────┬───────────────┬─────────────────────────┤
│   VERTICALS   │    ENGINES    │   MODULES     │       DOMAINS           │
│     (15)      │      (9)      │   GP2 (14)    │     (Immobilier)        │
├───────────────┴───────────────┴───────────────┴─────────────────────────┤
│                         DATA LAYER                                      │
│              (PostgreSQL + Redis + S3/MinIO)                            │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 📊 Verticals (15)

| Vertical | Endpoints | Tests | Coverage | Description |
|----------|-----------|-------|----------|-------------|
| BUSINESS_CRM | 19 | 30 | 100% | CRM et gestion des ventes |
| COMMUNITY | 25 | 24 | 100% | Plateformes communautaires |
| COMPLIANCE | 37 | 34 | 85% | Conformité réglementaire |
| CONSTRUCTION | 36 | 17 | 46% | Construction et AEC |
| CREATIVE_STUDIO | 46 | 65 | 100% | Création de contenu |
| EDUCATION | 45 | 41 | 100% | Gestion de l'apprentissage |
| ENTERTAINMENT | 37 | 38 | 100% | Divertissement et médias |
| FINANCE | 27 | 27 | 100% | Gestion financière |
| HR | 53 | 50 | 94% | Ressources humaines |
| MARKETING | 46 | 57 | 100% | Automatisation marketing |
| PERSONAL | 23 | 32 | 100% | Productivité personnelle |
| PROJECT_MGMT | 12 | 17 | 100% | Gestion de projets |
| REAL_ESTATE | 22 | 36 | 100% | Immobilier |
| SOCIAL | 45 | 48 | 88% | Réseaux sociaux |
| TEAM_COLLAB | 44 | 62 | 100% | Collaboration d'équipe |

**Total: 517 endpoints, 578 tests**

---

## 🔮 GP2 Modules (14)

Les modules GP2 (Modules 26-39) apportent des fonctionnalités de niveau civilisation:

| Module | Nom | Description |
|--------|-----|-------------|
| 26 | Transmission | Transmission de connaissances |
| 27 | Heritage | Préservation du patrimoine |
| 28 | Culture | Contexte culturel |
| 29 | Planetary | Coordination planétaire |
| 30 | Civilization OS | OS de civilisation |
| 31 | Temporal | Planification temporelle |
| 32 | Collapse | Prévention d'effondrement |
| 33 | Meaning | Création de sens |
| 34 | Evolution | Évolution adaptative |
| 35 | Intergenerational | Transfert intergénérationnel |
| 36 | Failsafe | Mécanismes de sécurité |
| 37 | External | Intégrations externes |
| 38 | Myth & Symbol | Systèmes symboliques |
| 39 | Posthuman | Continuité post-humaine |

---

## ⚙️ Engines (9)

| Engine | Description |
|--------|-------------|
| Workspace | Gestion des espaces de travail et bureaux |
| DataSpace | Gestion des DataSpaces et snapshots |
| Nova Kernel | Noyau d'intelligence core |
| Backstage | Intelligence backstage et analytics |
| Meeting | Gestion des réunions et consentement |
| Layout | UI layout et sections bureau |
| OneClick | Actions one-click et workflows |
| OCW | Organic Cognitive Workspace |
| Memory Governance | Gestion mémoire (10 Laws) |

---

## 📁 Structure des Dossiers

```
CHENU_V71_PLATFORM/
├── main.py                          # Entry point
├── requirements.txt                 # Dependencies
├── .env.example                     # Environment template
├── Makefile                         # Build commands
│
├── backend/
│   ├── __init__.py                  # Backend package
│   │
│   ├── api/
│   │   ├── v1/                      # API V1 (legacy)
│   │   │   ├── main.py
│   │   │   └── routers/
│   │   └── v2/                      # API V2 (current)
│   │       └── __init__.py
│   │
│   ├── core/                        # Core services
│   │   ├── config.py
│   │   ├── events.py
│   │   └── cache.py
│   │
│   ├── engines/                     # 9 Core engines
│   │   ├── workspace/
│   │   ├── dataspace/
│   │   ├── nova_kernel/
│   │   ├── backstage/
│   │   ├── meeting/
│   │   ├── layout/
│   │   ├── oneclick/
│   │   ├── ocw/
│   │   └── memory_governance/
│   │
│   ├── modules/                     # 14 GP2 modules
│   │   ├── module_26_transmission/
│   │   ├── module_27_heritage/
│   │   ├── module_28_culture/
│   │   ├── module_29_planetary/
│   │   ├── module_30_civilization_os/
│   │   ├── module_31_temporal/
│   │   ├── module_32_collapse/
│   │   ├── module_33_meaning/
│   │   ├── module_34_evolution/
│   │   ├── module_35_intergenerational/
│   │   ├── module_36_failsafe/
│   │   ├── module_37_external/
│   │   ├── module_38_myth_symbol/
│   │   └── module_39_posthuman/
│   │
│   ├── verticals/                   # 15 verticals
│   │   ├── BUSINESS_CRM/
│   │   ├── COMMUNITY/
│   │   ├── COMPLIANCE/
│   │   ├── CONSTRUCTION/
│   │   ├── CREATIVE_STUDIO/
│   │   ├── EDUCATION/
│   │   ├── ENTERTAINMENT/
│   │   ├── FINANCE/
│   │   ├── HR/
│   │   ├── MARKETING/
│   │   ├── PERSONAL/
│   │   ├── PROJECT_MGMT/
│   │   ├── REAL_ESTATE/
│   │   ├── SOCIAL/
│   │   └── TEAM_COLLAB/
│   │
│   ├── domains/                     # Domain-specific
│   │   └── immobilier/
│   │
│   ├── governance/                  # Governance layer
│   │   ├── opa/
│   │   │   └── policies/
│   │   └── ethics/
│   │
│   ├── agents/                      # Agent system
│   │   ├── core/
│   │   ├── registry/
│   │   ├── checkpoints/
│   │   └── prompts/
│   │
│   ├── auth/                        # Authentication
│   ├── database/                    # Database models
│   ├── realtime/                    # WebSocket
│   ├── graphql/                     # GraphQL
│   ├── xr/                          # XR/VR support
│   ├── middleware/                  # Middleware stack
│   ├── health/                      # Health checks
│   ├── metrics/                     # Prometheus metrics
│   ├── logging/                     # Structured logging
│   ├── workers/                     # Background workers
│   ├── schemas/                     # Pydantic schemas
│   │
│   └── tests/                       # Tests
│       ├── unit/
│       ├── integration/
│       └── e2e/
│
├── frontend/
│   └── src/
│       ├── components/
│       ├── pages/
│       ├── hooks/
│       ├── services/
│       ├── stores/
│       └── types/
│
├── infrastructure/
│   ├── k8s/
│   │   ├── base/
│   │   └── overlays/
│   │       ├── staging/
│   │       └── production/
│   ├── docker/
│   │   ├── Dockerfile
│   │   └── docker-compose.yml
│   ├── monitoring/
│   │   ├── grafana/
│   │   └── prometheus/
│   └── nginx/
│
├── sdk/
│   ├── python/
│   └── typescript/
│
├── cli/                             # CLI tools
├── scripts/                         # Deployment scripts
│
└── docs/
    ├── api/
    ├── guides/
    └── architecture/
```

---

## 🚀 Installation

### Prérequis

- Python 3.11+
- Node.js 18+
- PostgreSQL 15+
- Redis 7+
- Docker & Docker Compose

### Installation

```bash
# Clone
git clone https://github.com/che-nu/platform.git
cd CHENU_V71_PLATFORM

# Environment
cp .env.example .env

# Backend
pip install -r requirements.txt

# Frontend
cd frontend && npm install && cd ..

# Database
make db-migrate
```

---

## ⚡ Démarrage Rapide

### Développement

```bash
# Backend
make run-backend
# ou
python main.py

# Frontend
make run-frontend
# ou
cd frontend && npm run dev
```

### Docker

```bash
# Full stack
docker-compose up -d

# ou avec Make
make docker-up
```

### URLs

| Service | URL |
|---------|-----|
| API | http://localhost:8000 |
| Docs | http://localhost:8000/docs |
| Frontend | http://localhost:3000 |
| Grafana | http://localhost:3001 |

---

## 📚 API Reference

### Base URLs

```
API V1: /api/v1
API V2: /api/v2 (recommended)
```

### Endpoints Principaux

```bash
# Health
GET /health

# Verticals
GET /api/v2/verticals
GET /api/v2/verticals/{id}

# Engines
GET /api/v2/engines
GET /api/v2/engines/{id}

# Modules GP2
GET /api/v2/modules
GET /api/v2/modules/{id}

# Governance
GET /api/v2/governance/rules
GET /api/v2/governance/hitl-actions
GET /api/v2/governance/memory-laws

# Stats
GET /api/v2/stats
```

---

## 🔒 Gouvernance

### 7 Règles R&D

| Rule | Description |
|------|-------------|
| #1 | **Human Sovereignty** - No action without human approval |
| #2 | **Autonomy Isolation** - AI operates in sandboxes only |
| #3 | **Sphere Integrity** - Cross-sphere requires explicit workflows |
| #4 | **My Team Restrictions** - No AI orchestration of other AI |
| #5 | **Social Restrictions** - No ranking algorithms |
| #6 | **Module Traceability** - All modules have defined status |
| #7 | **R&D Continuity** - Build on previous decisions |

### 10 Laws of Memory

| Law | Description |
|-----|-------------|
| #1 | No Hidden Memory |
| #2 | Explicit Storage Approval |
| #3 | Identity Scoping |
| #4 | No Cross-Identity Access |
| #5 | Reversibility |
| #6 | Operation Logging |
| #7 | No Self-Directed Agent Learning |
| #8 | Domain Awareness |
| #9 | DataSpace Foundation |
| #10 | User-Controlled Lifespan |

### Actions HITL (Human-In-The-Loop)

Ces actions requièrent une approbation humaine explicite:

- `send_external_communication`
- `financial_transaction`
- `data_deletion`
- `publish_content`
- `cross_identity_operation`
- `cross_sphere_transfer`
- `agent_hiring`
- `sensitive_data_access`

---

## 🧪 Tests

```bash
# All tests
make test

# Unit tests
pytest backend/tests/unit/

# Integration tests
pytest backend/tests/integration/

# Coverage
pytest --cov=backend --cov-report=html
```

### Couverture Actuelle

- **Tests totaux:** 578
- **Verticals à 100%:** 12/15
- **Couverture moyenne:** 95%

---

## 🚀 Déploiement

### Kubernetes

```bash
# Staging
kubectl apply -k infrastructure/k8s/overlays/staging/

# Production
kubectl apply -k infrastructure/k8s/overlays/production/
```

### Variables d'Environnement

```env
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/chenu

# Redis
REDIS_URL=redis://localhost:6379

# Security
JWT_SECRET=your-secret-key
API_KEY=your-api-key

# Features
ENABLE_GP2_MODULES=true
ENABLE_XR=true
```

---

## 📞 Support

- Documentation: `/docs`
- Issues: GitHub Issues
- Email: support@che-nu.com

---

## 📄 License

Proprietary - CHE·NU™ 2026. All rights reserved.

---

```
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║                        GOUVERNANCE > EXÉCUTION                               ║
║                                                                              ║
║                    "Structure precedes intelligence."                         ║
║                    "Visibility precedes power."                              ║
║                    "Human accountability is non-negotiable."                  ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
```
