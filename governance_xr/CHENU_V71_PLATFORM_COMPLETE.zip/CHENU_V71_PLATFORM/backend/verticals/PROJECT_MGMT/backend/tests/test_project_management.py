"""
============================================================================
CHE·NU™ V71 — PROJECT MANAGEMENT TESTS
============================================================================
Version: 1.0.0
Vertical: PROJECT_MGMT_V68

Tests CANON compliance:
- Rule #1: Human Sovereignty (checkpoint blocking)
- Rule #2: Autonomy Isolation (analysis is read-only)
- Rule #5: No ranking algorithms (chronological order)
- Rule #6: Traceability (created_by, created_at)

"GOVERNANCE > EXECUTION"
============================================================================
"""

import pytest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

# Import from relative path
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from spheres.projects.agents.project_manager_agent import (
    ProjectManagerAgent,
    Project,
    Task,
    Milestone,
    Checkpoint,
    ProjectStatus,
    TaskStatus,
    TaskPriority,
    MilestoneStatus,
    CheckpointType,
)


# ============================================================================
# FIXTURES
# ============================================================================

@pytest.fixture
def agent() -> ProjectManagerAgent:
    """Create fresh agent instance for each test"""
    return ProjectManagerAgent()


@pytest.fixture
def sample_project(agent: ProjectManagerAgent) -> tuple:
    """Create a sample project with checkpoint"""
    project, checkpoint = agent.create_project_draft(
        name="Test Project",
        description="A test project",
        owner_id="owner_123",
        created_by="user_456",
        budget=Decimal("10000"),
    )
    return project, checkpoint


# ============================================================================
# CANON RULE #1: HUMAN SOVEREIGNTY TESTS
# ============================================================================

class TestHumanSovereignty:
    """
    Tests for CANON Rule #1: Human Sovereignty
    
    All sensitive actions require explicit human approval.
    Projects start in DRAFT and need checkpoint approval.
    """
    
    def test_project_starts_in_draft(self, agent: ProjectManagerAgent):
        """Project creation starts in DRAFT status"""
        project, checkpoint = agent.create_project_draft(
            name="New Project",
            description="Test",
            owner_id="owner_1",
            created_by="user_1",
        )
        
        assert project.status == ProjectStatus.DRAFT
        assert checkpoint.status == "pending"
        assert checkpoint.checkpoint_type == CheckpointType.PROJECT_CREATE
    
    def test_checkpoint_blocks_until_approved(self, agent: ProjectManagerAgent, sample_project):
        """Project stays in DRAFT until checkpoint approved"""
        project, checkpoint = sample_project
        
        # Project should still be DRAFT
        assert project.status == ProjectStatus.DRAFT
        
        # Approve checkpoint
        approved_project = agent.approve_project_creation(
            checkpoint_id=checkpoint.id,
            approved_by="approver_1",
            reason="Looks good",
        )
        
        # Now project should be PLANNING
        assert approved_project.status == ProjectStatus.PLANNING
        assert approved_project.modified_by == "approver_1"
    
    def test_checkpoint_can_be_rejected(self, agent: ProjectManagerAgent, sample_project):
        """Human can reject checkpoint to block action"""
        project, checkpoint = sample_project
        
        agent.reject_project_creation(
            checkpoint_id=checkpoint.id,
            rejected_by="approver_1",
            reason="Budget too high",
        )
        
        # Checkpoint should be rejected
        updated_checkpoint = agent.checkpoints[checkpoint.id]
        assert updated_checkpoint.status == "rejected"
        assert updated_checkpoint.resolved_by == "approver_1"
        assert updated_checkpoint.resolution_reason == "Budget too high"
        
        # Project should still be DRAFT
        assert agent.projects[project.id].status == ProjectStatus.DRAFT
    
    def test_cannot_approve_already_resolved_checkpoint(self, agent: ProjectManagerAgent, sample_project):
        """Cannot approve a checkpoint that's already resolved"""
        project, checkpoint = sample_project
        
        # Approve first time
        agent.approve_project_creation(
            checkpoint_id=checkpoint.id,
            approved_by="approver_1",
        )
        
        # Try to approve again - should fail
        with pytest.raises(ValueError, match="already resolved"):
            agent.approve_project_creation(
                checkpoint_id=checkpoint.id,
                approved_by="approver_2",
            )


# ============================================================================
# CANON RULE #2: AUTONOMY ISOLATION TESTS
# ============================================================================

class TestAutonomyIsolation:
    """
    Tests for CANON Rule #2: Autonomy Isolation
    
    Analysis mode is read-only and doesn't modify data.
    """
    
    def test_analysis_is_read_only(self, agent: ProjectManagerAgent, sample_project):
        """Project analysis doesn't modify any data"""
        project, checkpoint = sample_project
        
        # Approve project first
        agent.approve_project_creation(checkpoint.id, "approver", "")
        
        # Create some tasks
        task1 = agent.create_task(
            project_id=project.id,
            title="Task 1",
            description="First task",
            created_by="user_1",
        )
        task2 = agent.create_task(
            project_id=project.id,
            title="Task 2",
            description="Second task",
            created_by="user_1",
        )
        # Mark task2 as done
        agent.update_task_status(task2.id, TaskStatus.DONE, "user_1")
        
        # Get state before analysis
        tasks_before = len(agent.tasks)
        projects_before = len(agent.projects)
        
        # Run analysis
        analysis = agent.analyze_project(
            project_id=project.id,
            analyzed_by="analyst_1",
        )
        
        # State should be unchanged
        assert len(agent.tasks) == tasks_before
        assert len(agent.projects) == projects_before
        
        # Analysis should have correct metrics
        assert analysis.total_tasks == 2
        assert analysis.completed_tasks == 1
    
    def test_analysis_provides_suggestions_not_actions(self, agent: ProjectManagerAgent, sample_project):
        """Analysis provides suggestions, doesn't execute them"""
        project, checkpoint = sample_project
        agent.approve_project_creation(checkpoint.id, "approver", "")
        
        # Create overdue task
        agent.create_task(
            project_id=project.id,
            title="Overdue Task",
            description="This is overdue",
            created_by="user_1",
            due_date=datetime.now(timezone.utc) - timedelta(days=5),
        )
        
        analysis = agent.analyze_project(project.id, "analyst_1")
        
        # Should have suggestion about overdue tasks
        assert analysis.overdue_tasks == 1
        assert any("overdue" in s.lower() for s in analysis.suggestions)
        
        # But task should NOT be automatically modified
        task = list(agent.tasks.values())[0]
        assert task.status == TaskStatus.TODO  # Still TODO, not auto-changed


# ============================================================================
# CANON RULE #5: NO RANKING ALGORITHMS TESTS
# ============================================================================

class TestNoRankingAlgorithms:
    """
    Tests for CANON Rule #5: No Ranking Algorithms
    
    All listings are CHRONOLOGICAL, not engagement-based.
    Priority is USER-DEFINED, not AI-calculated.
    """
    
    def test_projects_listed_chronologically(self, agent: ProjectManagerAgent):
        """Projects are listed in chronological order, not ranked"""
        # Create projects in order
        p1, c1 = agent.create_project_draft("Project A", "", "owner", "user")
        p2, c2 = agent.create_project_draft("Project B", "", "owner", "user")
        p3, c3 = agent.create_project_draft("Project C", "", "owner", "user")
        
        projects = agent.list_projects()
        
        # Should be newest first (reverse chronological)
        assert projects[0].id == p3.id
        assert projects[1].id == p2.id
        assert projects[2].id == p1.id
    
    def test_tasks_listed_chronologically(self, agent: ProjectManagerAgent, sample_project):
        """Tasks are listed in chronological order, not by engagement"""
        project, checkpoint = sample_project
        agent.approve_project_creation(checkpoint.id, "approver", "")
        
        # Create tasks in order
        t1 = agent.create_task(project.id, "Task 1", "", "user")
        t2 = agent.create_task(project.id, "Task 2", "", "user")
        t3 = agent.create_task(project.id, "Task 3", "", "user")
        
        tasks = agent.list_tasks(project.id)
        
        # Should be in creation order (chronological)
        assert tasks[0].id == t1.id
        assert tasks[1].id == t2.id
        assert tasks[2].id == t3.id
    
    def test_priority_is_user_defined(self, agent: ProjectManagerAgent, sample_project):
        """Task priority is what USER sets, not AI-calculated"""
        project, checkpoint = sample_project
        agent.approve_project_creation(checkpoint.id, "approver", "")
        
        # User sets priority
        task = agent.create_task(
            project_id=project.id,
            title="Important Task",
            description="Very important",
            created_by="user_1",
            priority=TaskPriority.URGENT,  # USER-DEFINED
        )
        
        assert task.priority == TaskPriority.URGENT
        
        # Priority should NOT change automatically
        # (no engagement algorithm modifying it)
        assert agent.tasks[task.id].priority == TaskPriority.URGENT


# ============================================================================
# CANON RULE #6: TRACEABILITY TESTS
# ============================================================================

class TestTraceability:
    """
    Tests for CANON Rule #6: Traceability
    
    All objects have created_by, created_at, and unique ID.
    """
    
    def test_project_has_traceability_fields(self, agent: ProjectManagerAgent, sample_project):
        """Projects have full traceability"""
        project, _ = sample_project
        
        assert project.id is not None
        assert len(project.id) > 0
        assert project.created_by == "user_456"
        assert project.created_at is not None
        assert isinstance(project.created_at, datetime)
    
    def test_task_has_traceability_fields(self, agent: ProjectManagerAgent, sample_project):
        """Tasks have full traceability"""
        project, checkpoint = sample_project
        agent.approve_project_creation(checkpoint.id, "approver", "")
        
        task = agent.create_task(
            project_id=project.id,
            title="Traced Task",
            description="",
            created_by="task_creator",
        )
        
        assert task.id is not None
        assert task.created_by == "task_creator"
        assert task.created_at is not None
    
    def test_modifications_are_tracked(self, agent: ProjectManagerAgent, sample_project):
        """Modifications record who and when"""
        project, checkpoint = sample_project
        agent.approve_project_creation(checkpoint.id, "approver_1", "Approved")
        
        task = agent.create_task(project.id, "Task", "", "creator")
        
        # Update task
        updated_task = agent.update_task_status(
            task_id=task.id,
            new_status=TaskStatus.IN_PROGRESS,
            updated_by="updater_1",
        )
        
        assert updated_task.modified_by == "updater_1"
        assert updated_task.modified_at is not None
    
    def test_checkpoint_has_audit_trail(self, agent: ProjectManagerAgent, sample_project):
        """Checkpoints have full audit trail"""
        project, checkpoint = sample_project
        
        assert checkpoint.id is not None
        assert checkpoint.requested_by == "user_456"
        assert checkpoint.requested_at is not None
        
        # After approval
        agent.approve_project_creation(checkpoint.id, "approver", "Good to go")
        
        resolved_checkpoint = agent.checkpoints[checkpoint.id]
        assert resolved_checkpoint.resolved_by == "approver"
        assert resolved_checkpoint.resolved_at is not None
        assert resolved_checkpoint.resolution_reason == "Good to go"


# ============================================================================
# INTEGRATION TESTS
# ============================================================================

class TestIntegration:
    """Full workflow integration tests"""
    
    def test_full_project_lifecycle(self, agent: ProjectManagerAgent):
        """Test complete project lifecycle with governance"""
        # 1. Create project (DRAFT)
        project, checkpoint = agent.create_project_draft(
            name="Full Lifecycle Project",
            description="Testing complete flow",
            owner_id="owner_1",
            created_by="creator_1",
            budget=Decimal("50000"),
        )
        assert project.status == ProjectStatus.DRAFT
        
        # 2. Approve project (PLANNING)
        project = agent.approve_project_creation(
            checkpoint_id=checkpoint.id,
            approved_by="manager_1",
            reason="Approved for Q1",
        )
        assert project.status == ProjectStatus.PLANNING
        
        # 3. Create tasks
        task1 = agent.create_task(
            project_id=project.id,
            title="Design Phase",
            description="Initial design",
            created_by="lead_1",
            priority=TaskPriority.HIGH,
        )
        
        task2 = agent.create_task(
            project_id=project.id,
            title="Development Phase",
            description="Build it",
            created_by="lead_1",
            priority=TaskPriority.MEDIUM,
        )
        
        # 4. Create milestone
        milestone = agent.create_milestone(
            project_id=project.id,
            name="MVP Release",
            description="First release",
            target_date=datetime.now(timezone.utc) + timedelta(days=30),
            created_by="pm_1",
        )
        
        # 5. Update task status
        agent.update_task_status(task1.id, TaskStatus.IN_PROGRESS, "dev_1")
        agent.update_task_status(task1.id, TaskStatus.DONE, "dev_1")
        
        # 6. Analyze project (read-only)
        analysis = agent.analyze_project(project.id, "pm_1")
        
        assert analysis.total_tasks == 2
        assert analysis.completed_tasks == 1
        
        # 7. Verify audit trail
        assert len(agent.checkpoints) >= 1
        assert all(c.requested_by for c in agent.checkpoints.values())


# ============================================================================
# EDGE CASES
# ============================================================================

class TestEdgeCases:
    """Edge case handling"""
    
    def test_create_task_invalid_project(self, agent: ProjectManagerAgent):
        """Cannot create task for non-existent project"""
        with pytest.raises(ValueError, match="Project not found"):
            agent.create_task(
                project_id="nonexistent",
                title="Task",
                description="",
                created_by="user",
            )
    
    def test_update_task_invalid_id(self, agent: ProjectManagerAgent):
        """Cannot update non-existent task"""
        with pytest.raises(ValueError, match="Task not found"):
            agent.update_task_status("nonexistent", TaskStatus.DONE, "user")
    
    def test_approve_invalid_checkpoint(self, agent: ProjectManagerAgent):
        """Cannot approve non-existent checkpoint"""
        with pytest.raises(ValueError, match="Checkpoint not found"):
            agent.approve_project_creation("nonexistent", "user", "")


# ============================================================================
# RUN TESTS
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
