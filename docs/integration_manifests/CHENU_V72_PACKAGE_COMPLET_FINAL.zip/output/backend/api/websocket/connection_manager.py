"""
WEBSOCKET CONNECTION MANAGER
============================

Central manager for WebSocket connections in CHE·NU.
Handles connection lifecycle, rooms/subscriptions, and broadcasting.

R&D COMPLIANCE:
- Rule #1: Checkpoint events notify but don't auto-execute
- Rule #3: Identity boundary enforced - only receive your events
- Rule #6: All connections and events traced

VERSION: 1.0.0
"""

from typing import Dict, Set, Optional, List, Any
from uuid import UUID, uuid4
from datetime import datetime
from dataclasses import dataclass, field
from enum import Enum
import asyncio
import json
import logging

from fastapi import WebSocket, WebSocketDisconnect
from pydantic import BaseModel

logger = logging.getLogger(__name__)


# =============================================================================
# ENUMS & TYPES
# =============================================================================

class ConnectionState(str, Enum):
    """WebSocket connection states"""
    CONNECTING = "connecting"
    CONNECTED = "connected"
    AUTHENTICATED = "authenticated"
    DISCONNECTING = "disconnecting"
    DISCONNECTED = "disconnected"


class SubscriptionType(str, Enum):
    """Types of subscriptions"""
    THREAD = "thread"           # Subscribe to a specific Thread
    SPHERE = "sphere"           # Subscribe to a Sphere's activity
    IDENTITY = "identity"       # Subscribe to all identity events
    CHECKPOINT = "checkpoint"   # Subscribe to checkpoint notifications
    AGENT = "agent"             # Subscribe to agent execution updates
    NOVA = "nova"               # Subscribe to Nova pipeline updates
    SYSTEM = "system"           # System-wide notifications


class EventType(str, Enum):
    """WebSocket event types"""
    # Connection events
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
    AUTHENTICATED = "authenticated"
    SUBSCRIBED = "subscribed"
    UNSUBSCRIBED = "unsubscribed"
    
    # Thread events
    THREAD_CREATED = "thread.created"
    THREAD_UPDATED = "thread.updated"
    THREAD_ARCHIVED = "thread.archived"
    THREAD_EVENT_ADDED = "thread.event_added"
    THREAD_SNAPSHOT_CREATED = "thread.snapshot_created"
    
    # Sphere events
    SPHERE_UPDATED = "sphere.updated"
    SPHERE_ITEM_ADDED = "sphere.item_added"
    
    # Checkpoint events (Rule #1 - Human Sovereignty)
    CHECKPOINT_CREATED = "checkpoint.created"
    CHECKPOINT_PENDING = "checkpoint.pending"
    CHECKPOINT_APPROVED = "checkpoint.approved"
    CHECKPOINT_REJECTED = "checkpoint.rejected"
    CHECKPOINT_EXPIRED = "checkpoint.expired"
    
    # Agent events
    AGENT_EXECUTION_STARTED = "agent.execution_started"
    AGENT_EXECUTION_PROGRESS = "agent.execution_progress"
    AGENT_EXECUTION_COMPLETED = "agent.execution_completed"
    AGENT_EXECUTION_FAILED = "agent.execution_failed"
    AGENT_DRAFT_READY = "agent.draft_ready"
    
    # Nova pipeline events
    NOVA_PIPELINE_STARTED = "nova.pipeline_started"
    NOVA_LANE_COMPLETED = "nova.lane_completed"
    NOVA_CHECKPOINT_TRIGGERED = "nova.checkpoint_triggered"
    NOVA_PIPELINE_COMPLETED = "nova.pipeline_completed"
    NOVA_PIPELINE_FAILED = "nova.pipeline_failed"
    
    # Presence events
    PRESENCE_JOINED = "presence.joined"
    PRESENCE_LEFT = "presence.left"
    PRESENCE_UPDATED = "presence.updated"
    
    # System events
    SYSTEM_NOTIFICATION = "system.notification"
    SYSTEM_MAINTENANCE = "system.maintenance"
    SYSTEM_ERROR = "system.error"
    
    # Error events
    ERROR = "error"
    UNAUTHORIZED = "unauthorized"


# =============================================================================
# DATA MODELS
# =============================================================================

@dataclass
class WebSocketConnection:
    """Represents an active WebSocket connection"""
    connection_id: str
    websocket: WebSocket
    identity_id: Optional[str] = None
    state: ConnectionState = ConnectionState.CONNECTING
    subscriptions: Set[str] = field(default_factory=set)  # subscription keys
    connected_at: datetime = field(default_factory=datetime.utcnow)
    last_activity: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def update_activity(self):
        """Update last activity timestamp"""
        self.last_activity = datetime.utcnow()


@dataclass
class Subscription:
    """Represents a subscription to events"""
    subscription_id: str
    subscription_type: SubscriptionType
    target_id: str  # Thread ID, Sphere ID, Identity ID, etc.
    identity_id: str  # Owner of subscription (Rule #3)
    connection_id: str
    created_at: datetime = field(default_factory=datetime.utcnow)


class WebSocketMessage(BaseModel):
    """Message format for WebSocket communication"""
    type: str
    event: str
    data: Dict[str, Any]
    timestamp: str
    request_id: Optional[str] = None
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


# =============================================================================
# CONNECTION MANAGER
# =============================================================================

class ConnectionManager:
    """
    Manages WebSocket connections for CHE·NU real-time features.
    
    Features:
    - Connection lifecycle management
    - Room/subscription management
    - Event broadcasting with identity boundaries
    - Presence tracking
    - Connection health monitoring
    """
    
    def __init__(self):
        # Active connections by connection_id
        self._connections: Dict[str, WebSocketConnection] = {}
        
        # Connections by identity (for identity-scoped broadcasts)
        self._identity_connections: Dict[str, Set[str]] = {}
        
        # Subscriptions by key (e.g., "thread:uuid", "sphere:uuid")
        self._subscriptions: Dict[str, Set[str]] = {}  # key -> connection_ids
        
        # All subscriptions by id
        self._subscription_registry: Dict[str, Subscription] = {}
        
        # Presence by room (Thread ID, Sphere ID)
        self._presence: Dict[str, Set[str]] = {}  # room -> connection_ids
        
        # Lock for thread-safe operations
        self._lock = asyncio.Lock()
        
        # Stats
        self._stats = {
            "total_connections": 0,
            "total_messages_sent": 0,
            "total_messages_received": 0,
            "total_subscriptions": 0
        }
        
        logger.info("WebSocket ConnectionManager initialized")
    
    # -------------------------------------------------------------------------
    # CONNECTION LIFECYCLE
    # -------------------------------------------------------------------------
    
    async def connect(self, websocket: WebSocket) -> str:
        """
        Accept a new WebSocket connection.
        
        Returns:
            connection_id: Unique identifier for this connection
        """
        await websocket.accept()
        
        connection_id = str(uuid4())
        connection = WebSocketConnection(
            connection_id=connection_id,
            websocket=websocket,
            state=ConnectionState.CONNECTED
        )
        
        async with self._lock:
            self._connections[connection_id] = connection
            self._stats["total_connections"] += 1
        
        logger.info(f"WebSocket connected: {connection_id}")
        
        # Send connection confirmation
        await self._send_to_connection(connection_id, WebSocketMessage(
            type="connection",
            event=EventType.CONNECTED.value,
            data={
                "connection_id": connection_id,
                "message": "Connected to CHE·NU real-time service"
            },
            timestamp=datetime.utcnow().isoformat()
        ))
        
        return connection_id
    
    async def authenticate(
        self, 
        connection_id: str, 
        identity_id: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Authenticate a connection with an identity.
        
        Rule #3: Identity boundary - connection linked to specific identity
        """
        async with self._lock:
            connection = self._connections.get(connection_id)
            if not connection:
                return False
            
            connection.identity_id = identity_id
            connection.state = ConnectionState.AUTHENTICATED
            connection.metadata = metadata or {}
            
            # Track connection by identity
            if identity_id not in self._identity_connections:
                self._identity_connections[identity_id] = set()
            self._identity_connections[identity_id].add(connection_id)
        
        logger.info(f"WebSocket authenticated: {connection_id} -> identity {identity_id}")
        
        # Send authentication confirmation
        await self._send_to_connection(connection_id, WebSocketMessage(
            type="connection",
            event=EventType.AUTHENTICATED.value,
            data={
                "identity_id": identity_id,
                "message": "Authentication successful"
            },
            timestamp=datetime.utcnow().isoformat()
        ))
        
        return True
    
    async def disconnect(self, connection_id: str):
        """
        Disconnect and cleanup a WebSocket connection.
        """
        async with self._lock:
            connection = self._connections.get(connection_id)
            if not connection:
                return
            
            # Remove from identity tracking
            if connection.identity_id:
                identity_conns = self._identity_connections.get(connection.identity_id, set())
                identity_conns.discard(connection_id)
                if not identity_conns:
                    del self._identity_connections[connection.identity_id]
            
            # Remove all subscriptions
            for sub_key in list(connection.subscriptions):
                await self._remove_subscription(connection_id, sub_key)
            
            # Remove from presence
            for room_id in list(self._presence.keys()):
                self._presence[room_id].discard(connection_id)
            
            # Remove connection
            del self._connections[connection_id]
        
        logger.info(f"WebSocket disconnected: {connection_id}")
    
    # -------------------------------------------------------------------------
    # SUBSCRIPTIONS
    # -------------------------------------------------------------------------
    
    async def subscribe(
        self,
        connection_id: str,
        subscription_type: SubscriptionType,
        target_id: str
    ) -> Optional[str]:
        """
        Subscribe a connection to events.
        
        Rule #3: Only subscribe to resources within identity boundary.
        
        Args:
            connection_id: Connection to subscribe
            subscription_type: Type of subscription
            target_id: ID of resource to subscribe to
            
        Returns:
            subscription_id if successful, None otherwise
        """
        async with self._lock:
            connection = self._connections.get(connection_id)
            if not connection or not connection.identity_id:
                logger.warning(f"Cannot subscribe: connection {connection_id} not authenticated")
                return None
            
            # Create subscription key
            sub_key = f"{subscription_type.value}:{target_id}"
            
            # Create subscription record
            subscription_id = str(uuid4())
            subscription = Subscription(
                subscription_id=subscription_id,
                subscription_type=subscription_type,
                target_id=target_id,
                identity_id=connection.identity_id,
                connection_id=connection_id
            )
            
            # Register subscription
            self._subscription_registry[subscription_id] = subscription
            
            # Add to subscription index
            if sub_key not in self._subscriptions:
                self._subscriptions[sub_key] = set()
            self._subscriptions[sub_key].add(connection_id)
            
            # Track on connection
            connection.subscriptions.add(sub_key)
            
            self._stats["total_subscriptions"] += 1
        
        logger.info(f"Subscription created: {connection_id} -> {sub_key}")
        
        # Send confirmation
        await self._send_to_connection(connection_id, WebSocketMessage(
            type="subscription",
            event=EventType.SUBSCRIBED.value,
            data={
                "subscription_id": subscription_id,
                "subscription_type": subscription_type.value,
                "target_id": target_id
            },
            timestamp=datetime.utcnow().isoformat()
        ))
        
        return subscription_id
    
    async def unsubscribe(
        self,
        connection_id: str,
        subscription_type: SubscriptionType,
        target_id: str
    ) -> bool:
        """Unsubscribe from events"""
        sub_key = f"{subscription_type.value}:{target_id}"
        
        async with self._lock:
            result = await self._remove_subscription(connection_id, sub_key)
        
        if result:
            await self._send_to_connection(connection_id, WebSocketMessage(
                type="subscription",
                event=EventType.UNSUBSCRIBED.value,
                data={
                    "subscription_type": subscription_type.value,
                    "target_id": target_id
                },
                timestamp=datetime.utcnow().isoformat()
            ))
        
        return result
    
    async def _remove_subscription(self, connection_id: str, sub_key: str) -> bool:
        """Internal method to remove a subscription (must hold lock)"""
        connection = self._connections.get(connection_id)
        if not connection:
            return False
        
        if sub_key not in connection.subscriptions:
            return False
        
        connection.subscriptions.discard(sub_key)
        
        if sub_key in self._subscriptions:
            self._subscriptions[sub_key].discard(connection_id)
            if not self._subscriptions[sub_key]:
                del self._subscriptions[sub_key]
        
        # Remove subscription record
        for sub_id, sub in list(self._subscription_registry.items()):
            if sub.connection_id == connection_id and f"{sub.subscription_type.value}:{sub.target_id}" == sub_key:
                del self._subscription_registry[sub_id]
                break
        
        return True
    
    # -------------------------------------------------------------------------
    # BROADCASTING
    # -------------------------------------------------------------------------
    
    async def broadcast_to_subscription(
        self,
        subscription_type: SubscriptionType,
        target_id: str,
        event: EventType,
        data: Dict[str, Any],
        exclude_connection: Optional[str] = None
    ):
        """
        Broadcast an event to all subscribers of a resource.
        
        Rule #3: Only sends to connections with matching identity boundary.
        
        Args:
            subscription_type: Type of subscription
            target_id: ID of resource
            event: Event type
            data: Event data
            exclude_connection: Optional connection to exclude (e.g., sender)
        """
        sub_key = f"{subscription_type.value}:{target_id}"
        
        async with self._lock:
            connection_ids = self._subscriptions.get(sub_key, set()).copy()
        
        if exclude_connection:
            connection_ids.discard(exclude_connection)
        
        message = WebSocketMessage(
            type="event",
            event=event.value,
            data=data,
            timestamp=datetime.utcnow().isoformat()
        )
        
        await self._broadcast_to_connections(connection_ids, message)
    
    async def broadcast_to_identity(
        self,
        identity_id: str,
        event: EventType,
        data: Dict[str, Any]
    ):
        """
        Broadcast an event to all connections of an identity.
        
        Rule #3: Identity-scoped broadcasting
        """
        async with self._lock:
            connection_ids = self._identity_connections.get(identity_id, set()).copy()
        
        message = WebSocketMessage(
            type="event",
            event=event.value,
            data=data,
            timestamp=datetime.utcnow().isoformat()
        )
        
        await self._broadcast_to_connections(connection_ids, message)
    
    async def broadcast_to_all(self, event: EventType, data: Dict[str, Any]):
        """
        Broadcast to all connected clients.
        
        Use sparingly - mainly for system notifications.
        """
        async with self._lock:
            connection_ids = set(self._connections.keys())
        
        message = WebSocketMessage(
            type="system",
            event=event.value,
            data=data,
            timestamp=datetime.utcnow().isoformat()
        )
        
        await self._broadcast_to_connections(connection_ids, message)
    
    async def _broadcast_to_connections(
        self, 
        connection_ids: Set[str], 
        message: WebSocketMessage
    ):
        """Send message to multiple connections"""
        tasks = []
        for conn_id in connection_ids:
            tasks.append(self._send_to_connection(conn_id, message))
        
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def _send_to_connection(
        self, 
        connection_id: str, 
        message: WebSocketMessage
    ) -> bool:
        """Send message to a single connection"""
        connection = self._connections.get(connection_id)
        if not connection:
            return False
        
        try:
            await connection.websocket.send_json(message.dict())
            connection.update_activity()
            self._stats["total_messages_sent"] += 1
            return True
        except Exception as e:
            logger.warning(f"Failed to send to {connection_id}: {e}")
            # Connection likely dead, disconnect it
            await self.disconnect(connection_id)
            return False
    
    # -------------------------------------------------------------------------
    # PRESENCE
    # -------------------------------------------------------------------------
    
    async def join_presence(self, connection_id: str, room_id: str):
        """
        Add connection to a presence room (e.g., Thread workspace).
        """
        async with self._lock:
            connection = self._connections.get(connection_id)
            if not connection or not connection.identity_id:
                return
            
            if room_id not in self._presence:
                self._presence[room_id] = set()
            self._presence[room_id].add(connection_id)
        
        # Notify others in room
        await self.broadcast_to_subscription(
            SubscriptionType.THREAD,
            room_id,
            EventType.PRESENCE_JOINED,
            {
                "identity_id": connection.identity_id,
                "room_id": room_id
            },
            exclude_connection=connection_id
        )
    
    async def leave_presence(self, connection_id: str, room_id: str):
        """
        Remove connection from a presence room.
        """
        async with self._lock:
            connection = self._connections.get(connection_id)
            if not connection:
                return
            
            if room_id in self._presence:
                self._presence[room_id].discard(connection_id)
        
        # Notify others in room
        if connection.identity_id:
            await self.broadcast_to_subscription(
                SubscriptionType.THREAD,
                room_id,
                EventType.PRESENCE_LEFT,
                {
                    "identity_id": connection.identity_id,
                    "room_id": room_id
                },
                exclude_connection=connection_id
            )
    
    async def get_presence(self, room_id: str) -> List[str]:
        """Get list of identity IDs present in a room"""
        async with self._lock:
            connection_ids = self._presence.get(room_id, set())
            identity_ids = []
            for conn_id in connection_ids:
                conn = self._connections.get(conn_id)
                if conn and conn.identity_id:
                    identity_ids.append(conn.identity_id)
            return list(set(identity_ids))  # Dedupe
    
    # -------------------------------------------------------------------------
    # UTILITY
    # -------------------------------------------------------------------------
    
    async def handle_message(
        self, 
        connection_id: str, 
        data: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """
        Handle incoming message from client.
        
        Returns response to send back, or None.
        """
        connection = self._connections.get(connection_id)
        if not connection:
            return None
        
        connection.update_activity()
        self._stats["total_messages_received"] += 1
        
        action = data.get("action")
        payload = data.get("payload", {})
        
        if action == "ping":
            return {"action": "pong", "timestamp": datetime.utcnow().isoformat()}
        
        elif action == "subscribe":
            sub_type = SubscriptionType(payload.get("type"))
            target_id = payload.get("target_id")
            subscription_id = await self.subscribe(connection_id, sub_type, target_id)
            return {"action": "subscribed", "subscription_id": subscription_id}
        
        elif action == "unsubscribe":
            sub_type = SubscriptionType(payload.get("type"))
            target_id = payload.get("target_id")
            await self.unsubscribe(connection_id, sub_type, target_id)
            return {"action": "unsubscribed", "target_id": target_id}
        
        elif action == "join_presence":
            room_id = payload.get("room_id")
            await self.join_presence(connection_id, room_id)
            return {"action": "presence_joined", "room_id": room_id}
        
        elif action == "leave_presence":
            room_id = payload.get("room_id")
            await self.leave_presence(connection_id, room_id)
            return {"action": "presence_left", "room_id": room_id}
        
        elif action == "get_presence":
            room_id = payload.get("room_id")
            identities = await self.get_presence(room_id)
            return {"action": "presence_list", "room_id": room_id, "identities": identities}
        
        return None
    
    def get_connection(self, connection_id: str) -> Optional[WebSocketConnection]:
        """Get connection by ID"""
        return self._connections.get(connection_id)
    
    def get_connection_count(self) -> int:
        """Get number of active connections"""
        return len(self._connections)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get connection manager statistics"""
        return {
            **self._stats,
            "active_connections": len(self._connections),
            "authenticated_connections": sum(
                1 for c in self._connections.values() 
                if c.state == ConnectionState.AUTHENTICATED
            ),
            "active_subscriptions": len(self._subscription_registry),
            "active_presence_rooms": len(self._presence)
        }


# =============================================================================
# SINGLETON INSTANCE
# =============================================================================

# Global connection manager instance
connection_manager = ConnectionManager()


def get_connection_manager() -> ConnectionManager:
    """Get the global connection manager instance"""
    return connection_manager
