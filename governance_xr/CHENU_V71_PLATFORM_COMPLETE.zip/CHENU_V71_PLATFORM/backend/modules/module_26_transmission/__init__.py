"""
CHE·NU™ V70 — MODULE 26: TRANSMISSION ENGINE
=============================================
Le moteur de continuité civilisationnelle.

Si le WorldEngine simule le futur, le Transmission Engine empêche 
l'humanité d'oublier comment y arriver.

Fonctions principales:
- Transmission par l'Action (Apprise → Appliquée → Transmise)
- Artifacts de Transmission (Skill Trace, Causal Replay, Seeds)
- Boucle Intergénérationnelle (Mentorship XR)
- Mode Crise & Redémarrage (lié au Black-Box)
- XR: La Chambre de Transmission
"""

from .engine import (
    TransmissionMode,
    SkillPriority,
    SkillTrace,
    CausalReplay,
    TransmissionSeed,
    MentorshipLink,
    CrisisRecoveryPackage,
    TransmissionEngine,
)

__all__ = [
    "TransmissionMode",
    "SkillPriority",
    "SkillTrace",
    "CausalReplay",
    "TransmissionSeed",
    "MentorshipLink",
    "CrisisRecoveryPackage",
    "TransmissionEngine",
]

__version__ = "70.0.0"
