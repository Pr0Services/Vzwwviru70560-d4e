"""
CHE·NU™ V70 — SCHEMAS PACKAGE
=============================
Pydantic validation schemas.
"""

from .models import *

__version__ = "70.0.0"
