"""
CHE·NU™ V70 — MIDDLEWARE STACK
==============================
FastAPI middleware for GP2 system.

Features:
- Rate limiting
- Request logging
- Error handling
- Governance enforcement

GOUVERNANCE > EXÉCUTION
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Optional
from uuid import uuid4
import time
import logging
import traceback
from collections import defaultdict

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("chenu.middleware")


# =============================================================================
# RATE LIMITER
# =============================================================================

@dataclass
class RateLimitConfig:
    """Rate limit configuration."""
    requests_per_minute: int = 60
    requests_per_hour: int = 1000
    burst_limit: int = 10  # Max requests per second


class RateLimiter:
    """
    Token bucket rate limiter.
    
    Supports:
    - Per-user limits
    - Per-IP limits
    - Burst handling
    """
    
    def __init__(self, config: RateLimitConfig = None):
        self.config = config or RateLimitConfig()
        self._buckets: dict[str, dict] = defaultdict(lambda: {
            "tokens": self.config.burst_limit,
            "last_update": time.time(),
            "minute_count": 0,
            "minute_start": time.time(),
            "hour_count": 0,
            "hour_start": time.time(),
        })
    
    def is_allowed(self, key: str) -> tuple[bool, dict]:
        """Check if request is allowed."""
        bucket = self._buckets[key]
        now = time.time()
        
        # Refill tokens (1 token per second)
        elapsed = now - bucket["last_update"]
        bucket["tokens"] = min(
            self.config.burst_limit,
            bucket["tokens"] + elapsed
        )
        bucket["last_update"] = now
        
        # Reset minute counter
        if now - bucket["minute_start"] > 60:
            bucket["minute_count"] = 0
            bucket["minute_start"] = now
        
        # Reset hour counter
        if now - bucket["hour_start"] > 3600:
            bucket["hour_count"] = 0
            bucket["hour_start"] = now
        
        # Check limits
        headers = {
            "X-RateLimit-Limit": str(self.config.requests_per_minute),
            "X-RateLimit-Remaining": str(
                max(0, self.config.requests_per_minute - bucket["minute_count"])
            ),
            "X-RateLimit-Reset": str(int(bucket["minute_start"] + 60)),
        }
        
        # Check burst limit
        if bucket["tokens"] < 1:
            headers["Retry-After"] = "1"
            return False, headers
        
        # Check minute limit
        if bucket["minute_count"] >= self.config.requests_per_minute:
            retry_after = int(60 - (now - bucket["minute_start"]))
            headers["Retry-After"] = str(max(1, retry_after))
            return False, headers
        
        # Check hour limit
        if bucket["hour_count"] >= self.config.requests_per_hour:
            retry_after = int(3600 - (now - bucket["hour_start"]))
            headers["Retry-After"] = str(max(1, retry_after))
            return False, headers
        
        # Allow request
        bucket["tokens"] -= 1
        bucket["minute_count"] += 1
        bucket["hour_count"] += 1
        
        return True, headers


class RateLimitMiddleware(BaseHTTPMiddleware):
    """Rate limiting middleware."""
    
    def __init__(self, app: FastAPI, config: RateLimitConfig = None):
        super().__init__(app)
        self.limiter = RateLimiter(config)
        self._exempt_paths = {"/health", "/metrics", "/docs", "/redoc", "/openapi.json"}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Skip exempt paths
        if request.url.path in self._exempt_paths:
            return await call_next(request)
        
        # Get rate limit key (user_id or IP)
        key = request.headers.get("X-User-ID", request.client.host)
        
        # Check bypass permission
        if request.headers.get("X-Bypass-Rate-Limit") == "true":
            # Validate token has bypass permission
            # For now, skip rate limit
            return await call_next(request)
        
        # Check rate limit
        allowed, headers = self.limiter.is_allowed(key)
        
        if not allowed:
            return JSONResponse(
                status_code=429,
                content={
                    "error": "Too Many Requests",
                    "message": "Rate limit exceeded. Please retry later.",
                },
                headers=headers,
            )
        
        response = await call_next(request)
        
        # Add rate limit headers
        for header_name, header_value in headers.items():
            response.headers[header_name] = header_value
        
        return response


# =============================================================================
# REQUEST LOGGING
# =============================================================================

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Request/response logging middleware."""
    
    def __init__(self, app: FastAPI, log_body: bool = False):
        super().__init__(app)
        self.log_body = log_body
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        request_id = f"REQ_{uuid4().hex[:8]}"
        start_time = time.time()
        
        # Log request
        logger.info(
            f"[{request_id}] {request.method} {request.url.path} "
            f"from {request.client.host}"
        )
        
        # Add request ID to state
        request.state.request_id = request_id
        
        # Process request
        response = await call_next(request)
        
        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000
        
        # Log response
        logger.info(
            f"[{request_id}] {response.status_code} "
            f"({duration_ms:.2f}ms)"
        )
        
        # Add request ID header
        response.headers["X-Request-ID"] = request_id
        response.headers["X-Response-Time"] = f"{duration_ms:.2f}ms"
        
        return response


# =============================================================================
# ERROR HANDLING
# =============================================================================

class ErrorHandlingMiddleware(BaseHTTPMiddleware):
    """Global error handling middleware."""
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next(request)
        
        except PermissionError as e:
            logger.warning(f"Permission denied: {e}")
            return JSONResponse(
                status_code=403,
                content={
                    "error": "Forbidden",
                    "message": str(e),
                },
            )
        
        except ValueError as e:
            logger.warning(f"Validation error: {e}")
            return JSONResponse(
                status_code=400,
                content={
                    "error": "Bad Request",
                    "message": str(e),
                },
            )
        
        except Exception as e:
            request_id = getattr(request.state, "request_id", "unknown")
            logger.error(f"[{request_id}] Unhandled error: {e}")
            logger.error(traceback.format_exc())
            
            return JSONResponse(
                status_code=500,
                content={
                    "error": "Internal Server Error",
                    "message": "An unexpected error occurred",
                    "request_id": request_id,
                },
            )


# =============================================================================
# GOVERNANCE ENFORCEMENT
# =============================================================================

class GovernanceMiddleware(BaseHTTPMiddleware):
    """
    Governance enforcement middleware.
    
    Ensures all requests comply with:
    - Synthetic-only mode
    - XR read-only
    - HITL requirements
    """
    
    def __init__(self, app: FastAPI):
        super().__init__(app)
        self._write_methods = {"POST", "PUT", "PATCH", "DELETE"}
        self._xr_paths = {"/api/v1/xr/", "/xr/"}
    
    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Check XR write attempts (FORBIDDEN)
        if any(request.url.path.startswith(p) for p in self._xr_paths):
            if request.method in self._write_methods:
                logger.warning(
                    f"GOVERNANCE BLOCK: XR write attempt on {request.url.path}"
                )
                return JSONResponse(
                    status_code=403,
                    content={
                        "error": "Governance Violation",
                        "message": "XR is READ ONLY. Write operations are forbidden.",
                        "governance": {
                            "rule": "XR_READ_ONLY",
                            "level": "strict",
                        },
                    },
                )
        
        # Add governance headers
        response = await call_next(request)
        
        response.headers["X-Governance-Level"] = "strict"
        response.headers["X-Synthetic-Only"] = "true"
        response.headers["X-XR-Read-Only"] = "true"
        
        return response


# =============================================================================
# CORS
# =============================================================================

def setup_cors(app: FastAPI, origins: list[str] = None):
    """Setup CORS middleware."""
    from fastapi.middleware.cors import CORSMiddleware
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins or ["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=[
            "X-Request-ID",
            "X-Response-Time",
            "X-RateLimit-Limit",
            "X-RateLimit-Remaining",
            "X-RateLimit-Reset",
            "X-Governance-Level",
        ],
    )


# =============================================================================
# SETUP ALL MIDDLEWARE
# =============================================================================

def setup_middleware(
    app: FastAPI,
    rate_limit_config: RateLimitConfig = None,
    enable_cors: bool = True,
):
    """Setup all middleware for GP2 API."""
    
    # Order matters! Last added = first executed
    
    # 1. Error handling (outermost)
    app.add_middleware(ErrorHandlingMiddleware)
    
    # 2. Request logging
    app.add_middleware(RequestLoggingMiddleware, log_body=False)
    
    # 3. Governance enforcement
    app.add_middleware(GovernanceMiddleware)
    
    # 4. Rate limiting
    app.add_middleware(RateLimitMiddleware, config=rate_limit_config)
    
    # 5. CORS (innermost, applied first)
    if enable_cors:
        setup_cors(app)
    
    logger.info("Middleware stack configured")
