# CHE·NU — WIREFLOW CANONICAL (FINAL)

## 🧭 Vue d'ensemble

```
┌─────────┐     ┌─────────────────┐     ┌─────────────────┐     ┌─────────────┐
│  ENTRY  │────▶│ CONTEXT BUREAU  │────▶│  ACTION BUREAU  │────▶│  WORKSPACE  │
└─────────┘     └─────────────────┘     └─────────────────┘     └─────────────┘
                       │    ▲                  │    ▲                 │
                       │    │                  │    │                 │
                       └────┘                  └────┘                 │
                   (change context)       (change context)            │
                                               ▲                      │
                                               └──────────────────────┘
                                                    (back / change)
```

---

## 🧠 WIREFLOW MERMAID (Copiable)

```mermaid
flowchart TD
    subgraph ENTRY["🚀 ENTRY"]
        E1[App Open]
        E2[Diamond Hub Visible]
        E3[Nova Welcome]
    end
    
    subgraph CONTEXT["📍 CONTEXT BUREAU"]
        C1[Identity Selection]
        C2[Sphere Selection]
        C3[Project Selection]
        C4[Context Summary]
        C5[Confirm Button]
    end
    
    subgraph ACTION["⚡ ACTION BUREAU"]
        A1[Quick Actions]
        A2[Recent Workspaces]
        A3[Nova Suggestions]
        A4[Agent Delegation]
    end
    
    subgraph WORKSPACE["🔧 WORKSPACE"]
        W1[Canvas/Editor]
        W2[Draft/Staging/Review]
        W3[Version Control]
        W4[Agent Execution]
    end
    
    E1 --> E2
    E2 --> E3
    E3 -->|"Enter Context"| C1
    
    C1 -->|"Auto-fill if unique"| C2
    C2 -->|"Auto-fill if unique"| C3
    C3 --> C4
    C4 --> C5
    C5 -->|"CONFIRM_CONTEXT"| A1
    
    C1 -.->|"Change"| C1
    C2 -.->|"Change"| C1
    C3 -.->|"Clear"| C3
    
    A1 --> A2
    A2 --> A3
    A3 --> A4
    
    A1 -->|"OPEN_WORKSPACE"| W1
    A2 -->|"Select Recent"| W1
    A3 -->|"Accept Suggestion"| W1
    A4 -->|"Delegate"| W1
    
    A1 -.->|"CHANGE_CONTEXT"| C1
    
    W1 --> W2
    W2 --> W3
    W3 --> W4
    
    W1 -.->|"BACK"| A1
    W1 -.->|"CHANGE_CONTEXT"| C1
```

---

## 🔄 FLOW DÉTAILLÉ MERMAID

```mermaid
stateDiagram-v2
    [*] --> entry
    
    entry --> context_bureau : auto (500ms) / ENTER_APP
    
    state context_bureau {
        [*] --> preselect
        preselect --> show_identity
        show_identity --> show_sphere : identity selected
        show_sphere --> show_project : sphere selected
        show_project --> ready : (optional)
        ready --> [*]
    }
    
    context_bureau --> context_bureau : SELECT_IDENTITY / SELECT_SPHERE / SELECT_PROJECT
    context_bureau --> action_bureau : CONFIRM_CONTEXT [identity + sphere valid]
    
    state action_bureau {
        [*] --> suggest_actions
        suggest_actions --> show_workspaces
        show_workspaces --> show_nova_tips
        show_nova_tips --> [*]
    }
    
    action_bureau --> workspace : OPEN_WORKSPACE / CREATE_* / CALL_AGENT
    action_bureau --> context_bureau : CHANGE_CONTEXT
    
    state workspace {
        [*] --> lock_context
        lock_context --> execution
        execution --> [*]
    }
    
    workspace --> action_bureau : BACK_TO_ACTIONS
    workspace --> context_bureau : CHANGE_CONTEXT [invalidates workspace]
```

---

## 📱 ÉCRANS DÉTAILLÉS

### 🟦 SCREEN 0 — ENTRY / APP OPEN

```
┌─────────────────────────────────────────────────────────────┐
│                                                             │
│                           ◆                                 │
│                        CHE·NU                               │
│                                                             │
│                    ┌───────────────┐                        │
│                    │      ✦        │                        │
│                    │    Nova       │                        │
│                    │  "Bonjour!"   │                        │
│                    └───────────────┘                        │
│                                                             │
│              ○ ○ ○ ○ ○ ○ ○ ○  (8 spheres)                   │
│                                                             │
│                 [ Entrer dans mon contexte ]                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**But:** Ne pas réfléchir, comprendre où on est.

**Transition:** Toujours vers Context Bureau

---

### 🟨 SCREEN 1 — CONTEXT BUREAU

```
┌─────────────────────────────────────────────────────────────┐
│  📍 CONTEXT BUREAU                                          │
│  "Sur quoi je travaille?"                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  IDENTITÉ                                                   │
│  ┌─────────────────────────────────────────────┐            │
│  │ 💼 Pro Service Inc                    [Auto]│  [Change]  │
│  └─────────────────────────────────────────────┘            │
│                                                             │
│  SPHÈRE                                                     │
│  ┌─────────────────────────────────────────────┐            │
│  │ 💼 Business                           [Auto]│  [Change]  │
│  └─────────────────────────────────────────────┘            │
│                                                             │
│  PROJET (optionnel)                                         │
│  ┌─────────────────────────────────────────────┐            │
│  │ 📁 CHE·NU Development                       │  [Clear]   │
│  └─────────────────────────────────────────────┘            │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  RÉSUMÉ                                                     │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐                      │
│  │ 3 Tasks │  │ 2 Meet  │  │ 1 Alert │                      │
│  │ urgents │  │ proches │  │         │                      │
│  └─────────┘  └─────────┘  └─────────┘                      │
│                                                             │
│              ╔═══════════════════════════╗                  │
│              ║    ALLER TRAVAILLER →     ║                  │
│              ╚═══════════════════════════╝                  │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**But:** Répondre à "sur quoi je travaille?"

**Actions:**
- Changer identité
- Changer sphère  
- Changer projet
- Confirmer contexte

**Transitions:**
- → Action Bureau (CONFIRM_CONTEXT)
- → Navigation Hub (modifier le contexte)

---

### 🟧 SCREEN 2 — ACTION BUREAU

```
┌─────────────────────────────────────────────────────────────┐
│  ⚡ ACTION BUREAU                                           │
│  "Que faire maintenant?"                                    │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ACTIONS RAPIDES                                            │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐         │
│  │ 🔧 Workspace │ │ 📝 Note     │ │ ✅ Tâche    │         │
│  └──────────────┘ └──────────────┘ └──────────────┘         │
│  ┌──────────────┐ ┌──────────────┐                          │
│  │ 📹 Meeting   │ │ 🤖 Agent    │                          │
│  └──────────────┘ └──────────────┘                          │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  📌 WORKSPACES ÉPINGLÉS                                     │
│  ┌─────────────────────────────────────────────┐            │
│  │ Main Development Workspace              →   │            │
│  └─────────────────────────────────────────────┘            │
│                                                             │
│  🕐 RÉCENTS                                                 │
│  ┌─────────────────────────────────────────────┐            │
│  │ API Integration Session            (hier)   │            │
│  ├─────────────────────────────────────────────┤            │
│  │ Documentation Review              (2 jours) │            │
│  └─────────────────────────────────────────────┘            │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  💡 SUGGESTIONS NOVA                                        │
│  ┌─────────────────────────────────────────────┐            │
│  │ "Vous avez 3 tâches urgentes. Commencer?"   │            │
│  └─────────────────────────────────────────────┘            │
│                                                             │
│        [ ← Changer de contexte ]                            │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**But:** Décider quoi faire maintenant.

**Actions:**
- Ouvrir un workspace
- Créer du contenu
- Déléguer à un agent

**Transitions:**
- → Workspace
- → Context Bureau (si changement de cap)

---

### 🟥 SCREEN 3 — WORKSPACE

```
┌─────────────────────────────────────────────────────────────┐
│  🔧 WORKSPACE: Main Development                             │
│  Context: 💼 Business • Pro Service • CHE·NU Dev   [🔒]     │
├─────────────────────────────────────────────────────────────┤
│  ┌───────────────────────────────────────────────────────┐  │
│  │                                                       │  │
│  │                                                       │  │
│  │                      CANVAS                           │  │
│  │                                                       │  │
│  │              (doc / table / board / etc.)             │  │
│  │                                                       │  │
│  │                                                       │  │
│  │                                                       │  │
│  └───────────────────────────────────────────────────────┘  │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  MODE: [Draft] [Staging] [Review]                           │
│                                                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ 📋 Diff  │ │ 🔄 Sync  │ │ 🤖 Agent │ │ ↩️ Back  │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

**But:** Exécution.

**Note:** Le contexte est VERROUILLÉ (🔒) pendant l'exécution.

**Transitions:**
- → Action Bureau (BACK)
- → Context Bureau (CHANGE_CONTEXT - invalide le workspace)

---

## 🔐 RÈGLES DE GOUVERNANCE

| Règle | Description |
|-------|-------------|
| ❌ | Aucun accès direct au workspace sans contexte validé |
| ❌ | Aucun agent ne travaille sans contexte figé |
| ✅ | Tout changement de contexte invalide le workspace actif |
| ✅ | Le Diamond Hub reflète toujours l'état courant |

---

## 🧱 BLOC CANONIQUE (Pour Claude)

```
CHE·NU — WIREFLOW & STATE MACHINE RULES (FINAL)

There are exactly FOUR main states:
1) ENTRY
2) CONTEXT_BUREAU
3) ACTION_BUREAU
4) WORKSPACE

Context Bureau is NEVER skipped.
Intelligence is used only to pre-fill it, not bypass it.

Flow:
ENTRY → CONTEXT_BUREAU → ACTION_BUREAU → WORKSPACE

Returning backward is always allowed.

Any context change invalidates execution state.
Diamond Hub always reflects the current state.
```

---

## 📊 TRANSITIONS MATRIX

| From | To | Event | Guard |
|------|-----|-------|-------|
| entry | context_bureau | ENTER_APP / auto | - |
| context_bureau | context_bureau | SELECT_* | - |
| context_bureau | action_bureau | CONFIRM_CONTEXT | identity + sphere |
| action_bureau | workspace | OPEN_WORKSPACE | - |
| action_bureau | context_bureau | CHANGE_CONTEXT | - |
| workspace | action_bureau | BACK_TO_ACTIONS | - |
| workspace | context_bureau | CHANGE_CONTEXT | invalidates ws |

---

*CHE·NU — Governed Intelligence Operating System*
*Version: CANONICAL FINAL*
