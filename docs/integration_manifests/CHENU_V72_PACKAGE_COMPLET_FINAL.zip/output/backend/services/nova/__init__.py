"""
CHE·NU™ Nova Services
=====================

Nova is the system intelligence of CHE·NU.
It orchestrates all AI operations through the Multi-Lane Pipeline.

NOVA IS NOT AN AGENT:
- Nova is SYSTEM INTELLIGENCE, not a hired agent
- Nova coordinates execution, doesn't make decisions
- Nova enforces Human Sovereignty (Rule #1)
- Nova never operates autonomously

PIPELINE LANES:
A - Intent Analysis: Parse user intent
B - Context Snapshot: Capture Thread state
C - Semantic Encoding: Prepare for LLM
D - Governance Check: Verify permissions
E - Checkpoint: Block sensitive actions (HTTP 423)
F - Execution: Execute AI operation
G - Audit: Log everything
"""

from backend.services.nova.nova_pipeline import (
    # Enums
    PipelineLane,
    IntentType,
    GovernanceStatus,
    ExecutionStatus,
    
    # Request/Response
    NovaRequest,
    NovaPipelineResult,
    
    # Lane Results
    IntentAnalysisResult,
    ContextSnapshot,
    SemanticEncoding,
    GovernanceResult,
    CheckpointResult,
    ExecutionResult,
    AuditRecord,
    
    # Service
    NovaPipelineService,
    
    # Lane Handlers
    IntentAnalyzer,
    ContextSnapshotBuilder,
    SemanticEncoder,
    GovernanceChecker,
    CheckpointHandler,
    Executor,
    Auditor,
)

__all__ = [
    # Enums
    "PipelineLane",
    "IntentType",
    "GovernanceStatus",
    "ExecutionStatus",
    
    # Request/Response
    "NovaRequest",
    "NovaPipelineResult",
    
    # Lane Results
    "IntentAnalysisResult",
    "ContextSnapshot",
    "SemanticEncoding",
    "GovernanceResult",
    "CheckpointResult",
    "ExecutionResult",
    "AuditRecord",
    
    # Service
    "NovaPipelineService",
    
    # Lane Handlers
    "IntentAnalyzer",
    "ContextSnapshotBuilder",
    "SemanticEncoder",
    "GovernanceChecker",
    "CheckpointHandler",
    "Executor",
    "Auditor",
]
