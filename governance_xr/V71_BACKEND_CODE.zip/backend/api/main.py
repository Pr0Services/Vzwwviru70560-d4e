"""
CHE·NU™ V71 — Main API Application
==================================
FastAPI application integrating all V71 architectural modules.

Modules:
- Synaptic (Context, Switcher, Graph, YellowPages)
- Quantum (Orchestrator, QKD, Photonic)
- MultiTech (Technology Registry, Phases)
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import logging
from datetime import datetime

from .routes import synaptic_router, quantum_router, multitech_router

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(name)s | %(message)s'
)
logger = logging.getLogger("chenu.api")


# =============================================================================
# LIFESPAN MANAGEMENT
# =============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler"""
    # Startup
    logger.info("=" * 60)
    logger.info("CHE·NU™ V71 API Starting...")
    logger.info("=" * 60)
    
    # Initialize modules
    from ..core.synaptic import (
        get_synaptic_switcher,
        get_synaptic_graph,
        get_yellow_pages
    )
    from ..core.quantum import get_quantum_orchestrator
    from ..core.multitech import get_multi_tech_integration
    
    # Initialize singletons
    switcher = get_synaptic_switcher()
    graph = get_synaptic_graph()
    yellow_pages = get_yellow_pages()
    orchestrator = get_quantum_orchestrator()
    multitech = get_multi_tech_integration()
    
    logger.info(f"✅ SynapticSwitcher initialized")
    logger.info(f"✅ SynapticGraph initialized ({len(graph._edges)} edges)")
    logger.info(f"✅ YellowPages initialized ({len(yellow_pages._entries)} entries)")
    logger.info(f"✅ QuantumOrchestrator initialized ({len(orchestrator._backends)} backends)")
    logger.info(f"✅ MultiTechIntegration initialized (Phase: {multitech.current_phase.value})")
    
    logger.info("=" * 60)
    logger.info("CHE·NU™ V71 API Ready!")
    logger.info("=" * 60)
    
    yield
    
    # Shutdown
    logger.info("CHE·NU™ V71 API Shutting down...")


# =============================================================================
# APP CREATION
# =============================================================================

def create_app() -> FastAPI:
    """Create and configure FastAPI application"""
    
    app = FastAPI(
        title="CHE·NU™ V71 API",
        description="""
# CHE·NU™ V71 — Governed Intelligence Operating System

## Architectural Modules

### 🧠 Synaptic Infrastructure
- **Context Capsules**: 3-hub synchronized state
- **Switcher**: Atomic routing to Communication/Navigation/Execution
- **Graph**: 25 inter-module connections with anti-loop protection
- **YellowPages**: Service registry with needs→authority mapping

### ⚛️ Quantum Orchestration
- **Auto-routing**: Classical/Photonic/Quantum selection
- **QKD**: Quantum key distribution for secure communication
- **Photonic Sync**: Nanosecond precision for navigation

### 🔧 Multi-Tech Integration
- **5 Architecture Levels**: Physical → Kernel → Hubs → Agents → Interfaces
- **3 Integration Phases**: Compatibility → Hybridation → Quantum
- **5 Decision Rules**: Fallback, Modularity, No Lock-in, Transparency, Social Impact

## Core Principles
- **GOVERNANCE > EXECUTION**
- **Human Sovereignty**: No action without approval
- **Identity Boundary**: Strict isolation
- **Checkpoint Blocking**: HTTP 423 for governance gates
        """,
        version="71.0.0",
        docs_url="/docs",
        redoc_url="/redoc",
        lifespan=lifespan
    )
    
    # CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"]
    )
    
    # Include routers
    app.include_router(synaptic_router)
    app.include_router(quantum_router)
    app.include_router(multitech_router)
    
    # Root endpoint
    @app.get("/")
    async def root():
        return {
            "name": "CHE·NU™ V71 API",
            "version": "71.0.0",
            "status": "operational",
            "modules": [
                "synaptic",
                "quantum",
                "multitech"
            ],
            "docs": "/docs",
            "timestamp": datetime.utcnow().isoformat()
        }
    
    # Health endpoint
    @app.get("/health")
    async def health():
        return {
            "status": "healthy",
            "version": "71.0.0",
            "timestamp": datetime.utcnow().isoformat()
        }
    
    # API info
    @app.get("/api/v2/info")
    async def api_info():
        return {
            "api_version": "v2",
            "platform_version": "71.0.0",
            "modules": {
                "synaptic": {
                    "prefix": "/api/v2/synaptic",
                    "components": ["context", "switcher", "graph", "yellowpages"]
                },
                "quantum": {
                    "prefix": "/api/v2/quantum",
                    "components": ["orchestrator", "qkd", "photonic"]
                },
                "multitech": {
                    "prefix": "/api/v2/multitech",
                    "components": ["registry", "phases", "hubs"]
                }
            },
            "total_endpoints": 50,
            "governance": "GOVERNANCE > EXECUTION"
        }
    
    # Exception handlers
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        logger.error(f"Unhandled exception: {exc}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={
                "error": "internal_server_error",
                "message": str(exc),
                "timestamp": datetime.utcnow().isoformat()
            }
        )
    
    return app


# =============================================================================
# APP INSTANCE
# =============================================================================

app = create_app()


# =============================================================================
# MAIN ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "backend.api.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
